@echo off
title BW - criar icone
call "%~dp0CRIAR-ATALHO.bat" %*
