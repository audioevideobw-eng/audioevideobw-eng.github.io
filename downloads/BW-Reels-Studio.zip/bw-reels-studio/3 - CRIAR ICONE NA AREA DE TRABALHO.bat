@echo off
title BW Reels - criar icone
call "%~dp0CRIAR-ATALHO.bat" %*
