@echo off
title BW Reels - Instalar legenda automatica
cd /d "%~dp0"
set "PATH=%PATH%;C:\Program Files\nodejs;%LOCALAPPDATA%\Microsoft\WinGet\Links;%APPDATA%\npm"
node motor\instalar-legendas.mjs
echo.
pause
