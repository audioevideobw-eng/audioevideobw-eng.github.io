@echo off
title BW
call "%~dp0BW-REELS.bat" %*
