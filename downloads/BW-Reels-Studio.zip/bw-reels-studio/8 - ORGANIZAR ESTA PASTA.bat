@echo off
title BW Reels - organizar a pasta
cd /d "%~dp0"
echo.
echo  Escondendo os arquivos tecnicos (nada e apagado nem movido; tudo continua funcionando)...
for %%F in (BW-REELS.bat BW-REELS-ASSISTENTE.bat BW-REELS-RENDER.bat INSTALAR.bat CRIAR-ATALHO.bat GERAR-INSTALADOR.bat INSTALAR-LEGENDAS.bat INSTALAR-CLAUDE-CODE.bat ATUALIZAR.bat LEGENDAR.bat abrir-studio.ps1 instalador.iss site-offline.zip bw-reels.ico CLAUDE.md README.md TUTORIAL.md package.json package-lock.json .gitignore .mcp.json) do if exist "%%F" attrib +h "%%F"
for %%D in (node_modules schema motor assistente app assets conhecimento modelos atualizacao site-offline .claude instalador) do if exist "%%D" attrib +h "%%D"
attrib -h LEGENDAR.bat >nul 2>nul
echo.
echo  Pronto. Ficaram a vista so os arquivos numerados, o LEGENDAR, o LEIA-ME, o TUTORIAL e a pasta projetos.
echo  Para ver tudo de novo: "9 - MOSTRAR TUDO DE NOVO.bat".
echo.
pause
