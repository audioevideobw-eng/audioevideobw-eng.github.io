@echo off
title BW antigo
call "%~dp0BW-REELS.bat" --classico
