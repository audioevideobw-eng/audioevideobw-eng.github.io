# Animação por código — como usar

Com esta skill a sua IA cria **animações escrevendo código**: personagens 2D, mascote, logo se montando, vinhetas e textos animados. Não é IA de vídeo: cada quadro é desenhado por um programa e o **motor do app BW** transforma em MP4 aqui no seu computador. Resultado: animação nítida, com a sua marca e sem gastar créditos de IA de vídeo.

## 1. O que pedir
Abra a sua IA (Claude, Codex ou Gemini) e descreva o que quer, com o máximo de detalhe:

> Faça uma vinheta de 5 s: o logo da minha empresa entra letra por letra, brilha e fica parado no centro. Fundo escuro, formato 9:16.

> Quero uma mini-história com dois personagens: a cliente pergunta "e quem não puder ir ao evento?" e o cinegrafista responde "assiste ao vivo!". Termina com o nosso @.

Mande uma **referência** (link ou print) quando tiver: a animação fica muito melhor.

## 2. Como ela trabalha
1. Escreve o **storyboard** (o que aparece em cada momento) e te mostra.
2. Escreve a animação e testa sozinha se cada quadro está certo.
3. Revisa olhando uma folha com 12 quadros (braço solto, texto cortado, cor sem contraste).
4. Gera um **rascunho**, você aprova, e ela gera o vídeo final.
5. Se você quiser sobrepor no editor, ela gera com **fundo transparente** (.mov).

Os arquivos ficam na sua **pasta de animações**, uma subpasta por trabalho.

## 3. Onde usar
- Como cena no **BW Reels** (app BW → CRIAR REEL).
- No **Editor de vídeo** do app, por cima de filmagens.
- Em qualquer programa de edição (Premiere, CapCut…).

## 4. Regras
- Só personagens **originais** ou do cliente. Nada de personagem famoso ou mascote de outra marca.
- Personagem realista (pessoa de verdade falando) fica melhor em IA de vídeo: a skill te avisa quando for o caso.

## 5. Precisa de
- O **app BW** instalado (o motor vem com ele).
- Uma IA que **rode comandos** no computador (Claude Code, Codex, Gemini CLI). Se a sua só conversa, ela te entrega o arquivo e o comando para colar no Terminal.

Para mudar a pasta ou as cores da marca: app BW → **BW SKILL** → esta skill → **INSTALAR DE NOVO**.
