# Editor de vídeo profissional — como usar

Esta skill transforma a sua IA num editor de vídeo de produtora: ela organiza o material, decupa, monta os depoimentos, corrige a cor, corta na batida da música, faz as legendas e entrega o vídeo pronto nas versões certas.

## 1. Antes do primeiro projeto
- Deixe o material do evento num lugar só (um cartão ou uma pasta por câmera).
- Separe um vídeo de **referência** (um after que você goste). A skill estuda o ritmo, a cor e o som dele.
- Tenha o **logo do cliente** em PNG (fundo transparente) e, se houver, o guia de marca.

## 2. Começando um projeto
Abra a sua IA (Claude, Codex ou Gemini) e escreva algo assim:

> Novo projeto: AFTER EVENTO X. Os takes estão em D:\EVENTO X (pastas CANON e SONY). A referência é D:\REF\after-ref.mp4. Quero o after em 9:16, versões curta e longa.

A skill cria a pasta do projeto dentro da sua **pasta de projetos**, já com as subpastas CACHE, MÍDIA, TAKES DE VÍDEO, PROXY, RENDER e _CLAUDE, e segue sozinha:

1. Organiza a mídia e cria o projeto no programa de edição.
2. **Decupa**: uma sequência por câmera, com um trecho de cada take, para enxergar tudo rápido.
3. Corrige o **LOG** de cada câmera por camada de ajuste (nunca no arquivo).
4. Monta os **depoimentos**, um por pessoa, sem a parte de preparação.
5. Estuda a referência, escolhe trilha e efeitos e monta o after cortando na batida.
6. Renderiza na maior qualidade e te mostra.

## 3. Ajustes
Peça em linguagem normal: "tira o plano do coffee", "música mais baixa no depoimento", "deixa a cor mais quente". Cada ajuste vira uma versão nova (v2, v3), sem apagar a anterior.

## 4. Finalizar
Quando o vídeo estiver aprovado, escreva **"ok, finalizar"** e o caminho do arquivo final. A skill:
- legenda as falas nos seus idiomas;
- coloca **nome e cargo** animados (no padrão da sua marca, se o cliente não tiver um);
- renderiza o master em alta qualidade e a versão para Instagram, separando tudo em pastas por qualidade e idioma dentro de RENDER.

## 5. Dicas
- Grave os planos do espaço **vazio antes da montagem** e os mesmos planos depois: viram motions de "o evento se montando sozinho".
- Use só trilhas **licenciadas** em vídeo de cliente.
- Deixe o PC ligado e sem bloqueio de tela durante renders longos.

## 6. O que ela não faz
- Não inventa imagens do evento (pessoas, cenas). Para motions com IA ela prepara o pacote (frame inicial, prompt) e você gera na sua IA de vídeo.
- Precisa de uma IA que **mexa no computador** para clicar no programa de edição. Sem isso, ela te diz exatamente o que clicar e faz por arquivo (XML, LUT, legendas) o que der.

Para mudar as pastas, a marca ou a IA, abra o app BW → **BW SKILL** → esta skill → **INSTALAR DE NOVO**.
