# Tutorial — app BW (a plataforma Brightway no PC)

Versão 1.9.50 · 25/11/2026. O **app BW** é a plataforma Brightway instalada no computador, com as ferramentas de vídeo que usam a força do PC.

## Instalar e atualizar

1. Baixe o **BW-Setup.exe** em `audioevideobw-eng.github.io/baixar` (botão **BAIXAR O APP BW**) e dê dois cliques. Sem assinatura digital
   paga, o Windows mostra um aviso azul: clique em **Mais informações → Executar assim mesmo**.
2. Avance até o fim. Na primeira abertura o app prepara o que falta sozinho (uns minutos, com internet).
3. Abra pelo ícone **BW** (Área de Trabalho ou menu Iniciar). Na primeira vez ele baixa o programa (cerca de 110 MB, numa janela que mostra o andamento) e já abre.

**Atualizações:** o app procura versão nova ao abrir e quando a internet volta. Aparece o aviso com a lista do que vem; toque em
**ATUALIZAR AGORA** (ou **DEPOIS**). Seus projetos, vídeos, chaves e configurações continuam no lugar. Depois de atualizar, a tela
**O que mudou** mostra as novidades uma vez.

## Novidades da versão 1.9.50
- **Tutoriais com as telas de verdade.** Cada passo mostra a página real da Brightway num celular (iPhone ou Android): o dedo toca no botão certo, a tela rola e o teclado digita. Telas de outros sites aparecem desenhadas, com o selo TELA ILUSTRATIVA.
- **Narração e fundo musical.** Com 🔊 ligado, o assistente explica cada passo ("Olá, sou o seu assistente virtual e vou te ensinar a…") com uma música baixinha.
- **O robô agora é o seu Assistente.** Em Configurações → MEU ASSISTENTE: nome próprio, visual (ROBÔ BW, ROBÔ REDONDO, ELA, ELE), oito cores e voz masculina ou feminina.

## Novidades da versão 1.9.49

- **TUTORIAIS**: cartão novo e item no menu. Passo a passo de cada ferramenta com **demonstração animada** (o cursor vai até o botão certo), organizado por assunto: Começar, Conectar minhas IAs, Editor de vídeo, Fotos e artes e Gestão.
- **Minhas IAs (opcional)**: as IAs de imagem (15 por dia) e de decupagem (200 por dia) continuam funcionando com a conta da plataforma. Quem precisar de mais conecta a **própria conta grátis** (Cloudflare e Google) em Configurações → MINHAS IAS ou no tutorial: abrir o site, copiar, **📋 COLAR**, e ele conecta sozinho. Depois é só escolher **USAR MINHA CONTA** ou **USAR A DA PLATAFORMA**.
- A chave fica só neste computador: não vai para a sua conta Brightway nem fica guardada em servidor.

## Novidades da versão 1.9.48

- **Decupagem com IA no editor de vídeo**: embaixo da mídia, toque em **🎬 DECUPAR COM IA**. A IA do Google (Gemini) assiste a cada take e marca os trechos bons — falas (com a frase dita), plateia, palco, detalhes e movimentos — e os ruins (tremido, fora de foco), com nota de ★1 a ★5.
- **＋** põe um trecho na agulha já aparado; **MONTAR COM OS MELHORES** põe os trechos em fila; **COPIAR A LISTA** leva a decupagem em texto.
- Vai só uma cópia leve (360p) de cada take, depois do seu "sim", e ela não fica guardada. Precisa de internet e de login.

## Novidades da versão 1.9.47

- **Conferência do vídeo pronto**: todo vídeo que o app gera (Estúdio de motion, animações, reels) é conferido sozinho no fim. O app procura **texto cortado** ou saindo da tela, **letra pequena** demais para o celular, texto **sem contraste**, texto na **área dos botões** do Reels/TikTok, **imagem parada**, **tela preta** e **som** mudo, baixo ou estourando. ✗ é erro para corrigir; ⚠ é para olhar.
- O aviso de "Vídeo pronto" diz quantos problemas a conferência achou e qual é o primeiro.
- Também dá para conferir qualquer vídeo: `node motor/conferir.mjs arquivo.mp4`.
- Skill **ANIMAÇÃO POR CÓDIGO 1.3**: ensina a IA a usar a conferência antes de entregar.

## Novidades da versão 1.9.46

- **Mais segurança nas páginas**: a plataforma não abre mais escondida dentro de outro site (um site falso não consegue fazer você clicar sem ver).
- **Links que saem do site** levam só o nome da plataforma, nunca o endereço completo com códigos de galeria ou de cadastro.
- **Cópia sem internet** atualizada com o site de hoje.

## Novidades da versão 1.9.45

- **Prévias vivas no editor de vídeo**: cada cartão da biblioteca mostra o efeito rodando — nas transições e nas TELAS, **A** (palco) é o take que sai e **B** (apresentador no fundo verde) o que entra; nos efeitos, ANTES | DEPOIS. Movimento do texto, PESSOA E FUNDO (IA) e modelos de efeito também viraram cartões animados.
- **⟲ Remover atributos** no botão direito do take: volta ao original e mantém arquivo, cortes e lugar na linha do tempo (Ctrl+Z desfaz).
- **Transição aplicada**: tocar nela abre ver, tempo, mais rápida/lenta, trocar, usar em todas e EXCLUIR.
- **Arrastar não seleciona texto**: em todas as ferramentas, arrastar algo para aplicar não marca mais os textos da página.

## Novidades da versão 1.9.44

- **Editor de vídeo integrado**: abas ▦ TELAS (transições e divisões de tela) e ◆ MOTIONS (textos animados e gráficos do BW Reels Pro), e em ELEMENTOS os overlays, desenhos, objetos realistas e emojis do Criador IA. Tudo desenhado direto no vídeo — leve na prévia e rápido para exportar.
- **Editor de fotos**: painel de CAMADAS com pastas (como num programa profissional), aba EFEITOS com 37 efeitos e combinações automáticas, ★ MEUS PRESETS, ⟲ remover atributos e medida livre em px/cm.
- **Álbum 3D**: quantidade de fotos por modelo, cartão livre e tamanho do modelo (proporcional ou esticando X, Y e Z).

## Novidades da versão 1.9.43

- **O BW no computador agora é só o programa BW**: nome e ícone **BW** na barra de tarefas e no Gerenciador de Tarefas, e a placa de vídeo
  forte pedida pelo próprio programa. O ícone **BW** de sempre já abre ele.
- **Saiu a janela do Edge** e os atalhos da fase de teste ("BW (novo)", "6 - ABRIR BW NOVO", "7 - ABRIR BW ANTIGO"): somem sozinhos.
- **Primeira vez no programa**: entre de novo com a sua conta (o programa tem a própria memória). Os dados da conta voltam sozinhos;
  o que fica só no aparelho (projetos abertos no editor de vídeo, criações, fotos recentes) começa vazio.

## Novidades da versão 1.9.39

- **Placa de vídeo em 1 toque**: no editor de vídeo (⚙ projeto → PLACA DE VÍDEO), quando o PC tem placa dedicada (NVIDIA/AMD) e o navegador está na integrada, o botão **⚡ USAR A NVIDIA** pede ao Windows a placa forte para o Edge e o Chrome. Depois feche o app BW e abra de novo. É a mesma opção de Configurações → Sistema → Tela → Elementos gráficos (dá para desfazer por lá).
- **A janela do app já nasce na placa forte**: o app abre o navegador pedindo a placa de alto desempenho e a leitura de vídeo pela placa.
- **Editor de vídeo**: Controle de efeitos, Cor avançada com nós e LUTs, parado em qualidade total, trecho marcado (⟦ ENTRADA / SAÍDA ⟧) na exportação e os atalhos de editor de mesa.

## Novidades da versão 1.9.37

- **Segurança e seus dados**: um escudo verde ao lado do selo LOGADO (no topo e no menu) abre a página que explica onde ficam os seus dados, quem consegue ver, o que pode ser compartilhado (links de orçamento, cadastro, presença e galeria), o que vai para a IA e os testes de segurança.

## Novidades da versão 1.9.36

- **Mais segurança**: a ferramenta de PDF, a assinatura com certificado digital e a leitura de planilhas usam versões novas, sem falhas conhecidas. As páginas só carregam código de endereços conhecidos e conferem cada biblioteca antes de usar.
- **Política de uso**: as regras de uso e as proteções da plataforma ficam no menu (☰ → POLÍTICA DE USO).
- **Sem internet**: a leitura de planilhas também funciona sem internet no app (a biblioteca nova fica guardada no PC).

## Novidades da versão 1.9.34

- **Proxy com som**: o som dos takes de câmera (Sony, Canon e outras, inclusive arquivos de 1–2,5 GB) agora vai para o proxy. Se algum ficar sem som, o aviso diz o motivo.
- **Editor de fotos**: ＋ IMAGEM na aba CAMADAS volta a funcionar no iPhone.

## Novidades da versão 1.9.33

- **Proxy e exportação profissional no editor de vídeo**: ⚡ FAZER PROXY cria cópias leves (720p) para editar 4K sem travar; 🧹 LIMPAR CACHE e o
  ⚙ das pastas (projeto, cache e exportações). EXPORTAR abre a janela com YouTube 4K/Full HD, Instagram, WhatsApp, telão, só o áudio (WAV 24 bits),
  sequência JPG/PNG e personalizado. O vídeo final sai sempre do arquivo original.
- **A tela é o assunto**: em todas as ferramentas o painel escondido vira uma borda fina (toque para trazer de volta) e ⛶ SÓ A TELA (Tab) esconde tudo.
- **Criador IA**: seções com seta, FECHAR/ABRIR TUDO, arte grande ao lado dos ajustes, segurar 0,5 s num objeto abre as opções; botões novos com relevo.
- **Editor de fotos**: entrada nova com BIBLIOTECA (fotos recentes deste aparelho, criações e minha marca).

## Novidades da versão 1.9.32

- **Editor de vídeo mais leve**: enquanto você edita, a prévia é desenhada em no máximo 1280 px (a "prévia leve" dos editores profissionais).
  O vídeo exportado e o "salvar quadro" saem no tamanho real. Quem preferir pode marcar "Prévia em tamanho cheio" no painel do projeto.
- **Aviso de importação**: agora flutua por cima e some sozinho, sem tampar a linha do tempo.

## Novidades da versão 1.9.31

- **Editor de vídeo lê muitos takes de uma vez sem travar**: antes, a partir do ~20º arquivo tudo aparecia como "não abre aqui" (o editor
  deixava um player aberto para cada arquivo). Agora lê um por vez, solta o player, tenta de novo com mais prazo nos arquivos 4K pesados e
  só diz HEVC quando o arquivo é HEVC. Arquivo que não abriu tem o botão ↻ para tentar de novo.
- **Linha do tempo mais leve**: só os clipes perto da agulha ficam carregados.
- **Convite em vídeo**: botão 🎬 BAIXAR VÍDEO ANIMADO (MP4) em Salvar e enviar, com 720p, 1080p ou 4K.
- **Álbum 3D**: tamanho personalizado, tamanho da tela do aparelho e 21:9; vídeo em 4K.

## Novidades da versão 1.9.30

- **Estúdio de motion com biblioteca maior**: 20 itens novos (nome e cargo, legenda que acende, citação, marca-texto, botão com clique,
  lista com ✓, gráficos de barras e de rosca, barra de progresso, pesquisa digitando, post de rede social, estrelas, pino de local,
  onda de áudio, brilhos, raios de luz, confete, círculo e seta à mão, cantos de mira). São 34 itens.
- **Biblioteca integrada** no motion: personagens prontos, objetos realistas e desenhos dos convites, os seus personagens, as suas
  criações e emojis. Um toque põe na tela, já animado.
- **Convites de super-herói e anime**: 12 modelos com personagens nossos (herói e heroína de máscara e capa, chibis, gatinho da sorte).

## Novidades da versão 1.9.29

- **Convites para o público adulto**, por nicho: gamer, futebol, basquete, fitness, velocidade, rock, sertanejo, samba e pagode,
  eletrônica, anos 80, vinho, luau e cinema. São 96 convites prontos, com filtros 🎮 ⚽ 🎵 🍻 📸.
- **Objetos realistas**: 37 fotos de estúdio com fundo recortado (champanhe, balões dourados, bolo, rosas, alianças, troféu, bolas,
  controle, microfone, violão, vinil, chope, vinho e outros), que se mexem com sombra e brilho.
- **Letras 3D** no nome: relevo, ouro, cromado, balão metálico e neon.

## Novidades da versão 1.9.28

- **Biblioteca de convites** (Criador IA › CONVITE): 48 convites prontos em filtros (aniversário, infantil, 15 anos, casamento, bebê,
  formatura e empresa, datas e festas), 24 tipos de convite e 12 estilos novos (luxo art déco, mármore, aquarela, vintage, lousa,
  espacial, fundo do mar, junina, Halloween, bebê, circo e safári).
- **Convite animado**: 27 bichinhos e objetos que se mexem (ursinho piscando, borboleta, coelhinho, dinossauro, bolo com velas…),
  14 efeitos de tela (confete, luzes, borboletas, fogos, neve…), texto entrando com animação e **🎬 GERAR VÍDEO MP4** no próprio aparelho.

## Novidades da versão 1.9.27

- **Reels que ensinam** (BW Reels Pro › 🎬 MODELOS): 7 modelos novos no estilo dos reels explicativos — terminal digitando o comando,
  passo numerado com ícone que brilha (cada passo com a sua cor), painel de números com gráfico, medidor, catálogo numerado e o
  **Comenta PALAVRA** no fim. Dois estilos novos: TECH (escuro com grade) e IMPACTO (preto e rosa).
- **Fotolivros** (Álbum 3D e efeitos): livro de fotos na mesa com várias fotos por página e as páginas virando — aberto, com capa,
  visto de cima e em close.

## Novidades da versão 1.9.26

- **Arrastar sem surpresa** no editor de vídeo e no Estúdio de motion: encostar um take no outro só encosta. Cobrindo 60% ou mais, ao soltar
  aparece a pergunta (trocar de lugar, substituir, pôr por cima ou cancelar) e nada muda até você tocar.
- **Transição na agulha:** ponha a agulha na emenda entre dois takes (o ◆ acende) e toque na transição — ela entra ali.

## Novidades da versão 1.9.25

- **Álbum 3D e efeitos** (cartão novo e botão no Estúdio 3D): 45 modelos prontos — anel girando, carrossel, cascata, livro de fotos com páginas
  virando, polaroids, varal, coração de fotos, rolo de filme e efeitos 3D de tela cheia (cubo, persiana, explosão em peças…). Escolha o modelo,
  ponha as suas fotos e vídeos no lugar dos números e gere o vídeo — sem internet.

## Novidades da versão 1.9.24

- **Ferramentas que não "descolam":** no celular, a faixa de ferramentas e a linha do tempo do editor de vídeo e do Motion param firmes nas pontas,
  e há setinhas **‹ ›** discretas para andar pela faixa (segurar anda direto).
- **Segurar e arrastar:** segurar o dedo num take ou numa barra pega e já arrasta. As opções ficam no **⋯ Mais** (no PC, botão direito).
- **Abre direto no layout novo** (sem piscar a tela antiga) e o menu da caixa do assistente fica na frente de tudo.

## Novidades da versão 1.9.23

- **Estúdio de motion com cara de app** no celular e no tablet: prévia grande, ▶ no meio, agulha parada no meio da linha do tempo, faixa de
  ferramentas que muda quando você toca num item e folhas que sobem de baixo (no computador continuam os painéis).
- **Telas em movimento e Estúdio 3D com os ⋯ da prévia:** segundo monitor, tela cheia, salvar o quadro em PNG e controle pelo celular; nas Telas a
  rodinha aproxima só a vista; no 3D os ⋯ trazem ângulos da câmera, girar, PNG e gerar vídeo.
- **Desfazer com um toque** no Motion e nas Telas (antes, às vezes, precisava de dois).

## Novidades da versão 1.9.22

- **Editor de vídeo — adicionar mídia:** arquivo que não abre neste computador (vídeo HEVC, foto HEIC) aparece com **⚠ NÃO ABRE AQUI** e o aviso
  diz o que fazer; trazer vários arquivos mostra o progresso; cada botão (cortar, aparar, duplicar, apagar) é um passo próprio do **↶ desfazer**.
- **Opções da prévia nos ⋯** discretos no alto da prévia (editor de vídeo e Estúdio de motion) — clicar na prévia não abre mais o menu.
- **Tela parada:** ao rolar as ferramentas para o lado, só elas rolam; a tela não anda junto.

## Novidades da versão 1.9.21

- **Estúdio de motion com as ferramentas do editor de vídeo:** galeria **EFEITOS** (arraste até a barra do item: esquerda = entrada,
  direita = saída), barra em cima de outra camada = **⇄ TROCAR DE LUGAR** ou **⬆ PARA CIMA**, **Alt + rodinha** = camadas mais altas,
  **rodinha na prévia** = zoom da vista (clique = opções), **COR** por item (looks e ajuste fino, igual no vídeo final), **Q/W**, **Shift+E**,
  **Ctrl+Shift+C/V** (copiar e colar ajustes), **🖥** prévia no segundo monitor e **📱** controle pelo celular.

## Novidades da versão 1.9.20

- **Caixa do assistente na página do robô:** escreva o pedido e toque em ➤ (ou Enter). **＋** leva conta, foto ou print para a ferramenta
  certa; **⚡** traz atalhos (gerar arte, reel, orçamento; lançar gasto, recebimento, conta, lembrete; "como está meu dia"); **🎙** fala.
- **Escolha da IA (BW Smart):** o chip da caixa escolhe sozinho entre **Rápido** (papo e lançamentos) e **Inteligente** (textos, orçamentos,
  análises) — ou fixe um dos dois. Se a IA principal estiver ocupada, a reserva responde sozinha, e a linha embaixo diz quem respondeu.
- **✨ Varinha:** deixa o pedido mais claro (objetivo, ação e dados) sem inventar nada; ↺ volta ao seu texto.
- **Editor de vídeo:** arrastando um take em cima de outro aparece o aviso — **⇄ TROCAR DE LUGAR** (solte ali) ou **⬆ PARA CIMA**
  (suba o take: a camada nova nasce na hora).
- **Abertura:** a opção VÍDEO saiu; ficam **FOTO + MUNDO** (padrão) e **MUNDO**.

## Novidades da versão 1.9.17

- **Aberturas para escolher** (chave ABERTURA no alto da tela inicial; fica guardada neste PC; a opção VÍDEO saiu na 1.9.20):
  **FOTO + MUNDO** (padrão desde a 1.9.19, com a imagem nova em alta) — a cena parada com a animação no mundo: anéis, nós ligados e
  sinais correndo, e a faísca entre os dedos. **MUNDO** (1.9.18) — o mundo desenhado em branco e cinza, com os sinais das conexões
  passando em amarelo e azul.

## Novidades da versão 1.9.16

- **Abertura nova, com cara de software:** o BW abre em **tela cheia** com o mundo em rede animado (feixes de luz se encontram, nasce o
  globo com sinais correndo entre os nós) e o letreiro **BRIGHTWAY · SEU SOFTWARE INTELIGENTE**. Mexa o mouse: o mundo inclina e acende;
  clique para repetir o toque de luz. **ENTRAR**, no centro, leva para a página do robô da plataforma, ocupando a tela inteira.
- **Abertura:** escolha no alto da tela de entrada entre FOTO + MUNDO (padrão) e MUNDO (branco e cinza, sinais em amarelo e azul). A escolha fica neste PC.
- **Ferramentas deste PC:** pelo link embaixo do ENTRAR ou pelo botão **⌂ BW** (Meus vídeos, legendas, BW SKILL, gerador 3D, atualizações).
  O menu fica escondido: o **☰** (ou Ctrl+M) abre por cima; **Ctrl+K** busca uma ferramenta; **⛶** põe em tela cheia; embaixo, a barra de status mostra a placa de vídeo.
- **Dentro da plataforma:** o menu lateral fica sempre escondido (o ☰ abre por cima) e somem as opções que só servem na web (APP DOWNLOAD, instalar no celular).
- **PRETO E BRANCO** passa a ser o modo padrão da plataforma, até você escolher outro em Configurações.

## Novidades da versão 1.9.14

- **EDITOR DE VÍDEO com cara de app no celular e no tablet:** prévia grande, linha do tempo fina com a agulha parada no meio (o dedo
  arrasta o tempo; pinça aproxima), miniaturas dos takes e uma faixa de ferramentas que rola para o lado e muda conforme o que você toca
  (vídeo, texto ou som). Cada ferramenta abre uma folha que sobe de baixo só com aquele ajuste; segurar o dedo no take abre as opções.
  No computador continua o layout com os painéis. (1.9.15: no celular fica só esse layout.)

## Novidades da versão 1.9.13

- **EDITOR DE VÍDEO — pessoa, modelos e duas telas:**
  - **🧠 Pessoa e fundo:** ANALISAR acha a pessoa em cada quadro; textos e camadas passam POR TRÁS dela, texto em ANEL gira em volta,
    fundo desfocado/preto e branco/escuro/cor/sem fundo e contorno de luz. Tudo no próprio computador.
  - **🎬 Modelos prontos:** 12 edições (aftermovie 30/60 s, corporativo, reels, casamento, show, contagem, antes e depois, depoimento,
    top 3, telão, nome atrás da pessoa). Troque os espaços TAKE N pelos seus takes ou use PREENCHER SOZINHO; salve as suas como modelo.
  - **Arrastar:** take solto em cima de outro cria uma camada nova; transições e efeitos vão por arrasto até o take ou a emenda ◆;
    o tempo da transição muda arrastando o ◆. Alt + rodinha muda a altura da camada.
  - **Prévia:** rodinha aproxima e afasta; clique abre as opções (zoom, desafixar, 2º monitor, tela cheia, salvar quadro).
  - **🖥 / 📱:** a prévia abre direto no segundo monitor e o celular vira controle remoto pelo QR.

## Novidades da versão 1.9.12

- **EDITOR DE VÍDEO no padrão de um editor profissional** (Marketing → Editor de vídeo):
  - **Tela limpa:** nas ferramentas de edição e criação somem o menu e o topo; fica só a setinha ‹ de voltar.
  - **Painéis livres:** cada painel tem ✕ (esconde e o espaço vai para a prévia), ⇱ (descola: vira janela solta que você arrasta e
    estica) e a beirada da prévia estica a largura. Vale no vídeo, no motion, nas Telas, no Estúdio 3D e no Editor de fotos.
  - **🖥 Prévia em outra tela:** abre a prévia numa janela para o segundo monitor, em tela cheia.
  - **Chroma key** com AUTOMÁTICO em 5 níveis (cada nível tira mais fundo, suaviza a borda e guarda mais sombra) e MANUAL.
  - **Cor por take:** exposição, contraste, realces, sombras, brancos, pretos, brilho, temperatura, matiz, saturação, vibração,
    nitidez, desbotar e vinheta; 8 pontos de partida, predefinições suas e APLICAR EM TODOS.
  - **Som do take:** volume em dB, NORMALIZAR, REDUZIR RUÍDO, REALÇAR VOZ, EXTRAIR ÁUDIO e forma de onda.
  - **Botão direito no take:** copiar e colar os ajustes em outro take, cortar até a agulha (Q/W), desativar (Shift+E), cor e som.

## Novidades da versão 1.9.3

- **ESTÚDIO 3D** (Marketing → Estúdio 3D). Quatro modos, você escolhe:
  - **MODELO 3D** — abre GLB, OBJ e STL, gira, ilumina e gera o vídeo do giro no próprio aparelho.
  - **LOGO 3D** — a sua logo em PNG vira relevo dourado, prata ou cromado, com fundo transparente ou verde para recorte.
  - **MAQUETE DE PALCO E LED** — painéis de 0,5 m com medida real, treliça, pessoas de escala e, o mais útil:
    a **resolução em pixels do telão** (ex.: 10 × 5 painéis P3.9 = 1280 × 640 px), com um botão que já abre o
    Estúdio de motion ou as Telas nesse tamanho. Sai também a **planta em PDF** para mandar ao cliente.
  - **IA 3D (foto → objeto)** — monta o pedido em inglês para Tripo, Meshy, Rodin ou Hunyuan; você gera lá e traz o
    arquivo para cá. O app não chama nenhuma IA de 3D e não envia nada.
  Tudo roda no aparelho, sem biblioteca de fora: funciona **sem internet**.

## Novidades da versão 1.9

- **MINHA EMPRESA e MINHA CASA.** Dois ecossistemas separados: pessoa jurídica (azul) e pessoa física (verde). Cada um tem os seus
  números do mês, a sua agenda e as suas ferramentas. Os dados não se misturam.
- **LANÇAMENTOS PJ e PF** e **PAINEL PJ e PF.** Duas abas em cada página, uma para a empresa e outra para a casa.
- **Página principal nova.** O robô no centro e quatro telas (MEU NEGÓCIO, GESTÃO DE CASA, MARKETING, FERRAMENTAS). O assistente
  ganhou o visual do robô.
- **MODOS DE APARÊNCIA.** Na engrenagem: 28 modos (claros, vidro com luz em nove cores, JOGOS — NEON 80, TÁTICO, ARCADE 8-BIT, CORRIDA, FANTASIA, ESPACIAL, com cenário, letra e robô do tema —, FUTURISTA, NATAL, ANO NOVO…) e o modo com
  as cores da **sua marca**. A escolha vale para este computador; no celular você pode usar outro.
- **Painéis** financeiro e de investimentos acompanham o modo escolhido.

## Comece por aqui: o app BW

Abre uma janela própria, como um programa:

1. **Entrar** — clique em **ENTRAR COM A CONTA BRIGHTWAY** e faça o login na página da plataforma (a mesma conta do site e do celular).
   A senha é digitada na página da Brightway; o aplicativo não vê nem guarda a senha. Depois de entrar, as ferramentas deste PC
   funcionam por até 7 dias sem internet; passado esse prazo, ele pede para entrar de novo.
2. **Escolher a ferramenta.** Vídeo: **CRIAR REEL**, **QUADRO DE HISTÓRIA**, **PERSONAGENS**, **PROMPT IA**, **EDITOR DE VÍDEO**,
   **ESTÚDIO DE MOTION**, **TELAS EM MOVIMENTO**, **ASSISTENTE PASSO A PASSO**, **LEGENDAS AUTOMÁTICAS**, **IA DE VÍDEO** e **MINHAS IAS**.
   Estúdio e escritório: **BW SKILL**, **MINHA EMPRESA**, **MINHA CASA**, **LANÇAMENTOS PJ E PF**, **APARÊNCIA E MODOS**, **EDITOR DE FOTOS**,
   **PDF**, **CRIADOR DE ARTES**, **ORÇAMENTOS**, **LEITOR DE CONTAS** e **TODA A PLATAFORMA**.
3. **Renderizar** — dentro do aplicativo, o botão **RENDERIZAR NO PC** do editor já gera o vídeo sozinho, com barra de progresso.
   O vídeo pronto aparece em **MEUS VÍDEOS**, na tela inicial.
4. **Voltar** — o botão amarelo **⌂ BW** volta para a tela inicial de qualquer ferramenta. **SAIR** tira a conta deste PC.

### Usar sem internet (em casa, no notebook)

Na tela inicial, com a internet ligada, clique uma vez em **PREPARAR PARA USAR SEM INTERNET**. O aplicativo guarda neste computador
uma cópia das ferramentas e das bibliotecas delas. Depois disso, as ferramentas com a etiqueta **SEM INTERNET** abrem mesmo desconectado,
e o que você fizer sobe para a conta quando a conexão voltar. Precisam de internet: tudo o que usa IA na nuvem (criar imagem, roteiro
por IA, gerar clipe) e o login depois de 7 dias. Os modelos grandes de IA do editor de fotos (tirar fundo, retoque) ficam guardados
depois da primeira vez que você usa cada um com internet.

### IA de vídeo: conecte a sua

Em **IA DE VÍDEO** você conecta a IA que você assina — hoje **Runway** (Gen-4 Turbo e Gen-4.5) e **fal.ai** (Kling 3.0). Cole a chave
da sua conta; ela fica só neste computador e a cobrança é feita pela IA, na sua conta. Depois, nas cenas de IA (aba **MÍDIA** do
editor, vindas do Quadro de História), aparece **✨ GERAR O CLIPE AQUI**: o aplicativo mostra o custo de referência, pede confirmação,
gera o clipe de 5 s e já coloca na cena. Os preços mudam: confira no site da IA.

### Gerar o instalador (.exe)

Dois cliques em **GERAR-INSTALADOR.bat**: ele instala o Inno Setup (gratuito) se faltar e cria `instalador\BW-Setup.exe`,
que você pode mandar para outras pessoas. Sem assinatura digital paga, o Windows mostra o aviso azul na instalação.

O que você cria no celular com a mesma conta aparece aqui (e o que mandar com **ENVIAR PARA O PC** chega no editor).

## Assistente passo a passo

No aplicativo, clique em **ASSISTENTE PASSO A PASSO** (ou use o atalho **BW Reels Assistente**).
Abre uma janela que conduz etapa por etapa, com **Voltar** e **Avançar**, como um instalador:

1. **Preparar** — confere se o computador está pronto e diz como resolver o que faltar.
2. **Como criar** — quatro jeitos, com o recomendado já marcado conforme as IAs conectadas:
   - **BW IA FREE**: só IAs com cota grátis; acabou a cota de uma no dia, passa para a próxima sozinho.
   - **BW IA ECONOMIZE**: aberturas na IA grátis e roteiro final na IA paga (gasta o mínimo do plano).
   - **BW IA PRO**: tudo na IA paga que você escolheu (melhor qualidade).
   - **SEM IA**: modelo pronto, você troca os textos.
   Em **⚙ Minhas IAs** você conecta cada IA (cola a chave, que fica só no seu computador) ou usa o botão
   **INSTALAR IAS RECOMENDADAS**, que baixa de fontes oficiais o Claude Code e a IA que roda no próprio computador (Ollama + Gemma 3).
3. **Sobre o vídeo** — o assunto (ou o modelo), seu @ e o visual.
4. **Textos e prévia** — mude o que quiser; a prévia animada atualiza sozinha. Número sem fonte não passa.
5. **Conferir** — resumo do vídeo e de quantos pedidos de IA foram usados. Só gera depois de **Aceitar e gerar**.
6. **Gerar vídeo** — barra de progresso e, no fim, o botão para abrir a pasta. Nada é publicado sozinho.

Se a IA falhar (sem login ou limite do plano), o assistente avisa e oferece continuar sem IA.

## 1. Instalação (uma vez, cerca de 10 minutos)

**O que você precisa:** um PC com Windows 10 ou 11 e internet. Para o modo Claude Code (opcional), uma conta do Claude com acesso ao Claude Code (planos Pro, Max, Team ou Enterprise).

1. **Descompacte** o arquivo `.zip` numa pasta fixa, por exemplo `Vídeos` ou `Documentos`. Não rode de dentro do zip.
2. Abra a pasta `bw-reels-studio` e dê **dois cliques em `INSTALAR.bat`**. Se o Windows mostrar "O Windows protegeu o computador", clique em **Mais informações → Executar assim mesmo**.
3. O instalador faz tudo sozinho:
    - instala o Node.js, o FFmpeg e o Claude Code (se ainda não existirem);
    - instala as dependências do projeto e o navegador usado no render;
    - cria os ícones **BW Reels Render** e **BW Reels Studio** na Área de Trabalho;
    - renderiza um vídeo de teste.
4. No fim, a pasta com o vídeo de teste se abre. Se ele tocar, está tudo certo.

Se o instalador pedir para "rodar de novo" (acontece quando o Windows acabou de instalar o Node.js ou o FFmpeg), feche a janela e dê dois cliques no `INSTALAR.bat` outra vez. Ele só completa o que faltou.

## 2. Usar pela plataforma (BW Reels Pro)

1. Dê dois cliques no ícone **BW Reels Render** e **deixe a janela aberta** — é ela que liga a plataforma ao motor.
2. Na Brightway, abra **Marketing › BW REELS PRO**.
3. **CRIAR:** escreva o assunto, o nicho e a chamada final e toque em **✨ CRIAR GANCHOS E ROTEIRO**. Escolha o gancho, confira as **fontes** (o que não tiver fonte sai do vídeo) e o **estilo**.
4. **MÍDIA:** importe suas filmagens, fotos, motions de IA e música licenciada. Use **NA CENA** ou **+ CENA**.
5. **CENA:** toque numa cena da linha do tempo para editar texto, duração, mídia, movimento e transição. A prévia ao lado atualiza na hora.
6. **EXPORTAR:** toque em **RENDERIZAR NO PC**. O pedido vai para Downloads, a janela do BW Reels Render mostra o andamento e o vídeo abre sozinho quando fica pronto. Uma cópia fica em `Downloads\BW Reels - pedidos feitos`.

Os projetos e as mídias da plataforma ficam salvos só no seu aparelho (no navegador). A legenda do post criada pela IA fica na aba EXPORTAR, com o botão COPIAR.

## 3. Abrir o estúdio pelo Claude Code (opcional)

Dê dois cliques no ícone **BW Reels Studio** da Área de Trabalho. Ele abre o terminal já na pasta do estúdio, com o Claude Code iniciado.

**Só na primeira vez:**

1. **Tema** — aperte Enter para ficar no "Auto".
2. **Login** — entre com a sua conta do Claude; o navegador abre para você autorizar.
3. **Confiar na pasta** — responda que sim. Isso libera as skills e os comandos do estúdio.

**Como usar:** digite normalmente, em português, e aperte Enter. Comandos começam com `/`. Para sair, digite `/exit` ou feche a janela. Quando o Claude pedir permissão para rodar um comando (render, validação), aceite.

## 4. Como funciona (modo Claude Code)

Você só aprova em dois momentos: na escolha do gancho e no rascunho.

1. **Briefing** — o Claude entende o nicho, o objetivo, o público e o CTA (faz no máximo 3 perguntas).
2. **Pesquisa validada** — toda informação entra com fonte e data. Sem fonte, fica de fora.
3. **Ganchos** — 10 opções com nota; você escolhe entre as 3 melhores. *Sua aprovação.*
4. **Roteiro** — um arquivo curto (`roteiro.json`) com as cenas.
5. **Rascunho** — render rápido em meia resolução + uma folha com 8 quadros do vídeo. *Sua aprovação.*
6. **Final** — vídeo em 1080x1920 + legenda pronta do post (`post.md`).

Cada vídeo vira uma pasta em `bw-reels-studio\projetos\<nome-do-video>\`, com pesquisa, ganchos, roteiro, mídias e os vídeos renderizados.

## 5. Seu primeiro Reel, passo a passo

1. **Peça o vídeo.** Exemplo:
    `/reels 3 erros que derrubam a live do seu evento — nicho eventos corporativos, CTA chamar no direct`
    Quanto mais você disser (nicho, cliente, público, CTA, se tem filmagem), menos o Claude pergunta.
2. **Responda as perguntas, se vierem.**
3. **Escolha o gancho.** Responda só o número ("vai no 2") ou peça ajuste ("o 2, mas mais curto").
4. **Aprove o rascunho.** Para assistir, abra `projetos\<nome>\render\` e dê dois cliques no `.mp4`. Peça mudanças em linguagem normal:
    - "troca o estilo para corporativo"
    - "a cena 3 está rápida demais"
    - "coloca minha filmagem do palco na cena 2"
5. **Peça o final.** "Aprovado, renderiza o final." O vídeo em alta e a legenda do post ficam na pasta do projeto.

**Se o vídeo citar dados**, o Claude só usa o que tiver fonte confiável. A fonte aparece na tela e na legenda do post. Se não achar fonte, ele avisa e troca a frase por experiência própria.

## 6. Todos os comandos

| Comando | Quando usar | Exemplo |
| --- | --- | --- |
| `/reels` | Vídeo novo do zero, fluxo completo | `/reels por que contratar fotógrafo para o seu evento` |
| `/ganchos` | Só quer ideias de abertura | `/ganchos aftermovie de formatura` |
| `/cortar` | Tem um vídeo longo e quer Reels dele | `/cortar C:\Users\voce\Videos\palestra.mp4 3` |
| `/render` | Renderizar de novo; `final` = alta qualidade; `comparar` = testa os motores | `/render meu-projeto final` |
| `/revisar` | Revisão crítica do último vídeo | `/revisar meu-projeto` |
| `/legendar` | Legenda automática da fala (sem internet) | `/legendar meu-projeto` |
| `/animar` | Personagem, mascote, logo animado ou motion feito por código | `/animar o Bê acenando e apresentando a BW` |

O nome do projeto é o da pasta em `projetos\`. Você também pode só conversar: "abre o projeto X e troca o CTA" funciona sem comando.

## 7. Suas filmagens, músicas e motions de IA

Coloque os arquivos na pasta `midia\` do projeto e diga ao Claude em qual cena usar. Ele corta o trecho sozinho.

| Material | Onde colocar | Como pedir |
| --- | --- | --- |
| Filmagem | `projetos\<nome>\midia\` | "usa o palco.mp4 a partir de 1min20 na cena 2" |
| Foto | `projetos\<nome>\midia\` | "coloca a foto do público no fundo do gancho" |
| Música licenciada | `assets\musicas\` | "usa a trilha energia.mp3" |
| Narração / sua voz | `projetos\<nome>\midia\` | "a narração é o voz.m4a" (a música abaixa sozinha quando você fala) |
| Motion de IA (Higgsfield, Veo, Kling) | `projetos\<nome>\midia\` | "o logo-3d.mp4 é a abertura" |
| Logo | `assets\logos\` | "assina com o meu logo no final" |

### Legenda automática (sem internet)

O estúdio ouve a sua filmagem ou narração e escreve a legenda palavra por palavra, no próprio computador. Nada é enviado para fora.

1. **Uma vez só:** dê dois cliques em `INSTALAR-LEGENDAS.bat`. Ele baixa o motor de fala e o modelo (uns 500 MB).
2. **Legendar um reel:** arraste o `roteiro.json` do projeto para cima do `LEGENDAR.bat`. Ele liga o som da filmagem, ouve só os trechos usados e grava as palavras no roteiro. Depois é só renderizar.
3. **Legendar um vídeo solto:** arraste o vídeo para cima do `LEGENDAR.bat`. Sai um arquivo `.srt` ao lado, que abre no CapCut, Premiere e YouTube.

Sempre confira nomes de pessoas e de empresas: são os que o computador mais erra. Corrija no `roteiro.json` (campo `legendas.palavras`) ou peça ao Claude: "troca Bê Dáblio por BW na legenda".

Para a filmagem tocar com o som dela sem legenda, peça: "liga o som do vídeo na cena 2".

**Prompt de motion:** peça "escreve o prompt pro Higgsfield de uma abertura com o meu logo". Gere lá e salve o clipe na pasta `midia`.

**Música:** use só trilha licenciada ou sua. Música em alta sem licença pode derrubar o áudio ou o vídeo. Os efeitos de whoosh e impacto do estúdio são gerados por ele mesmo, sem direitos autorais.

### Personagens animados pelo motor

Na plataforma, toque em **🎬 MODELOS** → **HISTÓRIAS COM PERSONAGENS**: o Bê (câmera da BW), Ana, Léo, Bia, Rui e um Robô
entram, acenam, falam em balões, pensam, se assustam e comemoram — tudo desenhado pelo motor, sem IA de vídeo e sem custo.
No Claude Code, peça "cena com a Ana perguntando e o Bê respondendo" ou use `/animar` para algo sob medida
(o modelo fica em `modelos\animacoes\personagem-bw.html`).

Para animar o **seu** personagem, use **🎬 MODELOS → ANIMAR MEU PERSONAGEM**: envie a foto do avatar ou mascote, conte a história
e escolha **recorte animado** (grátis), **uma imagem por cena com IA** ou **vídeo com IA de fora** (prompts por cena).

Para personagem **realista** (pessoa de verdade, 3D de cinema), use **🎬 MODELOS → PERSONAGEM COM IA**: a plataforma monta os
prompts de imagem e de vídeo; você gera no Flux (Creator Factory) e anima no Higgsfield, Kling ou Veo, e importa os clipes.

## 8. Estilos, formatos e motores

Tudo se troca com uma frase ("muda para luxo", "faz em 4:5").

| Estilo | Visual | Bom para |
| --- | --- | --- |
| cinema | escuro, dourado, grão de filme | eventos, bastidores, institucional |
| corporativo | azul-marinho, limpo | B2B, palestras, dados |
| neon | preto com rosa brilhante | festas, lançamentos |
| editorial | claro, serifa, revista | dicas, educação, saúde |
| luxo | escuro, champanhe, serifa fina | casamentos, imóveis, gastronomia |

Para criar um estilo com as cores da sua marca: "cria um estilo com as cores #123456 e #abcdef e a fonte X". Ele fica salvo para os próximos vídeos.

**Formatos:** 9:16 (Reels, TikTok, Shorts), 4:5 (feed), 1:1 e 16:9 (YouTube, telão).

**Tipos de cena:** gancho · texto · mídia (filmagem ou foto com movimento) · dado (número animado com fonte) · lista · citação · CTA · personagem.

**Motions e gráficos:** logo animado · nome e cargo · contagem 3-2-1 · gráfico (barras ou rosca, com fonte) · linha do tempo · checklist · top/ranking · depoimento · local e data · oferta · AO VIVO · vídeo no celular · antes e depois · tela dividida.

**Motores:** o mesmo roteiro renderiza em três.

- **nativo** (padrão) — já vem pronto pelo instalador.
- **HyperFrames** (HeyGen) — peça "renderiza no hyperframes"; na primeira vez ele instala sozinho.
- **Remotion** — peça "renderiza no remotion". Grátis para pessoas e empresas de até 3 pessoas; acima disso, a empresa precisa de licença (remotion.dev/license).

## 9. Gastar poucos tokens

- **Peça tudo na primeira mensagem** (tema, nicho, CTA, material).
- **Aprove pelo rascunho**, e só depois peça o final.
- **Peça mudanças juntas** numa mensagem só.
- **Reaproveite:** "faz outro no mesmo estilo do projeto X" usa a pesquisa e o visual já salvos.
- **Um vídeo por conversa.** Para começar outro, digite `/clear`; os projetos continuam salvos.

## 10. Se algo der errado

| Problema | O que fazer |
| --- | --- |
| Ícone abre e diz "Claude Code não encontrado" | Rode o `INSTALAR.bat` de novo |
| Erro de Node, npm ou render | Rode o `INSTALAR.bat` de novo (ele só completa o que falta) |
| Fonte diferente da esperada | O render precisa de internet para baixar as fontes |
| Vídeo preto ou travado numa cena | Confira o nome do arquivo na pasta `midia` e se o trecho pedido existe no vídeo |
| "Roteiro com problemas" | Normal: o validador achou algo. Peça "corrige o que o validador apontou" |
| Ícone sumiu da Área de Trabalho | Rode o `CRIAR-ATALHO.bat` da pasta do estúdio |
| Toquei em RENDERIZAR NO PC e nada aconteceu | Abra o ícone **BW Reels Render** e deixe a janela aberta; o pedido que já está em Downloads é feito na hora |
| O navegador perguntou onde salvar o pedido | Salve em **Downloads** (é onde o BW Reels Render procura) |

Para qualquer outra dúvida, pergunte ao próprio Claude dentro do estúdio: ele conhece todos os arquivos do projeto.
