# Tutorial — BW Reels Studio

Motor de Reels, Shorts e TikToks cinematográficos. Você usa de dois jeitos:

- **Pela plataforma Brightway › BW Reels Pro** (recomendado): a interface fica no navegador — assunto, IA, ganchos, fontes, estilo, linha do tempo e prévia ao vivo — e este motor, instalado no PC, faz o MP4 em alta.
- **Pelo Claude Code** (opcional): você conversa com o Claude dentro do estúdio e ele faz tudo por comandos.

## 1. Instalação (uma vez, cerca de 10 minutos)

**O que você precisa:** um PC com Windows 10 ou 11 e internet. Para o modo Claude Code (opcional), uma conta do Claude com acesso ao Claude Code (planos Pro, Max, Team ou Enterprise).

1. **Descompacte** o arquivo `.zip` numa pasta fixa, por exemplo `Vídeos` ou `Documentos`. Não rode de dentro do zip.
2. Abra a pasta `bw-reels-studio` e dê **dois cliques em `INSTALAR.bat`**. Se o Windows mostrar "O Windows protegeu o computador", clique em **Mais informações → Executar assim mesmo**.
3. O instalador faz tudo sozinho:
    - instala o Node.js, o FFmpeg e o Claude Code (se ainda não existirem);
    - instala as dependências do projeto e o navegador usado no render;
    - cria os ícones **BW Reels Render** e **BW Reels Studio** na Área de Trabalho;
    - renderiza um vídeo de teste.
4. No fim, a pasta com o vídeo de teste se abre. Se ele tocar, está tudo certo.

Se o instalador pedir para "rodar de novo" (acontece quando o Windows acabou de instalar o Node.js ou o FFmpeg), feche a janela e dê dois cliques no `INSTALAR.bat` outra vez. Ele só completa o que faltou.

## 2. Usar pela plataforma (BW Reels Pro)

1. Dê dois cliques no ícone **BW Reels Render** e **deixe a janela aberta** — é ela que liga a plataforma ao motor.
2. Na Brightway, abra **Marketing › BW REELS PRO**.
3. **CRIAR:** escreva o assunto, o nicho e a chamada final e toque em **✨ CRIAR GANCHOS E ROTEIRO**. Escolha o gancho, confira as **fontes** (o que não tiver fonte sai do vídeo) e o **estilo**.
4. **MÍDIA:** importe suas filmagens, fotos, motions de IA e música licenciada. Use **NA CENA** ou **+ CENA**.
5. **CENA:** toque numa cena da linha do tempo para editar texto, duração, mídia, movimento e transição. A prévia ao lado atualiza na hora.
6. **EXPORTAR:** toque em **RENDERIZAR NO PC**. O pedido vai para Downloads, a janela do BW Reels Render mostra o andamento e o vídeo abre sozinho quando fica pronto. Uma cópia fica em `Downloads\BW Reels - pedidos feitos`.

Os projetos e as mídias da plataforma ficam salvos só no seu aparelho (no navegador). A legenda do post criada pela IA fica na aba EXPORTAR, com o botão COPIAR.

## 3. Abrir o estúdio pelo Claude Code (opcional)

Dê dois cliques no ícone **BW Reels Studio** da Área de Trabalho. Ele abre o terminal já na pasta do estúdio, com o Claude Code iniciado.

**Só na primeira vez:**

1. **Tema** — aperte Enter para ficar no "Auto".
2. **Login** — entre com a sua conta do Claude; o navegador abre para você autorizar.
3. **Confiar na pasta** — responda que sim. Isso libera as skills e os comandos do estúdio.

**Como usar:** digite normalmente, em português, e aperte Enter. Comandos começam com `/`. Para sair, digite `/exit` ou feche a janela. Quando o Claude pedir permissão para rodar um comando (render, validação), aceite.

## 4. Como funciona (modo Claude Code)

Você só aprova em dois momentos: na escolha do gancho e no rascunho.

1. **Briefing** — o Claude entende o nicho, o objetivo, o público e o CTA (faz no máximo 3 perguntas).
2. **Pesquisa validada** — toda informação entra com fonte e data. Sem fonte, fica de fora.
3. **Ganchos** — 10 opções com nota; você escolhe entre as 3 melhores. *Sua aprovação.*
4. **Roteiro** — um arquivo curto (`roteiro.json`) com as cenas.
5. **Rascunho** — render rápido em meia resolução + uma folha com 8 quadros do vídeo. *Sua aprovação.*
6. **Final** — vídeo em 1080x1920 + legenda pronta do post (`post.md`).

Cada vídeo vira uma pasta em `bw-reels-studio\projetos\<nome-do-video>\`, com pesquisa, ganchos, roteiro, mídias e os vídeos renderizados.

## 5. Seu primeiro Reel, passo a passo

1. **Peça o vídeo.** Exemplo:
    `/reels 3 erros que derrubam a live do seu evento — nicho eventos corporativos, CTA chamar no direct`
    Quanto mais você disser (nicho, cliente, público, CTA, se tem filmagem), menos o Claude pergunta.
2. **Responda as perguntas, se vierem.**
3. **Escolha o gancho.** Responda só o número ("vai no 2") ou peça ajuste ("o 2, mas mais curto").
4. **Aprove o rascunho.** Para assistir, abra `projetos\<nome>\render\` e dê dois cliques no `.mp4`. Peça mudanças em linguagem normal:
    - "troca o estilo para corporativo"
    - "a cena 3 está rápida demais"
    - "coloca minha filmagem do palco na cena 2"
5. **Peça o final.** "Aprovado, renderiza o final." O vídeo em alta e a legenda do post ficam na pasta do projeto.

**Se o vídeo citar dados**, o Claude só usa o que tiver fonte confiável. A fonte aparece na tela e na legenda do post. Se não achar fonte, ele avisa e troca a frase por experiência própria.

## 6. Todos os comandos

| Comando | Quando usar | Exemplo |
| --- | --- | --- |
| `/reels` | Vídeo novo do zero, fluxo completo | `/reels por que contratar fotógrafo para o seu evento` |
| `/ganchos` | Só quer ideias de abertura | `/ganchos aftermovie de formatura` |
| `/cortar` | Tem um vídeo longo e quer Reels dele | `/cortar C:\Users\voce\Videos\palestra.mp4 3` |
| `/render` | Renderizar de novo; `final` = alta qualidade; `comparar` = testa os motores | `/render meu-projeto final` |
| `/revisar` | Revisão crítica do último vídeo | `/revisar meu-projeto` |
| `/animar` | Personagem, mascote, logo animado ou motion feito por código | `/animar o Bê acenando e apresentando a BW` |

O nome do projeto é o da pasta em `projetos\`. Você também pode só conversar: "abre o projeto X e troca o CTA" funciona sem comando.

## 7. Suas filmagens, músicas e motions de IA

Coloque os arquivos na pasta `midia\` do projeto e diga ao Claude em qual cena usar. Ele corta o trecho sozinho.

| Material | Onde colocar | Como pedir |
| --- | --- | --- |
| Filmagem | `projetos\<nome>\midia\` | "usa o palco.mp4 a partir de 1min20 na cena 2" |
| Foto | `projetos\<nome>\midia\` | "coloca a foto do público no fundo do gancho" |
| Música licenciada | `assets\musicas\` | "usa a trilha energia.mp3" |
| Narração / sua voz | `projetos\<nome>\midia\` | "a narração é o voz.m4a" (a música abaixa sozinha quando você fala) |
| Motion de IA (Higgsfield, Veo, Kling) | `projetos\<nome>\midia\` | "o logo-3d.mp4 é a abertura" |
| Logo | `assets\logos\` | "assina com o meu logo no final" |

**Prompt de motion:** peça "escreve o prompt pro Higgsfield de uma abertura com o meu logo". Gere lá e salve o clipe na pasta `midia`.

**Música:** use só trilha licenciada ou sua. Música em alta sem licença pode derrubar o áudio ou o vídeo. Os efeitos de whoosh e impacto do estúdio são gerados por ele mesmo, sem direitos autorais.

### Personagens animados pelo motor

Na plataforma, toque em **🎬 MODELOS** → **HISTÓRIAS COM PERSONAGENS**: o Bê (câmera da BW), Ana, Léo, Bia, Rui e um Robô
entram, acenam, falam em balões, pensam, se assustam e comemoram — tudo desenhado pelo motor, sem IA de vídeo e sem custo.
No Claude Code, peça "cena com a Ana perguntando e o Bê respondendo" ou use `/animar` para algo sob medida
(o modelo fica em `modelos\animacoes\personagem-bw.html`).

Para animar o **seu** personagem, use **🎬 MODELOS → ANIMAR MEU PERSONAGEM**: envie a foto do avatar ou mascote, conte a história
e escolha **recorte animado** (grátis), **uma imagem por cena com IA** ou **vídeo com IA de fora** (prompts por cena).

Para personagem **realista** (pessoa de verdade, 3D de cinema), use **🎬 MODELOS → PERSONAGEM COM IA**: a plataforma monta os
prompts de imagem e de vídeo; você gera no Flux (Creator Factory) e anima no Higgsfield, Kling ou Veo, e importa os clipes.

## 8. Estilos, formatos e motores

Tudo se troca com uma frase ("muda para luxo", "faz em 4:5").

| Estilo | Visual | Bom para |
| --- | --- | --- |
| cinema | escuro, dourado, grão de filme | eventos, bastidores, institucional |
| corporativo | azul-marinho, limpo | B2B, palestras, dados |
| neon | preto com rosa brilhante | festas, lançamentos |
| editorial | claro, serifa, revista | dicas, educação, saúde |
| luxo | escuro, champanhe, serifa fina | casamentos, imóveis, gastronomia |

Para criar um estilo com as cores da sua marca: "cria um estilo com as cores #123456 e #abcdef e a fonte X". Ele fica salvo para os próximos vídeos.

**Formatos:** 9:16 (Reels, TikTok, Shorts), 4:5 (feed), 1:1 e 16:9 (YouTube, telão).

**Tipos de cena:** gancho · texto · mídia (filmagem ou foto com movimento) · dado (número animado com fonte) · lista · citação · CTA.

**Motores:** o mesmo roteiro renderiza em três.

- **nativo** (padrão) — já vem pronto pelo instalador.
- **HyperFrames** (HeyGen) — peça "renderiza no hyperframes"; na primeira vez ele instala sozinho.
- **Remotion** — peça "renderiza no remotion". Grátis para pessoas e empresas de até 3 pessoas; acima disso, a empresa precisa de licença (remotion.dev/license).

## 9. Gastar poucos tokens

- **Peça tudo na primeira mensagem** (tema, nicho, CTA, material).
- **Aprove pelo rascunho**, e só depois peça o final.
- **Peça mudanças juntas** numa mensagem só.
- **Reaproveite:** "faz outro no mesmo estilo do projeto X" usa a pesquisa e o visual já salvos.
- **Um vídeo por conversa.** Para começar outro, digite `/clear`; os projetos continuam salvos.

## 10. Se algo der errado

| Problema | O que fazer |
| --- | --- |
| Ícone abre e diz "Claude Code não encontrado" | Rode o `INSTALAR.bat` de novo |
| Erro de Node, npm ou render | Rode o `INSTALAR.bat` de novo (ele só completa o que falta) |
| Fonte diferente da esperada | O render precisa de internet para baixar as fontes |
| Vídeo preto ou travado numa cena | Confira o nome do arquivo na pasta `midia` e se o trecho pedido existe no vídeo |
| "Roteiro com problemas" | Normal: o validador achou algo. Peça "corrige o que o validador apontou" |
| Ícone sumiu da Área de Trabalho | Rode o `CRIAR-ATALHO.bat` da pasta do estúdio |
| Toquei em RENDERIZAR NO PC e nada aconteceu | Abra o ícone **BW Reels Render** e deixe a janela aberta; o pedido que já está em Downloads é feito na hora |
| O navegador perguntou onde salvar o pedido | Salve em **Downloads** (é onde o BW Reels Render procura) |

Para qualquer outra dúvida, pergunte ao próprio Claude dentro do estúdio: ele conhece todos os arquivos do projeto.
