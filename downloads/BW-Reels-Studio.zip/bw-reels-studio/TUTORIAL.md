# Tutorial — app BW (a plataforma Brightway no PC)

Versão 1.9.27 · 22/11/2026. O **app BW** é a plataforma Brightway instalada no computador, com as ferramentas de vídeo que usam a força do PC.

## Instalar e atualizar

1. Baixe o **BW-Setup.exe** em `audioevideobw-eng.github.io/baixar` (botão **BAIXAR O APP BW**) e dê dois cliques. Sem assinatura digital
   paga, o Windows mostra um aviso azul: clique em **Mais informações → Executar assim mesmo**.
2. Avance até o fim. Na primeira abertura o app prepara o que falta sozinho (uns minutos, com internet).
3. Abra pelo ícone **BW** (Área de Trabalho ou menu Iniciar).

**Atualizações:** o app procura versão nova ao abrir e quando a internet volta. Aparece o aviso com a lista do que vem; toque em
**ATUALIZAR AGORA** (ou **DEPOIS**). Seus projetos, vídeos, chaves e configurações continuam no lugar. Depois de atualizar, a tela
**O que mudou** mostra as novidades uma vez.

## Novidades da versão 1.9.27

- **Reels que ensinam** (BW Reels Pro › 🎬 MODELOS): 7 modelos novos no estilo dos reels explicativos — terminal digitando o comando,
  passo numerado com ícone que brilha (cada passo com a sua cor), painel de números com gráfico, medidor, catálogo numerado e o
  **Comenta PALAVRA** no fim. Dois estilos novos: TECH (escuro com grade) e IMPACTO (preto e rosa).
- **Fotolivros** (Álbum 3D e efeitos): livro de fotos na mesa com várias fotos por página e as páginas virando — aberto, com capa,
  visto de cima e em close.

## Novidades da versão 1.9.26

- **Arrastar sem surpresa** no editor de vídeo e no Estúdio de motion: encostar um take no outro só encosta. Cobrindo 60% ou mais, ao soltar
  aparece a pergunta (trocar de lugar, substituir, pôr por cima ou cancelar) e nada muda até você tocar.
- **Transição na agulha:** ponha a agulha na emenda entre dois takes (o ◆ acende) e toque na transição — ela entra ali.

## Novidades da versão 1.9.25

- **Álbum 3D e efeitos** (cartão novo e botão no Estúdio 3D): 45 modelos prontos — anel girando, carrossel, cascata, livro de fotos com páginas
  virando, polaroids, varal, coração de fotos, rolo de filme e efeitos 3D de tela cheia (cubo, persiana, explosão em peças…). Escolha o modelo,
  ponha as suas fotos e vídeos no lugar dos números e gere o vídeo — sem internet.

## Novidades da versão 1.9.24

- **Ferramentas que não "descolam":** no celular, a faixa de ferramentas e a linha do tempo do editor de vídeo e do Motion param firmes nas pontas,
  e há setinhas **‹ ›** discretas para andar pela faixa (segurar anda direto).
- **Segurar e arrastar:** segurar o dedo num take ou numa barra pega e já arrasta. As opções ficam no **⋯ Mais** (no PC, botão direito).
- **Abre direto no layout novo** (sem piscar a tela antiga) e o menu da caixa do Tio Cláudio fica na frente de tudo.

## Novidades da versão 1.9.23

- **Estúdio de motion com cara de app** no celular e no tablet: prévia grande, ▶ no meio, agulha parada no meio da linha do tempo, faixa de
  ferramentas que muda quando você toca num item e folhas que sobem de baixo (no computador continuam os painéis).
- **Telas em movimento e Estúdio 3D com os ⋯ da prévia:** segundo monitor, tela cheia, salvar o quadro em PNG e controle pelo celular; nas Telas a
  rodinha aproxima só a vista; no 3D os ⋯ trazem ângulos da câmera, girar, PNG e gerar vídeo.
- **Desfazer com um toque** no Motion e nas Telas (antes, às vezes, precisava de dois).

## Novidades da versão 1.9.22

- **Editor de vídeo — adicionar mídia:** arquivo que não abre neste computador (vídeo HEVC, foto HEIC) aparece com **⚠ NÃO ABRE AQUI** e o aviso
  diz o que fazer; trazer vários arquivos mostra o progresso; cada botão (cortar, aparar, duplicar, apagar) é um passo próprio do **↶ desfazer**.
- **Opções da prévia nos ⋯** discretos no alto da prévia (editor de vídeo e Estúdio de motion) — clicar na prévia não abre mais o menu.
- **Tela parada:** ao rolar as ferramentas para o lado, só elas rolam; a tela não anda junto.

## Novidades da versão 1.9.21

- **Estúdio de motion com as ferramentas do editor de vídeo:** galeria **EFEITOS** (arraste até a barra do item: esquerda = entrada,
  direita = saída), barra em cima de outra camada = **⇄ TROCAR DE LUGAR** ou **⬆ PARA CIMA**, **Alt + rodinha** = camadas mais altas,
  **rodinha na prévia** = zoom da vista (clique = opções), **COR** por item (looks e ajuste fino, igual no vídeo final), **Q/W**, **Shift+E**,
  **Ctrl+Shift+C/V** (copiar e colar ajustes), **🖥** prévia no segundo monitor e **📱** controle pelo celular.

## Novidades da versão 1.9.20

- **Caixa do Tio Cláudio na página do robô:** escreva o pedido e toque em ➤ (ou Enter). **＋** leva conta, foto ou print para a ferramenta
  certa; **⚡** traz atalhos (gerar arte, reel, orçamento; lançar gasto, recebimento, conta, lembrete; "como está meu dia"); **🎙** fala.
- **Escolha da IA (BW Smart):** o chip da caixa escolhe sozinho entre **Rápido** (papo e lançamentos) e **Inteligente** (textos, orçamentos,
  análises) — ou fixe um dos dois. Se a IA principal estiver ocupada, a reserva responde sozinha, e a linha embaixo diz quem respondeu.
- **✨ Varinha:** deixa o pedido mais claro (objetivo, ação e dados) sem inventar nada; ↺ volta ao seu texto.
- **Editor de vídeo:** arrastando um take em cima de outro aparece o aviso — **⇄ TROCAR DE LUGAR** (solte ali) ou **⬆ PARA CIMA**
  (suba o take: a camada nova nasce na hora).
- **Abertura:** a opção VÍDEO saiu; ficam **FOTO + MUNDO** (padrão) e **MUNDO**.

## Novidades da versão 1.9.17

- **Aberturas para escolher** (chave ABERTURA no alto da tela inicial; fica guardada neste PC; a opção VÍDEO saiu na 1.9.20):
  **FOTO + MUNDO** (padrão desde a 1.9.19, com a imagem nova em alta) — a cena parada com a animação no mundo: anéis, nós ligados e
  sinais correndo, e a faísca entre os dedos. **MUNDO** (1.9.18) — o mundo desenhado em branco e cinza, com os sinais das conexões
  passando em amarelo e azul.

## Novidades da versão 1.9.16

- **Abertura nova, com cara de software:** o BW abre em **tela cheia** com o mundo em rede animado (feixes de luz se encontram, nasce o
  globo com sinais correndo entre os nós) e o letreiro **BRIGHTWAY · SEU SOFTWARE INTELIGENTE**. Mexa o mouse: o mundo inclina e acende;
  clique para repetir o toque de luz. **ENTRAR**, no centro, leva para a página do robô da plataforma, ocupando a tela inteira.
- **Abertura:** escolha no alto da tela de entrada entre FOTO + MUNDO (padrão) e MUNDO (branco e cinza, sinais em amarelo e azul). A escolha fica neste PC.
- **Ferramentas deste PC:** pelo link embaixo do ENTRAR ou pelo botão **⌂ BW** (Meus vídeos, legendas, BW SKILL, gerador 3D, atualizações).
  O menu fica escondido: o **☰** (ou Ctrl+M) abre por cima; **Ctrl+K** busca uma ferramenta; **⛶** põe em tela cheia; embaixo, a barra de status mostra a placa de vídeo.
- **Dentro da plataforma:** o menu lateral fica sempre escondido (o ☰ abre por cima) e somem as opções que só servem na web (APP DOWNLOAD, instalar no celular).
- **PRETO E BRANCO** passa a ser o modo padrão da plataforma, até você escolher outro em Configurações.

## Novidades da versão 1.9.14

- **EDITOR DE VÍDEO com cara de app no celular e no tablet:** prévia grande, linha do tempo fina com a agulha parada no meio (o dedo
  arrasta o tempo; pinça aproxima), miniaturas dos takes e uma faixa de ferramentas que rola para o lado e muda conforme o que você toca
  (vídeo, texto ou som). Cada ferramenta abre uma folha que sobe de baixo só com aquele ajuste; segurar o dedo no take abre as opções.
  No computador continua o layout com os painéis. (1.9.15: no celular fica só esse layout.)

## Novidades da versão 1.9.13

- **EDITOR DE VÍDEO — pessoa, modelos e duas telas:**
  - **🧠 Pessoa e fundo:** ANALISAR acha a pessoa em cada quadro; textos e camadas passam POR TRÁS dela, texto em ANEL gira em volta,
    fundo desfocado/preto e branco/escuro/cor/sem fundo e contorno de luz. Tudo no próprio computador.
  - **🎬 Modelos prontos:** 12 edições (aftermovie 30/60 s, corporativo, reels, casamento, show, contagem, antes e depois, depoimento,
    top 3, telão, nome atrás da pessoa). Troque os espaços TAKE N pelos seus takes ou use PREENCHER SOZINHO; salve as suas como modelo.
  - **Arrastar:** take solto em cima de outro cria uma camada nova; transições e efeitos vão por arrasto até o take ou a emenda ◆;
    o tempo da transição muda arrastando o ◆. Alt + rodinha muda a altura da camada.
  - **Prévia:** rodinha aproxima e afasta; clique abre as opções (zoom, desafixar, 2º monitor, tela cheia, salvar quadro).
  - **🖥 / 📱:** a prévia abre direto no segundo monitor e o celular vira controle remoto pelo QR.

## Novidades da versão 1.9.12

- **EDITOR DE VÍDEO no padrão de um editor profissional** (Marketing → Editor de vídeo):
  - **Tela limpa:** nas ferramentas de edição e criação somem o menu e o topo; fica só a setinha ‹ de voltar.
  - **Painéis livres:** cada painel tem ✕ (esconde e o espaço vai para a prévia), ⇱ (descola: vira janela solta que você arrasta e
    estica) e a beirada da prévia estica a largura. Vale no vídeo, no motion, nas Telas, no Estúdio 3D e no Editor de fotos.
  - **🖥 Prévia em outra tela:** abre a prévia numa janela para o segundo monitor, em tela cheia.
  - **Chroma key** com AUTOMÁTICO em 5 níveis (cada nível tira mais fundo, suaviza a borda e guarda mais sombra) e MANUAL.
  - **Cor por take:** exposição, contraste, realces, sombras, brancos, pretos, brilho, temperatura, matiz, saturação, vibração,
    nitidez, desbotar e vinheta; 8 pontos de partida, predefinições suas e APLICAR EM TODOS.
  - **Som do take:** volume em dB, NORMALIZAR, REDUZIR RUÍDO, REALÇAR VOZ, EXTRAIR ÁUDIO e forma de onda.
  - **Botão direito no take:** copiar e colar os ajustes em outro take, cortar até a agulha (Q/W), desativar (Shift+E), cor e som.

## Novidades da versão 1.9.3

- **ESTÚDIO 3D** (Marketing → Estúdio 3D). Quatro modos, você escolhe:
  - **MODELO 3D** — abre GLB, OBJ e STL, gira, ilumina e gera o vídeo do giro no próprio aparelho.
  - **LOGO 3D** — a sua logo em PNG vira relevo dourado, prata ou cromado, com fundo transparente ou verde para recorte.
  - **MAQUETE DE PALCO E LED** — painéis de 0,5 m com medida real, treliça, pessoas de escala e, o mais útil:
    a **resolução em pixels do telão** (ex.: 10 × 5 painéis P3.9 = 1280 × 640 px), com um botão que já abre o
    Estúdio de motion ou as Telas nesse tamanho. Sai também a **planta em PDF** para mandar ao cliente.
  - **IA 3D (foto → objeto)** — monta o pedido em inglês para Tripo, Meshy, Rodin ou Hunyuan; você gera lá e traz o
    arquivo para cá. O app não chama nenhuma IA de 3D e não envia nada.
  Tudo roda no aparelho, sem biblioteca de fora: funciona **sem internet**.

## Novidades da versão 1.9

- **MINHA EMPRESA e MINHA CASA.** Dois ecossistemas separados: pessoa jurídica (azul) e pessoa física (verde). Cada um tem os seus
  números do mês, a sua agenda e as suas ferramentas. Os dados não se misturam.
- **LANÇAMENTOS PJ e PF** e **PAINEL PJ e PF.** Duas abas em cada página, uma para a empresa e outra para a casa.
- **Página principal nova.** O robô no centro e quatro telas (MEU NEGÓCIO, GESTÃO DE CASA, MARKETING, FERRAMENTAS). O Tio Cláudio
  ganhou o visual do robô.
- **MODOS DE APARÊNCIA.** Na engrenagem: 28 modos (claros, vidro com luz em nove cores, JOGOS — NEON 80, TÁTICO, ARCADE 8-BIT, CORRIDA, FANTASIA, ESPACIAL, com cenário, letra e robô do tema —, FUTURISTA, NATAL, ANO NOVO…) e o modo com
  as cores da **sua marca**. A escolha vale para este computador; no celular você pode usar outro.
- **Painéis** financeiro e de investimentos acompanham o modo escolhido.

## Comece por aqui: o app BW

Abre uma janela própria, como um programa:

1. **Entrar** — clique em **ENTRAR COM A CONTA BRIGHTWAY** e faça o login na página da plataforma (a mesma conta do site e do celular).
   A senha é digitada na página da Brightway; o aplicativo não vê nem guarda a senha. Depois de entrar, as ferramentas deste PC
   funcionam por até 7 dias sem internet; passado esse prazo, ele pede para entrar de novo.
2. **Escolher a ferramenta.** Vídeo: **CRIAR REEL**, **QUADRO DE HISTÓRIA**, **PERSONAGENS**, **PROMPT IA**, **EDITOR DE VÍDEO**,
   **ESTÚDIO DE MOTION**, **TELAS EM MOVIMENTO**, **ASSISTENTE PASSO A PASSO**, **LEGENDAS AUTOMÁTICAS**, **IA DE VÍDEO** e **MINHAS IAS**.
   Estúdio e escritório: **BW SKILL**, **MINHA EMPRESA**, **MINHA CASA**, **LANÇAMENTOS PJ E PF**, **APARÊNCIA E MODOS**, **EDITOR DE FOTOS**,
   **PDF**, **CRIADOR DE ARTES**, **ORÇAMENTOS**, **LEITOR DE CONTAS** e **TODA A PLATAFORMA**.
3. **Renderizar** — dentro do aplicativo, o botão **RENDERIZAR NO PC** do editor já gera o vídeo sozinho, com barra de progresso.
   O vídeo pronto aparece em **MEUS VÍDEOS**, na tela inicial.
4. **Voltar** — o botão amarelo **⌂ BW** volta para a tela inicial de qualquer ferramenta. **SAIR** tira a conta deste PC.

### Usar sem internet (em casa, no notebook)

Na tela inicial, com a internet ligada, clique uma vez em **PREPARAR PARA USAR SEM INTERNET**. O aplicativo guarda neste computador
uma cópia das ferramentas e das bibliotecas delas. Depois disso, as ferramentas com a etiqueta **SEM INTERNET** abrem mesmo desconectado,
e o que você fizer sobe para a conta quando a conexão voltar. Precisam de internet: tudo o que usa IA na nuvem (criar imagem, roteiro
por IA, gerar clipe) e o login depois de 7 dias. Os modelos grandes de IA do editor de fotos (tirar fundo, retoque) ficam guardados
depois da primeira vez que você usa cada um com internet.

### IA de vídeo: conecte a sua

Em **IA DE VÍDEO** você conecta a IA que você assina — hoje **Runway** (Gen-4 Turbo e Gen-4.5) e **fal.ai** (Kling 3.0). Cole a chave
da sua conta; ela fica só neste computador e a cobrança é feita pela IA, na sua conta. Depois, nas cenas de IA (aba **MÍDIA** do
editor, vindas do Quadro de História), aparece **✨ GERAR O CLIPE AQUI**: o aplicativo mostra o custo de referência, pede confirmação,
gera o clipe de 5 s e já coloca na cena. Os preços mudam: confira no site da IA.

### Gerar o instalador (.exe)

Dois cliques em **GERAR-INSTALADOR.bat**: ele instala o Inno Setup (gratuito) se faltar e cria `instalador\BW-Setup.exe`,
que você pode mandar para outras pessoas. Sem assinatura digital paga, o Windows mostra o aviso azul na instalação.

O que você cria no celular com a mesma conta aparece aqui (e o que mandar com **ENVIAR PARA O PC** chega no editor).

## Assistente passo a passo

No aplicativo, clique em **ASSISTENTE PASSO A PASSO** (ou use o atalho **BW Reels Assistente**).
Abre uma janela que conduz etapa por etapa, com **Voltar** e **Avançar**, como um instalador:

1. **Preparar** — confere se o computador está pronto e diz como resolver o que faltar.
2. **Como criar** — quatro jeitos, com o recomendado já marcado conforme as IAs conectadas:
   - **BW IA FREE**: só IAs com cota grátis; acabou a cota de uma no dia, passa para a próxima sozinho.
   - **BW IA ECONOMIZE**: aberturas na IA grátis e roteiro final na IA paga (gasta o mínimo do plano).
   - **BW IA PRO**: tudo na IA paga que você escolheu (melhor qualidade).
   - **SEM IA**: modelo pronto, você troca os textos.
   Em **⚙ Minhas IAs** você conecta cada IA (cola a chave, que fica só no seu computador) ou usa o botão
   **INSTALAR IAS RECOMENDADAS**, que baixa de fontes oficiais o Claude Code e a IA que roda no próprio computador (Ollama + Gemma 3).
3. **Sobre o vídeo** — o assunto (ou o modelo), seu @ e o visual.
4. **Textos e prévia** — mude o que quiser; a prévia animada atualiza sozinha. Número sem fonte não passa.
5. **Conferir** — resumo do vídeo e de quantos pedidos de IA foram usados. Só gera depois de **Aceitar e gerar**.
6. **Gerar vídeo** — barra de progresso e, no fim, o botão para abrir a pasta. Nada é publicado sozinho.

Se a IA falhar (sem login ou limite do plano), o assistente avisa e oferece continuar sem IA.

## 1. Instalação (uma vez, cerca de 10 minutos)

**O que você precisa:** um PC com Windows 10 ou 11 e internet. Para o modo Claude Code (opcional), uma conta do Claude com acesso ao Claude Code (planos Pro, Max, Team ou Enterprise).

1. **Descompacte** o arquivo `.zip` numa pasta fixa, por exemplo `Vídeos` ou `Documentos`. Não rode de dentro do zip.
2. Abra a pasta `bw-reels-studio` e dê **dois cliques em `INSTALAR.bat`**. Se o Windows mostrar "O Windows protegeu o computador", clique em **Mais informações → Executar assim mesmo**.
3. O instalador faz tudo sozinho:
    - instala o Node.js, o FFmpeg e o Claude Code (se ainda não existirem);
    - instala as dependências do projeto e o navegador usado no render;
    - cria os ícones **BW Reels Render** e **BW Reels Studio** na Área de Trabalho;
    - renderiza um vídeo de teste.
4. No fim, a pasta com o vídeo de teste se abre. Se ele tocar, está tudo certo.

Se o instalador pedir para "rodar de novo" (acontece quando o Windows acabou de instalar o Node.js ou o FFmpeg), feche a janela e dê dois cliques no `INSTALAR.bat` outra vez. Ele só completa o que faltou.

## 2. Usar pela plataforma (BW Reels Pro)

1. Dê dois cliques no ícone **BW Reels Render** e **deixe a janela aberta** — é ela que liga a plataforma ao motor.
2. Na Brightway, abra **Marketing › BW REELS PRO**.
3. **CRIAR:** escreva o assunto, o nicho e a chamada final e toque em **✨ CRIAR GANCHOS E ROTEIRO**. Escolha o gancho, confira as **fontes** (o que não tiver fonte sai do vídeo) e o **estilo**.
4. **MÍDIA:** importe suas filmagens, fotos, motions de IA e música licenciada. Use **NA CENA** ou **+ CENA**.
5. **CENA:** toque numa cena da linha do tempo para editar texto, duração, mídia, movimento e transição. A prévia ao lado atualiza na hora.
6. **EXPORTAR:** toque em **RENDERIZAR NO PC**. O pedido vai para Downloads, a janela do BW Reels Render mostra o andamento e o vídeo abre sozinho quando fica pronto. Uma cópia fica em `Downloads\BW Reels - pedidos feitos`.

Os projetos e as mídias da plataforma ficam salvos só no seu aparelho (no navegador). A legenda do post criada pela IA fica na aba EXPORTAR, com o botão COPIAR.

## 3. Abrir o estúdio pelo Claude Code (opcional)

Dê dois cliques no ícone **BW Reels Studio** da Área de Trabalho. Ele abre o terminal já na pasta do estúdio, com o Claude Code iniciado.

**Só na primeira vez:**

1. **Tema** — aperte Enter para ficar no "Auto".
2. **Login** — entre com a sua conta do Claude; o navegador abre para você autorizar.
3. **Confiar na pasta** — responda que sim. Isso libera as skills e os comandos do estúdio.

**Como usar:** digite normalmente, em português, e aperte Enter. Comandos começam com `/`. Para sair, digite `/exit` ou feche a janela. Quando o Claude pedir permissão para rodar um comando (render, validação), aceite.

## 4. Como funciona (modo Claude Code)

Você só aprova em dois momentos: na escolha do gancho e no rascunho.

1. **Briefing** — o Claude entende o nicho, o objetivo, o público e o CTA (faz no máximo 3 perguntas).
2. **Pesquisa validada** — toda informação entra com fonte e data. Sem fonte, fica de fora.
3. **Ganchos** — 10 opções com nota; você escolhe entre as 3 melhores. *Sua aprovação.*
4. **Roteiro** — um arquivo curto (`roteiro.json`) com as cenas.
5. **Rascunho** — render rápido em meia resolução + uma folha com 8 quadros do vídeo. *Sua aprovação.*
6. **Final** — vídeo em 1080x1920 + legenda pronta do post (`post.md`).

Cada vídeo vira uma pasta em `bw-reels-studio\projetos\<nome-do-video>\`, com pesquisa, ganchos, roteiro, mídias e os vídeos renderizados.

## 5. Seu primeiro Reel, passo a passo

1. **Peça o vídeo.** Exemplo:
    `/reels 3 erros que derrubam a live do seu evento — nicho eventos corporativos, CTA chamar no direct`
    Quanto mais você disser (nicho, cliente, público, CTA, se tem filmagem), menos o Claude pergunta.
2. **Responda as perguntas, se vierem.**
3. **Escolha o gancho.** Responda só o número ("vai no 2") ou peça ajuste ("o 2, mas mais curto").
4. **Aprove o rascunho.** Para assistir, abra `projetos\<nome>\render\` e dê dois cliques no `.mp4`. Peça mudanças em linguagem normal:
    - "troca o estilo para corporativo"
    - "a cena 3 está rápida demais"
    - "coloca minha filmagem do palco na cena 2"
5. **Peça o final.** "Aprovado, renderiza o final." O vídeo em alta e a legenda do post ficam na pasta do projeto.

**Se o vídeo citar dados**, o Claude só usa o que tiver fonte confiável. A fonte aparece na tela e na legenda do post. Se não achar fonte, ele avisa e troca a frase por experiência própria.

## 6. Todos os comandos

| Comando | Quando usar | Exemplo |
| --- | --- | --- |
| `/reels` | Vídeo novo do zero, fluxo completo | `/reels por que contratar fotógrafo para o seu evento` |
| `/ganchos` | Só quer ideias de abertura | `/ganchos aftermovie de formatura` |
| `/cortar` | Tem um vídeo longo e quer Reels dele | `/cortar C:\Users\voce\Videos\palestra.mp4 3` |
| `/render` | Renderizar de novo; `final` = alta qualidade; `comparar` = testa os motores | `/render meu-projeto final` |
| `/revisar` | Revisão crítica do último vídeo | `/revisar meu-projeto` |
| `/legendar` | Legenda automática da fala (sem internet) | `/legendar meu-projeto` |
| `/animar` | Personagem, mascote, logo animado ou motion feito por código | `/animar o Bê acenando e apresentando a BW` |

O nome do projeto é o da pasta em `projetos\`. Você também pode só conversar: "abre o projeto X e troca o CTA" funciona sem comando.

## 7. Suas filmagens, músicas e motions de IA

Coloque os arquivos na pasta `midia\` do projeto e diga ao Claude em qual cena usar. Ele corta o trecho sozinho.

| Material | Onde colocar | Como pedir |
| --- | --- | --- |
| Filmagem | `projetos\<nome>\midia\` | "usa o palco.mp4 a partir de 1min20 na cena 2" |
| Foto | `projetos\<nome>\midia\` | "coloca a foto do público no fundo do gancho" |
| Música licenciada | `assets\musicas\` | "usa a trilha energia.mp3" |
| Narração / sua voz | `projetos\<nome>\midia\` | "a narração é o voz.m4a" (a música abaixa sozinha quando você fala) |
| Motion de IA (Higgsfield, Veo, Kling) | `projetos\<nome>\midia\` | "o logo-3d.mp4 é a abertura" |
| Logo | `assets\logos\` | "assina com o meu logo no final" |

### Legenda automática (sem internet)

O estúdio ouve a sua filmagem ou narração e escreve a legenda palavra por palavra, no próprio computador. Nada é enviado para fora.

1. **Uma vez só:** dê dois cliques em `INSTALAR-LEGENDAS.bat`. Ele baixa o motor de fala e o modelo (uns 500 MB).
2. **Legendar um reel:** arraste o `roteiro.json` do projeto para cima do `LEGENDAR.bat`. Ele liga o som da filmagem, ouve só os trechos usados e grava as palavras no roteiro. Depois é só renderizar.
3. **Legendar um vídeo solto:** arraste o vídeo para cima do `LEGENDAR.bat`. Sai um arquivo `.srt` ao lado, que abre no CapCut, Premiere e YouTube.

Sempre confira nomes de pessoas e de empresas: são os que o computador mais erra. Corrija no `roteiro.json` (campo `legendas.palavras`) ou peça ao Claude: "troca Bê Dáblio por BW na legenda".

Para a filmagem tocar com o som dela sem legenda, peça: "liga o som do vídeo na cena 2".

**Prompt de motion:** peça "escreve o prompt pro Higgsfield de uma abertura com o meu logo". Gere lá e salve o clipe na pasta `midia`.

**Música:** use só trilha licenciada ou sua. Música em alta sem licença pode derrubar o áudio ou o vídeo. Os efeitos de whoosh e impacto do estúdio são gerados por ele mesmo, sem direitos autorais.

### Personagens animados pelo motor

Na plataforma, toque em **🎬 MODELOS** → **HISTÓRIAS COM PERSONAGENS**: o Bê (câmera da BW), Ana, Léo, Bia, Rui e um Robô
entram, acenam, falam em balões, pensam, se assustam e comemoram — tudo desenhado pelo motor, sem IA de vídeo e sem custo.
No Claude Code, peça "cena com a Ana perguntando e o Bê respondendo" ou use `/animar` para algo sob medida
(o modelo fica em `modelos\animacoes\personagem-bw.html`).

Para animar o **seu** personagem, use **🎬 MODELOS → ANIMAR MEU PERSONAGEM**: envie a foto do avatar ou mascote, conte a história
e escolha **recorte animado** (grátis), **uma imagem por cena com IA** ou **vídeo com IA de fora** (prompts por cena).

Para personagem **realista** (pessoa de verdade, 3D de cinema), use **🎬 MODELOS → PERSONAGEM COM IA**: a plataforma monta os
prompts de imagem e de vídeo; você gera no Flux (Creator Factory) e anima no Higgsfield, Kling ou Veo, e importa os clipes.

## 8. Estilos, formatos e motores

Tudo se troca com uma frase ("muda para luxo", "faz em 4:5").

| Estilo | Visual | Bom para |
| --- | --- | --- |
| cinema | escuro, dourado, grão de filme | eventos, bastidores, institucional |
| corporativo | azul-marinho, limpo | B2B, palestras, dados |
| neon | preto com rosa brilhante | festas, lançamentos |
| editorial | claro, serifa, revista | dicas, educação, saúde |
| luxo | escuro, champanhe, serifa fina | casamentos, imóveis, gastronomia |

Para criar um estilo com as cores da sua marca: "cria um estilo com as cores #123456 e #abcdef e a fonte X". Ele fica salvo para os próximos vídeos.

**Formatos:** 9:16 (Reels, TikTok, Shorts), 4:5 (feed), 1:1 e 16:9 (YouTube, telão).

**Tipos de cena:** gancho · texto · mídia (filmagem ou foto com movimento) · dado (número animado com fonte) · lista · citação · CTA · personagem.

**Motions e gráficos:** logo animado · nome e cargo · contagem 3-2-1 · gráfico (barras ou rosca, com fonte) · linha do tempo · checklist · top/ranking · depoimento · local e data · oferta · AO VIVO · vídeo no celular · antes e depois · tela dividida.

**Motores:** o mesmo roteiro renderiza em três.

- **nativo** (padrão) — já vem pronto pelo instalador.
- **HyperFrames** (HeyGen) — peça "renderiza no hyperframes"; na primeira vez ele instala sozinho.
- **Remotion** — peça "renderiza no remotion". Grátis para pessoas e empresas de até 3 pessoas; acima disso, a empresa precisa de licença (remotion.dev/license).

## 9. Gastar poucos tokens

- **Peça tudo na primeira mensagem** (tema, nicho, CTA, material).
- **Aprove pelo rascunho**, e só depois peça o final.
- **Peça mudanças juntas** numa mensagem só.
- **Reaproveite:** "faz outro no mesmo estilo do projeto X" usa a pesquisa e o visual já salvos.
- **Um vídeo por conversa.** Para começar outro, digite `/clear`; os projetos continuam salvos.

## 10. Se algo der errado

| Problema | O que fazer |
| --- | --- |
| Ícone abre e diz "Claude Code não encontrado" | Rode o `INSTALAR.bat` de novo |
| Erro de Node, npm ou render | Rode o `INSTALAR.bat` de novo (ele só completa o que falta) |
| Fonte diferente da esperada | O render precisa de internet para baixar as fontes |
| Vídeo preto ou travado numa cena | Confira o nome do arquivo na pasta `midia` e se o trecho pedido existe no vídeo |
| "Roteiro com problemas" | Normal: o validador achou algo. Peça "corrige o que o validador apontou" |
| Ícone sumiu da Área de Trabalho | Rode o `CRIAR-ATALHO.bat` da pasta do estúdio |
| Toquei em RENDERIZAR NO PC e nada aconteceu | Abra o ícone **BW Reels Render** e deixe a janela aberta; o pedido que já está em Downloads é feito na hora |
| O navegador perguntou onde salvar o pedido | Salve em **Downloads** (é onde o BW Reels Render procura) |

Para qualquer outra dúvida, pergunte ao próprio Claude dentro do estúdio: ele conhece todos os arquivos do projeto.
