@echo off
title BW (novo)
call "%~dp0BW-ELECTRON.bat" %*
