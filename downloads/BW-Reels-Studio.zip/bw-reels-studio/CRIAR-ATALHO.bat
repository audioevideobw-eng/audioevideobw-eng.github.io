@echo off
REM Cria os atalhos "BW Reels Studio" (Claude Code) e "BW Reels Render" (motor da plataforma) na Area de Trabalho
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=(Get-Location).Path; $d=[Environment]::GetFolderPath('Desktop'); $ws=New-Object -ComObject WScript.Shell; foreach($t in @($d,$p)){ $l=$ws.CreateShortcut((Join-Path $t 'BW Reels Studio.lnk')); $l.TargetPath=(Join-Path $env:SystemRoot 'System32\WindowsPowerShell\v1.0\powershell.exe'); $l.Arguments=('-NoExit -ExecutionPolicy Bypass -File \"' + (Join-Path $p 'abrir-studio.ps1') + '\"'); $l.WorkingDirectory=$p; $l.IconLocation=(Join-Path $p 'bw-reels.ico'); $l.Description='Abre o BW Reels Studio no Claude Code'; $l.Save() }; Write-Host ('Atalho criado em: ' + $d)"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=(Get-Location).Path; $d=[Environment]::GetFolderPath('Desktop'); $ws=New-Object -ComObject WScript.Shell; foreach($t in @($d,$p)){ $l=$ws.CreateShortcut((Join-Path $t 'BW Reels Render.lnk')); $l.TargetPath=(Join-Path $p 'BW-REELS-RENDER.bat'); $l.WorkingDirectory=$p; $l.IconLocation=(Join-Path $p 'bw-reels.ico'); $l.Description='Liga o motor a plataforma Brightway (BW Reels Pro)'; $l.Save() }"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=(Get-Location).Path; $d=[Environment]::GetFolderPath('Desktop'); $ws=New-Object -ComObject WScript.Shell; foreach($t in @($d,$p)){ $l=$ws.CreateShortcut((Join-Path $t 'BW Reels Assistente.lnk')); $l.TargetPath=(Join-Path $p 'BW-REELS-ASSISTENTE.bat'); $l.WorkingDirectory=$p; $l.WindowStyle=7; $l.IconLocation=(Join-Path $p 'bw-reels.ico'); $l.Description='Cria um Reel passo a passo (recomendado para comecar)'; $l.Save() }"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=(Get-Location).Path; $d=[Environment]::GetFolderPath('Desktop'); $ws=New-Object -ComObject WScript.Shell; foreach($t in @($d,$p)){ $l=$ws.CreateShortcut((Join-Path $t 'BW Reels.lnk')); $l.TargetPath=(Join-Path $p 'BW-REELS.bat'); $l.WorkingDirectory=$p; $l.WindowStyle=7; $l.IconLocation=(Join-Path $p 'bw-reels.ico'); $l.Description='BW Reels - o aplicativo com todas as ferramentas (comece por aqui)'; $l.Save() }"
echo.
echo Pronto! Na Area de Trabalho:
echo   BW Reels = o aplicativo com login e todas as ferramentas (comece por aqui)
echo   BW Reels Assistente = abre direto no passo a passo
echo   BW Reels Render  = liga o motor a plataforma Brightway (BW Reels Pro)
echo   BW Reels Studio  = abre o Claude Code no estudio
if /i not "%~1"=="nopause" timeout /t 8
