@echo off
REM Cria o icone "BW" (o aplicativo) na Area de Trabalho e nesta pasta.
REM Os atalhos antigos (Assistente, Render, Studio) nao sao mais criados: tudo isso abre de dentro do aplicativo.
cd /d "%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -Command "$p=(Get-Location).Path; $d=[Environment]::GetFolderPath('Desktop'); $ws=New-Object -ComObject WScript.Shell; foreach($t in @($d,$p)){ $v=(Join-Path $t 'BW Reels.lnk'); if(Test-Path $v){Remove-Item $v}; $l=$ws.CreateShortcut((Join-Path $t 'BW.lnk')); $l.TargetPath=(Join-Path $p 'BW-REELS.bat'); $l.WorkingDirectory=$p; $l.WindowStyle=7; $l.IconLocation=(Join-Path $p 'bw-reels.ico'); $l.Description='BW - o aplicativo com todas as ferramentas'; $l.Save() }; Write-Host ('Icone criado em: ' + $d)"
echo.
echo Pronto! O icone "BW" esta na Area de Trabalho.
echo Dentro dele ficam o editor, o Quadro de Historia, o assistente, as legendas e a plataforma.
if /i not "%~1"=="nopause" timeout /t 6
