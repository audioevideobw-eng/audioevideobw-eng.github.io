@echo off
title BW Reels Studio - Instalacao
cd /d "%~dp0"
echo.
echo  ==================================================
echo   BW Reels Studio - instalacao automatica (1 clique)
echo  ==================================================
echo   Pode levar de 5 a 15 minutos na primeira vez.
echo.
set "PATH=%PATH%;C:\Program Files\nodejs;%LOCALAPPDATA%\Microsoft\WinGet\Links;%APPDATA%\npm;%USERPROFILE%\.local\bin"

echo [1/7] Node.js...
where node >nul 2>nul
if errorlevel 1 (
  echo     Instalando Node.js LTS via winget...
  winget install -e --id OpenJS.NodeJS.LTS --accept-source-agreements --accept-package-agreements
) else (
  for /f %%v in ('node -v') do echo     Node.js %%v ja instalado.
)

echo [2/7] FFmpeg...
where ffmpeg >nul 2>nul
if errorlevel 1 (
  echo     Instalando FFmpeg via winget...
  winget install -e --id Gyan.FFmpeg --accept-source-agreements --accept-package-agreements
) else (
  echo     FFmpeg ja instalado.
)

where node >nul 2>nul || (echo. & echo  Node.js instalado, mas o Windows precisa de uma nova janela. Feche e rode o INSTALAR.bat de novo. & pause & exit /b 1)
where ffmpeg >nul 2>nul || (echo. & echo  FFmpeg instalado, mas o Windows precisa de uma nova janela. Feche e rode o INSTALAR.bat de novo. & pause & exit /b 1)

echo [3/7] Claude Code...
where claude >nul 2>nul
if errorlevel 1 (
  echo     Instalando Claude Code (instalador oficial claude.ai/install.ps1)...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "irm https://claude.ai/install.ps1 | iex"
) else (
  echo     Claude Code ja instalado.
)

echo [4/7] Dependencias do projeto (npm install)...
call npm install || (echo ERRO no npm install & pause & exit /b 1)

echo [5/7] Navegador de render (Chromium)...
call npx playwright install chromium || (echo ERRO ao instalar o Chromium & pause & exit /b 1)

echo [6/7] Criando os icones "BW Reels Render" e "BW Reels Studio" na Area de Trabalho...
call "%~dp0CRIAR-ATALHO.bat" nopause

echo [7/7] Renderizando o video de demonstracao (teste)...
call npm run demo || (echo ERRO no render da demo & pause & exit /b 1)

echo.
echo  ==================================================
echo   PRONTO!
echo   COMECE PELO ICONE "BW Reels" na Area de Trabalho:
echo     entre com a sua conta Brightway e escolha a ferramenta.
echo   PELA PLATAFORMA no navegador (Brightway, BW Reels Pro):
echo     abra o icone "BW Reels Render" e deixe a janela aberta;
echo     na plataforma, toque em RENDERIZAR NO PC.
echo   PELO CLAUDE CODE (opcional):
echo     abra o icone "BW Reels Studio" e digite  /reels  e o tema
echo   Tutorial completo: TUTORIAL.pdf
echo  ==================================================
start "" "%~dp0projetos\exemplo-bw-transmissao\render"
pause
