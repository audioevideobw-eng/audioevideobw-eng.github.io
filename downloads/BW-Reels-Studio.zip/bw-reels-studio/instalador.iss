﻿; BW — roteiro do instalador (Inno Setup 6). Gere com GERAR-INSTALADOR.bat (ele monta a pasta limpa instalador\_pacote antes).
[Setup]
AppId={{7C2D9A41-3B5E-4F86-A1D2-5E9B0C6F4A17}
AppName=BW
AppVersion=1.9.26
AppPublisher=BW Audiovisual
DefaultDirName={localappdata}\BW
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=instalador
OutputBaseFilename=BW-Setup
SetupIconFile=bw-reels.ico
UninstallDisplayIcon={app}\bw-reels.ico
Compression=lzma2
SolidCompression=yes
WizardStyle=modern

[Languages]
Name: "pt"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Tasks]
Name: "desktopicon"; Description: "Criar o ícone BW na área de trabalho"; GroupDescription: "Atalhos:"

[Files]
Source: "instalador\_pacote\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{autoprograms}\BW"; Filename: "{app}\BW-REELS.bat"; WorkingDir: "{app}"; IconFilename: "{app}\bw-reels.ico"; Flags: runminimized
Name: "{autodesktop}\BW"; Filename: "{app}\BW-REELS.bat"; WorkingDir: "{app}"; IconFilename: "{app}\bw-reels.ico"; Flags: runminimized; Tasks: desktopicon

[Run]
Filename: "{app}\INSTALAR.bat"; Description: "Instalar agora os componentes (Node.js, FFmpeg e navegador do motor) - precisa de internet"; Flags: postinstall shellexec waituntilterminated

[UninstallDelete]
Type: filesandordirs; Name: "{app}\node_modules"
Type: filesandordirs; Name: "{app}\site-offline"
