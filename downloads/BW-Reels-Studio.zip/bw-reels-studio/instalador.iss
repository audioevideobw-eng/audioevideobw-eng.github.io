; BW Reels — roteiro do instalador (Inno Setup 6). Gere com GERAR-INSTALADOR.bat (ele monta a pasta limpa instalador\_pacote antes).
[Setup]
AppId={{7C2D9A41-3B5E-4F86-A1D2-5E9B0C6F4A17}
AppName=BW Reels
AppVersion=1.0
AppPublisher=BW Audiovisual
DefaultDirName={localappdata}\BW Reels
DisableProgramGroupPage=yes
PrivilegesRequired=lowest
OutputDir=instalador
OutputBaseFilename=BW-Reels-Setup
SetupIconFile=bw-reels.ico
UninstallDisplayIcon={app}\bw-reels.ico
Compression=lzma2
SolidCompression=yes
WizardStyle=modern

[Languages]
Name: "pt"; MessagesFile: "compiler:Languages\BrazilianPortuguese.isl"

[Files]
Source: "instalador\_pacote\*"; DestDir: "{app}"; Flags: recursesubdirs createallsubdirs ignoreversion

[Icons]
Name: "{autoprograms}\BW Reels"; Filename: "{app}\BW-REELS.bat"; WorkingDir: "{app}"; IconFilename: "{app}\bw-reels.ico"; Flags: runminimized

[Run]
Filename: "{app}\INSTALAR.bat"; Description: "Instalar agora os componentes (Node.js, FFmpeg e navegador do motor) - precisa de internet"; Flags: postinstall shellexec waituntilterminated

[UninstallDelete]
Type: filesandordirs; Name: "{app}\node_modules"
Type: filesandordirs; Name: "{app}\site-offline"
