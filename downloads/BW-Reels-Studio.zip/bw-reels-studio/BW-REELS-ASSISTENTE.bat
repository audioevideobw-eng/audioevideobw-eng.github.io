@echo off
title BW Reels Assistente
cd /d "%~dp0"
set "PATH=%PATH%;C:\Program Files\nodejs;%LOCALAPPDATA%\Microsoft\WinGet\Links;%APPDATA%\npm;%USERPROFILE%\.local\bin"
where node >nul 2>nul || (echo. & echo  Falta instalar: de dois cliques em INSTALAR.bat nesta pasta e depois abra o assistente de novo. & pause & exit /b 1)
node motor\assistente.mjs
if errorlevel 1 pause
