@echo off
title BW - legendas
call "%~dp0INSTALAR-LEGENDAS.bat" %*
