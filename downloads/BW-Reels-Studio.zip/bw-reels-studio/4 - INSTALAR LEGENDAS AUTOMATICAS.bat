@echo off
title BW Reels - legendas
call "%~dp0INSTALAR-LEGENDAS.bat" %*
