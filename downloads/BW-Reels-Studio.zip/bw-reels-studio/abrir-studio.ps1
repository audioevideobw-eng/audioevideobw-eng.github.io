﻿# Abre o BW Reels Studio no Claude Code
$Host.UI.RawUI.WindowTitle = 'BW Reels Studio'
Set-Location -Path $PSScriptRoot
$local = Join-Path $HOME '.local\bin'
if ((Test-Path $local) -and ($env:Path -notlike "*$local*")) { $env:Path = "$local;$env:Path" }
Write-Host ''
Write-Host '  BW REELS STUDIO' -ForegroundColor Yellow
Write-Host '  Comandos: /reels  /ganchos  /cortar  /render  /revisar' -ForegroundColor DarkGray
Write-Host ''
if (Get-Command claude -ErrorAction SilentlyContinue) {
    claude
} else {
    Write-Host '  Claude Code nao encontrado neste PC.' -ForegroundColor Red
    Write-Host '  Para instalar, rode:  irm https://claude.ai/install.ps1 | iex' -ForegroundColor Red
}
