# BW Reels Studio 🎬

Estúdio de Reels/Shorts/TikToks **por código**, operado pelo Claude Code. Você conversa e o Claude:
1. pesquisa e valida as informações, com fonte;
2. cria ganchos e dá nota a cada um;
3. escreve um roteiro curto em JSON;
4. renderiza um vídeo cinematográfico no seu PC.

O mesmo roteiro roda em **3 motores**: **nativo** (Chromium + FFmpeg), **HyperFrames** (HeyGen) e **Remotion**. Assim você testa e escolhe.

## Comece aqui
1. Descompacte o zip numa pasta fixa (ex.: `Vídeos`).
2. Dê dois cliques em **`INSTALAR.bat`**. Ele instala tudo (Node.js, FFmpeg, Claude Code, dependências), cria o ícone **BW Reels Studio** na Área de Trabalho e renderiza um vídeo de teste.
3. Abra o ícone e siga o **`TUTORIAL.pdf`**.

## Como usar
Abra o Claude Code nesta pasta (`claude`) e use os comandos abaixo.

| Comando | O que faz |
|---|---|
| `/reels <tema> [nicho] [cliente]` | Pipeline completo: briefing → pesquisa → ganchos → roteiro → rascunho → revisão → final |
| `/ganchos <tema ou projeto>` | Gera 10 ganchos pontuados e mostra o top 3 |
| `/cortar <vídeo longo> [qtd]` | Transforma um evento, palestra ou entrevista em Reels com legenda |
| `/render <projeto> [final] [motor\|comparar]` | Valida e renderiza; o `comparar` faz o mesmo vídeo nos motores |
| `/revisar <projeto>` | Revisão por amostragem de quadros + correções |

Você também pode rodar sem o Claude:
```bash
node motor/validar.mjs projetos/<projeto>/roteiro.json
node motor/render.mjs  projetos/<projeto>/roteiro.json --rascunho            # rápido
node motor/render.mjs  projetos/<projeto>/roteiro.json --motor remotion      # outro motor
node motor/amostrar.mjs projetos/<projeto>/render/<video>.mp4                # folha de contato
```

## Por que gasta poucos tokens
- O Claude escreve **só o `roteiro.json`** (~1–2 mil tokens). Animação, legendas, som e render já estão prontos no `motor/`.
- A revisão usa **1 imagem com 8 quadros**, e não o vídeo inteiro.
- A validação e o rascunho em meia resolução pegam os erros antes do render final.
- Pesquisa e ganchos ficam salvos no projeto e são reaproveitados.

## O que já vem pronto
- **7 tipos de cena:** gancho, texto, mídia (com Ken Burns), dado (número animado com fonte), lista, citação e CTA.
- **5 estilos:** cinema, corporativo, neon, editorial e luxo. Também dá para criar o estilo de cada cliente.
- **Formatos:** 9:16, 4:5, 1:1 e 16:9.
- **Transições:** corte, fade, zoom com desfoque, deslize e flash.
- **Acabamento:** legendas karaokê (por estimativa ou com timestamps do Whisper), grão, vinheta, letterbox, luz que se move, barra de progresso e marca.
- **Som:** efeitos sintetizados (whoosh e impacto, sem direitos autorais), música com fade e ducking automático sob a narração.
- **Validação:** checa fontes obrigatórias para dados, velocidade de leitura, gancho de até 3 s e mídia ausente.

## Licenças
- **Nativo:** código deste projeto, sem licença extra.
- **HyperFrames:** Apache 2.0, uso comercial livre.
- **Remotion:** grátis para pessoa física e empresas de até 3 pessoas. A partir de 4 pessoas, a empresa precisa de licença (remotion.dev/license).
- **Música e imagens:** use só material licenciado ou próprio. A IA não torna uma música "livre".
