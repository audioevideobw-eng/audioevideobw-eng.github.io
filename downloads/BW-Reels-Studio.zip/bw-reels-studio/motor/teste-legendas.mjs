#!/usr/bin/env node
// Teste da LEGENDA AUTOMÁTICA com um "ouvido" SIMULADO (cada bipe vira uma palavra) — confere cortes, tempos, som da filmagem e o render.
// O modelo de fala de verdade só é testado no PC (INSTALAR-LEGENDAS.bat). Uso: node motor/teste-legendas.mjs [--render]
import { mkdtempSync, mkdirSync, writeFileSync, readFileSync, existsSync, rmSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { tmpdir } from 'node:os';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const RAIZ = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const tmp = mkdtempSync(join(tmpdir(), 'bwleg-teste-'));
const falso = join(tmp, 'ouvido-falso.mjs');
writeFileSync(falso, `// cada trecho com som vira uma palavra; a 2ª palavra vem em dois pedaços + vírgula, como o modelo real faz
const NOMES = [[' Olá'], [' pes', 'soal', ','], [' bem'], [' vin', 'dos', '.'], [' hoje'], [' tem'], [' evento']];
let n = 0;
export function decodificar(a) {
  const tokens = [], timestamps = []; let dentro = false, quieto = 0;
  for (let i = 0; i < a.length; i += 160) {
    let e = 0; for (let k = i; k < Math.min(a.length, i + 160); k++) e += Math.abs(a[k]);
    const som = e / 160 > 0.02;
    if (som && !dentro) { const p = NOMES[n++ % NOMES.length]; p.forEach((x, j) => { tokens.push(x); timestamps.push(+(i / 16000 + j * 0.06).toFixed(3)); }); dentro = true; quieto = 0; }
    else if (!som && dentro && ++quieto > 8) dentro = false;
  }
  return { tokens, timestamps, texto: tokens.join('') };
}`);
process.env.BWREELS_TRANSCRICAO_TESTE = falso;
const { transcrever, cortesEm, palavrasDe, srtDe, estado } = await import('./transcrever.mjs');
const { legendarRoteiro, legendarArquivo } = await import('./legendar.mjs');
const { criarPlano } = await import('./plano.mjs');

let falhas = 0;
const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) falhas++; };
const ff = (a) => { const r = spawnSync('ffmpeg', ['-y', '-hide_banner', '-loglevel', 'error', ...a], { encoding: 'utf8' }); if (r.status !== 0) throw new Error(r.stderr); };
const bipes = (ts) => "'sin(2*PI*440*t)*0.5*(" + ts.map((t) => `between(t,${t},${(t + 0.3).toFixed(1)})`).join('+') + ")'";

try {
  // --- unidades
  ok(estado().pronto, 'modo de teste ligado (ouvido simulado)');
  const ws = palavrasDe([' Olá', ' pes', 'soal', ',', ' bem', '▁vin', 'dos', '.'], [0.5, 1.5, 1.56, 1.62, 2.5, 3.5, 3.56, 3.62], 10, 5);
  ok(ws.map((w) => w.palavra).join('|') === 'Olá|pessoal,|bem|vindos.', 'pedaços viram palavras inteiras com a pontuação junto');
  ok(ws[0].inicio === 10.5 && ws[1].inicio === 11.5 && ws.every((w, i) => w.fim > w.inicio && (!ws[i + 1] || w.fim <= ws[i + 1].inicio)), 'tempos deslocados e sem uma palavra por cima da outra');
  const c = cortesEm(70, [{ meio: 20, dur: 0.5 }, { meio: 23, dur: 0.9 }, { meio: 45, dur: 0.4 }]);
  ok(c[1] === 23 && c.every((x, i) => i === 0 || x - c[i - 1] <= 26.5) && c[c.length - 1] === 70, 'som longo é cortado em pedaços ≤ 26 s, de preferência no maior silêncio: ' + c.join(' · '));
  ok(/00:00:10,500 --> /.test(srtDe(ws)) && srtDe(ws).split('\n\n').length >= 1, 'gera .srt');

  // --- projeto com filmagem falada
  const proj = join(tmp, 'proj'); mkdirSync(join(proj, 'midia'), { recursive: true });
  ff(['-f', 'lavfi', '-i', 'testsrc=size=540x960:rate=30:duration=8', '-f', 'lavfi', '-i', `aevalsrc=${bipes([1.5, 2.5, 3.5, 5])}:s=48000:d=8`, '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-shortest', join(proj, 'midia', 'fala.mp4')]);
  ff(['-f', 'lavfi', '-i', 'testsrc=size=540x960:rate=30:duration=3', '-c:v', 'libx264', '-preset', 'ultrafast', '-pix_fmt', 'yuv420p', join(proj, 'midia', 'mudo.mp4')]);
  const roteiro = { titulo: 'Teste legenda', formato: '9:16', fps: 30, motor: 'nativo', estilo: 'neon', efeitos: { sfx: false }, audio: { trilha: 'nenhuma' }, marca: { handle: '@teste' }, fontes: [],
    cenas: [{ tipo: 'gancho', duracao: 3, texto: 'Abertura' }, { tipo: 'midia', duracao: 4, midia: 'midia/fala.mp4', inicioNoArquivo: 1 }, { tipo: 'midia', duracao: 2, midia: 'midia/mudo.mp4' }, { tipo: 'cta', duracao: 2, texto: 'Fim', acao: 'Siga' }] };
  const arq = join(proj, 'roteiro.json'); writeFileSync(arq, JSON.stringify(roteiro));
  const f = await legendarRoteiro(arq);
  const r2 = JSON.parse(readFileSync(arq, 'utf8'));
  const p = r2.legendas.palavras;
  ok(f.somLigado.join() === '2' && r2.cenas[1].somDoVideo === true && r2.cenas[2].somDoVideo === undefined, 'liga o som só da filmagem que tem áudio (cena 2); a muda fica como está');
  ok(p.length === 3 && p.map((w) => w.palavra).join(' ') === 'Olá pessoal, bem', 'ouviu só o trecho usado da filmagem (3 falas): ' + p.map((w) => w.palavra).join(' '));
  ok(p.every((w, i) => Math.abs(w.inicio - [3.5, 4.5, 5.5][i]) < 0.06), 'cada palavra cai no tempo certo da linha do tempo: ' + p.map((w) => w.inicio).join(' · '));
  ok(existsSync(f.copia) && existsSync(f.srt) && !JSON.parse(readFileSync(f.copia, 'utf8')).legendas, 'guarda a cópia do roteiro de antes e o legendas.srt');
  const plano = criarPlano(r2);
  ok(plano.legendas.length >= 1 && plano.legendas[0].palavras[0].txt === 'Olá', 'o motor mostra as palavras ouvidas como legenda');
  const fala = plano.audios.find((a) => a.papel === 'fala');
  ok(fala && fala.inicio === 3 && fala.corte.de === 1 && fala.corte.dur === 4 && plano.volumeTrilha === 0.22, 'o som da filmagem entra na mixagem no trecho certo e a trilha abaixa');
  let erro = ''; try { await legendarRoteiro((writeFileSync(join(proj, 'so-texto.json'), JSON.stringify({ ...roteiro, cenas: [roteiro.cenas[0], roteiro.cenas[3]] })), join(proj, 'so-texto.json'))); } catch (e) { erro = e.message; }
  ok(/não tem fala/.test(erro), 'reel só de texto: explica que não há fala para legendar');

  // --- arquivo solto e som longo
  ff(['-f', 'lavfi', '-i', `aevalsrc=${bipes(Array.from({ length: 22 }, (_, i) => 1 + i * 3))}:s=16000:d=70`, join(tmp, 'longo.wav')]);
  const l = await legendarArquivo(join(tmp, 'longo.wav'));
  ok(l.palavras.length === 22 && l.pedacos >= 3 && l.palavras.every((w, i) => Math.abs(w.inicio - (1 + i * 3)) < 0.08), `som de 70 s: ${l.pedacos} pedaços, 22 falas nos tempos certos (nenhuma perdida nem repetida nas emendas)`);
  ok(existsSync(l.srt) && existsSync(l.json), 'arquivo solto: gera .srt e .transcricao.json ao lado');

  // --- render de verdade: a fala da filmagem sai no vídeo
  if (process.argv.includes('--render')) {
    const r = spawnSync('node', [join(RAIZ, 'motor', 'render.mjs'), arq, '--rascunho'], { encoding: 'utf8' });
    const mp4 = join(proj, 'render', 'proj-rascunho-nativo.mp4');
    ok(r.status === 0 && existsSync(mp4), 'render do reel legendado' + (r.status ? ': ' + (r.stderr || '').slice(-300) : ''));
    const vol = (de, dur) => { const v = spawnSync('ffmpeg', ['-hide_banner', '-ss', String(de), '-t', String(dur), '-i', mp4, '-vn', '-af', 'volumedetect', '-f', 'null', '-'], { encoding: 'utf8' }); const m = /max_volume: (-?[\d.]+|-inf) dB/.exec(v.stderr); return m ? (m[1] === '-inf' ? -99 : +m[1]) : -99; };
    const com = vol(3.5, 0.3), sem = vol(0.5, 2), fora = vol(7.2, 1.5);
    ok(com > -20 && sem < -50 && fora < -50, `no vídeo final a fala toca só na cena dela (bipe ${com} dB · abertura ${sem} dB · depois ${fora} dB)`);
    const qd = join(tmp, 'q.png'); ff(['-ss', '3.7', '-i', mp4, '-frames:v', '1', qd]);
    ok(existsSync(qd), 'quadro com a legenda salvo para conferir: ' + qd);
    if (process.argv.includes('--guardar')) spawnSync('cp', [qd, '/tmp/legenda-quadro.png']);
  }
} catch (e) { console.error(e); falhas++; }
if (!process.argv.includes('--guardar')) rmSync(tmp, { recursive: true, force: true });
console.log(`\nFALHAS: ${falhas}`);
process.exit(falhas ? 1 : 0);
