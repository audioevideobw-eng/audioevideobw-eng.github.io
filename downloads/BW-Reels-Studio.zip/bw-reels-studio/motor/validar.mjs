// Validação barata ANTES do render (evita gastar tempo e tokens renderizando roteiro quebrado).
// Uso direto: node motor/validar.mjs projetos/<slug>/roteiro.json

import { existsSync, readFileSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { ESTILOS, FORMATOS } from './estilos.mjs';
import { PERSONAGENS, ACOES } from './personagens.mjs';

const TIPOS = ['gancho', 'texto', 'midia', 'dado', 'lista', 'citacao', 'cta', 'personagem', 'nome', 'logo', 'contagem', 'grafico', 'linha', 'checklist', 'ranking', 'antesdepois', 'depoimento', 'local', 'oferta', 'aovivo', 'celular', 'dividida'];
const palavras = (s = '') => String(s).split(/\s+/).filter(Boolean).length;

export function validarRoteiro(r, proj, avisos = []) {
  const e = [];
  if (!Array.isArray(r.cenas) || !r.cenas.length) return ['"cenas" vazio'];
  if (r.formato && !FORMATOS[r.formato]) e.push(`formato "${r.formato}" inválido (${Object.keys(FORMATOS).join(', ')})`);
  if (r.estilo && !ESTILOS[r.estilo]) e.push(`estilo "${r.estilo}" inválido (${Object.keys(ESTILOS).join(', ')})`);
  if (r.motor && !['nativo', 'hyperframes', 'remotion'].includes(r.motor)) e.push(`motor "${r.motor}" inválido`);

  let total = 0;
  r.cenas.forEach((c, i) => {
    const n = `cena ${i + 1} (${c.tipo})`;
    if (!TIPOS.includes(c.tipo)) e.push(`${n}: tipo inválido — use ${TIPOS.join(', ')}`);
    const d = Number(c.duracao);
    if (!(d > 0)) e.push(`${n}: "duracao" obrigatória (segundos)`);
    total += d || 0;
    if (c.midia && proj && !existsSync(join(proj, c.midia))) e.push(`${n}: mídia não encontrada: ${c.midia}`);
    if (c.tipo === 'gancho' && !c.texto) e.push(`${n}: gancho sem "texto"`);
    if (c.tipo === 'dado') {
      if (c.valor === undefined) e.push(`${n}: "valor" obrigatório`);
      if (!c.fonte) e.push(`${n}: todo dado precisa de "fonte" visível na tela`);
    }
    if (['lista', 'grafico', 'linha', 'checklist', 'ranking'].includes(c.tipo) && !(Array.isArray(c.itens) && c.itens.length)) e.push(`${n}: "itens" obrigatório`);
    if (c.tipo === 'grafico') {
      if (!c.fonte) e.push(`${n}: gráfico precisa de "fonte" visível (ou "dados próprios")`);
      (c.itens || []).forEach((it) => { if (!/[:=–-]\s*[\d.,]+\s*$/.test(String(it))) e.push(`${n}: item do gráfico sem número — use "Rótulo: 12"`); });
    }
    if (c.tipo === 'nome' && !(c.titulo || c.texto)) e.push(`${n}: "titulo" (nome da pessoa) obrigatório`);
    if (c.tipo === 'oferta' && !(Number(c.valor) > 0)) e.push(`${n}: "valor" (preço) obrigatório`);
    if (c.tipo === 'depoimento' && !c.texto) e.push(`${n}: depoimento sem "texto" (a frase real do cliente)`);
    if (c.midia2 && proj && !existsSync(join(proj, c.midia2))) e.push(`${n}: mídia 2 não encontrada: ${c.midia2}`);
    if (c.tipo === 'personagem') {
      const el = Array.isArray(c.elenco) && !c.elenco.length && c.midia ? [] : c.elenco && c.elenco.length ? c.elenco : [{ personagem: c.personagem || 'be', acao: c.acao }];
      if (el.length > 2) e.push(`${n}: no máximo 2 personagens por cena`);
      el.forEach((a) => {
        if (a.personagem === 'foto') { if (!a.imagem) e.push(`${n}: personagem "foto" precisa de "imagem" (PNG do personagem)`); else if (proj && !existsSync(join(proj, a.imagem))) e.push(`${n}: imagem do personagem não encontrada: ${a.imagem}`); }
        else if (a.personagem === 'meu') { if (!a.look || typeof a.look !== 'object') e.push(`${n}: personagem "meu" precisa de "look" (montado no CRIAR PERSONAGEM)`); }
        else if (a.personagem && !PERSONAGENS[a.personagem]) e.push(`${n}: personagem "${a.personagem}" não existe (${Object.keys(PERSONAGENS).join(', ')})`);
        if (a.acao && !ACOES.includes(a.acao)) e.push(`${n}: ação "${a.acao}" inválida (${ACOES.join(', ')})`);
      });
      const fs = c.falas || (c.balao ? [{ texto: c.balao }] : []);
      const pw = fs.reduce((s2, f) => s2 + palavras(f.texto), 0) + palavras(c.texto);
      if (d && pw / d > 2.8) avisos.push(`${n}: ${pw} palavras de balão em ${d}s — aumente a duração (balão precisa de tempo para ler)`);
      fs.forEach((f) => { if (palavras(f.texto) > 14) avisos.push(`${n}: balão longo (${palavras(f.texto)} palavras) — divida em duas falas`); });
    }
    // leitura confortável: ~3,2 palavras/s de texto na tela
    const txt = [c.texto, c.titulo, c.subtitulo, c.rotulo, ...(c.itens || [])].filter(Boolean).join(' ');
    if (c.tipo !== 'personagem' && c.tipo !== 'grafico' && d && palavras(txt) / d > 3.2) avisos.push(`${n}: ${palavras(txt)} palavras em ${d}s — difícil de ler; aumente a duração ou corte texto`);
    if (c.fala && d && palavras(c.fala) / d > 3.6) avisos.push(`${n}: fala rápida demais (${palavras(c.fala)} palavras em ${d}s)`);
  });

  if (r.cenas[0].tipo !== 'gancho' && r.cenas[0].tipo !== 'personagem') avisos.push('a 1ª cena não é "gancho" — o vídeo perde força nos 3 primeiros segundos');
  else if (r.cenas[0].duracao > 3.5) avisos.push('gancho com mais de 3,5s — encurte para segurar a retenção');
  if (total > 90) avisos.push(`duração total ${total.toFixed(1)}s — acima de 90s fica fora do formato Reels`);
  if (r.cenas.some((c) => c.tipo === 'dado') && !(r.fontes || []).length) e.push('há dados no roteiro mas a lista "fontes" está vazia — rode a pesquisa validada');
  for (const f of r.fontes || []) if (!f.url || !f.afirmacao) e.push(`fonte incompleta: ${JSON.stringify(f)} (precisa de "afirmacao" e "url")`);

  const au = r.audio || {};
  for (const k of ['musica', 'narracao']) if (au[k] && proj && !existsSync(join(proj, au[k]))) e.push(`áudio não encontrado: ${au[k]}`);
  return e;
}

if (import.meta.url === `file://${process.argv[1]}` || process.argv[1]?.endsWith('validar.mjs')) {
  const arq = resolve(process.argv[2] || '');
  const r = JSON.parse(readFileSync(arq, 'utf8'));
  const avisos = [];
  const erros = validarRoteiro(r, dirname(arq), avisos);
  const dur = r.cenas.reduce((s, c) => s + (Number(c.duracao) || 0), 0);
  console.log(`${r.titulo || arq}: ${r.cenas.length} cenas, ${dur.toFixed(1)}s`);
  avisos.forEach((a) => console.log('  ⚠ ' + a));
  erros.forEach((x) => console.log('  ✖ ' + x));
  if (!erros.length) console.log('  ✔ pronto para renderizar');
  process.exit(erros.length ? 1 : 0);
}
