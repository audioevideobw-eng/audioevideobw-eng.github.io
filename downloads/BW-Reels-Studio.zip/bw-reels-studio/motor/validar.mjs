// Validação barata ANTES do render (evita gastar tempo e tokens renderizando roteiro quebrado).
// Uso direto: node motor/validar.mjs projetos/<slug>/roteiro.json

import { existsSync, readFileSync } from 'node:fs';
import { join, dirname, resolve } from 'node:path';
import { ESTILOS, FORMATOS } from './estilos.mjs';

const TIPOS = ['gancho', 'texto', 'midia', 'dado', 'lista', 'citacao', 'cta'];
const palavras = (s = '') => String(s).split(/\s+/).filter(Boolean).length;

export function validarRoteiro(r, proj, avisos = []) {
  const e = [];
  if (!Array.isArray(r.cenas) || !r.cenas.length) return ['"cenas" vazio'];
  if (r.formato && !FORMATOS[r.formato]) e.push(`formato "${r.formato}" inválido (${Object.keys(FORMATOS).join(', ')})`);
  if (r.estilo && !ESTILOS[r.estilo]) e.push(`estilo "${r.estilo}" inválido (${Object.keys(ESTILOS).join(', ')})`);
  if (r.motor && !['nativo', 'hyperframes', 'remotion'].includes(r.motor)) e.push(`motor "${r.motor}" inválido`);

  let total = 0;
  r.cenas.forEach((c, i) => {
    const n = `cena ${i + 1} (${c.tipo})`;
    if (!TIPOS.includes(c.tipo)) e.push(`${n}: tipo inválido — use ${TIPOS.join(', ')}`);
    const d = Number(c.duracao);
    if (!(d > 0)) e.push(`${n}: "duracao" obrigatória (segundos)`);
    total += d || 0;
    if (c.midia && proj && !existsSync(join(proj, c.midia))) e.push(`${n}: mídia não encontrada: ${c.midia}`);
    if (c.tipo === 'gancho' && !c.texto) e.push(`${n}: gancho sem "texto"`);
    if (c.tipo === 'dado') {
      if (c.valor === undefined) e.push(`${n}: "valor" obrigatório`);
      if (!c.fonte) e.push(`${n}: todo dado precisa de "fonte" visível na tela`);
    }
    if (c.tipo === 'lista' && !Array.isArray(c.itens)) e.push(`${n}: "itens" obrigatório`);
    // leitura confortável: ~3,2 palavras/s de texto na tela
    const txt = [c.texto, c.titulo, c.subtitulo, c.rotulo, ...(c.itens || [])].filter(Boolean).join(' ');
    if (d && palavras(txt) / d > 3.2) avisos.push(`${n}: ${palavras(txt)} palavras em ${d}s — difícil de ler; aumente a duração ou corte texto`);
    if (c.fala && d && palavras(c.fala) / d > 3.6) avisos.push(`${n}: fala rápida demais (${palavras(c.fala)} palavras em ${d}s)`);
  });

  if (r.cenas[0].tipo !== 'gancho') avisos.push('a 1ª cena não é "gancho" — o vídeo perde força nos 3 primeiros segundos');
  else if (r.cenas[0].duracao > 3.5) avisos.push('gancho com mais de 3,5s — encurte para segurar a retenção');
  if (total > 90) avisos.push(`duração total ${total.toFixed(1)}s — acima de 90s fica fora do formato Reels`);
  if (r.cenas.some((c) => c.tipo === 'dado') && !(r.fontes || []).length) e.push('há dados no roteiro mas a lista "fontes" está vazia — rode a pesquisa validada');
  for (const f of r.fontes || []) if (!f.url || !f.afirmacao) e.push(`fonte incompleta: ${JSON.stringify(f)} (precisa de "afirmacao" e "url")`);

  const au = r.audio || {};
  for (const k of ['musica', 'narracao']) if (au[k] && proj && !existsSync(join(proj, au[k]))) e.push(`áudio não encontrado: ${au[k]}`);
  return e;
}

if (import.meta.url === `file://${process.argv[1]}` || process.argv[1]?.endsWith('validar.mjs')) {
  const arq = resolve(process.argv[2] || '');
  const r = JSON.parse(readFileSync(arq, 'utf8'));
  const avisos = [];
  const erros = validarRoteiro(r, dirname(arq), avisos);
  const dur = r.cenas.reduce((s, c) => s + (Number(c.duracao) || 0), 0);
  console.log(`${r.titulo || arq}: ${r.cenas.length} cenas, ${dur.toFixed(1)}s`);
  avisos.forEach((a) => console.log('  ⚠ ' + a));
  erros.forEach((x) => console.log('  ✖ ' + x));
  if (!erros.length) console.log('  ✔ pronto para renderizar');
  process.exit(erros.length ? 1 : 0);
}
