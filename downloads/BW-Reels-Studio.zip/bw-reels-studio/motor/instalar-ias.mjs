// Instalação com um botão das IAs recomendadas (só de fontes oficiais).
//   1. Claude Code  — instalador oficial da Anthropic (claude.ai/install.ps1). Depois o usuário entra com a conta dele (plano Pro ou Max).
//   2. Ollama       — programa oficial (winget: Ollama.Ollama) que roda IA no próprio computador: grátis, sem chave e sem cota.
//   3. Modelo local — Gemma 3 do Google (cerca de 3,3 GB), baixado pelo Ollama.
// As IAs grátis da internet (Groq, Gemini, OpenRouter) não têm o que instalar: só precisam da chave, colada em Minhas IAs.
import { spawn, spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { join } from 'node:path';

const WIN = process.platform === 'win32';
export const MODELO_LOCAL = 'gemma3';
export const PLANO = [
  { id: 'claude', nome: 'Claude Code', de: 'Anthropic (claude.ai)', tamanho: 'cerca de 200 MB', para: 'IA paga de melhor qualidade. Depois de instalar, entre com a sua conta Claude.' },
  { id: 'ollama', nome: 'Ollama', de: 'ollama.com (via loja de programas do Windows)', tamanho: 'cerca de 1 GB', para: 'Faz a IA rodar no seu computador: grátis e sem limite diário.' },
  { id: 'modelo', nome: 'Modelo Gemma 3', de: 'Google, baixado pelo Ollama', tamanho: 'cerca de 3,3 GB', para: 'O "cérebro" da IA do computador. Precisa de 8 GB de memória ou mais.' },
];
const tem = (cmd) => { try { return spawnSync(cmd, ['--version'], { shell: WIN, timeout: 15000 }).status === 0; } catch { return false; } };
function ollamaExe() {
  if (tem('ollama')) return 'ollama';
  const c = join(process.env.LOCALAPPDATA || '', 'Programs', 'Ollama', 'ollama.exe');
  return existsSync(c) ? `"${c}"` : null;
}
function rodar(cmd, args, aoLer) {
  return new Promise((ok) => {
    const p = spawn(cmd, args, { shell: true, windowsHide: true });
    const le = (d) => { const l = String(d).split(/[\r\n]+/).map((x) => x.trim()).filter(Boolean).pop(); if (l) aoLer(l.slice(0, 90)); };
    p.stdout.on('data', le); p.stderr.on('data', le);
    p.on('error', () => ok(false)); p.on('close', (c) => ok(c === 0));
  });
}

export async function instalarRecomendadas(aviso = () => {}) {
  const res = [];
  const passo = async (i, jaTem, fazer) => {
    const item = PLANO[i]; aviso({ n: i + 1, de: PLANO.length, nome: item.nome, linha: 'conferindo…' });
    if (process.env.BWREELS_TESTE) { await new Promise((r) => setTimeout(r, 150)); res.push({ ...item, ok: true, como: 'simulado' }); return; }
    if (jaTem()) { res.push({ ...item, ok: true, como: 'já estava instalado' }); return; }
    if (!WIN) { res.push({ ...item, ok: false, como: 'instalação automática só no Windows' }); return; }
    const deu = await fazer((linha) => aviso({ n: i + 1, de: PLANO.length, nome: item.nome, linha }));
    res.push({ ...item, ok: deu && jaTem(), como: deu ? 'instalado agora' : 'não consegui instalar' });
  };
  await passo(0, () => tem(process.env.BWREELS_CLAUDE || 'claude') || existsSync(join(process.env.USERPROFILE || '', '.local', 'bin', 'claude.exe')),
    (l) => rodar('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', '"irm https://claude.ai/install.ps1 | iex"'], l));
  await passo(1, () => !!ollamaExe(),
    (l) => rodar('winget', ['install', '-e', '--id', 'Ollama.Ollama', '--accept-source-agreements', '--accept-package-agreements'], l));
  await passo(2, () => { const o = ollamaExe(); if (!o) return false; try { return spawnSync(o, ['list'], { shell: true, encoding: 'utf8', timeout: 20000 }).stdout.includes(MODELO_LOCAL); } catch { return false; } },
    async (l) => { const o = ollamaExe(); if (!o) return false; spawn(o, ['serve'], { shell: true, detached: true, stdio: 'ignore', windowsHide: true }).unref(); await new Promise((r) => setTimeout(r, 4000)); return rodar(o, ['pull', MODELO_LOCAL], l); });
  return res;
}
