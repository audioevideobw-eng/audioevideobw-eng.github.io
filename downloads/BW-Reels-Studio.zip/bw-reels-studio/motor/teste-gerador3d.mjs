/* motor/teste-gerador3d.mjs — testa o GERADOR 3D NO PC (instalação, estado, geração, remoção)
   com os comandos SIMULADOS (BW3D_SIMULADO=1): aqui não há placa NVIDIA nem Windows.
   Uso: BW3D_SIMULADO=1 node motor/teste-gerador3d.mjs */
import { existsSync, readFileSync, rmSync } from 'node:fs';
import { join } from 'node:path';
process.env.BW3D_SIMULADO = '1';
const G = await import('./gerador3d.mjs');
let falhas = 0;
const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) falhas++; };

rmSync(G.RAIZ3D, { recursive: true, force: true });

console.log('\n=== requisitos ===');
const q = G.requisitos();
ok(q.pronto === true, 'máquina com NVIDIA + Python + git é considerada pronta');
ok(q.aviso.some((a) => /FORMA|textura/i.test(a)), 'avisa que com menos de 16 GB sai só a forma, sem textura');

console.log('\n=== antes de instalar ===');
const e0 = G.estado();
ok(e0.instalado === false && e0.feitas === 0, 'começa sem nada instalado');
ok(/tencent/i.test(e0.licenca.url) && /União Europeia/i.test(e0.licenca.resumo), 'mostra a licença do modelo e a restrição do autor');

console.log('\n=== instalação ===');
const vistas = [];
const r = await G.instalar((et) => vistas.push(et));
ok(r.ok, 'instalou sem erro (' + (r.erro || 'ok') + ')');
ok(vistas.length === G.ETAPAS.length, 'passou pelas ' + G.ETAPAS.length + ' etapas, em ordem');
ok(vistas[0] === 'pastas' && vistas[vistas.length - 1] === 'teste', 'a 1ª etapa é preparar pastas e a última é o teste de prova');
const e1 = G.estado();
ok(e1.instalado && e1.feitas === e1.total, 'estado final: instalado, ' + e1.feitas + '/' + e1.total);
ok(existsSync(join(G.RAIZ3D, 'gerar.py')), 'gravou o programa que gera a malha');
const roteiro = readFileSync(join(G.RAIZ3D, 'gerar.py'), 'utf8');
ok(/tencent\/Hunyuan3D-2mini/.test(roteiro) && /hunyuan3d-dit-v2-mini/.test(roteiro), 'o programa aponta para o modelo e a subpasta certos');
ok(/device="cuda"/.test(roteiro), 'o programa roda na placa (cuda)');
ok(!/requests|urllib|upload|http/i.test(roteiro), 'o programa NÃO manda nada para a internet');
ok(G.RAIZ3D.includes('.bw-reels'), 'tudo mora em ~/.bw-reels/3d — a atualização do app não toca aqui');

console.log('\n=== retomar de onde parou ===');
const vistas2 = [];
await G.instalar((et, t) => vistas2.push(et + ':' + t));
ok(vistas2.filter((x) => /já feito/.test(x)).length >= 7, 'na 2ª vez pula o que já estava feito');

console.log('\n=== gerar ===');
const g = await G.gerar({ imagem: join(G.RAIZ3D, 'prova.glb') });
ok(g.ok && existsSync(g.arquivo) && /\.glb$/.test(g.arquivo), 'gera o .glb na pasta de saídas');
const ruim = await G.gerar({ imagem: join(G.RAIZ3D, 'nao-existe.png') });
ok(!ruim.ok && /imagem/i.test(ruim.erro), 'imagem que não existe dá erro claro, não trava');

console.log('\n=== remover ===');
ok(G.remover().ok && !existsSync(G.RAIZ3D), 'remove tudo quando o usuário pede');

console.log('\n' + (falhas ? '❌ ' + falhas + ' falha(s)' : '✅ GERADOR 3D NO PC: 0 falhas (comandos simulados)'));
process.exit(falhas ? 1 : 0);
