/* motor/teste-gerador3d.mjs — testa o GERADOR 3D NO PC (instalação, estado, geração, remoção)
   com os comandos SIMULADOS (BW3D_SIMULADO=1): aqui não há placa NVIDIA nem Windows.
   Uso: BW3D_SIMULADO=1 node motor/teste-gerador3d.mjs */
import { existsSync, readFileSync, writeFileSync, rmSync } from 'node:fs';
import { join } from 'node:path';
process.env.BW3D_SIMULADO = '1';
const G = await import('./gerador3d.mjs');
let falhas = 0;
const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) falhas++; };

rmSync(G.RAIZ3D, { recursive: true, force: true });

console.log('\n=== requisitos ===');
const q = G.requisitos();
ok(q.pronto === true, 'máquina com NVIDIA + Python + git é considerada pronta');
ok(q.aviso.some((a) => /FORMA|textura/i.test(a)), 'avisa que com menos de 16 GB sai só a forma, sem textura');

console.log('\n=== antes de instalar ===');
const e0 = G.estado();
ok(e0.instalado === false && e0.feitas === 0, 'começa sem nada instalado');
ok(/tencent/i.test(e0.licenca.url) && /União Europeia/i.test(e0.licenca.resumo), 'mostra a licença do modelo e a restrição do autor');

console.log('\n=== instalação ===');
const vistas = [];
const r = await G.instalar((et) => vistas.push(et));
ok(r.ok, 'instalou sem erro (' + (r.erro || 'ok') + ')');
ok(vistas.length === G.ETAPAS.length, 'passou pelas ' + G.ETAPAS.length + ' etapas, em ordem');
ok(vistas[0] === 'pastas' && vistas[vistas.length - 1] === 'teste', 'a 1ª etapa é preparar pastas e a última é o teste de prova');
const e1 = G.estado();
ok(e1.instalado && e1.feitas === e1.total, 'estado final: instalado, ' + e1.feitas + '/' + e1.total);
ok(existsSync(join(G.RAIZ3D, 'gerar.py')), 'gravou o programa que gera a malha');
const roteiro = readFileSync(join(G.RAIZ3D, 'gerar.py'), 'utf8');
ok(/tencent\/Hunyuan3D-2mini/.test(roteiro) && /hunyuan3d-dit-v2-mini/.test(roteiro), 'o programa aponta para o modelo e a subpasta certos');
ok(/device="cuda"/.test(roteiro), 'o programa roda na placa (cuda)');
ok(!/requests|urllib|upload|http/i.test(roteiro), 'o programa NÃO manda nada para a internet');
ok(G.RAIZ3D.includes('.bw-reels'), 'tudo mora em ~/.bw-reels/3d — a atualização do app não toca aqui');

console.log('\n=== retomar de onde parou ===');
const vistas2 = [];
await G.instalar((et, t) => vistas2.push(et + ':' + t));
ok(vistas2.filter((x) => /já feito/.test(x)).length >= 7, 'na 2ª vez pula o que já estava feito');

console.log('\n=== gerar ===');
const g = await G.gerar({ imagem: join(G.RAIZ3D, 'prova.glb') });
ok(g.ok && existsSync(g.arquivo) && /\.glb$/.test(g.arquivo), 'gera o .glb na pasta de saídas');
const ruim = await G.gerar({ imagem: join(G.RAIZ3D, 'nao-existe.png') });
ok(!ruim.ok && /imagem/i.test(ruim.erro), 'imagem que não existe dá erro claro, não trava');

console.log('\n=== Python e Git que faltam (20/11: faltavam no PC do dono) ===');
ok(G.BASICOS.length === 2 && G.BASICOS.some((b) => b.id === 'python') && G.BASICOS.some((b) => b.id === 'git'),
  'sabe instalar os dois que faltam: Python e Git');
ok(G.BASICOS.every((b) => /^https:\/\//.test(b.site) && b.winget),
  'cada um tem o pacote do winget e o site oficial para baixar à mão');
{
  const py = G.BASICOS.find((b) => b.id === 'python');
  ok(/python\.org\/ftp\/python\/3\.12\./.test(py.site) && /\-amd64\.exe$/.test(py.site),
    'o link do Python é o ARQUIVO 3.12 de 64 bits do python.org, não a página geral (que baixa a versão nova)');
  ok(/Store/i.test(py.dica) && /PATH/.test(py.dica),
    'avisa da caixinha do PATH e da versão da Microsoft Store (o dono baixou essa por engano em 20/11)');
}
ok(G.faltamBasicos().length === 0, 'máquina completa: não pede nada');
const semNada = await import('./gerador3d.mjs?real=1');
{ /* fora do simulado, a leitura é a da máquina de verdade: aqui (Linux) não há winget */
  const antes = process.env.BW3D_SIMULADO; delete process.env.BW3D_SIMULADO;
  ok(semNada.temWinget() === false, 'fora do Windows não finge que tem o instalador automático');
  const r = await semNada.instalarBasicos();
  ok(!r.ok && /Windows|winget|site/i.test(r.erro), 'fora do Windows explica o que fazer à mão, não trava');
  const req = semNada.requisitos();
  ok(req.python && typeof req.gitCmd === 'string', 'a leitura real diz por qual caminho o Python e o Git foram achados');
  process.env.BW3D_SIMULADO = antes;
}

console.log('\n=== Python novo demais (o dono instalou o 3.15 em 20/11) ===');
{
  process.env.BW3D_SIM_PY = '3.15';
  const q3 = G.requisitos();
  ok(!q3.pronto, 'Python 3.15 não é dado como pronto — a instalação quebraria na etapa do PyTorch');
  ok(q3.motivos.some((m) => /novo demais/i.test(m) && /3\.12/.test(m)), 'explica o porquê e manda instalar o ' + G.PY_FAIXA.indicado);
  ok(q3.motivos.some((m) => /junto/i.test(m)), 'avisa que não precisa desinstalar o que já tem');
  ok(G.faltamBasicos().some((b) => b.id === 'python'), 'oferece instalar o Python certo sozinho');
  process.env.BW3D_SIM_PY = '3.9';
  ok(G.requisitos().motivos.some((m) => /3\.10 ou mais novo/.test(m)), 'Python velho demais também é recusado, com o mínimo na mensagem');
  delete process.env.BW3D_SIM_PY;
  ok(G.requisitos().pronto, 'Python dentro da faixa volta a ficar pronto');
  ok(G.PY_FAIXA.min === 10 && G.PY_FAIXA.max === 13, 'a faixa que tem roda de PyTorch com CUDA no Windows está escrita num lugar só');
}

console.log('\n=== Python da Microsoft Store (o dono instalou esse por engano em 20/11) ===');
{
  process.env.BW3D_SIM_STORE = '1';
  const q4 = G.requisitos();
  ok(!q4.pronto, 'Python da Store não é dado como pronto');
  ok(q4.motivos.some((m) => /Store/i.test(m) && /pasta protegida/i.test(m) && /Desinstale/i.test(m)),
    'explica o problema da pasta protegida e manda desinstalar');
  ok(G.faltamBasicos().some((b) => b.id === 'python'), 'oferece instalar o Python certo no lugar');
  delete process.env.BW3D_SIM_STORE;
  ok(G.requisitos().pronto, 'sem a da Store, volta a ficar pronto');
}

console.log('\n=== o modelo vem inteiro (20/11: faltou o VAE e o teste de prova quebrou) ===');
{
  const roteiro = readFileSync(join(G.RAIZ3D, 'gerar.py'), 'utf8');
  ok(/use_safetensors=False/.test(roteiro) && /Missing key/.test(roteiro),
    'se o safetensors vier sem o encoder, o programa tenta o .ckpt em vez de quebrar');
  const mjs = readFileSync(new URL('./gerador3d.mjs', import.meta.url), 'utf8');
  ok(/hunyuan3d-dit-v2-mini\/\*/.test(mjs) && /hunyuan3d-vae-v2-mini\/\*/.test(mjs),
    'o download traz o DiT E o VAE (as duas pastas que o pipeline carrega)');
  ok(/\*\.yaml/.test(mjs), 'traz também os config.yaml das pastas');
  /* teste falhou → a próxima tentativa confere o modelo de novo, não pula */
  rmSync(G.RAIZ3D, { recursive: true, force: true });
  await G.instalar(() => {});
  const est = JSON.parse(readFileSync(join(G.RAIZ3D, 'estado.json'), 'utf8'));
  est.etapas.teste = 'erro'; est.instalado = false;
  writeFileSync(join(G.RAIZ3D, 'estado.json'), JSON.stringify(est));
  const refeitas = [];
  await G.instalar((et, t) => { if (!/já feito/.test(t)) refeitas.push(et); });
  ok(refeitas.includes('modelo') && refeitas.includes('roteiro'),
    'depois de falhar no teste, o TENTAR DE NOVO refaz o modelo e o roteiro (' + refeitas.join(', ') + ')');
  ok(!refeitas.includes('torch'), 'mas não baixa o PyTorch de novo');
}

console.log('\n=== remover ===');
ok(G.remover().ok && !existsSync(G.RAIZ3D), 'remove tudo quando o usuário pede');

console.log('\n' + (falhas ? '❌ ' + falhas + ' falha(s)' : '✅ GERADOR 3D NO PC: 0 falhas (comandos simulados)'));
process.exit(falhas ? 1 : 0);
