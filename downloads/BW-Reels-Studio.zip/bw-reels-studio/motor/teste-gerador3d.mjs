/* motor/teste-gerador3d.mjs — testa o GERADOR 3D NO PC (instalação, estado, geração, remoção)
   com os comandos SIMULADOS (BW3D_SIMULADO=1): aqui não há placa NVIDIA nem Windows.
   Uso: BW3D_SIMULADO=1 node motor/teste-gerador3d.mjs */
import { existsSync, readFileSync, rmSync } from 'node:fs';
import { join } from 'node:path';
process.env.BW3D_SIMULADO = '1';
const G = await import('./gerador3d.mjs');
let falhas = 0;
const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) falhas++; };

rmSync(G.RAIZ3D, { recursive: true, force: true });

console.log('\n=== requisitos ===');
const q = G.requisitos();
ok(q.pronto === true, 'máquina com NVIDIA + Python + git é considerada pronta');
ok(q.aviso.some((a) => /FORMA|textura/i.test(a)), 'avisa que com menos de 16 GB sai só a forma, sem textura');

console.log('\n=== antes de instalar ===');
const e0 = G.estado();
ok(e0.instalado === false && e0.feitas === 0, 'começa sem nada instalado');
ok(/tencent/i.test(e0.licenca.url) && /União Europeia/i.test(e0.licenca.resumo), 'mostra a licença do modelo e a restrição do autor');

console.log('\n=== instalação ===');
const vistas = [];
const r = await G.instalar((et) => vistas.push(et));
ok(r.ok, 'instalou sem erro (' + (r.erro || 'ok') + ')');
ok(vistas.length === G.ETAPAS.length, 'passou pelas ' + G.ETAPAS.length + ' etapas, em ordem');
ok(vistas[0] === 'pastas' && vistas[vistas.length - 1] === 'teste', 'a 1ª etapa é preparar pastas e a última é o teste de prova');
const e1 = G.estado();
ok(e1.instalado && e1.feitas === e1.total, 'estado final: instalado, ' + e1.feitas + '/' + e1.total);
ok(existsSync(join(G.RAIZ3D, 'gerar.py')), 'gravou o programa que gera a malha');
const roteiro = readFileSync(join(G.RAIZ3D, 'gerar.py'), 'utf8');
ok(/tencent\/Hunyuan3D-2mini/.test(roteiro) && /hunyuan3d-dit-v2-mini/.test(roteiro), 'o programa aponta para o modelo e a subpasta certos');
ok(/device="cuda"/.test(roteiro), 'o programa roda na placa (cuda)');
ok(!/requests|urllib|upload|http/i.test(roteiro), 'o programa NÃO manda nada para a internet');
ok(G.RAIZ3D.includes('.bw-reels'), 'tudo mora em ~/.bw-reels/3d — a atualização do app não toca aqui');

console.log('\n=== retomar de onde parou ===');
const vistas2 = [];
await G.instalar((et, t) => vistas2.push(et + ':' + t));
ok(vistas2.filter((x) => /já feito/.test(x)).length >= 7, 'na 2ª vez pula o que já estava feito');

console.log('\n=== gerar ===');
const g = await G.gerar({ imagem: join(G.RAIZ3D, 'prova.glb') });
ok(g.ok && existsSync(g.arquivo) && /\.glb$/.test(g.arquivo), 'gera o .glb na pasta de saídas');
const ruim = await G.gerar({ imagem: join(G.RAIZ3D, 'nao-existe.png') });
ok(!ruim.ok && /imagem/i.test(ruim.erro), 'imagem que não existe dá erro claro, não trava');

console.log('\n=== Python e Git que faltam (20/11: faltavam no PC do dono) ===');
ok(G.BASICOS.length === 2 && G.BASICOS.some((b) => b.id === 'python') && G.BASICOS.some((b) => b.id === 'git'),
  'sabe instalar os dois que faltam: Python e Git');
ok(G.BASICOS.every((b) => /^https:\/\//.test(b.site) && b.winget),
  'cada um tem o pacote do winget e o site oficial para baixar à mão');
ok(G.faltamBasicos().length === 0, 'máquina completa: não pede nada');
const semNada = await import('./gerador3d.mjs?real=1');
{ /* fora do simulado, a leitura é a da máquina de verdade: aqui (Linux) não há winget */
  const antes = process.env.BW3D_SIMULADO; delete process.env.BW3D_SIMULADO;
  ok(semNada.temWinget() === false, 'fora do Windows não finge que tem o instalador automático');
  const r = await semNada.instalarBasicos();
  ok(!r.ok && /Windows|winget|site/i.test(r.erro), 'fora do Windows explica o que fazer à mão, não trava');
  const req = semNada.requisitos();
  ok(req.python && typeof req.gitCmd === 'string', 'a leitura real diz por qual caminho o Python e o Git foram achados');
  process.env.BW3D_SIMULADO = antes;
}

console.log('\n=== Python novo demais (o dono instalou o 3.15 em 20/11) ===');
{
  process.env.BW3D_SIM_PY = '3.15';
  const q3 = G.requisitos();
  ok(!q3.pronto, 'Python 3.15 não é dado como pronto — a instalação quebraria na etapa do PyTorch');
  ok(q3.motivos.some((m) => /novo demais/i.test(m) && /3\.12/.test(m)), 'explica o porquê e manda instalar o ' + G.PY_FAIXA.indicado);
  ok(q3.motivos.some((m) => /junto/i.test(m)), 'avisa que não precisa desinstalar o que já tem');
  ok(G.faltamBasicos().some((b) => b.id === 'python'), 'oferece instalar o Python certo sozinho');
  process.env.BW3D_SIM_PY = '3.9';
  ok(G.requisitos().motivos.some((m) => /3\.10 ou mais novo/.test(m)), 'Python velho demais também é recusado, com o mínimo na mensagem');
  delete process.env.BW3D_SIM_PY;
  ok(G.requisitos().pronto, 'Python dentro da faixa volta a ficar pronto');
  ok(G.PY_FAIXA.min === 10 && G.PY_FAIXA.max === 13, 'a faixa que tem roda de PyTorch com CUDA no Windows está escrita num lugar só');
}

console.log('\n=== remover ===');
ok(G.remover().ok && !existsSync(G.RAIZ3D), 'remove tudo quando o usuário pede');

console.log('\n' + (falhas ? '❌ ' + falhas + ' falha(s)' : '✅ GERADOR 3D NO PC: 0 falhas (comandos simulados)'));
process.exit(falhas ? 1 : 0);
