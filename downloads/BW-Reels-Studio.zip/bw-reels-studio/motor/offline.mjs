// USO SEM INTERNET — o aplicativo guarda no computador uma cópia das ferramentas da plataforma e das bibliotecas que elas usam.
// Com internet: busca a versão nova e atualiza a cópia. Sem internet: entrega a cópia guardada. Sem servidor local:
// é a própria janela que troca a resposta da rede pelo arquivo do disco (as páginas continuam no endereço real da plataforma).
// Nunca guarda: conta/Supabase, pedidos que não sejam GET, nem nada de sites fora da lista abaixo.
import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, statSync, rmSync } from 'node:fs';
import { join, dirname, extname } from 'node:path';
import { homedir } from 'node:os';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';

export const PASTA = join(homedir(), '.bw-reels', 'offline');
// bibliotecas e modelos que as ferramentas baixam (só leitura, públicos)
const CDNS = new Set(['cdn.jsdelivr.net', 'unpkg.com', 'cdnjs.cloudflare.com', 'fonts.googleapis.com', 'fonts.gstatic.com', 'storage.googleapis.com',
  'huggingface.co', 'cdn-lfs.huggingface.co', 'cdn-lfs.hf.co', 'cas-bridge.xethub.hf.co', 'tessdata.projectnaptha.com', 'esm.sh']);
const TIPOS = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.mjs': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.woff': 'font/woff', '.ttf': 'font/ttf', '.wasm': 'application/wasm', '.mp4': 'video/mp4', '.pdf': 'application/pdf', '.txt': 'text/plain; charset=utf-8' };
const MAX = 220e6;
// páginas das ferramentas que fazem sentido sem internet (usadas pelo PREPARAR)
export const PAGINAS = ['index.html', 'fotos.html', 'pdf.html', 'criador.html', 'propostas.html', 'leitor.html', 'reels.html', 'personagens.html', 'video.html', 'motion.html', 'lancamentos.html', 'casa.html', 'promptia.html', 'login.html', 'ferramentas.html', 'marketing.html', 'negocio.html',
  'eventos.html', 'equipe.html', 'fluxo.html', 'custos.html', 'contas.html', 'orcamento.html', 'reserva.html', 'financeiro-painel.html', 'dados.html', 'transcricao.html', 'assistente.html'];

const sha = (t) => createHash('sha1').update(t).digest('hex').slice(0, 20);
function limpo(caminho) { return caminho.split('/').filter((p) => p && p !== '.' && p !== '..').map((p) => p.replace(/[<>:"\\|?*\x00-\x1f]/g, '_')).join('/'); }

/** Onde uma URL fica guardada. Plataforma: pelo caminho (a versão ?v= mais nova substitui a antiga). Bibliotecas: pela URL inteira. */
export function lugar(site, url) {
  let u; try { u = new URL(url); } catch { return null; }
  if (u.origin === new URL(site).origin) {
    let c = limpo(decodeURIComponent(u.pathname)); if (!c || u.pathname.endsWith('/')) c = (c ? c + '/' : '') + 'index.html';
    if (!extname(c)) c += '.html';
    return { tipo: 'site', rel: c, arquivo: join(PASTA, 'site', c) };
  }
  if (u.protocol === 'https:' && CDNS.has(u.hostname)) return { tipo: 'cdn', rel: u.hostname + '/' + sha(u.href), arquivo: join(PASTA, 'cdn', u.hostname, sha(u.href) + (extname(u.pathname).slice(0, 8) || '.bin')) };
  return null;
}
function guardar(l, corpo, tipoConteudo, url) {
  try { mkdirSync(dirname(l.arquivo), { recursive: true }); writeFileSync(l.arquivo, corpo); writeFileSync(l.arquivo + '.meta', JSON.stringify({ tipo: tipoConteudo || '', url, quando: Date.now() })); } catch { /* disco cheio: segue sem guardar */ }
}
function guardado(l, pastaCopia) {
  const tenta = [l.arquivo]; if (l.tipo === 'site' && pastaCopia) tenta.push(join(pastaCopia, l.rel));
  for (const a of tenta) {
    if (!existsSync(a)) continue;
    let tipo = ''; try { tipo = JSON.parse(readFileSync(a + '.meta', 'utf8')).tipo; } catch { /* cópia que veio no instalador não tem .meta */ }
    return { corpo: readFileSync(a), tipo: tipo || TIPOS[extname(a).toLowerCase()] || 'application/octet-stream' };
  }
  return null;
}

/** Liga o "rede primeiro, cópia do disco quando faltar" na janela. pastaCopia = cópia da plataforma que veio junto com o aplicativo. */
export async function ligar(contexto, site, pastaCopia) {
  const estado = { semRede: 0, comRede: 0, daCopia: 0 };
  await contexto.route('**/*', async (rota) => {
    const req = rota.request();
    if (req.method() !== 'GET') return rota.continue();
    const l = lugar(site, req.url());
    if (!l || req.headers().range) return rota.continue();
    try {
      const resp = await rota.fetch({ timeout: l.tipo === 'site' ? 7000 : 20000 });
      const st = resp.status();
      if (st === 200) { const corpo = await resp.body(); if (corpo.length <= MAX) guardar(l, corpo, resp.headers()['content-type'], req.url()); estado.comRede++; return rota.fulfill({ response: resp, body: corpo }); }
      if (st >= 500) { const g = guardado(l, pastaCopia); if (g) { estado.daCopia++; return rota.fulfill({ status: 200, body: g.corpo, headers: { 'content-type': g.tipo, 'access-control-allow-origin': '*' } }); } }
      return rota.fulfill({ response: resp });
    } catch {
      estado.semRede++;
      const g = guardado(l, pastaCopia);
      if (g) { estado.daCopia++; return rota.fulfill({ status: 200, body: g.corpo, headers: { 'content-type': g.tipo, 'access-control-allow-origin': '*', 'x-bw-offline': '1' } }); }
      return rota.abort('internetdisconnected');
    }
  });
  return estado;
}

/** A cópia da plataforma vem no pacote como site-offline.zip; abre uma vez (e de novo quando o pacote muda). */
export function abrirCopia(raiz) {
  const zip = join(raiz, 'site-offline.zip'), pasta = join(raiz, 'site-offline'), marca = join(pasta, '.aberto');
  if (!existsSync(zip)) return existsSync(pasta) ? pasta : null;
  const assinatura = String(statSync(zip).size) + '-' + Math.round(statSync(zip).mtimeMs);
  try { if (readFileSync(marca, 'utf8') === assinatura) return pasta; } catch { /* ainda não aberto */ }
  rmSync(pasta, { recursive: true, force: true }); mkdirSync(pasta, { recursive: true });
  for (const [cmd, a] of [['tar', ['-xf', zip, '-C', pasta]], ['python3', ['-m', 'zipfile', '-e', zip, pasta]], ['python', ['-m', 'zipfile', '-e', zip, pasta]], ['unzip', ['-o', '-q', zip, '-d', pasta]]]) {
    const r = spawnSync(cmd, a, { stdio: 'ignore' });
    if (r.status === 0 && existsSync(join(pasta, 'index.html'))) { writeFileSync(marca, assinatura); return pasta; }
  }
  return null;
}

function contar(pasta) { let n = 0, b = 0; const anda = (p) => { let l = []; try { l = readdirSync(p); } catch { return; } for (const x of l) { const c = join(p, x); let s; try { s = statSync(c); } catch { continue; } if (s.isDirectory()) anda(c); else if (!x.endsWith('.meta') && x !== '.aberto') { n++; b += s.size; } } }; anda(pasta); return { n, mb: +(b / 1048576).toFixed(1) }; }
export function situacao(pastaCopia) {
  const site = contar(join(PASTA, 'site')), cdn = contar(join(PASTA, 'cdn')), copia = pastaCopia ? contar(pastaCopia) : { n: 0, mb: 0 };
  let preparado = ''; try { preparado = JSON.parse(readFileSync(join(PASTA, 'preparado.json'), 'utf8')).quando; } catch { /* nunca */ }
  return { paginas: Math.max(site.n, copia.n), bibliotecas: cdn.n, mb: +(site.mb + cdn.mb + copia.mb).toFixed(1), preparado, pronto: (site.n > 0 || copia.n > 0) && cdn.n > 0 };
}

/** PREPARAR PARA USAR SEM INTERNET: baixa as páginas das ferramentas, os arquivos delas e as bibliotecas citadas no código. */
export async function preparar(site, pastaCopia, aviso = () => {}) {
  const base = site.replace(/\/$/, '') + '/';
  const baixar = async (url) => {
    const l = lugar(site, url); if (!l) return null;
    const c = new AbortController(); const t = setTimeout(() => c.abort(), 60000);
    try { const r = await fetch(url, { signal: c.signal, redirect: 'follow' }); if (!r.ok) return null; const corpo = Buffer.from(await r.arrayBuffer()); if (corpo.length > MAX) return null; guardar(l, corpo, r.headers.get('content-type') || '', url); return corpo; }
    catch { return null; } finally { clearTimeout(t); }
  };
  const vistos = new Set(), fila = PAGINAS.map((p) => base + p), libs = new Set();
  let ok = 0, falhou = 0, i = 0;
  const RE_LOCAL = /(?:src|href)\s*=\s*["']([^"'#?]+\.(?:js|css|png|jpg|jpeg|webp|svg|json|ico|woff2?))(?:\?[^"']*)?["']/gi;
  const RE_LIB = /https:\/\/(?:cdn\.jsdelivr\.net|unpkg\.com|cdnjs\.cloudflare\.com|fonts\.googleapis\.com|fonts\.gstatic\.com|storage\.googleapis\.com|tessdata\.projectnaptha\.com)\/[^\s"'`<>)\\]+/g;
  while (fila.length) {
    const url = fila.shift(); if (vistos.has(url)) continue; vistos.add(url);
    aviso({ etapa: 'Guardando as ferramentas', feito: ++i, total: i + fila.length });
    let corpo = await baixar(url);
    if (!corpo) { const g = guardado(lugar(site, url), pastaCopia); if (g) corpo = g.corpo; else { falhou++; continue; } } else ok++;
    if (!/\.(html|js|css)$/i.test(new URL(url).pathname)) continue;
    const txt = corpo.toString('utf8');
    for (const m of txt.matchAll(RE_LIB)) { const u = m[0].replace(/[.,;]+$/, ''); if (!/\$\{|\+$/.test(u) && /\.[a-z0-9]{2,5}($|\?)|\/css2?\?/i.test(u)) libs.add(u); }
    if (/\.html$/i.test(new URL(url).pathname)) for (const m of txt.matchAll(RE_LOCAL)) { if (/^(https?:)?\/\//.test(m[1]) || m[1].startsWith('data:')) continue; try { const u = new URL(m[1], url).href; if (u.startsWith(base) && !vistos.has(u)) fila.push(u); } catch { /* caminho estranho */ } }
  }
  let j = 0; const lista = [...libs];
  for (const u of lista) {
    aviso({ etapa: 'Guardando as bibliotecas', feito: ++j, total: lista.length });
    const corpo = await baixar(u); if (corpo) ok++; else falhou++;
    if (corpo && /fonts\.googleapis\.com/.test(u)) for (const m of corpo.toString('utf8').matchAll(/https:\/\/fonts\.gstatic\.com\/[^\s)'"]+/g)) { if (await baixar(m[0])) ok++; }
  }
  mkdirSync(PASTA, { recursive: true });
  writeFileSync(join(PASTA, 'preparado.json'), JSON.stringify({ quando: new Date().toISOString(), ok, falhou }));
  return { ...situacao(pastaCopia), ok, falhou };
}
