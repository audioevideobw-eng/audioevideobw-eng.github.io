// Núcleo de animação compartilhado pelos 3 motores (nativo, HyperFrames, Remotion).
// Funções puras: dado um tempo t (s), devolvem o estado visual de cada elemento.

export const EASES = {
  linear: (x) => x,
  none: (x) => x,
  'sine.inOut': (x) => -(Math.cos(Math.PI * x) - 1) / 2,
  'power2.out': (x) => 1 - (1 - x) ** 2,
  'power3.out': (x) => 1 - (1 - x) ** 3,
  'power4.out': (x) => 1 - (1 - x) ** 4,
  'power2.inOut': (x) => (x < 0.5 ? 2 * x * x : 1 - (-2 * x + 2) ** 2 / 2),
  'expo.out': (x) => (x === 1 ? 1 : 1 - 2 ** (-10 * x)),
  'expo.inOut': (x) =>
    x === 0 ? 0 : x === 1 ? 1 : x < 0.5 ? 2 ** (20 * x - 10) / 2 : (2 - 2 ** (-20 * x + 10)) / 2,
  'back.out': (x) => {
    const c1 = 1.70158, c3 = c1 + 1;
    return 1 + c3 * (x - 1) ** 3 + c1 * (x - 1) ** 2;
  },
};

export const PADRAO = { opacity: 1, x: 0, y: 0, scale: 1, rot: 0, blur: 0, ls: 0, p: 0 };   // p = progresso 0..1 (vira a variável CSS --p)

const lerp = (a, b, k) => a + (b - a) * k;

/** Estado de um elemento no tempo t a partir da lista de tweens. */
export function estadoEm(tweens = [], t) {
  const s = { ...PADRAO };
  if (!tweens.length) return s;
  const ord = [...tweens].sort((a, b) => a.t0 - b.t0);
  // valores iniciais = "de" da primeira tween de cada propriedade
  for (const tw of [...ord].reverse()) Object.assign(s, tw.de);
  for (const tw of ord) {
    if (t < tw.t0) break;
    const k = tw.dur <= 0 ? 1 : Math.min(1, (t - tw.t0) / tw.dur);
    const e = (EASES[tw.ease] || EASES['power3.out'])(k);
    for (const p of Object.keys(tw.para)) {
      const de = tw.de[p] ?? s[p];
      s[p] = lerp(de, tw.para[p], e);
    }
  }
  return s;
}

export function estadoParaCss(s) {
  return {
    opacity: String(Math.max(0, Math.min(1, s.opacity))),
    transform: `translate(${s.x}px, ${s.y}px) scale(${s.scale}) rotate(${s.rot}deg)`,
    filter: s.blur > 0.05 ? `blur(${s.blur}px)` : 'none',
    letterSpacing: s.ls ? `${s.ls}em` : '',
    p: s.p,
  };
}

export function visivel(el, t) {
  return t >= el.inicio && t < el.fim;
}

/** Valor do contador animado (cenas "dado"). */
export function contadorEm(c, t) {
  if (t <= c.t0) return c.de;
  const k = Math.min(1, (t - c.t0) / c.dur);
  return lerp(c.de, c.para, EASES['expo.out'](k));
}

export function formatarNumero(v, c) {
  const casas = c.casas ?? 0;
  const n = v.toLocaleString('pt-BR', { minimumFractionDigits: casas, maximumFractionDigits: casas });
  const pre = c.prefixo ? `<small>${c.prefixo.trim()}</small>` : '';
  const suf = c.sufixo ? (c.sufixo.trim().length > 2 ? `<small>${c.sufixo.trim()}</small>` : c.sufixo) : '';
  return `${pre}${n}${suf}`;
}

/** Página de legenda ativa e índice da palavra falada no tempo t. */
export function legendaEm(paginas = [], t) {
  const p = paginas.find((pg) => t >= pg.t0 && t < pg.t1);
  if (!p) return null;
  let ativa = -1;
  p.palavras.forEach((w, i) => {
    if (t >= w.t0) ativa = i;
  });
  return { pagina: p, ativa };
}
