#!/usr/bin/env node
// Instala a LEGENDA AUTOMÁTICA (uma vez): biblioteca sherpa-onnx + modelo de fala Parakeet v3 (~500 MB), tudo de fontes oficiais.
import { existsSync, mkdirSync, createWriteStream, rmSync, statSync, renameSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { estado, PASTA_MODELOS, PASTA_MODELO, NOME_MODELO } from './transcrever.mjs';

const RAIZ = resolve(dirname(fileURLToPath(import.meta.url)), '..');
export const URL_MODELO = `https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/${NOME_MODELO}.tar.bz2`;

export async function instalarLegendas(aviso = (m) => console.log('  ' + m)) {
  let e = estado();
  if (e.pronto) { aviso('✓ A legenda automática já está instalada.'); return e; }
  if (!e.biblioteca) {
    aviso('[1/3] Baixando o motor de fala (sherpa-onnx, oficial do npm)…');
    const r = spawnSync(process.platform === 'win32' ? 'npm.cmd' : 'npm', ['install', 'sherpa-onnx-node', '--no-audit', '--no-fund'], { cwd: RAIZ, stdio: 'inherit', shell: process.platform === 'win32' });
    if (r.status !== 0) throw new Error('não consegui baixar o motor de fala (sem internet?). Tente de novo.');
  } else aviso('[1/3] Motor de fala já instalado.');
  if (!estado().modelo) {
    mkdirSync(PASTA_MODELOS, { recursive: true });
    const pacote = join(PASTA_MODELOS, NOME_MODELO + '.tar.bz2'), parcial = pacote + '.baixando';
    if (!existsSync(pacote)) {
      aviso('[2/3] Baixando o modelo de fala (uns 500 MB, do GitHub do projeto sherpa-onnx)…');
      const resp = await fetch(URL_MODELO, { redirect: 'follow' });
      if (!resp.ok || !resp.body) throw new Error('o download do modelo falhou (' + resp.status + '). Tente de novo mais tarde.');
      const total = Number(resp.headers.get('content-length')) || 0;
      let lido = 0, ultimo = -1;
      const conta = new TransformStream({ transform(pedaco, ctl) { lido += pedaco.length; const p = total ? Math.floor(lido / total * 20) : Math.floor(lido / 26214400); if (p !== ultimo) { ultimo = p; aviso(total ? `      ${p * 5}% (${(lido / 1048576).toFixed(0)} MB)` : `      ${(lido / 1048576).toFixed(0)} MB`); } ctl.enqueue(pedaco); } });
      await pipeline(Readable.fromWeb(resp.body.pipeThrough(conta)), createWriteStream(parcial));
      if (total && statSync(parcial).size !== total) { rmSync(parcial, { force: true }); throw new Error('o download veio incompleto. Rode de novo.'); }
      renameSync(parcial, pacote);
    }
    aviso('[3/3] Abrindo o pacote…');
    const t = spawnSync('tar', ['-xjf', pacote, '-C', PASTA_MODELOS], { stdio: 'inherit' });
    if (t.status !== 0 || !estado().modelo) throw new Error('não consegui abrir o pacote do modelo. Apague a pasta ' + PASTA_MODELOS + ' e rode de novo.');
    rmSync(pacote, { force: true });
    rmSync(join(PASTA_MODELO, 'test_wavs'), { recursive: true, force: true });
  } else aviso('[2/3] Modelo de fala já baixado.');
  e = estado();
  if (!e.pronto) throw new Error('a instalação terminou, mas algo ficou faltando. Rode de novo.');
  aviso('✓ Pronto. Agora arraste um vídeo ou o roteiro.json de um projeto para cima do LEGENDAR.bat.');
  return e;
}

if (process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url))) {
  console.log('\n  BW Reels — instalar a LEGENDA AUTOMÁTICA (funciona sem internet depois de instalada)\n');
  instalarLegendas().then(() => console.log('')).catch((err) => { console.error('\n  Não deu: ' + err.message + '\n'); process.exit(1); });
}
