// Interpreta o MESMO plano dos outros motores, usando o mesmo núcleo de animação (motor/anim.mjs).
import React, { useEffect, useLayoutEffect, useRef, useState } from 'react';
import {
  AbsoluteFill, Audio, Img, OffthreadVideo, Sequence, staticFile,
  useCurrentFrame, useVideoConfig, delayRender, continueRender, interpolate,
} from 'remotion';
import { estadoEm, estadoParaCss, contadorEm, formatarNumero, legendaEm } from '../../anim.mjs';
import { animarPersonagem } from '../../personagens.mjs';

// Personagem: o SVG vem pronto do plano; a mesma função dos outros motores mexe as partes no tempo t.
const Ator = ({ n, t, props }) => {
  const ref = useRef(null);
  useLayoutEffect(() => { const r = n.rig; if (ref.current) animarPersonagem(ref.current, r, Math.max(r.t0, Math.min(t, r.t1))); });
  if (n.filhos) return React.createElement(n.tag, { ...props, ref }, n.filhos.map((f) => <No key={f.id} n={f} t={t} fps={30} />));
  return React.createElement(n.tag, { ...props, ref, dangerouslySetInnerHTML: { __html: n.html } });
};

const No = ({ n, t, fps }) => {
  if (n.tag === 'video') {
    return (
      <Sequence from={Math.round(n.inicio * fps)} durationInFrames={Math.max(1, Math.round((n.fim - n.inicio) * fps))} layout="none">
        <OffthreadVideo className={n.classe} src={staticFile(n.src)} startFrom={Math.round((n.inicioNoArquivo || 0) * fps)} muted />
      </Sequence>
    );
  }
  if (n.tag === 'img') return <Img className={n.classe} src={staticFile(n.src)} />;

  const style = {};
  if (n.inicio !== undefined) style.visibility = t >= n.inicio && t < n.fim ? 'visible' : 'hidden';
  if (n.tweens?.length) {
    const c = estadoParaCss(estadoEm(n.tweens, t));
    Object.assign(style, { opacity: c.opacity, transform: c.transform, filter: c.filter });
    if (n.tweens.some((x) => 'p' in x.para)) style['--p'] = c.p;
  }
  const props = { id: n.id, className: n.classe, style };
  if (n.rig) return <Ator n={n} t={t} props={props} />;
  if (n.contador) return React.createElement(n.tag, { ...props, dangerouslySetInnerHTML: { __html: formatarNumero(contadorEm(n.contador, t), n.contador) } });
  if (n.html !== undefined && !n.filhos) return React.createElement(n.tag, { ...props, dangerouslySetInnerHTML: { __html: n.html } });
  return React.createElement(n.tag, props, (n.filhos || []).map((f) => <No key={f.id} n={f} t={t} fps={fps} />));
};

const Legendas = ({ plano, t }) => {
  const l = legendaEm(plano.legendas, t);
  if (!l) return <div id="legendas" />;
  return (
    <div id="legendas">
      {l.pagina.palavras.map((w, i) => (
        <span key={i} className={'lw' + (i === l.ativa ? ' ativa' : i > l.ativa ? ' futura' : '')}
          style={w.enfase ? { color: 'var(--destaque)' } : undefined} dangerouslySetInnerHTML={{ __html: w.txt + ' ' }} />
      ))}
    </div>
  );
};

export const Reel = ({ plano }) => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const [h] = useState(() => delayRender('fontes'));
  useEffect(() => {
    document.fonts.ready.then(() => continueRender(h)).catch(() => continueRender(h));
  }, [h]);

  if (!plano) return <AbsoluteFill style={{ background: '#111', color: '#fff', fontSize: 50, padding: 80 }}>Rode via motor/render.mjs --motor remotion</AbsoluteFill>;

  const t = frame / fps;
  const fx = plano.efeitos;
  const f8 = frame % 8;
  const k = t / plano.duracao;

  return (
    <div id="stage">
      <style>{`@import url('${plano.fontesUrl}');\n${plano.css}`}</style>
      {fx.luz !== false && <div id="luz" className="global" style={{ transform: `translate(${Math.sin(k * Math.PI * 2) * 18}%, ${-20 + k * 40}%)` }} />}
      {plano.cenas.map((c) => <No key={c.id} n={c} t={t} fps={fps} />)}
      {plano.globais.map((g) => <No key={g.id} n={g} t={t} fps={fps} />)}
      <Legendas plano={plano} t={t} />
      {fx.letterbox && (<><div className="barra" style={{ top: 0 }} /><div className="barra" style={{ bottom: 0 }} /></>)}
      {fx.vinheta && <div id="vinheta" className="global" />}
      {fx.grao && <div id="grao" className="global" style={{ transform: `translate(${((f8 * 37) % 100) - 50}px, ${((f8 * 61) % 100) - 50}px)` }} />}
      {fx.barraProgresso && <div id="progresso" style={{ width: `${Math.min(1, k) * 100}%` }} />}
      {plano.marca?.handle && <div id="marca">{plano.marca.handle}</div>}
      {(plano.audiosTodos || []).map((a, i) => (
        <Sequence key={i} from={Math.round((a.inicio || 0) * fps)} layout="none">
          <Audio
            src={staticFile(a.src)}
            volume={(f) =>
              a.papel === 'musica'
                ? (a.volume ?? 1) * interpolate(f / fps, [0, 0.4, plano.duracao - 1.5, plano.duracao], [0, 1, 1, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' })
                : a.volume ?? 1
            }
          />
        </Sequence>
      ))}
    </div>
  );
};
