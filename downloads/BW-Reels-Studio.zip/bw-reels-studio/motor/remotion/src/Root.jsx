import React from 'react';
import { Composition } from 'remotion';
import { Reel } from './Reel.jsx';

// O plano vem de motor/render.mjs via --props (render/plano.json do projeto).
export const Root = () => (
  <Composition
    id="Reel"
    component={Reel}
    width={1080}
    height={1920}
    fps={30}
    durationInFrames={150}
    defaultProps={{ plano: null }}
    calculateMetadata={({ props }) =>
      props.plano
        ? {
            durationInFrames: Math.ceil(props.plano.duracao * props.plano.fps),
            fps: props.plano.fps,
            width: props.plano.largura,
            height: props.plano.altura,
          }
        : {}
    }
  />
);
