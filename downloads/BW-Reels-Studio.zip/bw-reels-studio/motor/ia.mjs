// BW IA — escolhe e reveza as IAs do BW Reels Assistente.
//   BW IA FREE      : só IAs com cota grátis; acabou a cota de uma hoje → passa para a próxima sozinho.
//   BW IA PRO       : a IA paga escolhida pelo usuário (melhor raciocínio).
//   BW IA ECONOMIZE : tarefa leve (ganchos) nas grátis, tarefa pesada (roteiro) na paga; uma cobre a outra se faltar.
// As chaves ficam SÓ neste computador (~/.bw-reels/ias.json) e nunca são devolvidas para a tela.
// Provedores falam o formato "OpenAI compatível" (/models e /chat/completions); o Claude usa o Claude Code instalado.
import { readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { join } from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { tmpdir } from 'node:os';
import { PASTA } from './conta.mjs';

const WIN = process.platform === 'win32';
const CLAUDE = process.env.BWREELS_CLAUDE || 'claude';
const ARQ = join(PASTA, 'ias.json');
const FORA = /embed|tts|image|audio|whisper|guard|realtime|transcri|moderation|dall|sora|veo|imagen|aqa|learnlm|robotics|computer-use/i;

export const PROVEDORES = [
  { id: 'groq', nome: 'Groq', tipo: 'gratis', base: 'https://api.groq.com/openai/v1', site: 'https://console.groq.com/keys', prefere: [/gpt-oss-120b/, /llama-3\.3-70b/, /70b/] },
  { id: 'gemini', nome: 'Google Gemini', tipo: 'gratis', base: 'https://generativelanguage.googleapis.com/v1beta/openai', site: 'https://aistudio.google.com/apikey', prefere: [/flash-latest$/, /flash$/, /flash/] },
  { id: 'openrouter', nome: 'OpenRouter (modelos grátis)', tipo: 'gratis', base: 'https://openrouter.ai/api/v1', site: 'https://openrouter.ai/keys', so: /:free$/, prefere: [/llama-3\.3-70b/, /gemini/, /deepseek/] },
  { id: 'local', nome: 'IA no computador (Ollama)', tipo: 'gratis', local: true, base: 'http://127.0.0.1:11434/v1', site: 'https://ollama.com/download', prefere: [/^gemma3/, /^gemma/, /^llama3/, /^qwen/] },
  { id: 'claude', nome: 'Claude (seu plano)', tipo: 'pago', cli: true },
  { id: 'openai', nome: 'ChatGPT / OpenAI', tipo: 'pago', base: 'https://api.openai.com/v1', site: 'https://platform.openai.com/api-keys', so: /^(gpt|o\d|chatgpt)/, prefere: [/^gpt-5(\.\d+)?$/, /^gpt-5/, /^gpt-4\.1$/, /^gpt-4o$/] },
];
const base = (p) => (process.env.BWREELS_IA_TESTE ? `${process.env.BWREELS_IA_TESTE}/${p.id}` : p.base);
const hoje = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

function ler() {
  let c = {}; try { c = JSON.parse(readFileSync(ARQ, 'utf8')); } catch { /* primeira vez */ }
  c.chaves ||= {}; if (!c.uso || c.uso.dia !== hoje()) c.uso = { dia: hoje(), por: {} };
  return c;
}
function gravar(c) { mkdirSync(PASTA, { recursive: true }); writeFileSync(ARQ, JSON.stringify(c, null, 2)); }
function marcar(id, { pedido, esgotado }) {
  const c = ler(); const u = (c.uso.por[id] ||= { pedidos: 0 });
  if (pedido) u.pedidos++; if (esgotado) u.esgotado = true; gravar(c);
}

let temClaude = null;
export function claudeDisponivel() {
  if (temClaude === null) { try { const r = spawnSync(CLAUDE, ['--version'], { encoding: 'utf8', shell: WIN, timeout: 15000 }); temClaude = r.status === 0 ? (r.stdout || '').trim().split('\n')[0] || 'instalado' : false; } catch { temClaude = false; } }
  return temClaude;
}

// IA local (Ollama): sem chave e sem cota. Confere se o programa está aberto e quais modelos já foram baixados.
let LOCAL = [];
export async function detectarLocal() {
  const p = PROVEDORES.find((x) => x.local);
  try { const r = await fetch(base(p) + '/models', { headers: { Authorization: 'Bearer ollama' }, signal: AbortSignal.timeout(1500) }); const j = await r.json(); LOCAL = (j.data || []).map((m) => String(m.id)).filter((m) => m && !FORA.test(m)); }
  catch { LOCAL = []; }
  return LOCAL;
}

export function status() {
  const c = ler();
  const lista = PROVEDORES.map((p) => {
    const k = c.chaves[p.id], u = c.uso.por[p.id] || {};
    if (p.local) { const modelo = LOCAL.includes(k?.modelo) ? k.modelo : p.prefere.map((re) => LOCAL.find((m) => re.test(m))).find(Boolean) || LOCAL[0] || '';
      return { id: p.id, nome: p.nome, tipo: p.tipo, local: true, cli: false, site: p.site, disponivel: !!modelo, configurada: false, final: '', modelo, modelos: LOCAL, pedidosHoje: u.pedidos || 0, esgotadoHoje: false }; }
    const disponivel = p.cli ? !!claudeDisponivel() : !!(k && k.chave && k.modelo);
    return { id: p.id, nome: p.nome, tipo: p.tipo, cli: !!p.cli, site: p.site || '', disponivel, configurada: !!(k && k.chave), final: k?.chave ? '…' + k.chave.slice(-4) : '',
      modelo: k?.modelo || '', modelos: k?.modelos || [], pedidosHoje: u.pedidos || 0, esgotadoHoje: !!u.esgotado };
  });
  const pagos = lista.filter((p) => p.tipo === 'pago' && p.disponivel);
  const pro = pagos.find((p) => p.id === c.pro) || pagos[0] || null;
  return { lista, pro: pro?.id || '' };
}

async function http(p, caminho, chave, corpo) {
  let r;
  try {
    r = await fetch(base(p) + caminho, { method: corpo ? 'POST' : 'GET', headers: { Authorization: 'Bearer ' + chave, 'Content-Type': 'application/json' }, body: corpo ? JSON.stringify(corpo) : undefined, signal: AbortSignal.timeout(p.local ? 420000 : 120000) });
  } catch (e) { throw new Error(e.name === 'TimeoutError' ? 'demorou demais' : 'sem conexão com a internet ou serviço fora do ar'); }
  const t = await r.text();
  if (r.ok) { try { return JSON.parse(t); } catch { throw new Error('resposta fora do formato'); } }
  const e = new Error(r.status === 401 || r.status === 403 && !/quota|limit|credit|billing/i.test(t) ? 'a chave não foi aceita' : r.status === 429 || r.status === 402 || /quota|rate.?limit|credit|billing/i.test(t) ? 'a cota de hoje acabou' : `erro ${r.status}`);
  e.esgotou = e.message === 'a cota de hoje acabou'; throw e;
}

// Guarda a chave digitada pelo usuário, confere no serviço e escolhe o melhor modelo disponível.
export async function salvarChave(id, chave) {
  const p = PROVEDORES.find((x) => x.id === id && !x.cli); if (!p) throw new Error('IA desconhecida');
  chave = String(chave || '').trim(); if (chave.length < 8) throw new Error('cole a chave inteira');
  const r = await http(p, '/models', chave);
  let ids = (r.data || r.models || []).map((m) => String(m.id || m.name || '')).filter((m) => m && !FORA.test(m));
  if (p.so) ids = ids.filter((m) => p.so.test(m.replace(/^models\//, '')));
  if (!ids.length) throw new Error('a chave funcionou, mas não achei modelo de texto disponível');
  const modelo = p.prefere.map((re) => ids.find((m) => re.test(m.replace(/^models\//, '')))).find(Boolean) || ids[0];
  const c = ler(); c.chaves[id] = { chave, modelo, modelos: ids.slice(0, 60) }; gravar(c);
  return status();
}
export function trocarModelo(id, modelo) { const c = ler(); if (id === 'local' && LOCAL.includes(modelo)) { c.chaves.local = { modelo }; gravar(c); } else if (c.chaves[id]?.modelos?.includes(modelo)) { c.chaves[id].modelo = modelo; gravar(c); } return status(); }
export function removerChave(id) { const c = ler(); delete c.chaves[id]; gravar(c); return status(); }
export function escolherPro(id) { const c = ler(); c.pro = id; gravar(c); return status(); }

function extrairJson(texto) {
  const i = texto.indexOf('{'), f = texto.lastIndexOf('}');
  if (i < 0 || f <= i) throw new Error('respondeu fora do formato');
  try { return JSON.parse(texto.slice(i, f + 1)); } catch { throw new Error('respondeu fora do formato'); }
}
async function viaHttp(p, prompt) {
  const k = p.local ? { chave: 'ollama', modelo: status().lista.find((x) => x.id === 'local').modelo } : ler().chaves[p.id];
  const r = await http(p, '/chat/completions', k.chave, { model: k.modelo, messages: [{ role: 'user', content: prompt }] });
  return extrairJson(String(r.choices?.[0]?.message?.content || ''));
}
function viaClaude(prompt, modelo) {
  return new Promise((ok, falha) => {
    const p = spawn(CLAUDE, ['-p', '--output-format', 'json', '--model', modelo, '--max-turns', '2'], { shell: WIN, cwd: tmpdir(), windowsHide: true });
    let out = '', err = '';
    const relogio = setTimeout(() => { p.kill(); falha(new Error('demorou demais')); }, 180000);
    p.stdout.on('data', (d) => { out += d; }); p.stderr.on('data', (d) => { err += d; });
    p.on('error', (e) => { clearTimeout(relogio); falha(new Error('não abriu: ' + e.message)); });
    p.on('close', (cod) => {
      clearTimeout(relogio);
      const limite = /limit|credit|quota/i.test(err + out);
      if (cod !== 0 && !out.trim()) { const e = new Error(/login|auth/i.test(err) ? 'pediu login (abra o Claude Code e entre na conta)' : limite ? 'a cota de hoje acabou' : 'não respondeu'); e.esgotou = limite && !/login|auth/i.test(err); return falha(e); }
      try {
        let texto = out.trim();
        try { const env = JSON.parse(texto); if (env && typeof env.result === 'string') { if (env.is_error) { const e = new Error(limite ? 'a cota de hoje acabou' : env.result.slice(0, 120)); e.esgotou = limite; return falha(e); } texto = env.result; } } catch { /* já é texto */ }
        ok(extrairJson(texto));
      } catch (e) { falha(e); }
    });
    p.stdin.write(prompt); p.stdin.end();
  });
}

export function fila(modo, papel) {
  const s = status(), ok = s.lista.filter((p) => p.disponivel && !p.esgotadoHoje);
  const gratis = ok.filter((p) => p.tipo === 'gratis').sort((a, b) => !!a.local - !!b.local); // a do computador fica por último: nunca acaba, mas é mais lenta
  const pagos = ok.filter((p) => p.tipo === 'pago').sort((a, b) => (b.id === s.pro) - (a.id === s.pro));
  if (modo === 'free') return gratis;
  if (modo === 'pro') return pagos.filter((p) => p.id === s.pro);
  return papel === 'forte' ? [...pagos, ...gratis] : [...gratis, ...pagos];
}

// Um pedido = uma resposta em JSON. Devolve também qual IA respondeu e quem foi pulado no caminho.
export async function pedir(prompt, { modo = 'economize', papel = 'leve' } = {}) {
  await detectarLocal();
  const f = fila(modo, papel), pulos = [];
  if (!f.length) throw new Error(modo === 'free' ? 'as IAs grátis conectadas já usaram a cota de hoje (ou nenhuma está conectada)' : 'nenhuma IA disponível neste modo — confira em Minhas IAs');
  for (const p of f) {
    try {
      const json = p.cli ? await viaClaude(prompt, papel === 'forte' ? 'opus' : 'sonnet') : await viaHttp(PROVEDORES.find((x) => x.id === p.id), prompt);
      marcar(p.id, { pedido: true });
      return { json, usada: p.nome, pulos };
    } catch (e) { if (e.esgotou) marcar(p.id, { esgotado: true }); pulos.push(`${p.nome}: ${e.message}`); }
  }
  throw new Error(pulos.join(' · '));
}
