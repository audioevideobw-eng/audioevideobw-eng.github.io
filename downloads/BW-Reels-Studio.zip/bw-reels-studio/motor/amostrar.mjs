#!/usr/bin/env node
// Revisão barata: gera UMA imagem (folha de contato) com N quadros do vídeo.
// O Claude olha essa imagem em vez de assistir o vídeo — custa poucos tokens.
// Uso: node motor/amostrar.mjs video.mp4 [--quadros 8] [--tempos 0.5,2,4.2]

import { spawnSync } from 'node:child_process';
import { resolve, dirname, basename, join } from 'node:path';
import { mkdtempSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';

const args = process.argv.slice(2);
const video = resolve(args[0]);
const opt = (n, d) => { const i = args.indexOf(`--${n}`); return i >= 0 ? args[i + 1] : d; };
const dur = parseFloat(spawnSync('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', video]).stdout.toString());
const n = parseInt(opt('quadros', '8'), 10);
const tempos = opt('tempos') ? opt('tempos').split(',').map(Number) : Array.from({ length: n }, (_, i) => ((i + 0.5) * dur) / n);
const tmp = mkdtempSync(join(tmpdir(), 'amostra-'));
tempos.forEach((t, i) => {
  spawnSync('ffmpeg', ['-y', '-loglevel', 'error', '-ss', String(t), '-i', video, '-frames:v', '1',
    '-vf', `scale=-2:480,drawtext=text='${t.toFixed(1)}s':x=10:y=10:fontsize=22:fontcolor=white:box=1:boxcolor=black@0.6`, join(tmp, `f${String(i).padStart(2, '0')}.png`)]);
});
const cols = Math.min(tempos.length, 4);
const saida = join(dirname(video), basename(video).replace(/\.\w+$/, '') + '-amostra.jpg');
spawnSync('ffmpeg', ['-y', '-loglevel', 'error', '-pattern_type', 'glob', '-i', join(tmp, 'f*.png'),
  '-vf', `tile=${cols}x${Math.ceil(tempos.length / cols)}:padding=6:color=black`, '-q:v', '4', saida]);
rmSync(tmp, { recursive: true, force: true });
console.log(saida);
