#!/usr/bin/env node
// LEGENDA AUTOMÁTICA, sem internet.
//   node motor/legendar.mjs projetos/<nome>/roteiro.json   → ouve a narração e as filmagens do reel e grava as palavras no roteiro
//   node motor/legendar.mjs video.mp4                      → gera video.srt e video.transcricao.json ao lado do arquivo
// Opções: --sem-som (não liga o som das filmagens)  --palavras 3 (palavras por vez na tela)
import { readFileSync, writeFileSync, existsSync, copyFileSync } from 'node:fs';
import { dirname, join, resolve, basename, extname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { criarPlano } from './plano.mjs';
import { transcrever, srtDe, estado, temSom } from './transcrever.mjs';

const EH_VIDEO = /\.(mp4|mov|webm|m4v|mkv)$/i;

/** Legenda um roteiro. Devolve o resumo do que fez (não imprime nada). */
export async function legendarRoteiro(arqRoteiro, { ligarSom = true, palavrasPorPagina, aviso = () => {} } = {}) {
  const roteiro = JSON.parse(readFileSync(arqRoteiro, 'utf8'));
  const proj = dirname(arqRoteiro);
  const feito = { fontes: [], palavras: 0, somLigado: [], semSom: [], avisos: [] };
  const au = roteiro.audio || {};
  // 1) liga o som das filmagens que têm fala (se não houver narração)
  if (ligarSom && !au.narracao) {
    (roteiro.cenas || []).forEach((c, i) => {
      if (!c.midia || !EH_VIDEO.test(c.midia) || c.somDoVideo !== undefined) return;
      const arq = join(proj, c.midia);
      if (existsSync(arq) && temSom(arq)) { c.somDoVideo = true; feito.somLigado.push(i + 1); } else feito.semSom.push(i + 1);
    });
  }
  const plano = criarPlano(roteiro);
  const fontes = [];
  if (au.narracao) fontes.push({ nome: 'narração', arquivo: join(proj, au.narracao), de: 0, dur: Math.max(0, plano.duracao - (au.inicioNarracao || 0)), desloc: au.inicioNarracao || 0 });
  (roteiro.cenas || []).forEach((c, i) => {
    if (c.somDoVideo && c.midia && EH_VIDEO.test(c.midia)) {
      const pc = plano.cenas[i];
      fontes.push({ nome: `cena ${i + 1}`, arquivo: join(proj, c.midia), de: c.inicioNoArquivo || 0, dur: pc.fim - pc.inicio, desloc: pc.inicio });
    }
  });
  if (!fontes.length) throw new Error('Este reel não tem fala para legendar: sem narração e sem filmagem com som. (Reel só de texto já mostra o texto na tela.)');
  const todas = [];
  for (const f of fontes) {
    aviso(`${f.nome}: ${basename(f.arquivo)}`);
    const r = await transcrever(f.arquivo, { de: f.de, dur: f.dur, aviso });
    const ws = r.palavras.map((w) => ({ palavra: w.palavra, inicio: +(w.inicio + f.desloc).toFixed(3), fim: +(Math.min(w.fim, f.dur) + f.desloc).toFixed(3) }))
      .filter((w) => w.inicio < f.desloc + f.dur);
    if (!ws.length) feito.avisos.push(`${f.nome}: não ouvi fala nesse trecho`);
    feito.fontes.push({ nome: f.nome, palavras: ws.length });
    todas.push(...ws);
  }
  todas.sort((a, b) => a.inicio - b.inicio);
  if (!todas.length) throw new Error('Não encontrei fala em nenhum trecho deste reel.');
  const antes = arqRoteiro.replace(/\.json$/i, '.antes-da-legenda.json');
  if (!existsSync(antes)) copyFileSync(arqRoteiro, antes);
  roteiro.legendas = { ...(roteiro.legendas || {}), ativas: true, palavras: todas };
  if (palavrasPorPagina) roteiro.legendas.palavrasPorPagina = palavrasPorPagina;
  writeFileSync(arqRoteiro, JSON.stringify(roteiro, null, 2));
  writeFileSync(join(proj, 'legendas.srt'), srtDe(todas));
  feito.palavras = todas.length; feito.copia = antes; feito.srt = join(proj, 'legendas.srt');
  feito.texto = todas.map((w) => w.palavra).join(' ');
  return feito;
}

/** Legenda um arquivo solto de vídeo ou áudio. */
export async function legendarArquivo(arquivo, { aviso = () => {} } = {}) {
  const r = await transcrever(arquivo, { aviso });
  const base = arquivo.slice(0, arquivo.length - extname(arquivo).length);
  writeFileSync(base + '.srt', srtDe(r.palavras));
  writeFileSync(base + '.transcricao.json', JSON.stringify({ arquivo: basename(arquivo), duracao: +r.duracao.toFixed(2), texto: r.texto, palavras: r.palavras }, null, 2));
  return { ...r, srt: base + '.srt', json: base + '.transcricao.json' };
}

if (process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url))) {
  const args = process.argv.slice(2);
  const alvo = args.find((a) => !a.startsWith('--'));
  const n = args.indexOf('--palavras') >= 0 ? Number(args[args.indexOf('--palavras') + 1]) : undefined;
  const sair = (msg) => { console.error('\n  ' + msg + '\n'); process.exit(1); };
  if (!alvo) sair('Arraste um vídeo, um áudio ou o roteiro.json de um projeto para cima do LEGENDAR.bat.');
  const arq = resolve(alvo);
  if (!existsSync(arq)) sair('Não achei o arquivo: ' + arq);
  const e = estado();
  if (!e.pronto) sair('A legenda automática ainda não está instalada. Dê dois cliques no INSTALAR-LEGENDAS.bat (uma vez só, ~500 MB).');
  const aviso = (m) => console.log('  · ' + m);
  const t0 = Date.now();
  try {
    if (/\.json$/i.test(arq)) {
      console.log('\n  Legendando o reel (tudo neste computador, sem internet)…');
      const f = await legendarRoteiro(arq, { ligarSom: !args.includes('--sem-som'), palavrasPorPagina: n, aviso });
      console.log(`\n  ✓ ${f.palavras} palavras legendadas em ${((Date.now() - t0) / 1000).toFixed(0)} s.`);
      if (f.somLigado.length) console.log(`  ✓ Liguei o som da filmagem na(s) cena(s) ${f.somLigado.join(', ')}.`);
      f.avisos.forEach((a) => console.log('  ⚠ ' + a));
      console.log(`  Texto ouvido: "${f.texto.slice(0, 220)}${f.texto.length > 220 ? '…' : ''}"`);
      console.log(`  Confira e corrija nomes próprios em: ${f.srt}\n  Cópia do roteiro de antes: ${f.copia}\n  Agora é só renderizar.\n`);
    } else {
      console.log('\n  Transcrevendo (tudo neste computador, sem internet)…');
      const r = await legendarArquivo(arq, { aviso });
      console.log(`\n  ✓ ${r.palavras.length} palavras em ${((Date.now() - t0) / 1000).toFixed(0)} s (${r.duracao.toFixed(0)} s de som).`);
      console.log(`  Legenda: ${r.srt}\n  Palavras com tempo: ${r.json}\n`);
    }
  } catch (err) { sair('Não deu: ' + err.message); }
}
