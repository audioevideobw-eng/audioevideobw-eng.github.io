#!/usr/bin/env python3
"""Gera o motor para o navegador (Brightway › BW Reels Pro) a partir dos MESMOS arquivos do Studio.
Uso: python3 motor/gerar-motor-web.py <saida.js>   — o resultado define window.BWReelsMotor (script clássico)."""
import json, os, re, sys

AQUI = os.path.dirname(os.path.abspath(__file__))
ler = lambda n: open(os.path.join(AQUI, n), encoding="utf-8").read()
semExport = lambda s: re.sub(r"^export ", "", s, flags=re.M)
semImport = lambda s: re.sub(r"^import .*?;\n", "", s, flags=re.M)

anim = semExport(ler("anim.mjs"))
estilos = semExport(ler("estilos.mjs"))
plano = semExport(semImport(ler("plano.mjs")))
html = ler("html.mjs")
html = semImport(html)
html = re.sub(r"^const ANIM = readFileSync\(.*?\n", lambda m: "const ANIM = " + json.dumps(anim) + ";\n", html, flags=re.M)
html = semExport(html)
validar = ler("validar.mjs")
validar = validar[:validar.index("\nif (import.meta.url")]
validar = semExport(semImport(validar))
validar = validar.replace("existsSync(", "(typeof existsSync === 'function' ? existsSync : () => true)(")

saida = f"""/* BW Reels Pro — motor de vídeo (prévia no navegador). GERADO por bw-reels-studio/motor/gerar-motor-web.py
   a partir dos mesmos arquivos do BW Reels Studio: não edite aqui, edite lá e gere de novo. */
(function () {{
"use strict";
{anim}
{estilos}
{plano}
{html}
{validar}
window.BWReelsMotor = {{ criarPlano: criarPlano, validarRoteiro: validarRoteiro, construirHtml: construirHtml, css: css, ESTILOS: ESTILOS, FORMATOS: FORMATOS,
  estadoEm: estadoEm, legendaEm: legendaEm, versao: 1 }};
}})();
"""
open(sys.argv[1], "w", encoding="utf-8").write(saida)
print("ok", len(saida))
