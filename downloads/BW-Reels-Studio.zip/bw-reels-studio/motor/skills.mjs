// BW SKILL — skills testadas e validadas pela Brightway, instaladas por um assistente passo a passo dentro do app BW.
// As skills vêm DENTRO do pacote do app (pasta bw-skills/) e chegam pelas atualizações; só quem entrou com a conta usa
// (a ponte do app recusa estas ações sem login). Cada skill é um modelo com {{CAMPOS}} preenchidos com as pastas e a
// marca da pessoa, e é gravada na pasta de skills da IA escolhida (formato aberto SKILL.md: Claude, Codex, Gemini…).
import { readFileSync, writeFileSync, existsSync, mkdirSync, rmSync, readdirSync, statSync } from 'node:fs';
import { join, resolve, sep, basename } from 'node:path';
import { homedir } from 'node:os';
import { spawnSync } from 'node:child_process';
import { RAIZ, conta } from './assistente-nucleo.mjs';

const WIN = process.platform === 'win32';
const PASTA_SKILLS = join(RAIZ, 'bw-skills');
const casa = () => homedir();
const arqRegistro = () => join(conta.PASTA, 'skills.json');
const ID_OK = /^bw-[a-z0-9-]{2,60}$/;

export const IAS = [
  { id: 'claude', nome: 'Claude (Claude Code)', pasta: () => join(casa(), '.claude', 'skills'), cmd: 'claude', marca: () => join(casa(), '.claude'),
    como: 'Abra o Claude Code no PC (ou o app do Claude com acesso ao computador) e peça normalmente — a skill é escolhida sozinha.' },
  { id: 'codex', nome: 'ChatGPT (Codex no PC)', pasta: () => join(casa(), '.codex', 'skills'), cmd: 'codex', marca: () => join(casa(), '.codex'),
    como: 'Abra o Codex no PC (terminal ou app) e peça normalmente.' },
  { id: 'gemini', nome: 'Gemini (Gemini CLI)', pasta: () => join(casa(), '.gemini', 'skills'), cmd: 'gemini', marca: () => join(casa(), '.gemini'),
    como: 'Abra o Gemini CLI no PC e peça normalmente.' },
  { id: 'outra', nome: 'Outra IA ou IA no navegador', pasta: null,
    como: 'Gera um arquivo .zip em Downloads. No Claude do navegador: Configurações → Capacidades → Skills → enviar o .zip. Em outras IAs, coloque a pasta onde ela lê as skills (SKILL.md).' },
];

/* ---------- leitura ---------- */
function lerJSON(arq, padrao) { try { return JSON.parse(readFileSync(arq, 'utf8')); } catch { return padrao; } }
function registro() { return lerJSON(arqRegistro(), {}); }
function salvarRegistro(r) { mkdirSync(conta.PASTA, { recursive: true }); writeFileSync(arqRegistro(), JSON.stringify(r, null, 2)); }
export function catalogo() { return lerJSON(join(PASTA_SKILLS, 'catalogo.json'), { skills: [] }).skills.filter((s) => ID_OK.test(s.id)); }
function achar(id) { const s = catalogo().find((x) => x.id === id); if (!s) throw new Error('skill não encontrada'); return s; }
function padroes(s) {
  const p = {};
  for (const c of s.campos) if (c.padraoPC === 'projetos') p[c.id] = join(casa(), 'Videos', 'BW Animacoes');
  return p;
}

export function listar() {
  const reg = registro();
  return catalogo().map((s) => {
    const r = reg[s.id];
    return { ...s, padroes: padroes(s), instalada: r ? { versao: r.versao, ias: r.ias, data: r.data, valores: r.valores } : null,
      temNova: !!(r && r.versao !== s.versao), tutorial: tutorial(s.id) };
  });
}
export function tutorial(id) {
  if (!ID_OK.test(id)) throw new Error('skill inválida');
  try { return readFileSync(join(PASTA_SKILLS, id, 'TUTORIAL.md'), 'utf8'); } catch { return ''; }
}

/* ---------- PC: IAs e requisitos ---------- */
function temComando(cmd) {
  if (process.env.BWREELS_TESTE) return false;   // no teste só valem as pastas simuladas
  const r = spawnSync(WIN ? 'where' : 'which', [cmd], { encoding: 'utf8', windowsHide: true });
  return r.status === 0 && !!(r.stdout || '').trim();
}
export function ias() {
  return IAS.map((i) => ({ id: i.id, nome: i.nome, como: i.como, instalada: i.id === 'outra' ? true : (existsSync(i.marca()) || temComando(i.cmd)), recomendada: i.id === 'claude' }));
}
function programaEdicao() {
  if (!WIN) return null;
  const pf = [process.env.ProgramFiles || 'C:\\Program Files', process.env.LOCALAPPDATA || ''];
  const achados = [];
  try { for (const n of readdirSync(join(pf[0], 'Adobe'))) if (/^Adobe Premiere Pro/i.test(n)) achados.push(n); } catch { /* sem Adobe */ }
  if (existsSync(join(pf[0], 'Blackmagic Design', 'DaVinci Resolve'))) achados.push('DaVinci Resolve');
  if (pf[1] && existsSync(join(pf[1], 'CapCut'))) achados.push('CapCut');
  return achados;
}
export function requisitos(id) {
  const s = achar(id), lista = [];
  for (const r of s.requisitos || []) {
    if (r === 'ffmpeg') {
      const ok = spawnSync('ffmpeg', ['-version'], { stdio: 'ignore', windowsHide: true, shell: WIN }).status === 0;
      lista.push({ id: r, nome: 'Gerador de vídeo (FFmpeg)', ok, detalhe: ok ? 'instalado' : 'não encontrado', como: 'Rode o INSTALAR.bat do BW (ele instala o FFmpeg).' });
    } else if (r === 'editor') {
      const a = programaEdicao();
      lista.push({ id: r, nome: 'Programa de edição', ok: a === null ? null : a.length > 0, opcional: true,
        detalhe: a === null ? 'confira você mesmo' : a.length ? a.join(', ') : 'nenhum encontrado',
        como: 'A skill funciona melhor com o Premiere Pro. Sem programa de edição ela ainda faz o trabalho por arquivo (ffmpeg).' });
    } else if (r === 'motor_bw') {
      const ok = existsSync(join(RAIZ, 'motor', 'animar.mjs'));
      lista.push({ id: r, nome: 'Motor de vídeo do app BW', ok, detalhe: ok ? 'já vem com o app' : 'faltando', como: 'Instale o BW de novo pelo BW-Setup.exe.' });
    } else if (r === 'ia_agente') {
      const l = ias().filter((i) => i.instalada && i.id !== 'outra');
      lista.push({ id: r, nome: 'IA que trabalha no computador', ok: l.length > 0, opcional: true, detalhe: l.length ? l.map((i) => i.nome).join(', ') : 'nenhuma encontrada',
        como: 'No app BW → MINHAS IAS → INSTALAR IAS RECOMENDADAS (instala o Claude Code). Também dá para usar o Codex ou o Gemini CLI.' });
    }
  }
  return { itens: lista, pronto: lista.every((i) => i.ok !== false || i.opcional) };
}

/* ---------- janela do Windows para escolher pasta ---------- */
export function escolherPasta(titulo) {
  if (process.env.BWREELS_PASTA_TESTE) return process.env.BWREELS_PASTA_TESTE;
  if (!WIN) throw new Error('A escolha de pasta por janela é só no Windows.');
  const t = String(titulo || 'Escolha a pasta').replace(/'/g, '').slice(0, 120);
  const ps = `Add-Type -AssemblyName System.Windows.Forms; $f = New-Object System.Windows.Forms.Form; $f.TopMost = $true; $d = New-Object System.Windows.Forms.FolderBrowserDialog; $d.Description = 'BW - ${t}'; $d.ShowNewFolderButton = $true; [Console]::OutputEncoding = [Text.Encoding]::UTF8; if ($d.ShowDialog($f) -eq 'OK') { Write-Output $d.SelectedPath }`;
  const r = spawnSync('powershell', ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-Command', ps], { encoding: 'utf8', windowsHide: true });
  return (r.stdout || '').trim() || null;
}

/* ---------- montar e instalar ---------- */
const hoje = () => { const d = new Date(), z = (n) => String(n).padStart(2, '0'); return `${z(d.getDate())}/${z(d.getMonth() + 1)}/${d.getFullYear()}`; };
function limparValores(s, valores) {
  const v = {};
  for (const c of s.campos) {
    let x = String((valores || {})[c.id] ?? '').replace(/[\r\n]+/g, ' ').replace(/\{\{|\}\}/g, '').trim().slice(0, 300);
    if (c.tipo === 'cor' && x && !/^#[0-9a-f]{6}$/i.test(x)) throw new Error(`Cor inválida em "${c.rotulo}".`);
    if (c.tipo === 'escolha' && x && !(c.opcoes || []).includes(x)) throw new Error(`Opção inválida em "${c.rotulo}".`);
    if (!x && c.padrao) x = c.padrao;
    if (!x && c.padraoPC) x = padroes(s)[c.id] || '';
    if (!x && c.obrigatorio) throw new Error(`Falta preencher: ${c.rotulo}`);
    if (c.tipo === 'pasta' && x) {
      x = resolve(x);
      if (!existsSync(x)) { if (c.padraoPC) mkdirSync(x, { recursive: true }); else throw new Error(`A pasta não existe: ${x}`); }
      if (!statSync(x).isDirectory()) throw new Error(`Não é uma pasta: ${x}`);
    }
    v[c.id] = x;
  }
  return v;
}
export function montar(id, valores) {
  const s = achar(id), v = limparValores(s, valores);
  const vars = { DATA: hoje(), VERSAO: s.versao, PASTA_BW: RAIZ };
  for (const c of s.campos) vars[c.id] = v[c.id] || c.vazio || 'não informado';
  const txt = readFileSync(join(PASTA_SKILLS, id, 'SKILL.md'), 'utf8').replace(/\{\{([A-Z_]+)\}\}/g, (m, k) => (k in vars ? vars[k] : m));
  const sobra = txt.match(/\{\{[A-Z_]+\}\}/);
  if (sobra) throw new Error('campo sem valor no modelo: ' + sobra[0]);
  return { skill: s, valores: v, texto: txt };
}

// .zip simples (sem compressão) — funciona igual em qualquer sistema, sem programa extra
const TAB = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = (b) => { let c = 0xffffffff; for (const x of b) c = TAB[(c ^ x) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
function zipar(arquivos) {
  const partes = [], central = []; let pos = 0;
  for (const [nome, conteudo] of arquivos) {
    const n = Buffer.from(nome, 'utf8'), d = Buffer.from(conteudo, 'utf8'), c = crc32(d);
    const h = Buffer.alloc(30); h.writeUInt32LE(0x04034b50, 0); h.writeUInt16LE(20, 4); h.writeUInt16LE(0x0800, 6); h.writeUInt32LE(c, 14); h.writeUInt32LE(d.length, 18); h.writeUInt32LE(d.length, 22); h.writeUInt16LE(n.length, 26);
    partes.push(h, n, d);
    const e = Buffer.alloc(46); e.writeUInt32LE(0x02014b50, 0); e.writeUInt16LE(20, 4); e.writeUInt16LE(20, 6); e.writeUInt16LE(0x0800, 8); e.writeUInt32LE(c, 16); e.writeUInt32LE(d.length, 20); e.writeUInt32LE(d.length, 24); e.writeUInt16LE(n.length, 28); e.writeUInt32LE(pos, 42);
    central.push(e, n); pos += 30 + n.length + d.length;
  }
  const cd = Buffer.concat(central), fim = Buffer.alloc(22);
  fim.writeUInt32LE(0x06054b50, 0); fim.writeUInt16LE(arquivos.length, 8); fim.writeUInt16LE(arquivos.length, 10); fim.writeUInt32LE(cd.length, 12); fim.writeUInt32LE(pos, 16);
  return Buffer.concat([...partes, cd, fim]);
}

export function instalar(id, { ias: escolhidas = [], valores = {} } = {}) {
  if (!ID_OK.test(id)) throw new Error('skill inválida');
  const alvo = [...new Set(escolhidas)].filter((x) => IAS.some((i) => i.id === x));
  if (!alvo.length) throw new Error('Escolha pelo menos uma IA.');
  const { skill, valores: v, texto } = montar(id, valores);
  const tut = tutorial(id);
  const cfg = JSON.stringify({ skill: id, versao: skill.versao, instalada: new Date().toISOString(), valores: v }, null, 2);
  const destinos = []; let zip = null;
  for (const ia of alvo) {
    const def = IAS.find((i) => i.id === ia);
    if (ia === 'outra') {
      const pasta = [join(casa(), 'Downloads'), casa()].find((p) => existsSync(p));
      zip = join(pasta, `BW-SKILL-${id}.zip`);
      writeFileSync(zip, zipar([[`${id}/SKILL.md`, texto], [`${id}/TUTORIAL.md`, tut], [`${id}/bw-config.json`, cfg]]));
      continue;
    }
    const base = def.pasta(), dest = join(base, id);
    if (!resolve(dest).startsWith(resolve(base) + sep)) throw new Error('pasta inválida');
    mkdirSync(dest, { recursive: true });
    writeFileSync(join(dest, 'SKILL.md'), texto); writeFileSync(join(dest, 'TUTORIAL.md'), tut); writeFileSync(join(dest, 'bw-config.json'), cfg);
    destinos.push(dest);
  }
  const reg = registro(); reg[id] = { versao: skill.versao, ias: alvo, destinos, zip, valores: v, data: new Date().toISOString() }; salvarRegistro(reg);
  return { destinos, zip, teste: conferir(id) };
}

// "teste rápido" depois de instalar: os arquivos estão lá, o nome bate com a pasta e nenhum campo ficou vazio
export function conferir(id) {
  const r = registro()[id]; if (!r) return [];
  const itens = r.destinos.map((d) => {
    let t = ''; try { t = readFileSync(join(d, 'SKILL.md'), 'utf8'); } catch { /* falta */ }
    const nome = (t.match(/^name:\s*"?([a-z0-9-]+)"?/m) || [])[1];
    return { onde: d, ok: !!t && nome === basename(d) && !/\{\{[A-Z_]+\}\}/.test(t) && existsSync(join(d, 'TUTORIAL.md')) };
  });
  if (r.zip) itens.push({ onde: r.zip, ok: existsSync(r.zip) && statSync(r.zip).size > 200 });
  return itens;
}

export function desinstalar(id) {
  if (!ID_OK.test(id)) throw new Error('skill inválida');
  const reg = registro(), r = reg[id]; if (!r) return { removidas: 0 };
  let n = 0;
  for (const d of r.destinos || []) {
    const ia = IAS.find((i) => i.pasta && resolve(d) === resolve(join(i.pasta(), id)));
    if (ia && basename(d) === id && existsSync(join(d, 'SKILL.md'))) { rmSync(d, { recursive: true, force: true }); n++; }
  }
  delete reg[id]; salvarRegistro(reg);
  return { removidas: n };
}
export function pastaInstalada(id) { const r = registro()[id]; return r && (r.destinos[0] || r.zip) || null; }
