// Núcleo do BW Reels Assistente (sem tela): checagem do PC, modos, modelos, IA em lote, prévia, projeto e render.
// A janela (motor/assistente.mjs + assistente/index.html) só chama as funções daqui.
import { readFileSync, writeFileSync, existsSync, mkdirSync, statfsSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { tmpdir } from 'node:os';
import vm from 'node:vm';
import { criarPlano } from './plano.mjs';
import { construirHtml } from './html.mjs';
import { validarRoteiro } from './validar.mjs';
import { ESTILOS } from './estilos.mjs';
import * as conta from './conta.mjs';

export const RAIZ = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const WIN = process.platform === 'win32';
const ARQ_PREFS = join(conta.PASTA, 'assistente.json');
const CLAUDE = process.env.BWREELS_CLAUDE || 'claude';

/* ---------- preferências e rascunho (para "continuar de onde parou") ---------- */
export function lerPrefs() { try { return JSON.parse(readFileSync(ARQ_PREFS, 'utf8')); } catch { return {}; } }
export function salvarPrefs(p) {
  mkdirSync(conta.PASTA, { recursive: true });
  const junto = { ...lerPrefs(), ...p };
  writeFileSync(ARQ_PREFS, JSON.stringify(junto, null, 2));
  return junto;
}

/* ---------- 1. checagem do PC ---------- */
function roda(cmd, args) {
  try { const r = spawnSync(cmd, args, { encoding: 'utf8', shell: WIN, timeout: 15000 }); return r.status === 0 ? (r.stdout || r.stderr || '').trim() : null; }
  catch { return null; }
}
export function checar() {
  const ff = roda('ffmpeg', ['-version']);
  const cl = roda(CLAUDE, ['--version']);
  let livreGB = null;
  try { const s = statfsSync(RAIZ); livreGB = Math.round((s.bavail * s.bsize) / 1e9); } catch { /* sem leitura */ }
  const itens = [
    { id: 'node', nome: 'Programa base (Node.js)', ok: true, detalhe: process.version },
    { id: 'ffmpeg', nome: 'Gerador de vídeo (FFmpeg)', ok: !!ff, detalhe: ff ? ff.split('\n')[0].replace(/ Copyright.*/, '') : 'não encontrado',
      comoResolver: 'Feche esta janela e dê dois cliques em INSTALAR.bat na pasta do BW Reels Studio.' },
    { id: 'disco', nome: 'Espaço no disco', ok: livreGB === null || livreGB >= 2, detalhe: livreGB === null ? 'não medido' : `${livreGB} GB livres`,
      comoResolver: 'Libere pelo menos 2 GB no disco para os vídeos.' },
    { id: 'claude', nome: 'Claude (roteiro com IA)', ok: !!cl, opcional: true, detalhe: cl ? cl.split('\n')[0] : 'não instalado — dá para usar o modo SEM IA',
      comoResolver: 'Opcional. Para ligar a IA: rode INSTALAR.bat e entre com a sua conta Claude (plano Pro ou Max).' },
  ];
  return { itens, pronto: itens.every((i) => i.ok || i.opcional), temClaude: !!cl, conta: conta.estado() };
}

/* ---------- 2. modos ---------- */
export function modos(temClaude) {
  const lista = [
    { id: 'qualidade', nome: 'QUALIDADE', icone: '★', precisaClaude: true,
      resumo: 'O melhor roteiro. Você escolhe entre 5 ganchos e a IA escreve e revisa.',
      gasto: 'Gasta mais do seu plano Claude (2 pedidos, modelo mais forte).', quando: 'Para vídeo importante: lançamento, anúncio, cliente grande.',
      pedidos: 2, modeloGanchos: 'sonnet', modeloRoteiro: 'opus', render: 'final' },
    { id: 'economico', nome: 'ECONÔMICO', icone: '⚡', precisaClaude: true,
      resumo: 'Rápido e bom. Um pedido só: a IA já entrega gancho e roteiro prontos.',
      gasto: 'Gasta pouco do seu plano Claude (1 pedido, modelo leve).', quando: 'Para o dia a dia: dicas, bastidores, avisos.',
      pedidos: 1, modeloRoteiro: 'sonnet', render: 'final' },
    { id: 'semia', nome: 'SEM IA (GRÁTIS)', icone: '✎', precisaClaude: false,
      resumo: 'Você escolhe um modelo pronto e troca os textos. Funciona sem conta Claude.',
      gasto: 'Não gasta nada.', quando: 'Quando você já sabe o que escrever ou não tem plano Claude.',
      pedidos: 0, render: 'final' },
  ];
  const recomendado = temClaude ? 'economico' : 'semia';
  return lista.map((m) => ({ ...m, disponivel: !m.precisaClaude || temClaude, recomendado: m.id === recomendado,
    motivo: m.id === recomendado ? (temClaude ? 'Recomendado: melhor equilíbrio entre resultado e gasto.' : 'Recomendado: o Claude não está instalado neste PC.') : '' }));
}

/* ---------- 3. modelos prontos (os mesmos da galeria do site) ---------- */
let GALERIA = null;
function galeria() {
  if (!GALERIA) { const ctx = { window: {} }; vm.runInNewContext(readFileSync(join(RAIZ, 'modelos', 'galeria-web.js'), 'utf8'), ctx); GALERIA = ctx.window.BWReelsModelos; }
  return GALERIA;
}
const CATS_OK = ['texto', 'graf', 'personagem'];
export function modelos() {
  const G = galeria();
  return {
    categorias: G.categorias.filter((c) => CATS_OK.includes(c.id)).map((c) => ({ id: c.id, nome: c.nome, desc: c.desc })),
    modelos: G.modelos.filter((m) => CATS_OK.includes(m.cat)).map((m) => ({ id: m.id, cat: m.cat, nome: m.nome, desc: m.desc, cenas: m.roteiro.cenas.length })),
    estilos: Object.keys(ESTILOS).map((id) => ({ id, nome: ESTILOS[id].nome || id })),
  };
}
const clonar = (o) => JSON.parse(JSON.stringify(o));
function aplicarMarca(r, b) {
  const h = (b.handle || '').trim(); const arroba = h ? (h.startsWith('@') ? h : '@' + h) : '';
  if (b.estilo && ESTILOS[b.estilo]) r.estilo = b.estilo;
  r.marca = { ...(r.marca || {}), handle: arroba || r.marca?.handle || '' };
  if (arroba) { const s = JSON.stringify(r).split('@seuperfil').join(arroba); Object.assign(r, JSON.parse(s)); }
  if (b.tema) r.titulo = b.tema;
  return r;
}
export function roteiroDoModelo(modeloId, briefing = {}) {
  const m = galeria().modelos.find((x) => x.id === modeloId);
  if (!m) throw new Error('modelo não encontrado: ' + modeloId);
  return aplicarMarca(clonar(m.roteiro), briefing);
}

/* ---------- 4. IA (Claude Code sem conversa: 1 pedido = 1 resposta em JSON) ---------- */
const TIPOS_IA = ['gancho', 'texto', 'lista', 'checklist', 'ranking', 'cta'];
const REGRAS = `Você é roteirista de Reels (vídeo vertical curto) em português do Brasil, tom direto e descontraído.
REGRAS: frases curtas (até 7 palavras na tela). NÃO invente números, estatísticas, pesquisas, nomes de clientes nem citações.
Só use um número se ele estiver no pedido do usuário. Responda SOMENTE com JSON válido, sem texto antes ou depois, sem markdown.`;
const FORMA_ROTEIRO = `"cenas": lista de 4 a 6 cenas. Tipos permitidos e campos:
 {"tipo":"gancho","duracao":3,"texto":"...","enfase":["palavra"],"chamada":"etiqueta curta"}
 {"tipo":"texto","duracao":3.5,"titulo":"...","subtitulo":"...","enfase":["palavra"]}
 {"tipo":"lista","duracao":5,"titulo":"...","itens":["até 4 itens curtos"]}
 {"tipo":"checklist","duracao":5,"titulo":"...","itens":["até 5 itens curtos"]}
 {"tipo":"ranking","duracao":5,"titulo":"...","itens":["1º lugar primeiro, até 5"]}
 {"tipo":"cta","duracao":3,"texto":"...","enfase":["palavra"],"acao":"o que fazer agora"}
A primeira cena é sempre "gancho" e a última é sempre "cta". "legenda": texto do post com 3 a 5 hashtags.`;

function pedirClaude(prompt, modelo) {
  return new Promise((ok, falha) => {
    const p = spawn(CLAUDE, ['-p', '--output-format', 'json', '--model', modelo, '--max-turns', '2'], { shell: WIN, cwd: tmpdir(), windowsHide: true });
    let out = '', err = '';
    const relogio = setTimeout(() => { p.kill(); falha(new Error('a IA demorou demais (3 min)')); }, 180000);
    p.stdout.on('data', (d) => { out += d; }); p.stderr.on('data', (d) => { err += d; });
    p.on('error', (e) => { clearTimeout(relogio); falha(new Error('não consegui abrir o Claude: ' + e.message)); });
    p.on('close', (cod) => {
      clearTimeout(relogio);
      if (cod !== 0 && !out.trim()) return falha(new Error(/login|auth|credit|limit/i.test(err) ? 'o Claude pediu login ou o limite do plano acabou' : 'o Claude não respondeu (' + (err.trim().split('\n').pop() || 'código ' + cod) + ')'));
      try {
        let texto = out.trim();
        try { const env = JSON.parse(texto); if (env && typeof env.result === 'string') { if (env.is_error) return falha(new Error(env.result.slice(0, 200))); texto = env.result; } } catch { /* já é texto */ }
        const i = texto.indexOf('{'), f = texto.lastIndexOf('}');
        if (i < 0 || f <= i) throw new Error('sem JSON');
        ok(JSON.parse(texto.slice(i, f + 1)));
      } catch { falha(new Error('a IA respondeu fora do formato')); }
    });
    p.stdin.write(prompt); p.stdin.end();
  });
}
const txt = (v, n = 90) => String(v ?? '').replace(/[*#`]/g, '').trim().slice(0, n);
function limparCenas(cenas) {
  const saida = [];
  for (const c of Array.isArray(cenas) ? cenas : []) {
    if (!c || !TIPOS_IA.includes(c.tipo)) continue;
    const n = { tipo: c.tipo, duracao: Math.min(8, Math.max(2.4, Number(c.duracao) || 3.5)) };
    if (['gancho', 'cta'].includes(c.tipo)) { n.texto = txt(c.texto || c.titulo); if (!n.texto) continue; }
    else { n.titulo = txt(c.titulo || c.texto); if (!n.titulo) continue; }
    if (c.tipo === 'texto' && c.subtitulo) n.subtitulo = txt(c.subtitulo, 120);
    if (c.tipo === 'gancho' && c.chamada) n.chamada = txt(c.chamada, 28);
    if (c.tipo === 'cta') n.acao = txt(c.acao || 'Siga o perfil', 40);
    if (['lista', 'checklist', 'ranking'].includes(c.tipo)) {
      n.itens = (Array.isArray(c.itens) ? c.itens : []).map((x) => txt(x, 48)).filter(Boolean).slice(0, c.tipo === 'lista' ? 4 : 5);
      if (!n.itens.length) continue;
    }
    const base = n.texto || n.titulo;
    const enf = (Array.isArray(c.enfase) ? c.enfase : []).map((x) => txt(x, 24)).filter((x) => x && base.toLowerCase().includes(x.toLowerCase())).slice(0, 2);
    if (enf.length) n.enfase = enf;
    saida.push(n);
  }
  if (saida.length && saida[0].tipo !== 'gancho') saida[0] = { tipo: 'gancho', duracao: 3, texto: saida[0].texto || saida[0].titulo };
  if (saida.length && saida[saida.length - 1].tipo !== 'cta') saida.push({ tipo: 'cta', duracao: 3, texto: 'Gostou? Salva este vídeo', acao: 'Siga o perfil' });
  return saida;
}
function montarDaIA(resp, briefing) {
  const cenas = limparCenas(resp.cenas);
  if (cenas.length < 3) throw new Error('a IA devolveu um roteiro incompleto');
  const base = roteiroDoModelo('dica-rapida', briefing);
  base.cenas = cenas; base.fontes = []; base.legendaPost = txt(resp.legenda, 600);
  return base;
}
const contexto = (b) => `Assunto: ${txt(b.tema, 200)}\nObjetivo: ${txt(b.objetivo || 'ganhar seguidores', 60)}\nNegócio: ${txt(b.negocio || 'não informado', 120)}\nPerfil: ${txt(b.handle || '', 40)}`;

export async function iaGanchos(briefing) {
  const r = await pedirClaude(`${REGRAS}\n\n${contexto(briefing)}\n\nCrie 5 ganchos diferentes (primeira frase do vídeo, até 8 palavras) para este assunto, cada um com nota de 0 a 10 e o porquê em uma frase.\nFormato: {"ganchos":[{"texto":"...","nota":9,"porque":"..."}]}`, 'sonnet');
  const g = (Array.isArray(r.ganchos) ? r.ganchos : []).map((x) => ({ texto: txt(x.texto, 80), nota: Math.max(0, Math.min(10, Number(x.nota) || 0)), porque: txt(x.porque, 140) })).filter((x) => x.texto);
  if (!g.length) throw new Error('a IA não devolveu ganchos');
  return g.sort((a, b) => b.nota - a.nota).slice(0, 5);
}
export async function iaRoteiro(briefing, gancho, modelo = 'opus') {
  const r = await pedirClaude(`${REGRAS}\n\n${contexto(briefing)}\nGancho escolhido (use exatamente na primeira cena): ${txt(gancho, 90)}\n\nEscreva o roteiro e revise antes de responder (cada cena precisa prender até a próxima).\nFormato: {"cenas":[...],"legenda":"..."}\n${FORMA_ROTEIRO}`, modelo);
  return montarDaIA(r, briefing);
}
export async function iaTudo(briefing) {
  const r = await pedirClaude(`${REGRAS}\n\n${contexto(briefing)}\n\nEscolha o melhor gancho e escreva o roteiro completo de uma vez.\nFormato: {"cenas":[...],"legenda":"..."}\n${FORMA_ROTEIRO}`, 'sonnet');
  return montarDaIA(r, briefing);
}

/* ---------- 5. prévia e conferência ---------- */
const AMIGAVEL = [[/fonte/i, 'Falta dizer de onde veio um número (campo "Fonte").'], [/duracao/i, 'Uma cena está sem duração.'], [/itens/i, 'Uma lista está vazia ou com item incompleto.']];
export function previa(roteiro) {
  const avisos = [];
  let erros = [];
  try { erros = validarRoteiro(roteiro, RAIZ, avisos); } catch (e) { erros = [e.message]; }
  let html = '', duracao = 0;
  if (!erros.length) { const plano = criarPlano(roteiro); duracao = plano.duracao; html = construirHtml(plano, 'nativo'); }
  return { html, duracao, avisos, erros, errosSimples: erros.map((e) => (AMIGAVEL.find(([re]) => re.test(e)) || [0, e])[1] + ' (' + e.split(':')[0] + ')') };
}

/* ---------- 6. projeto e render ---------- */
const slug = (s) => (String(s || 'reel').normalize('NFD').replace(/[̀-ͯ]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'reel');
export function salvarProjeto(roteiro, nome) {
  const d = new Date(); const dia = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  let pasta = join(RAIZ, 'projetos', `${dia}-${slug(nome || roteiro.titulo)}`);
  for (let n = 2; existsSync(join(pasta, 'render')) && n < 50; n++) pasta = join(RAIZ, 'projetos', `${dia}-${slug(nome || roteiro.titulo)}-${n}`);
  mkdirSync(pasta, { recursive: true });
  const arq = join(pasta, 'roteiro.json');
  const { legendaPost, ...limpo } = roteiro;
  writeFileSync(arq, JSON.stringify(limpo, null, 2));
  if (legendaPost) writeFileSync(join(pasta, 'post.md'), legendaPost + '\n');
  return { pasta, arquivo: arq };
}
export function renderizar(arquivo, { rascunho = false } = {}, aoProgredir = () => {}) {
  return new Promise((ok, falha) => {
    const args = [join(RAIZ, 'motor', 'render.mjs'), arquivo]; if (rascunho) args.push('--rascunho');
    const p = spawn(process.execPath, args, { cwd: RAIZ, windowsHide: true });
    let log = '', saida = '';
    const le = (d) => {
      const s = String(d); log += s;
      const q = [...s.matchAll(/quadro (\d+)\/(\d+)/g)].pop();
      if (q) aoProgredir({ etapa: 'Desenhando o vídeo', pct: Math.round((Number(q[1]) / Number(q[2])) * 90) });
      if (/quadros em/.test(s)) aoProgredir({ etapa: 'Juntando som e imagem', pct: 94 });
      const m = s.match(/✔ (.+?\.mp4)/); if (m) saida = resolve(RAIZ, m[1]);
    };
    p.stdout.on('data', le); p.stderr.on('data', le);
    p.on('error', (e) => falha(new Error('não consegui iniciar o render: ' + e.message)));
    p.on('close', (cod) => {
      if (cod === 0 && saida && existsSync(saida)) { aoProgredir({ etapa: 'Pronto', pct: 100 }); return ok({ video: saida, pasta: dirname(saida) }); }
      falha(new Error((log.trim().split('\n').filter((l) => !/quadro/.test(l)).pop() || 'o render parou') + ''));
    });
  });
}
export function abrirPasta(pasta) {
  if (process.env.BWREELS_NAO_ABRIR) return false;
  try { spawn(WIN ? 'explorer' : process.platform === 'darwin' ? 'open' : 'xdg-open', [pasta], { detached: true, stdio: 'ignore' }).unref(); return true; } catch { return false; }
}
export { conta };
