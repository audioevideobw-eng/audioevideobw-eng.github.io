// Plano -> HTML. Dois sabores:
//  - "nativo": runtime próprio com window.__seek(t), renderizado por Chromium + FFmpeg (motor/nativo.mjs)
//  - "hyperframes": mesmo runtime dirigido por UMA timeline GSAP registrada em window.__timelines
//    (formato de composição documentado no README do heygen-com/hyperframes)

import { readFileSync } from 'node:fs';
import { GOOGLE_FONTS } from './estilos.mjs';

const ANIM = readFileSync(new URL('./anim.mjs', import.meta.url), 'utf8').replace(/^export /gm, '');

export function css(p) {
  const e = p.estilo, W = p.largura, H = p.altura, u = W / 1080;
  const topo = p.vertical ? H * 0.11 : H * 0.08;
  const base = p.vertical ? H * 0.25 : H * 0.12;
  const brilho = e.brilho ? `text-shadow: 0 0 ${18 * u}px var(--destaque), 0 0 ${48 * u}px var(--destaque);` : '';
  return `
@font-face{font-family:'BWPesada';src:local('Inter Display Black'),local('Inter Black'),local('Inter ExtraBold'),local('Arial Black'),local('Impact')}
:root{--fundo:${e.fundo};--texto:${e.texto};--destaque:${e.destaque};--suave:${e.suave};--ft:${e.fonteTitulo};--fx:${e.fonteTexto}}
*{margin:0;padding:0;box-sizing:border-box}
html,body{width:${W}px;height:${H}px;overflow:hidden;background:var(--fundo)}
#stage{position:relative;width:${W}px;height:${H}px;overflow:hidden;background:${e.gradiente || 'var(--fundo)'};color:var(--texto);font-family:var(--fx)}
.cena{position:absolute;inset:0;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;
  padding:${topo}px ${W * 0.075}px ${base}px;gap:${36 * u}px;visibility:hidden;will-change:transform,opacity,filter}
.cena.tipo-midia{justify-content:flex-start;padding-top:${topo + 40 * u}px}
.midia{position:absolute;inset:0;z-index:0;overflow:hidden}
.midia-el,video.clip{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.escurecer{position:absolute;inset:0;z-index:1;background:linear-gradient(180deg,rgba(0,0,0,.35) 0%,rgba(0,0,0,.05) 35%,rgba(0,0,0,.25) 60%,rgba(0,0,0,.8) 100%)}
.cena>*:not(.midia):not(.escurecer){position:relative;z-index:2}
.titulo{font-family:var(--ft);font-weight:${e.pesoTitulo};${e.caixaAlta ? 'text-transform:uppercase;' : ''}line-height:1.0;font-size:${108 * u}px;letter-spacing:${e.espacamento || (e.caixaAlta ? 0.01 : -0.02)}em}
.titulo.gigante{font-size:${(e.caixaAlta ? 158 : 128) * u}px;line-height:.95}
.titulo.pequeno{font-size:${84 * u}px}
.titulo.citacao{font-size:${92 * u}px;line-height:1.12;text-transform:none;font-family:var(--ft)}
.w{display:inline-block;margin:0 ${0.12}em;will-change:transform,opacity,filter}
.enf{color:var(--destaque);${brilho}}
.chamada{font-size:${30 * u}px;font-weight:800;letter-spacing:.25em;text-transform:uppercase;color:var(--fundo);background:var(--destaque);padding:${10 * u}px ${24 * u}px;border-radius:999px}
.sub{font-size:${52 * u}px;line-height:1.3;color:var(--suave);max-width:92%}
.numero{font-family:var(--ft);font-size:${300 * u}px;line-height:1;color:var(--destaque);font-weight:${e.pesoTitulo};${brilho}font-variant-numeric:tabular-nums}
.rotulo{font-size:${62 * u}px;line-height:1.25;font-weight:600;max-width:90%}
.fonte{position:absolute!important;bottom:${base - 60 * u}px;left:0;right:0;font-size:${30 * u}px;color:var(--suave);letter-spacing:.02em}
.lista{list-style:none;display:flex;flex-direction:column;gap:${28 * u}px;width:100%;text-align:left}
.item{display:flex;align-items:center;gap:${30 * u}px;font-size:${60 * u}px;font-weight:600;line-height:1.2}
.item b{flex:none;width:${96 * u}px;height:${96 * u}px;border-radius:50%;display:grid;place-items:center;background:var(--destaque);color:var(--fundo);font-family:var(--ft);font-size:${44 * u}px}
.aspas{font-family:Georgia,serif;font-size:${260 * u}px;line-height:.6;color:var(--destaque);height:${130 * u}px}
.botao{background:var(--destaque);color:var(--fundo);font-weight:900;font-size:${46 * u}px;padding:${26 * u}px ${56 * u}px;border-radius:999px;letter-spacing:.02em}
.numero small{font-size:.32em;color:var(--texto);font-family:var(--fx);font-weight:800;margin:0 .15em}
#luz{z-index:0;inset:-30%;background:radial-gradient(35% 25% at 50% 50%,var(--destaque),transparent 70%);opacity:.13;filter:blur(40px)}
.rodape{margin-bottom:${20 * u}px}
#legendas{position:absolute;left:${W * 0.06}px;right:${W * 0.06}px;top:${p.vertical ? H * 0.64 : H * 0.78}px;z-index:20;text-align:center;
  font-family:var(--fx);font-weight:900;font-size:${68 * u}px;line-height:1.15;text-transform:uppercase;
  text-shadow:0 ${4 * u}px ${18 * u}px rgba(0,0,0,.85),0 0 ${3 * u}px rgba(0,0,0,.9)}
#legendas .lw{display:inline-block;margin:0 .14em;opacity:.95;transition:none}
#legendas .lw.ativa{color:var(--destaque);transform:scale(1.12)}
#legendas .lw.futura{opacity:.45}
.global{position:absolute;inset:0;pointer-events:none}
#grao{z-index:30;opacity:.10;mix-blend-mode:overlay;inset:-50%;
  background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='300' height='300'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='2' stitchTiles='stitch'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>")}
#vinheta{z-index:31;background:radial-gradient(120% 90% at 50% 50%,transparent 55%,rgba(0,0,0,.55) 100%)}
.barra{position:absolute;left:0;right:0;height:${H * 0.065}px;background:#000;z-index:32}
#progresso{position:absolute;left:0;bottom:0;height:${8 * u}px;width:0;background:var(--destaque);z-index:33}
#marca{position:absolute;top:${topo * 0.45}px;left:0;right:0;text-align:center;z-index:34;font-size:${28 * u}px;font-weight:800;letter-spacing:.18em;color:var(--texto);opacity:.75}
.flash{position:absolute;inset:0;background:#fff;z-index:40;visibility:hidden}
`;
}

function no(n, sabor) {
  if (n.tag === 'video' && sabor === 'hyperframes') return ''; // vídeos viram clips de topo no HyperFrames
  const attrs = [`id="${n.id}"`, n.classe ? `class="${n.classe}"` : ''];
  if (n.tag === 'video') attrs.push(`src="${n.src}"`, 'muted', 'playsinline', 'preload="auto"');
  if (n.tag === 'img') return `<img ${attrs.join(' ')} src="${n.src}" alt="">`;
  const filhos = (n.filhos || []).map((f) => no(f, sabor)).join('');
  return `<${n.tag} ${attrs.join(' ')}>${n.html ?? ''}${filhos}</${n.tag}>`;
}

function coletar(nos, acc = []) {
  for (const n of nos) {
    if (n.tweens?.length || n.inicio !== undefined || n.contador || n.tag === 'video') {
      acc.push({ id: n.id, tweens: n.tweens || [], inicio: n.inicio, fim: n.fim, contador: n.contador,
        video: n.tag === 'video', inicioNoArquivo: n.inicioNoArquivo });
    }
    if (n.filhos) coletar(n.filhos, acc);
  }
  return acc;
}

const RUNTIME = (sabor) => `
${ANIM}
const P = window.__PLANO;
const ELS = P.els.map(e => ({...e, el: document.getElementById(e.id)}));
const LEG = document.getElementById('legendas');
const GRAO = document.getElementById('grao');
const PROG = document.getElementById('progresso');
const LUZ = document.getElementById('luz');
let ultimaPagina = null;
function aplicar(t){
  for (const e of ELS){
    if (!e.el) continue;
    if (e.inicio !== undefined && !e.video){ e.el.style.visibility = (t >= e.inicio && t < e.fim) ? 'visible' : 'hidden'; }
    if (e.tweens.length){ const c = estadoParaCss(estadoEm(e.tweens, t)); e.el.style.opacity=c.opacity; e.el.style.transform=c.transform; e.el.style.filter=c.filter; if(c.letterSpacing) e.el.style.letterSpacing=c.letterSpacing; }
    if (e.contador){ e.el.innerHTML = formatarNumero(contadorEm(e.contador, t), e.contador); }
  }
  if (LEG){
    const l = legendaEm(P.legendas, t);
    if (!l){ LEG.innerHTML=''; ultimaPagina=null; }
    else {
      if (ultimaPagina !== l.pagina){ LEG.innerHTML = l.pagina.palavras.map(w=>'<span class="lw">'+w.txt+'</span>').join(' '); ultimaPagina = l.pagina; }
      [...LEG.children].forEach((s,i)=>{ s.className = 'lw' + (i===l.ativa ? ' ativa' : i>l.ativa ? ' futura' : ''); if (l.pagina.palavras[i].enfase) s.style.color='var(--destaque)'; });
    }
  }
  if (GRAO){ const f = Math.floor(t*P.fps)%8; GRAO.style.transform = 'translate(' + ((f*37)%100-50) + 'px,' + ((f*61)%100-50) + 'px)'; }
  if (LUZ){ const k=t/P.duracao; LUZ.style.transform='translate('+(Math.sin(k*Math.PI*2)*18)+'%,'+(-20+k*40)+'%)'; }
  if (PROG) PROG.style.width = (Math.min(1, t/P.duracao)*100) + '%';
}
${sabor === 'nativo' ? `
window.__seek = async (t) => {
  aplicar(t);
  const espera = [];
  for (const e of ELS){
    if (!e.video || !e.el) continue;
    const on = t >= e.inicio && t < e.fim;
    if (window.__PREVIEW){   /* prévia ao vivo (Brightway): o vídeo toca sozinho e só corrige quando desvia */
      if (!on){ if (!e.el.paused) e.el.pause(); continue; }
      const alvoP = e.inicioNoArquivo + (t - e.inicio);
      if (window.__TOCANDO){
        if (e.el.paused){ try { e.el.currentTime = alvoP; } catch(_){} e.el.play().catch(()=>{}); }
        else if (Math.abs(e.el.currentTime - alvoP) > 0.35){ try { e.el.currentTime = alvoP; } catch(_){} }
      } else {
        if (!e.el.paused) e.el.pause();
        if (Math.abs(e.el.currentTime - alvoP) > 0.04){ try { e.el.currentTime = alvoP; } catch(_){} }
      }
      continue;
    }
    if (!on) continue;
    const alvo = e.inicioNoArquivo + (t - e.inicio);
    if (Math.abs(e.el.currentTime - alvo) > 0.001){
      espera.push(new Promise(r => { const ok = () => { e.el.removeEventListener('seeked', ok); r(); }; e.el.addEventListener('seeked', ok); setTimeout(r, 3000); e.el.currentTime = alvo; }));
    }
  }
  await Promise.all(espera);
};
window.__pronto = (async () => {
  try { await document.fonts.ready; } catch(e) {}
  await Promise.all([...document.images].map(i => i.complete ? 0 : new Promise(r => { i.onload = i.onerror = r; })));
  await Promise.all([...document.querySelectorAll('video')].map(v => v.readyState >= 2 ? 0 : new Promise(r => { v.onloadeddata = v.onerror = r; setTimeout(r, 8000); })));
  aplicar(0); return true;
})();
` : `
// HyperFrames: uma única tween GSAP em um "setter" chama aplicar(t) a cada frame, inclusive em seek.
const proxy = { _t: 0, get t(){ return this._t; }, set t(v){ this._t = v; aplicar(v); } };
const tl = gsap.timeline({ paused: true });
tl.to(proxy, { t: P.duracao, duration: P.duracao, ease: 'none' }, 0);
window.__timelines = window.__timelines || {};
window.__timelines.reel = tl;
aplicar(0);
`}
`;

export function construirHtml(plano, sabor = 'nativo') {
  const fx = plano.efeitos;
  const todos = [...plano.cenas, ...plano.globais];
  const dados = { fps: plano.fps, duracao: plano.duracao, legendas: plano.legendas, els: coletar(todos) };
  const cenasHtml = plano.cenas.map((c) => no(c, sabor)).join('\n');
  const globaisHtml = plano.globais.map((g) => no(g, sabor)).join('\n');

  // HyperFrames: vídeos como clips de topo (track 0) e áudios como elementos <audio>
  let clipsHf = '';
  if (sabor === 'hyperframes') {
    const vids = [];
    const busca = (ns) => ns.forEach((n) => { if (n.tag === 'video') vids.push(n); if (n.filhos) busca(n.filhos); });
    busca(plano.cenas);
    clipsHf = vids.map((v) => `<video class="clip" data-start="${v.inicio.toFixed(3)}" data-duration="${(v.fim - v.inicio).toFixed(3)}" data-track-index="0" src="${v.src}" muted playsinline></video>`).join('\n');
    clipsHf += '\n' + plano.audios.concat(plano.sfxArquivos || []).map((a, i) => `<audio data-start="${(a.inicio || 0).toFixed(3)}" data-duration="${(a.duracao || plano.duracao).toFixed(3)}" data-track-index="${10 + i}" data-volume="${a.volume ?? 1}" src="${a.src}"></audio>`).join('\n');
  }

  const raiz = sabor === 'hyperframes'
    ? `<div id="stage" data-composition-id="reel" data-start="0" data-width="${plano.largura}" data-height="${plano.altura}">`
    : `<div id="stage">`;

  return `<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><title>${plano.titulo}</title>
<link rel="stylesheet" href="${GOOGLE_FONTS}">
<style>${css(plano)}</style></head><body>
${raiz}
${clipsHf}
${fx.luz !== false ? '<div id="luz" class="global"></div>' : ''}
${cenasHtml}
${globaisHtml}
<div id="legendas"></div>
${fx.letterbox ? '<div class="barra" style="top:0"></div><div class="barra" style="bottom:0"></div>' : ''}
${fx.vinheta ? '<div id="vinheta" class="global"></div>' : ''}
${fx.grao ? '<div id="grao" class="global"></div>' : ''}
${fx.barraProgresso ? '<div id="progresso"></div>' : ''}
${plano.marca?.handle ? `<div id="marca">${plano.marca.handle}</div>` : ''}
${sabor === 'hyperframes' ? '<script src="https://cdn.jsdelivr.net/npm/gsap@3/dist/gsap.min.js"></script>' : ''}
<script>window.__PLANO = ${JSON.stringify(dados)};</script>
<script>${RUNTIME(sabor)}</script>
</div></body></html>`;
}
