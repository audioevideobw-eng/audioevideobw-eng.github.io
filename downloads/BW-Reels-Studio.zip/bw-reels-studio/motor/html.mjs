// Plano -> HTML. Dois sabores:
//  - "nativo": runtime próprio com window.__seek(t), renderizado por Chromium + FFmpeg (motor/nativo.mjs)
//  - "hyperframes": mesmo runtime dirigido por UMA timeline GSAP registrada em window.__timelines
//    (formato de composição documentado no README do heygen-com/hyperframes)

import { readFileSync } from 'node:fs';
import { GOOGLE_FONTS } from './estilos.mjs';

const ANIM = readFileSync(new URL('./anim.mjs', import.meta.url), 'utf8').replace(/^export /gm, '');
const PERS = readFileSync(new URL('./personagens.mjs', import.meta.url), 'utf8').replace(/^export /gm, '');

export function css(p) {
  const e = p.estilo, W = p.largura, H = p.altura, u = W / 1080;
  const topo = p.vertical ? H * 0.11 : H * 0.08;
  const base = p.vertical ? H * 0.25 : H * 0.12;
  const brilho = e.brilho ? `text-shadow: 0 0 ${18 * u}px var(--destaque), 0 0 ${48 * u}px var(--destaque);` : '';
  return `
@font-face{font-family:'BWPesada';src:local('Inter Display Black'),local('Inter Black'),local('Inter ExtraBold'),local('Arial Black'),local('Impact')}
:root{--fundo:${e.fundo};--texto:${e.texto};--destaque:${e.destaque};--suave:${e.suave};--ft:${e.fonteTitulo};--fx:${e.fonteTexto}}
*{margin:0;padding:0;box-sizing:border-box}
html,body{width:${W}px;height:${H}px;overflow:hidden;background:var(--fundo)}
#stage{position:relative;width:${W}px;height:${H}px;overflow:hidden;background:${e.gradiente || 'var(--fundo)'};color:var(--texto);font-family:var(--fx)}
.cena{position:absolute;inset:0;display:flex;flex-direction:column;justify-content:center;align-items:center;text-align:center;
  padding:${topo}px ${W * 0.075}px ${base}px;gap:${36 * u}px;visibility:hidden;will-change:transform,opacity,filter}
.cena.tipo-midia{justify-content:flex-start;padding-top:${topo + 40 * u}px}
.midia{position:absolute;inset:0;z-index:0;overflow:hidden}
.midia-el,video.clip{position:absolute;inset:0;width:100%;height:100%;object-fit:cover}
.escurecer{position:absolute;inset:0;z-index:1;background:linear-gradient(180deg,rgba(0,0,0,.35) 0%,rgba(0,0,0,.05) 35%,rgba(0,0,0,.25) 60%,rgba(0,0,0,.8) 100%)}
.cena>*:not(.midia):not(.escurecer){position:relative;z-index:2}
.titulo{font-family:var(--ft);font-weight:${e.pesoTitulo};${e.caixaAlta ? 'text-transform:uppercase;' : ''}line-height:1.0;font-size:${108 * u}px;letter-spacing:${e.espacamento || (e.caixaAlta ? 0.01 : -0.02)}em}
.titulo.gigante{font-size:${(e.caixaAlta ? 158 : 128) * u}px;line-height:.95}
.titulo.pequeno{font-size:${84 * u}px}
.titulo.citacao{font-size:${92 * u}px;line-height:1.12;text-transform:none;font-family:var(--ft)}
.w{display:inline-block;margin:0 ${0.12}em;will-change:transform,opacity,filter}
.enf{color:var(--destaque);${brilho}}
.chamada{font-size:${30 * u}px;font-weight:800;letter-spacing:.25em;text-transform:uppercase;color:var(--fundo);background:var(--destaque);padding:${10 * u}px ${24 * u}px;border-radius:999px}
.sub{font-size:${52 * u}px;line-height:1.3;color:var(--suave);max-width:92%}
.numero{font-family:var(--ft);font-size:${300 * u}px;line-height:1;color:var(--destaque);font-weight:${e.pesoTitulo};${brilho}font-variant-numeric:tabular-nums}
.rotulo{font-size:${62 * u}px;line-height:1.25;font-weight:600;max-width:90%}
.fonte{position:absolute!important;bottom:${base - 60 * u}px;left:0;right:0;font-size:${30 * u}px;color:var(--suave);letter-spacing:.02em}
.lista{list-style:none;display:flex;flex-direction:column;gap:${28 * u}px;width:100%;text-align:left}
.item{display:flex;align-items:center;gap:${30 * u}px;font-size:${60 * u}px;font-weight:600;line-height:1.2}
.item b{flex:none;width:${96 * u}px;height:${96 * u}px;border-radius:50%;display:grid;place-items:center;background:var(--destaque);color:var(--fundo);font-family:var(--ft);font-size:${44 * u}px}
.aspas{font-family:Georgia,serif;font-size:${260 * u}px;line-height:.6;color:var(--destaque);height:${130 * u}px}
.botao{background:var(--destaque);color:var(--fundo);font-weight:900;font-size:${46 * u}px;padding:${26 * u}px ${56 * u}px;border-radius:999px;letter-spacing:.02em}
.numero small{font-size:.32em;color:var(--texto);font-family:var(--fx);font-weight:800;margin:0 .15em}
#luz{z-index:0;inset:-30%;background:radial-gradient(35% 25% at 50% 50%,var(--destaque),transparent 70%);opacity:.13;filter:blur(40px)}
.rodape{margin-bottom:${20 * u}px}
#legendas{position:absolute;left:${W * 0.06}px;right:${W * 0.06}px;top:${p.vertical ? H * 0.64 : H * 0.78}px;z-index:20;text-align:center;
  font-family:var(--fx);font-weight:900;font-size:${68 * u}px;line-height:1.15;text-transform:uppercase;
  text-shadow:0 ${4 * u}px ${18 * u}px rgba(0,0,0,.85),0 0 ${3 * u}px rgba(0,0,0,.9)}
#legendas .lw{display:inline-block;margin:0 .14em;opacity:.95;transition:none}
#legendas .lw.ativa{color:var(--destaque);transform:scale(1.12)}
#legendas .lw.futura{opacity:.45}
.global{position:absolute;inset:0;pointer-events:none}
#grao{z-index:30;opacity:.10;mix-blend-mode:overlay;inset:-50%;
  background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='300' height='300'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='2' stitchTiles='stitch'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>")}
#vinheta{z-index:31;background:radial-gradient(120% 90% at 50% 50%,transparent 55%,rgba(0,0,0,.55) 100%)}
.barra{position:absolute;left:0;right:0;height:${H * 0.065}px;background:#000;z-index:32}
#progresso{position:absolute;left:0;bottom:0;height:${8 * u}px;width:0;background:var(--destaque);z-index:33}
#marca{position:absolute;top:${topo * 0.45}px;left:0;right:0;text-align:center;z-index:34;font-size:${28 * u}px;font-weight:800;letter-spacing:.18em;color:var(--texto);opacity:.75}

/* ---- motions e gráficos (17/11) ---- */
.lt{position:absolute!important;left:${W * 0.06}px;bottom:${base + 30 * u}px;display:grid;grid-template-columns:${12 * u}px auto;grid-template-rows:auto auto;column-gap:${22 * u}px;align-items:center;text-align:left;
  background:linear-gradient(90deg,rgba(0,0,0,.78),rgba(0,0,0,.45));padding:${22 * u}px ${36 * u}px ${22 * u}px ${22 * u}px;border-radius:${10 * u}px;max-width:88%}
.lt-barra{grid-row:1/3;width:${12 * u}px;height:100%;background:var(--destaque);border-radius:${6 * u}px;transform-origin:50% 100%}
.lt-nome{font-family:var(--ft);font-size:${70 * u}px;line-height:1.05;${e.caixaAlta ? 'text-transform:uppercase;' : ''}font-weight:${e.pesoTitulo}}
.lt-cargo{font-size:${40 * u}px;color:var(--destaque);font-weight:700;letter-spacing:.04em}
.logo-box{display:grid;place-items:center;max-width:78%}
.logo-img{max-width:${W * 0.7}px;max-height:${H * 0.3}px;object-fit:contain;filter:drop-shadow(0 ${10 * u}px ${30 * u}px rgba(0,0,0,.5))}
.logo-txt{font-family:var(--ft);font-size:${150 * u}px;line-height:1;${e.caixaAlta ? 'text-transform:uppercase;' : ''}font-weight:${e.pesoTitulo};color:var(--texto);letter-spacing:.01em;line-height:1.05}
.logo-raio{position:absolute!important;inset:0;z-index:4!important;pointer-events:none;background:linear-gradient(100deg,transparent 40%,rgba(255,255,255,.55) 50%,transparent 60%);mix-blend-mode:overlay}
.logo-slogan{text-transform:uppercase;font-weight:700}
.cg-num{position:absolute!important;left:0;right:0;top:50%;margin-top:${-170 * u}px;font-family:var(--ft);font-size:${340 * u}px;line-height:1;color:var(--destaque);font-weight:${e.pesoTitulo};${brilho}opacity:0}
.cg-anel{position:absolute!important;left:50%;top:50%;width:${520 * u}px;height:${520 * u}px;margin:${-260 * u}px 0 0 ${-260 * u}px;border-radius:50%;--p:0;
  background:conic-gradient(var(--destaque) calc(var(--p) * 360deg),rgba(255,255,255,.08) 0);-webkit-mask:radial-gradient(closest-side,transparent 88%,#000 89%);mask:radial-gradient(closest-side,transparent 88%,#000 89%)}
.cg-txt{position:absolute!important;left:${W * 0.075}px;right:${W * 0.075}px;top:42%}
.gr-barras{display:flex;flex-direction:column;gap:${26 * u}px;width:100%}
.gr-linha{display:grid;grid-template-columns:minmax(0,${260 * u}px) minmax(0,1fr) ${170 * u}px;gap:${18 * u}px;align-items:center;text-align:left}
.gr-rot{font-size:${42 * u}px;font-weight:700;line-height:1.1}
.gr-trilho{height:${54 * u}px;border-radius:${27 * u}px;background:rgba(255,255,255,.08);overflow:hidden}
.gr-barra{display:block;height:100%;--p:0;width:calc(var(--p) * 100%);background:var(--suave);border-radius:inherit}
.gr-barra.prim{background:var(--destaque)}
.gr-val{font-family:var(--ft);font-size:${56 * u}px;color:var(--texto);text-align:right;font-variant-numeric:tabular-nums}
.gr-val small{font-size:.5em}
.gr-pizza{width:${560 * u}px;height:${560 * u}px;--p:0}.gr-rosca{width:100%;height:100%}
.gr-leg{list-style:none;display:flex;flex-direction:column;gap:${14 * u}px;font-size:${40 * u}px;text-align:left}
.gr-leg i{display:inline-block;width:${28 * u}px;height:${28 * u}px;border-radius:50%;margin-right:${14 * u}px;vertical-align:middle}
.gr-leg b{color:var(--destaque);margin-left:${10 * u}px}
.tl{position:relative;width:100%;display:flex;flex-direction:column;gap:${40 * u}px;padding-left:${70 * u}px;text-align:left}
.tl-reta{position:absolute;left:${24 * u}px;top:${10 * u}px;width:${8 * u}px;--p:0;height:calc(var(--p) * 100%);background:var(--destaque);border-radius:${4 * u}px}
.tl-item{position:relative;display:flex;flex-direction:column;gap:${4 * u}px}
.tl-item i{position:absolute;left:${-60 * u}px;top:${8 * u}px;width:${36 * u}px;height:${36 * u}px;border-radius:50%;background:var(--fundo);border:${8 * u}px solid var(--destaque)}
.tl-item b{font-family:var(--ft);font-size:${52 * u}px;color:var(--destaque);line-height:1}
.tl-item span{font-size:${46 * u}px;font-weight:600;line-height:1.2}
.ck{list-style:none;display:flex;flex-direction:column;gap:${30 * u}px;width:100%;text-align:left}
.ck-item{display:flex;align-items:center;gap:${28 * u}px}
.ck-box{flex:none;width:${80 * u}px;height:${80 * u}px;border-radius:${18 * u}px;border:${6 * u}px solid var(--destaque);display:grid;place-items:center}
.ck-v{font-size:${60 * u}px;color:var(--destaque);font-weight:900;line-height:1}
.ck-txt{font-size:${54 * u}px;font-weight:700;line-height:1.15;--p:0;opacity:calc(1 - var(--p) * .35)}
.rk{position:absolute!important;left:${W * 0.07}px;right:${W * 0.07}px;top:40%;display:flex;flex-direction:column;align-items:center;gap:${16 * u}px;opacity:0}
.rk b{font-family:var(--ft);font-size:${260 * u}px;line-height:.9;color:var(--destaque);${brilho}}
.rk span{font-size:${70 * u}px;font-weight:800;line-height:1.1}
.rk1 b{font-size:${320 * u}px}
.rk-tit{position:absolute!important;top:${topo + 20 * u}px;left:${W * 0.075}px;right:${W * 0.075}px}
.ad{position:absolute!important;inset:0;z-index:1!important;overflow:hidden}
.ad-camada{position:absolute;inset:0;overflow:hidden;background:#222;display:grid;place-items:center}
.ad-depois{--p:0;clip-path:inset(0 0 0 calc((1 - var(--p)) * 100%));background:#333}
.ad-vazio{font-family:var(--ft);font-size:${120 * u}px;color:rgba(255,255,255,.25)}
.ad-linha{position:absolute;top:0;bottom:0;width:${8 * u}px;margin-left:${-4 * u}px;--p:0;left:calc((1 - var(--p)) * 100%);background:#fff;box-shadow:0 0 ${20 * u}px rgba(0,0,0,.6)}
.ad-tag{position:absolute;top:${topo + 30 * u}px;padding:${8 * u}px ${22 * u}px;border-radius:999px;font-size:${34 * u}px;font-weight:900;letter-spacing:.08em;background:rgba(0,0,0,.7)}
.ad-tag.a{left:${W * 0.06}px}.ad-tag.b{right:${W * 0.06}px;background:var(--destaque);color:var(--fundo)}
.ad-txt{position:absolute!important;left:${W * 0.075}px;right:${W * 0.075}px;bottom:${base}px;text-shadow:0 ${4 * u}px ${20 * u}px rgba(0,0,0,.8)}
.dp-estrelas{display:flex;gap:${14 * u}px;font-size:${100 * u}px;line-height:1}
.dp-estrelas i{font-style:normal;color:rgba(255,255,255,.18)}.dp-estrelas i.on{color:#ffc93c;text-shadow:0 0 ${20 * u}px rgba(255,201,60,.6)}
.dp-txt{font-size:${74 * u}px}
.mapa{position:absolute!important;inset:-20%;z-index:0!important;opacity:.5;
  background:linear-gradient(transparent ${46 * u}px,rgba(255,255,255,.06) 0) 0 0/${48 * u}px ${48 * u}px,linear-gradient(90deg,transparent ${46 * u}px,rgba(255,255,255,.06) 0) 0 0/${48 * u}px ${48 * u}px,
  linear-gradient(30deg,transparent 48%,color-mix(in srgb,var(--destaque) 35%,transparent) 49% 51%,transparent 52%),linear-gradient(-60deg,transparent 46%,rgba(255,255,255,.12) 47% 49%,transparent 50%)}
.pino{width:${120 * u}px;height:${160 * u}px;margin-bottom:${10 * u}px}
.pino i{display:block;width:${120 * u}px;height:${120 * u}px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);background:var(--destaque);box-shadow:inset 0 0 0 ${30 * u}px var(--destaque),inset 0 0 0 ${60 * u}px var(--fundo)}
.pino-onda{position:absolute!important;left:50%;top:50%;width:${140 * u}px;height:${50 * u}px;margin:${-120 * u}px 0 0 ${-70 * u}px;border-radius:50%;border:${5 * u}px solid var(--destaque);opacity:0}
.of-selo{background:#ff3b3b;color:#fff;font-weight:900;font-size:${44 * u}px;letter-spacing:.08em;padding:${16 * u}px ${36 * u}px;border-radius:${12 * u}px;text-transform:uppercase}
.of-preco{font-size:${230 * u}px}
.av-selo{display:inline-flex;align-items:center;gap:${16 * u}px;background:#e11d2e;color:#fff;font-weight:900;font-size:${46 * u}px;letter-spacing:.12em;padding:${14 * u}px ${34 * u}px;border-radius:${12 * u}px}
.av-selo i{width:${24 * u}px;height:${24 * u}px;border-radius:50%;background:#fff;animation:none}
.cel{width:${560 * u}px;height:${1080 * u}px;border-radius:${80 * u}px;background:#0b0b0d;border:${14 * u}px solid #2a2d35;box-shadow:0 ${40 * u}px ${80 * u}px rgba(0,0,0,.6),inset 0 0 0 ${3 * u}px #444;position:relative;padding:${18 * u}px}
.cel-tela{position:relative;width:100%;height:100%;border-radius:${62 * u}px;overflow:hidden;background:#1b1e26;display:grid;place-items:center;color:rgba(255,255,255,.35);font-size:${34 * u}px}
.cel-notch{position:absolute;top:${30 * u}px;left:50%;width:${160 * u}px;height:${40 * u}px;margin-left:${-80 * u}px;border-radius:${20 * u}px;background:#000}
.dv{position:absolute!important;inset:0;z-index:1!important;display:flex;flex-direction:column;gap:${8 * u}px;background:#000}
.dv-parte{position:relative;flex:1;overflow:hidden;background:#1b1e26;display:grid;place-items:center}
.dv-tag{position:absolute!important;z-index:5!important;padding:${10 * u}px ${26 * u}px;border-radius:${10 * u}px;font-size:${40 * u}px;font-weight:900;background:rgba(0,0,0,.72)}
.dv-tag.a{top:${topo + 20 * u}px;left:${W * 0.06}px}.dv-tag.b{top:calc(50% + ${30 * u}px);left:${W * 0.06}px;background:var(--destaque);color:var(--fundo)}
.tipo-nome,.tipo-aovivo.com-midia{justify-content:flex-end}
.flash{position:absolute;inset:0;background:#fff;z-index:40;visibility:hidden}
.tipo-personagem{justify-content:flex-start}
.cenario{position:absolute!important;z-index:0!important;pointer-events:none}
.cenario.raios{inset:-40%;background:repeating-conic-gradient(from 0deg at 50% 50%,color-mix(in srgb,var(--destaque) 22%,transparent) 0deg 9deg,transparent 9deg 24deg);opacity:.55;
  -webkit-mask:radial-gradient(closest-side,#000 30%,transparent 100%);mask:radial-gradient(closest-side,#000 30%,transparent 100%)}
.cenario.palco{inset:0}
.cenario.palco .chao{position:absolute;left:-10%;right:-10%;bottom:${base - 40 * u}px;height:${H * 0.22}px;border-radius:50%;background:radial-gradient(60% 50% at 50% 40%,color-mix(in srgb,var(--destaque) 35%,#000) 0%,rgba(0,0,0,.6) 70%,transparent 100%)}
.cenario.palco .spot{position:absolute;top:-5%;width:${W * 0.55}px;height:${H * 0.9}px;background:linear-gradient(180deg,rgba(255,255,255,.28),rgba(255,255,255,0) 85%);clip-path:polygon(45% 0,55% 0,100% 100%,0 100%);filter:blur(${6 * u}px)}
.cenario.palco .spot.e{left:-6%;transform:rotate(-14deg);transform-origin:50% 0}.cenario.palco .spot.d{right:-6%;transform:rotate(14deg);transform-origin:50% 0}
.cenario.bolinhas{inset:-10% 0;background-image:radial-gradient(color-mix(in srgb,var(--destaque) 40%,transparent) ${5 * u}px,transparent ${6 * u}px);background-size:${90 * u}px ${90 * u}px;opacity:.35}
.topo-pers{margin-top:${10 * u}px}
.ator{position:absolute!important;bottom:${base - 10 * u}px;height:${H * (p.vertical ? 0.46 : 0.62)}px;aspect-ratio:400/640;left:50%;margin-left:${-(H * (p.vertical ? 0.46 : 0.62) * 0.625) / 2}px;z-index:3!important}
.ator.duplo{height:${H * (p.vertical ? 0.37 : 0.54)}px;margin-left:${-(H * (p.vertical ? 0.37 : 0.54) * 0.625) / 2}px}
.ator.lado-1{left:${p.vertical ? 27 : 30}%}.ator.lado1{left:${p.vertical ? 73 : 70}%}
.ator.solo.lado-1{left:32%}.ator.solo.lado1{left:68%}
.ator svg{display:block;width:100%;height:100%}
.ator.foto{aspect-ratio:auto;width:${W * (p.vertical ? 0.8 : 0.42)}px;margin-left:${-W * (p.vertical ? 0.4 : 0.21)}px}
.ator.foto.duplo{width:${W * (p.vertical ? 0.5 : 0.3)}px;margin-left:${-W * (p.vertical ? 0.25 : 0.15)}px}
.foto-corpo{position:absolute;inset:0;transform-origin:50% 100%;will-change:transform,opacity}
.foto-img{position:absolute;inset:0;width:100%;height:100%;object-fit:contain;object-position:50% 100%;filter:drop-shadow(0 ${10 * u}px ${14 * u}px rgba(0,0,0,.45))}
.ator.contorno .foto-img{filter:drop-shadow(${4 * u}px 0 0 #fff) drop-shadow(-${4 * u}px 0 0 #fff) drop-shadow(0 ${4 * u}px 0 #fff) drop-shadow(0 -${4 * u}px 0 #fff) drop-shadow(0 ${12 * u}px ${14 * u}px rgba(0,0,0,.45))}
.foto-sombra{position:absolute;left:22%;right:22%;bottom:-${1.5 * u}%;height:${26 * u}px;border-radius:50%;background:rgba(0,0,0,.5);filter:blur(${8 * u}px);will-change:transform,opacity}
.balao{position:absolute!important;z-index:5!important;top:${p.vertical ? H * 0.2 : H * 0.12}px;left:50%;width:${W * (p.vertical ? 0.78 : 0.42)}px;margin-left:${-W * (p.vertical ? 0.39 : 0.21)}px;
  background:#fff;color:#111;border:${6 * u}px solid #0b0d12;border-radius:${40 * u}px;padding:${26 * u}px ${34 * u}px;font-family:var(--fx);font-weight:800;
  font-size:${54 * u}px;line-height:1.18;text-align:center;box-shadow:0 ${14 * u}px 0 rgba(0,0,0,.35);opacity:0}
.balao::after{content:'';position:absolute;bottom:${-34 * u}px;left:50%;margin-left:${-22 * u}px;border:${22 * u}px solid transparent;border-top:${30 * u}px solid #0b0d12}
.balao.duplo{width:${W * (p.vertical ? 0.56 : 0.34)}px;font-size:${48 * u}px}
.balao.duplo.lado-1{left:${p.vertical ? 40 : 38}%;margin-left:${-W * (p.vertical ? 0.28 : 0.17)}px}.balao.duplo.lado1{left:${p.vertical ? 60 : 62}%;margin-left:${-W * (p.vertical ? 0.28 : 0.17)}px}
.balao.duplo.lado-1::after{left:${p.vertical ? 27 : 30}%}.balao.duplo.lado1::after{left:${p.vertical ? 73 : 70}%}
/* ---- reels que explicam (22/11) ---- */
.tm{width:100%;background:rgba(12,14,20,.92);border:${2 * u}px solid rgba(255,255,255,.14);border-radius:${26 * u}px;overflow:hidden;text-align:left;box-shadow:0 ${30 * u}px ${70 * u}px rgba(0,0,0,.55)}
.tm-barra{display:flex;align-items:center;gap:${12 * u}px;padding:${18 * u}px ${24 * u}px;background:rgba(255,255,255,.06);font-family:ui-monospace,'Cascadia Mono',Consolas,monospace;font-size:${28 * u}px;color:#8b93a7}
.tm-barra i{width:${20 * u}px;height:${20 * u}px;border-radius:50%;background:#ff5f57}.tm-barra i:nth-child(2){background:#febc2e}.tm-barra i:nth-child(3){background:#28c840}
.tm-barra span{margin-left:${14 * u}px}
.tm-linha,.tm-out{font-family:ui-monospace,'Cascadia Mono',Consolas,monospace;font-size:${42 * u}px;line-height:1.35;padding:${8 * u}px ${30 * u}px;color:#e9edf5;white-space:nowrap}
.tm-linha{padding-top:${26 * u}px}.tm-out:last-child{padding-bottom:${30 * u}px}
.tm-linha>b{color:var(--destaque);margin-right:${18 * u}px}
.tm-cmd{display:inline-block;overflow:hidden;white-space:nowrap;vertical-align:bottom;--p:0;max-width:calc(var(--p) * var(--n) * 1ch + .02ch)}
.tm-cursor{display:inline-block;width:.6ch;height:1.1em;vertical-align:text-bottom;background:var(--destaque);margin-left:${4 * u}px}
.tm-out{color:#aab3c5;font-size:${36 * u}px;white-space:normal}.tm-out b{color:#28c840}
.tipo-passo{background:radial-gradient(70% 45% at 50% 52%,color-mix(in srgb,var(--destaque) 38%,transparent),transparent 75%)}
.ps-num{z-index:3!important;text-shadow:0 0 ${30 * u}px #000;font-family:var(--ft);font-size:${64 * u}px;color:var(--destaque);line-height:1}.ps-num small{font-size:.55em;color:var(--suave)}
.ps-feixe{position:absolute!important;z-index:1!important;left:50%;top:0;width:${140 * u}px;margin-left:${-70 * u}px;height:52%;background:linear-gradient(180deg,transparent,color-mix(in srgb,var(--destaque) 70%,#fff) 85%,transparent);filter:blur(${16 * u}px);opacity:.7;transform-origin:50% 0}
.ps-icone{width:${330 * u}px;height:${330 * u}px;border-radius:${80 * u}px;display:grid;place-items:center;font-size:${180 * u}px;line-height:1;
  background:linear-gradient(160deg,color-mix(in srgb,var(--destaque) 55%,#111),#0c0d12);border:${4 * u}px solid color-mix(in srgb,var(--destaque) 70%,#fff);
  box-shadow:0 0 ${60 * u}px color-mix(in srgb,var(--destaque) 70%,transparent),0 0 ${160 * u}px color-mix(in srgb,var(--destaque) 40%,transparent)}
.ps-sub{color:var(--texto);font-weight:700}
.ps-tit{z-index:3!important;text-shadow:0 ${4 * u}px ${30 * u}px #000}
.tipo-passo .ps-icone{z-index:3!important}
.pn{width:100%;background:rgba(18,20,28,.92);border:${2 * u}px solid rgba(255,255,255,.12);border-radius:${34 * u}px;padding:${40 * u}px ${44 * u}px;text-align:left;box-shadow:0 ${30 * u}px ${70 * u}px rgba(0,0,0,.5);position:relative}
.pn-rot{font-size:${34 * u}px;color:#9aa3b5;font-weight:700;letter-spacing:.03em}
.pn-val{font-family:var(--ft);font-size:${170 * u}px;line-height:1;color:#fff;font-variant-numeric:tabular-nums;margin-top:${10 * u}px}
.pn-val small{font-size:.4em;color:#9aa3b5}
.pn-var{position:absolute;top:${40 * u}px;right:${44 * u}px;background:color-mix(in srgb,#28c840 22%,transparent);color:#5fe07a;font-weight:900;font-size:${38 * u}px;padding:${8 * u}px ${20 * u}px;border-radius:999px}
.pn-graf{height:${300 * u}px;margin-top:${24 * u}px;--p:0}.pn-graf svg{width:100%;height:100%;overflow:visible}
.pn-traco{fill:none;stroke:var(--destaque);stroke-width:5;stroke-linecap:round;stroke-linejoin:round;stroke-dasharray:1;stroke-dashoffset:calc(1 - var(--p))}
.pn-area{fill:var(--destaque);opacity:calc(var(--p) * .18)}
.md{position:relative;width:${720 * u}px;height:${720 * u}px}
.md-arco{position:absolute;inset:0;border-radius:50%;--p:0;background:conic-gradient(from -120deg,var(--destaque) calc(var(--p) * 240deg),rgba(255,255,255,.1) 0 240deg,transparent 0);
  -webkit-mask:radial-gradient(closest-side,transparent 80%,#000 81%);mask:radial-gradient(closest-side,transparent 80%,#000 81%);filter:drop-shadow(0 0 ${20 * u}px var(--destaque))}
.md-ponteiro{position:absolute;left:50%;bottom:50%;width:${14 * u}px;height:${300 * u}px;margin-left:${-7 * u}px;border-radius:${7 * u}px;background:#fff;transform-origin:50% 100%}
.md-val{position:absolute;left:0;right:0;top:62%;font-family:var(--ft);font-size:${130 * u}px;line-height:1;color:#fff;font-variant-numeric:tabular-nums}
.md-val small{font-size:.38em;color:var(--suave)}
.md-rot{position:absolute;left:0;right:0;top:82%;font-size:${40 * u}px;color:var(--suave);font-weight:700}
.tipo-catalogo{justify-content:flex-start}
.ct{width:100%;flex:1;display:grid;grid-template-columns:minmax(0,40%) minmax(0,60%);gap:${30 * u}px;align-items:center;min-height:0}
.ct-lista{list-style:none;display:flex;flex-direction:column;gap:${16 * u}px;text-align:left}
.ct-item{font-size:${38 * u}px;font-weight:800;line-height:1.15;display:flex;gap:${14 * u}px;align-items:baseline;opacity:.28}
.ct-item b{flex:none;color:var(--destaque);font-family:var(--ft);font-size:1.1em;min-width:1.3em}
.ct-cartoes{position:relative;height:${H * 0.5}px}
.ct-cartao{position:absolute;inset:0;border-radius:${36 * u}px;display:flex;flex-direction:column;justify-content:center;align-items:center;gap:${24 * u}px;padding:${30 * u}px;opacity:0;
  border:${3 * u}px solid rgba(255,255,255,.18);box-shadow:0 ${30 * u}px ${70 * u}px rgba(0,0,0,.55)}
.ct-cartao b{font-family:var(--ft);font-size:${66 * u}px;line-height:1.05;color:#fff;text-shadow:0 ${4 * u}px ${20 * u}px rgba(0,0,0,.5)}
.ct-ic{font-size:${200 * u}px;line-height:1}
.ct-cartao.c0{background:linear-gradient(160deg,#3b82f6,#0b1d4a)}.ct-cartao.c1{background:linear-gradient(160deg,#ec4899,#3b0a2a)}.ct-cartao.c2{background:linear-gradient(160deg,#f59e0b,#4a2a03)}
.ct-cartao.c3{background:linear-gradient(160deg,#10b981,#06392a)}.ct-cartao.c4{background:linear-gradient(160deg,#8b5cf6,#25124d)}.ct-cartao.c5{background:linear-gradient(160deg,#ef4444,#4a0d0d)}
.cm-tit{font-size:${96 * u}px}
.cm-pal{font-family:var(--ft);font-size:${170 * u}px;line-height:1;color:var(--fundo);background:var(--destaque);padding:${14 * u}px ${44 * u}px;border-radius:${20 * u}px;${brilho}}
.cm-caixa{display:flex;align-items:center;gap:${20 * u}px;width:92%;background:rgba(255,255,255,.95);color:#111;border-radius:999px;padding:${18 * u}px ${24 * u}px;font-size:${48 * u}px;font-weight:800;text-align:left}
.cm-av{flex:none;width:${70 * u}px;height:${70 * u}px;border-radius:50%;background:linear-gradient(135deg,var(--destaque),#7c3aed)}
.cm-txt{flex:1;font-family:var(--fx);max-width:calc(var(--p) * var(--n) * 1.1ch + .02ch)}
.cm-env{flex:none;color:var(--destaque);font-size:${54 * u}px}
.cm-resp{background:#1f2937;color:#fff;border-radius:${30 * u}px;padding:${22 * u}px ${34 * u}px;font-size:${42 * u}px;font-weight:700}
${e.enfaseItalica ? `.enf{font-family:'Playfair Display',Georgia,serif;font-style:italic;font-weight:700;text-transform:none}` : ''}
${e.grade ? `#stage::before{content:'';position:absolute;inset:0;pointer-events:none;background:linear-gradient(rgba(255,255,255,.045) ${2 * u}px,transparent 0) 0 0/${90 * u}px ${90 * u}px,linear-gradient(90deg,rgba(255,255,255,.045) ${2 * u}px,transparent 0) 0 0/${90 * u}px ${90 * u}px;-webkit-mask:radial-gradient(80% 70% at 50% 45%,#000,transparent);mask:radial-gradient(80% 70% at 50% 45%,#000,transparent)}` : ''}
`;
}

function no(n, sabor) {
  if (n.tag === 'video' && sabor === 'hyperframes') return ''; // vídeos viram clips de topo no HyperFrames
  const attrs = [`id="${n.id}"`, n.classe ? `class="${n.classe}"` : '', n.estilo ? `style="${n.estilo}"` : ''];
  if (n.tag === 'video') attrs.push(`src="${n.src}"`, 'muted', 'playsinline', 'preload="auto"');
  if (n.tag === 'img') return `<img ${attrs.join(' ')} src="${n.src}" alt="">`;
  const filhos = (n.filhos || []).map((f) => no(f, sabor)).join('');
  return `<${n.tag} ${attrs.join(' ')}>${n.html ?? ''}${filhos}</${n.tag}>`;
}

function coletar(nos, acc = []) {
  for (const n of nos) {
    if (n.tweens?.length || n.inicio !== undefined || n.contador || n.tag === 'video' || n.rig) {
      acc.push({ id: n.id, tweens: n.tweens || [], inicio: n.inicio, fim: n.fim, contador: n.contador,
        video: n.tag === 'video', inicioNoArquivo: n.inicioNoArquivo, rig: n.rig, temP: (n.tweens || []).some((t) => 'p' in t.para) });
    }
    if (n.filhos) coletar(n.filhos, acc);
  }
  return acc;
}

const RUNTIME = (sabor) => `
${ANIM}
${PERS}
const P = window.__PLANO;
const ELS = P.els.map(e => ({...e, el: document.getElementById(e.id)}));
const LEG = document.getElementById('legendas');
const GRAO = document.getElementById('grao');
const PROG = document.getElementById('progresso');
const LUZ = document.getElementById('luz');
let ultimaPagina = null;
function aplicar(t){
  for (const e of ELS){
    if (!e.el) continue;
    if (e.inicio !== undefined && !e.video){ e.el.style.visibility = (t >= e.inicio && t < e.fim) ? 'visible' : 'hidden'; }
    if (e.tweens.length){ const c = estadoParaCss(estadoEm(e.tweens, t)); e.el.style.opacity=c.opacity; e.el.style.transform=c.transform; e.el.style.filter=c.filter; if(c.letterSpacing) e.el.style.letterSpacing=c.letterSpacing; if(e.temP) e.el.style.setProperty('--p', c.p); }
    if (e.contador){ e.el.innerHTML = formatarNumero(contadorEm(e.contador, t), e.contador); }
    if (e.rig && t >= e.rig.t0 - 0.05 && t < e.rig.t1 + 0.05){ animarPersonagem(e.el, e.rig, Math.max(e.rig.t0, Math.min(t, e.rig.t1))); }
  }
  if (LEG){
    const l = legendaEm(P.legendas, t);
    if (!l){ LEG.innerHTML=''; ultimaPagina=null; }
    else {
      if (ultimaPagina !== l.pagina){ LEG.innerHTML = l.pagina.palavras.map(w=>'<span class="lw">'+w.txt+'</span>').join(' '); ultimaPagina = l.pagina; }
      [...LEG.children].forEach((s,i)=>{ s.className = 'lw' + (i===l.ativa ? ' ativa' : i>l.ativa ? ' futura' : ''); if (l.pagina.palavras[i].enfase) s.style.color='var(--destaque)'; });
    }
  }
  if (GRAO){ const f = Math.floor(t*P.fps)%8; GRAO.style.transform = 'translate(' + ((f*37)%100-50) + 'px,' + ((f*61)%100-50) + 'px)'; }
  if (LUZ){ const k=t/P.duracao; LUZ.style.transform='translate('+(Math.sin(k*Math.PI*2)*18)+'%,'+(-20+k*40)+'%)'; }
  if (PROG) PROG.style.width = (Math.min(1, t/P.duracao)*100) + '%';
}
${sabor === 'nativo' ? `
window.__seek = async (t) => {
  aplicar(t);
  const espera = [];
  for (const e of ELS){
    if (!e.video || !e.el) continue;
    const on = t >= e.inicio && t < e.fim;
    if (window.__PREVIEW){   /* prévia ao vivo (Brightway): o vídeo toca sozinho e só corrige quando desvia */
      if (!on){ if (!e.el.paused) e.el.pause(); continue; }
      const alvoP = e.inicioNoArquivo + (t - e.inicio);
      if (window.__TOCANDO){
        if (e.el.paused){ try { e.el.currentTime = alvoP; } catch(_){} e.el.play().catch(()=>{}); }
        else if (Math.abs(e.el.currentTime - alvoP) > 0.35){ try { e.el.currentTime = alvoP; } catch(_){} }
      } else {
        if (!e.el.paused) e.el.pause();
        if (Math.abs(e.el.currentTime - alvoP) > 0.04){ try { e.el.currentTime = alvoP; } catch(_){} }
      }
      continue;
    }
    if (!on) continue;
    const alvo = e.inicioNoArquivo + (t - e.inicio);
    if (Math.abs(e.el.currentTime - alvo) > 0.001){
      espera.push(new Promise(r => { const ok = () => { e.el.removeEventListener('seeked', ok); r(); }; e.el.addEventListener('seeked', ok); setTimeout(r, 3000); e.el.currentTime = alvo; }));
    }
  }
  await Promise.all(espera);
};
window.__pronto = (async () => {
  try { await document.fonts.ready; } catch(e) {}
  await Promise.all([...document.images].map(i => i.complete ? 0 : new Promise(r => { i.onload = i.onerror = r; })));
  await Promise.all([...document.querySelectorAll('video')].map(v => v.readyState >= 2 ? 0 : new Promise(r => { v.onloadeddata = v.onerror = r; setTimeout(r, 8000); })));
  aplicar(0); return true;
})();
` : `
// HyperFrames: uma única tween GSAP em um "setter" chama aplicar(t) a cada frame, inclusive em seek.
const proxy = { _t: 0, get t(){ return this._t; }, set t(v){ this._t = v; aplicar(v); } };
const tl = gsap.timeline({ paused: true });
tl.to(proxy, { t: P.duracao, duration: P.duracao, ease: 'none' }, 0);
window.__timelines = window.__timelines || {};
window.__timelines.reel = tl;
aplicar(0);
`}
`;

export function construirHtml(plano, sabor = 'nativo') {
  const fx = plano.efeitos;
  const todos = [...plano.cenas, ...plano.globais];
  const dados = { fps: plano.fps, duracao: plano.duracao, legendas: plano.legendas, els: coletar(todos) };
  const cenasHtml = plano.cenas.map((c) => no(c, sabor)).join('\n');
  const globaisHtml = plano.globais.map((g) => no(g, sabor)).join('\n');

  // HyperFrames: vídeos como clips de topo (track 0) e áudios como elementos <audio>
  let clipsHf = '';
  if (sabor === 'hyperframes') {
    const vids = [];
    const busca = (ns) => ns.forEach((n) => { if (n.tag === 'video') vids.push(n); if (n.filhos) busca(n.filhos); });
    busca(plano.cenas);
    clipsHf = vids.map((v) => `<video class="clip" data-start="${v.inicio.toFixed(3)}" data-duration="${(v.fim - v.inicio).toFixed(3)}" data-track-index="0" src="${v.src}" muted playsinline></video>`).join('\n');
    clipsHf += '\n' + plano.audios.concat(plano.sfxArquivos || []).map((a, i) => `<audio data-start="${(a.inicio || 0).toFixed(3)}" data-duration="${(a.duracao || plano.duracao).toFixed(3)}" data-track-index="${10 + i}" data-volume="${a.volume ?? 1}" src="${a.src}"></audio>`).join('\n');
  }

  const raiz = sabor === 'hyperframes'
    ? `<div id="stage" data-composition-id="reel" data-start="0" data-width="${plano.largura}" data-height="${plano.altura}">`
    : `<div id="stage">`;

  return `<!doctype html>
<html lang="pt-BR"><head><meta charset="utf-8"><title>${plano.titulo}</title>
<link rel="stylesheet" href="${GOOGLE_FONTS}">
<style>${css(plano)}</style></head><body>
${raiz}
${clipsHf}
${fx.luz !== false ? '<div id="luz" class="global"></div>' : ''}
${cenasHtml}
${globaisHtml}
<div id="legendas"></div>
${fx.letterbox ? '<div class="barra" style="top:0"></div><div class="barra" style="bottom:0"></div>' : ''}
${fx.vinheta ? '<div id="vinheta" class="global"></div>' : ''}
${fx.grao ? '<div id="grao" class="global"></div>' : ''}
${fx.barraProgresso ? '<div id="progresso"></div>' : ''}
${plano.marca?.handle ? `<div id="marca">${plano.marca.handle}</div>` : ''}
${sabor === 'hyperframes' ? '<script src="https://cdn.jsdelivr.net/npm/gsap@3/dist/gsap.min.js"></script>' : ''}
<script>window.__PLANO = ${JSON.stringify(dados)}; window.__DUR = ${plano.duracao}; window.__W = ${plano.largura}; window.__H = ${plano.altura}; window.__FPS = ${plano.fps};</script>
<script>${RUNTIME(sabor)}</script>
</div></body></html>`;
}
