#!/usr/bin/env node
// Gera os vídeos de exemplo da galeria do BW Reels Pro a partir dos modelos do site (assets/reels-modelos.js).
// Uso: node motor/exemplos-web.mjs <pasta do site> [id ...]
import { readFileSync, writeFileSync, mkdirSync, rmSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import vm from 'node:vm';
import { criarPlano } from './plano.mjs';
import { construirHtml } from './html.mjs';

const AQUI = dirname(fileURLToPath(import.meta.url));
const site = resolve(process.argv[2] || '.');
const so = process.argv.slice(3);
const ctx = { window: {} }; vm.runInNewContext(readFileSync(join(site, 'assets/reels-modelos.js'), 'utf8'), ctx);
const M = ctx.window.BWReelsModelos;
const lista = M.modelos.map((m) => [m.id, m.roteiro]).concat([['demo-ia', M.demoIA]]).filter(([id]) => !so.length || so.includes(id));
const saida = join(site, 'assets/reels-exemplos'); mkdirSync(saida, { recursive: true });
const tmp = join(AQUI, '..', 'projetos', '_exemplos'); mkdirSync(tmp, { recursive: true });
for (const [id, r] of lista) {
  const html = join(tmp, `${id}.html`);
  const rr = JSON.parse(JSON.stringify(r)); rr.efeitos = { ...rr.efeitos, sfx: false };
  writeFileSync(html, construirHtml(criarPlano(rr), 'nativo'));
  const mp4 = join(saida, `${id}.mp4`);
  const p = spawnSync('node', [join(AQUI, 'animar.mjs'), html, '--escala', '0.3334', '--fps', '24', '--crf', '31', '--saida', mp4], { stdio: 'inherit' });
  if (p.status !== 0) { console.error('falhou: ' + id); continue; }
  spawnSync('ffmpeg', ['-y', '-hide_banner', '-loglevel', 'error', '-ss', '2.2', '-i', mp4, '-frames:v', '1', '-q:v', '5', join(saida, `${id}.jpg`)], { stdio: 'inherit' });
  console.log('✔ ' + id);
}
rmSync(tmp, { recursive: true, force: true });
