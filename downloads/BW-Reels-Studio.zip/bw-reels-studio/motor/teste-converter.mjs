/* Teste da conversão de takes do iPhone no PC (motor/converter-video.mjs): HEVC 10 bits HLG girado, ProRes e H.264 girado
   viram MP4 H.264 + AAC em pé; HDR sai em BT.709; o temporário some no fim; id/tamanho errados são recusados. Uso: node motor/teste-converter.mjs */
import { spawnSync } from 'node:child_process';
import { mkdtempSync, readFileSync, writeFileSync, existsSync, readdirSync } from 'node:fs';
import { join } from 'node:path';
import { tmpdir } from 'node:os';
const T = mkdtempSync(join(tmpdir(), 'bwconv-')); process.env.BW_CONV_PASTA = join(T, 'trab');
const C = await import('./converter-video.mjs');
let falhas = 0; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) falhas++; };
const ff = (a) => { const r = spawnSync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', ...a]); if (r.status) throw new Error(String(r.stderr)); };
const SRC = ['-f', 'lavfi', '-i', 'color=red:s=320x180:d=2:r=30', '-f', 'lavfi', '-i', 'color=lime:s=60x40:d=2:r=30', '-f', 'lavfi', '-i', 'sine=f=440:d=2'];
ff([...SRC, '-filter_complex', '[0][1]overlay=10:10,format=yuv420p10le[v]', '-map', '[v]', '-map', '2', '-c:v', 'libx265', '-x265-params', 'log-level=error', '-color_primaries', 'bt2020', '-color_trc', 'arib-std-b67', '-colorspace', 'bt2020nc', '-tag:v', 'hvc1', '-c:a', 'aac', join(T, 'h0.mov')]);
ff(['-display_rotation', '-90', '-i', join(T, 'h0.mov'), '-c', 'copy', '-tag:v', 'hvc1', join(T, 'hevc.mov')]);
ff([...SRC, '-filter_complex', '[0][1]overlay=10:10,format=yuv422p10le[v]', '-map', '[v]', '-map', '2', '-c:v', 'prores_ks', '-profile:v', '3', '-c:a', 'pcm_s16le', join(T, 'prores.mov')]);
const cap = C.pode(); ok(cap.ffmpeg, `FFmpeg achado (${cap.versao}; NVIDIA: ${cap.nvenc ? 'sim' : 'não'}; mapa de tons: ${cap.tonemap ? 'sim' : 'não'})`);
for (const [f, w, h, hdr] of [['hevc.mov', 180, 320, true], ['prores.mov', 320, 180, false]]) {
  const b = readFileSync(join(T, f)), { id } = C.ini({ nome: 'IMG_' + f, bytes: b.length });
  for (let o = 0; o < b.length; o += 50000) C.pedaco({ id, b64: b.subarray(o, o + 50000).toString('base64') });
  let pct = 0; const r = await C.fazer({ id, curto: 2160 }, (p) => { pct = p.pct; });
  const parts = []; for (let o = 0; o < r.bytes; o += 40000) parts.push(Buffer.from(C.ler({ id, de: o, ate: Math.min(r.bytes, o + 40000) }), 'base64'));
  const saida = join(T, f + '.mp4'); writeFileSync(saida, Buffer.concat(parts)); const s = C.sonda(saida);
  ok(s && s.codec === 'h264' && s.w === w && s.h === h && s.som && s.pix === 'yuv420p', `${f} → H.264 ${s && s.w}×${s && s.h} com som (${r.placa === 'NVIDIA' ? 'pela NVIDIA' : 'pelo processador'}), progresso ${Math.round(pct)}%`);
  if (hdr) ok(r.hdr && s.trc === 'bt709', `…HDR (HLG) virou SDR BT.709 (${s.trc})`);
  C.fim({ id }); ok(!readdirSync(process.env.BW_CONV_PASTA).length, '…arquivos temporários apagados no fim');
}
let rec = 0; for (const t of [() => C.pedaco({ id: '../../etc', b64: 'AA==' }), () => C.ini({ nome: 'x', bytes: 13 * 1024 ** 3 }), () => C.ler({ id: 'zzzz', de: 0, ate: 9 })]) try { t(); } catch (e) { rec++; }
ok(rec === 3, 'id inventado, caminho de fora e take grande demais são recusados');
const { id } = C.ini({ nome: 'a.mov', bytes: 4 }); let a = 0; try { C.pedaco({ id, b64: Buffer.alloc(8).toString('base64') }); } catch (e) { a = 1; } ok(a, '…pedaço maior que o anunciado é recusado'); C.fim({ id });
console.log(falhas ? `\n❌ ${falhas} falha(s)` : '\n✅ 0 falhas'); process.exit(falhas ? 1 : 0);
