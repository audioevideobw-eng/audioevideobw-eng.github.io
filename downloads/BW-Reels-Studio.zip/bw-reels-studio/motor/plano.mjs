// Converte o roteiro (JSON curto escrito pelo Claude) em um "plano de render"
// independente de motor: árvore de elementos + tweens + legendas + áudios.

import { ESTILOS, FORMATOS } from './estilos.mjs';
import { PERSONAGENS, svgPersonagem } from './personagens.mjs';

const esc = (s = '') =>
  String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const limpa = (w) => w.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\w%+]/g, '');

const TRANSICAO_PADRAO = {
  gancho: 'zoom', texto: 'deslize', midia: 'corte', dado: 'zoom', lista: 'deslize', citacao: 'fade', cta: 'zoom', personagem: 'fade',
};

export function criarPlano(roteiro) {
  const fmt = FORMATOS[roteiro.formato || '9:16'];
  if (!fmt) throw new Error(`formato inválido: ${roteiro.formato}`);
  const est = ESTILOS[roteiro.estilo || 'cinema'];
  if (!est) throw new Error(`estilo inválido: ${roteiro.estilo}`);
  const W = fmt.largura, H = fmt.altura, vertical = H > W;
  const fx = { grao: true, vinheta: true, letterbox: false, barraProgresso: true, sfx: true, ...(roteiro.efeitos || {}) };
  const u = W / 1080; // unidade de escala

  const plano = {
    titulo: roteiro.titulo || 'reel', largura: W, altura: H, fps: roteiro.fps || 30,
    estilo: est, efeitos: fx, cenas: [], globais: [], legendas: [], audios: [], sfx: [], duracao: 0,
    marca: roteiro.marca || {},
    estiloNome: roteiro.estilo || 'cinema',
  };
  const au0 = roteiro.audio || {};
  // trilha de fundo gerada pelo motor: 'auto' = a do estilo; com música própria, fica desligada (a não ser que peçam)
  const tr0 = au0.trilha ?? (au0.musica ? 'nenhuma' : 'auto');
  plano.trilha = tr0 === 'auto' ? plano.estiloNome : tr0;
  plano.volumeTrilha = au0.volumeTrilha ?? (au0.narracao ? 0.22 : 0.45);
  const som = (ev) => { if (fx.sfx) plano.sfx.push(ev); };

  let t = 0;
  let id = 0;
  const novoId = (p) => `${p}${id++}`;
  const tw = (t0, dur, de, para, ease = 'expo.out') => ({ t0, dur, de, para, ease });

  // Quebra um texto em palavras animáveis (stagger), marcando ênfases.
  function palavras(texto, a, { atraso = 0.05, passo = 0.09, y = 80 * u, blur = 14, dur = 0.6, enfase = [] } = {}) {
    const enf = new Set((enfase || []).map(limpa));
    return String(texto).split(/\s+/).filter(Boolean).map((w, i) => ({
      id: novoId('w'), tag: 'span', classe: enf.has(limpa(w)) ? 'w enf' : 'w', html: esc(w),
      tweens: [tw(a + atraso + i * passo, dur, { opacity: 0, y, blur }, { opacity: 1, y: 0, blur: 0 })],
    }));
  }

  const midiaNo = (c, a, d) => {
    if (!c.midia) return null;
    const ehVideo = /\.(mp4|mov|webm|m4v|mkv)$/i.test(c.midia);
    const mov = c.movimento || (ehVideo ? 'zoom-in-suave' : 'zoom-in');
    const mapa = {
      'zoom-in': [{ scale: 1 }, { scale: 1.18 }],
      'zoom-in-suave': [{ scale: 1.02 }, { scale: 1.08 }],
      'zoom-out': [{ scale: 1.18 }, { scale: 1 }],
      'pan-esq': [{ scale: 1.15, x: 60 * u }, { scale: 1.15, x: -60 * u }],
      'pan-dir': [{ scale: 1.15, x: -60 * u }, { scale: 1.15, x: 60 * u }],
      fixo: [{ scale: 1 }, { scale: 1 }],
    };
    const [de, para] = mapa[mov] || mapa['zoom-in'];
    return {
      id: novoId('m'), tag: 'div', classe: 'midia',
      tweens: [tw(a, d, de, para, 'linear')],
      filhos: [{
        id: novoId('mv'), tag: ehVideo ? 'video' : 'img', classe: 'midia-el', src: c.midia,
        inicioNoArquivo: c.inicioNoArquivo || 0, inicio: a, fim: a + d, video: ehVideo,
      }],
    };
  };

  roteiro.cenas.forEach((c, i) => {
    const d = Number(c.duracao) || 3;
    const a = t;
    const filhos = [];
    const m = midiaNo(c, a, d);
    if (m) {
      filhos.push(m);
      filhos.push({ id: novoId('g'), tag: 'div', classe: 'escurecer' });
    }

    switch (c.tipo) {
      case 'gancho': {
        if (c.chamada) filhos.push({ id: novoId('k'), tag: 'div', classe: 'chamada', html: esc(c.chamada),
          tweens: [tw(a, 0.4, { opacity: 0, y: -20 * u }, { opacity: 1, y: 0 })] });
        filhos.push({ id: novoId('h'), tag: 'h1', classe: 'titulo gigante', filhos: palavras(c.texto, a, { enfase: c.enfase }),
          tweens: [tw(a, d, { scale: 1 }, { scale: 1.06 }, 'linear')] });
        break;
      }
      case 'texto': {
        filhos.push({ id: novoId('h'), tag: 'h2', classe: 'titulo', filhos: palavras(c.titulo || c.texto, a, { y: 50 * u, enfase: c.enfase }) });
        if (c.subtitulo) filhos.push({ id: novoId('p'), tag: 'p', classe: 'sub', html: esc(c.subtitulo),
          tweens: [tw(a + 0.55, 0.6, { opacity: 0, y: 24 * u }, { opacity: 1, y: 0 })] });
        break;
      }
      case 'midia': {
        if (c.texto) filhos.push({ id: novoId('h'), tag: 'h2', classe: 'titulo rodape', filhos: palavras(c.texto, a + 0.2, { y: 40 * u, enfase: c.enfase }) });
        break;
      }
      case 'dado': {
        som({ tipo: 'contador', inicio: a + 0.15, dur: Math.min(1.6, d * 0.6) });
        filhos.push({ id: novoId('n'), tag: 'div', classe: 'numero', html: '0',
          contador: { de: 0, para: Number(c.valor), t0: a + 0.15, dur: Math.min(1.6, d * 0.6), prefixo: c.prefixo, sufixo: c.sufixo, casas: c.casas },
          tweens: [tw(a, 0.7, { scale: 0.7, opacity: 0 }, { scale: 1, opacity: 1 }, 'back.out')] });
        if (c.rotulo) filhos.push({ id: novoId('r'), tag: 'p', classe: 'rotulo', html: esc(c.rotulo),
          tweens: [tw(a + 0.6, 0.6, { opacity: 0, y: 30 * u }, { opacity: 1, y: 0 })] });
        if (c.fonte) filhos.push({ id: novoId('f'), tag: 'p', classe: 'fonte', html: `Fonte: ${esc(c.fonte)}`,
          tweens: [tw(a + 1.0, 0.5, { opacity: 0 }, { opacity: 0.85 })] });
        break;
      }
      case 'lista': {
        if (c.titulo) filhos.push({ id: novoId('h'), tag: 'h2', classe: 'titulo pequeno', filhos: palavras(c.titulo, a, { y: 40 * u, enfase: c.enfase }) });
        const passo = Math.min(0.5, (d - 1) / Math.max(1, c.itens.length));
        c.itens.forEach((_, k) => som({ tipo: 'clique', inicio: a + 0.45 + k * passo }));
        filhos.push({ id: novoId('l'), tag: 'ol', classe: 'lista', filhos: c.itens.map((it, k) => ({
          id: novoId('li'), tag: 'li', classe: 'item', html: `<b>${k + 1}</b><span>${esc(it)}</span>`,
          tweens: [tw(a + 0.45 + k * passo, 0.55, { opacity: 0, x: -70 * u, blur: 8 }, { opacity: 1, x: 0, blur: 0 })],
        })) });
        break;
      }
      case 'citacao': {
        filhos.push({ id: novoId('q'), tag: 'div', classe: 'aspas', html: '“',
          tweens: [tw(a, 0.6, { opacity: 0, scale: 1.6 }, { opacity: 1, scale: 1 })] });
        filhos.push({ id: novoId('h'), tag: 'h2', classe: 'titulo citacao', filhos: palavras(c.texto, a + 0.2, { passo: 0.06, y: 0, blur: 6, dur: 0.5, enfase: c.enfase }) });
        if (c.autor) filhos.push({ id: novoId('au'), tag: 'p', classe: 'sub', html: `— ${esc(c.autor)}`,
          tweens: [tw(a + 0.9, 0.6, { opacity: 0 }, { opacity: 1 })] });
        break;
      }
      case 'cta': {
        filhos.push({ id: novoId('h'), tag: 'h2', classe: 'titulo', filhos: palavras(c.texto, a, { y: 50 * u, enfase: c.enfase }) });
        if (c.acao) som({ tipo: 'brilho', inicio: a + 0.62 });
        if (c.acao) filhos.push({ id: novoId('b'), tag: 'div', classe: 'botao', html: esc(c.acao),
          tweens: [
            tw(a + 0.6, 0.6, { opacity: 0, scale: 0.6 }, { opacity: 1, scale: 1 }, 'back.out'),
            tw(a + 1.5, 0.35, { scale: 1 }, { scale: 1.07 }, 'sine.inOut'),
            tw(a + 1.85, 0.35, { scale: 1.07 }, { scale: 1 }, 'sine.inOut'),
          ] });
        break;
      }
      case 'personagem': {
        // Elenco (1 ou 2 personagens), ação de cada um, balões de fala em sequência e cenário.
        // elenco [] (vazio de propósito) + mídia = cena só com a imagem (ex.: cena criada por IA a partir da foto do personagem)
        const elenco = (Array.isArray(c.elenco) && !c.elenco.length && c.midia ? [] : c.elenco && c.elenco.length ? c.elenco : [{ personagem: c.personagem || 'be', acao: c.acao }]).slice(0, 2);
        const falas = (c.falas && c.falas.length ? c.falas : (c.balao ? [{ quem: 0, texto: c.balao }] : []))
          .filter((f) => f && f.texto).map((f) => ({ quem: Math.max(0, Math.min(elenco.length - 1, Number(f.quem) || 0)), texto: String(f.texto) }));
        const ini = a + (c.entrada === 'nenhuma' ? 0.15 : 0.6), util = Math.max(0.6, d - (ini - a) - 0.25);
        const pesos = falas.map((f) => 1.2 + f.texto.split(/\s+/).length * 0.32);
        const soma = pesos.reduce((s2, p2) => s2 + p2, 0) || 1;
        let cur = ini;
        const tempos = falas.map((f, k) => { const dd = (pesos[k] / soma) * util; const o = [cur, cur + dd]; cur += dd; return o; });
        const cen = c.cenario || (m ? 'nenhum' : 'raios');
        if (cen === 'raios') filhos.push({ id: novoId('cn'), tag: 'div', classe: 'cenario raios', tweens: [tw(a, d, { rot: 0, scale: 1.4 }, { rot: 14, scale: 1.4 }, 'linear')] });
        if (cen === 'palco') filhos.push({ id: novoId('cn'), tag: 'div', classe: 'cenario palco', html: '<i class="spot e"></i><i class="spot d"></i><b class="chao"></b>',
          tweens: [tw(a, 0.6, { opacity: 0 }, { opacity: 1 }, 'power2.out')] });
        if (cen === 'bolinhas') filhos.push({ id: novoId('cn'), tag: 'div', classe: 'cenario bolinhas', tweens: [tw(a, d, { y: 0 }, { y: -90 * u }, 'linear')] });
        if (c.texto) filhos.push({ id: novoId('h'), tag: 'h2', classe: 'titulo pequeno topo-pers', filhos: palavras(c.texto, a, { y: 40 * u, enfase: c.enfase }) });
        const dois = elenco.length > 1;
        elenco.forEach((ator, k) => {
          const foto = ator.personagem === 'foto' && ator.imagem;
          const pid = ator.personagem === 'meu' && ator.look ? ator.look : ator.personagem && PERSONAGENS[ator.personagem] ? ator.personagem : 'be';
          const lado = dois ? (k === 0 ? -1 : 1) : (c.posicao === 'esquerda' ? -1 : c.posicao === 'direita' ? 1 : 0);
          const minhas = tempos.filter((_, j) => falas[j].quem === k);
          const outro = tempos.filter((_, j) => falas[j].quem !== k).length ? (dois ? -lado : 0) : 0;
          const rig = { t0: a, t1: a + d, acao: ator.acao || (minhas.length ? 'fala' : 'parado'), entrada: c.entrada || 'pula', lado: lado || 1, falas: minhas, olhar: outro, semente: i * 3 + k * 7 + 1 };
          if (foto) {
            rig.foto = true; rig.espelhar = !!ator.espelhar;
            filhos.push({ id: novoId('at'), tag: 'div', classe: `ator foto ${dois ? 'duplo' : 'solo'} lado${lado}${ator.contorno === false ? '' : ' contorno'}`, rig,
              filhos: [{ id: novoId('as'), tag: 'i', classe: 'foto-sombra' }, { id: novoId('ac'), tag: 'div', classe: 'foto-corpo', filhos: [{ id: novoId('ai'), tag: 'img', classe: 'foto-img', src: ator.imagem }] }] });
          } else {
            filhos.push({ id: novoId('at'), tag: 'div', classe: `ator ${dois ? 'duplo' : 'solo'} lado${lado}`, html: svgPersonagem(pid, ator.cores), rig });
          }
        });
        const temNarr = !!(roteiro.audio && roteiro.audio.narracao);
        if ((c.entrada || 'pula') === 'pula' && elenco.length) som({ tipo: 'boing', inicio: a + 0.42 });
        elenco.forEach((at) => { if (at.acao === 'comemora') som({ tipo: 'confete', inicio: a + 0.3 }); if (at.acao === 'surpresa') som({ tipo: 'susto', inicio: a + 0.12 }); });
        falas.forEach((f, k) => {
          const [t0b, t1b] = tempos[k];
          som({ tipo: 'pop', inicio: t0b });
          if (!temNarr) { const quem = elenco[f.quem] || {}; const nome = String(quem.personagem === 'foto' ? quem.imagem : quem.personagem || 'be');
            let h = 0; for (const ch of nome) h = (h * 31 + ch.charCodeAt(0)) % 997;
            som({ tipo: 'fala', inicio: t0b + 0.15, fim: t1b - 0.25, voz: 300 + (h % 7) * 45 }); }
          const lado = dois ? (f.quem === 0 ? -1 : 1) : 0;
          filhos.push({ id: novoId('bl'), tag: 'div', classe: `balao lado${lado}${dois ? ' duplo' : ''}`, html: esc(f.texto),
            tweens: [tw(t0b, 0.35, { opacity: 0, scale: 0.6, y: 30 * u }, { opacity: 1, scale: 1, y: 0 }, 'back.out'),
              tw(Math.max(t0b + 0.4, t1b - 0.2), 0.2, { opacity: 1, scale: 1 }, { opacity: 0, scale: 0.9 }, 'power2.out')] });
        });
        break;
      }
      default:
        throw new Error(`cena ${i + 1}: tipo desconhecido "${c.tipo}"`);
    }

    // Transição de entrada da cena
    const ant = roteiro.cenas[i - 1];
    const continua = c.tipo === 'personagem' && ant && ant.tipo === 'personagem' && (ant.cenario || 'raios') === (c.cenario || 'raios');
    const tr = c.transicao || (i === 0 ? 'zoom' : continua ? 'corte' : TRANSICAO_PADRAO[c.tipo]);   // mesma cena de personagem continua sem piscar
    const trTweens = {
      corte: [],
      fade: [tw(a, 0.35, { opacity: 0 }, { opacity: 1 }, 'power2.out')],
      zoom: [tw(a, 0.45, { scale: 1.25, blur: 18 }, { scale: 1, blur: 0 })],
      deslize: [tw(a, 0.45, { y: H * 0.12, opacity: 0 }, { y: 0, opacity: 1 })],
      flash: [],
    }[tr] ?? [];
    if (tr === 'flash' || (tr === 'zoom' && i > 0 && fx.flashNoZoom)) {
      plano.globais.push({ id: novoId('fl'), tag: 'div', classe: 'flash', inicio: a, fim: a + 0.3,
        tweens: [tw(a, 0.3, { opacity: 0.9 }, { opacity: 0 }, 'power2.out')] });
    }
    if (fx.sfx && i > 0 && (tr === 'zoom' || tr === 'deslize')) plano.sfx.push({ tipo: 'whoosh', inicio: Math.max(0, a - 0.12) });
    if (fx.sfx && tr === 'flash') plano.sfx.push({ tipo: 'impacto', inicio: a });
    if (fx.sfx && i === 0) plano.sfx.push({ tipo: 'impacto', inicio: 0.02 });

    plano.cenas.push({
      id: `cena${i}`, tag: 'section', classe: `cena tipo-${c.tipo}${m ? ' com-midia' : ''}`,
      inicio: a, fim: a + d, tweens: trTweens, filhos, fala: c.fala, legendaOculta: !!c.legendaOculta,
    });
    t += d;
  });
  plano.duracao = +t.toFixed(3);

  // Legendas karaokê: usa timestamps reais (Whisper) se fornecidos; senão distribui a "fala" de cada cena.
  const n = roteiro.legendas?.palavrasPorPagina || 3;
  if (roteiro.legendas?.ativas !== false) {
    const enf = new Set((roteiro.legendas?.enfase || []).map(limpa));
    const paginar = (ws) => {
      for (let k = 0; k < ws.length; k += n) {
        const grupo = ws.slice(k, k + n).map((w) => ({ ...w, txt: esc(w.txt), enfase: enf.has(limpa(w.txt)) }));
        plano.legendas.push({ t0: grupo[0].t0, t1: grupo[grupo.length - 1].t1 + 0.05, palavras: grupo });
      }
    };
    if (Array.isArray(roteiro.legendas?.palavras)) {
      // timestamps reais (Whisper): quebra página também em pausas > 0,6s
      let bloco = [];
      for (const w of roteiro.legendas.palavras) {
        const ult = bloco[bloco.length - 1];
        if (ult && w.inicio - ult.t1 > 0.6) { paginar(bloco); bloco = []; }
        bloco.push({ txt: w.palavra, t0: w.inicio, t1: w.fim });
      }
      paginar(bloco);
    } else {
      // distribui a "fala" de cada cena dentro da própria cena (páginas nunca atravessam cortes)
      plano.cenas.forEach((c, i) => {
        const cena = roteiro.cenas[i];
        const oculta = cena.legenda === false || ((cena.tipo === 'gancho' || cena.tipo === 'personagem') && cena.legenda !== true);
        if (!c.fala || oculta) return;
        const lista = c.fala.split(/\s+/).filter(Boolean);
        const pesos = lista.map((w) => 0.6 + w.length * 0.12);
        const total = pesos.reduce((s, p) => s + p, 0);
        const util = (c.fim - c.inicio) - 0.3;
        let cur = c.inicio + 0.12;
        const ws = lista.map((w, k) => { const d = (pesos[k] / total) * util; const o = { txt: w, t0: cur, t1: cur + d }; cur += d; return o; });
        paginar(ws);
      });
    }
  }

  // Áudios (música + narração). Os SFX são gerados no render.
  const au = roteiro.audio || {};
  if (au.musica) plano.audios.push({ papel: 'musica', src: au.musica, inicio: 0, volume: au.volumeMusica ?? (au.narracao ? 0.25 : 0.6) });
  if (au.narracao) plano.audios.push({ papel: 'narracao', src: au.narracao, inicio: au.inicioNarracao || 0, volume: au.volumeNarracao ?? 1 });

  plano.vertical = vertical;
  return plano;
}
