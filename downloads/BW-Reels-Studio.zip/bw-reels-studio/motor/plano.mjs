// Converte o roteiro (JSON curto escrito pelo Claude) em um "plano de render"
// independente de motor: árvore de elementos + tweens + legendas + áudios.

import { ESTILOS, FORMATOS } from './estilos.mjs';

const esc = (s = '') =>
  String(s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');

const limpa = (w) => w.toLowerCase().normalize('NFD').replace(/[̀-ͯ]/g, '').replace(/[^\w%+]/g, '');

const TRANSICAO_PADRAO = {
  gancho: 'zoom', texto: 'deslize', midia: 'corte', dado: 'zoom', lista: 'deslize', citacao: 'fade', cta: 'zoom',
};

export function criarPlano(roteiro) {
  const fmt = FORMATOS[roteiro.formato || '9:16'];
  if (!fmt) throw new Error(`formato inválido: ${roteiro.formato}`);
  const est = ESTILOS[roteiro.estilo || 'cinema'];
  if (!est) throw new Error(`estilo inválido: ${roteiro.estilo}`);
  const W = fmt.largura, H = fmt.altura, vertical = H > W;
  const fx = { grao: true, vinheta: true, letterbox: false, barraProgresso: true, sfx: true, ...(roteiro.efeitos || {}) };
  const u = W / 1080; // unidade de escala

  const plano = {
    titulo: roteiro.titulo || 'reel', largura: W, altura: H, fps: roteiro.fps || 30,
    estilo: est, efeitos: fx, cenas: [], globais: [], legendas: [], audios: [], sfx: [], duracao: 0,
    marca: roteiro.marca || {},
  };

  let t = 0;
  let id = 0;
  const novoId = (p) => `${p}${id++}`;
  const tw = (t0, dur, de, para, ease = 'expo.out') => ({ t0, dur, de, para, ease });

  // Quebra um texto em palavras animáveis (stagger), marcando ênfases.
  function palavras(texto, a, { atraso = 0.05, passo = 0.09, y = 80 * u, blur = 14, dur = 0.6, enfase = [] } = {}) {
    const enf = new Set((enfase || []).map(limpa));
    return String(texto).split(/\s+/).filter(Boolean).map((w, i) => ({
      id: novoId('w'), tag: 'span', classe: enf.has(limpa(w)) ? 'w enf' : 'w', html: esc(w),
      tweens: [tw(a + atraso + i * passo, dur, { opacity: 0, y, blur }, { opacity: 1, y: 0, blur: 0 })],
    }));
  }

  const midiaNo = (c, a, d) => {
    if (!c.midia) return null;
    const ehVideo = /\.(mp4|mov|webm|m4v|mkv)$/i.test(c.midia);
    const mov = c.movimento || (ehVideo ? 'zoom-in-suave' : 'zoom-in');
    const mapa = {
      'zoom-in': [{ scale: 1 }, { scale: 1.18 }],
      'zoom-in-suave': [{ scale: 1.02 }, { scale: 1.08 }],
      'zoom-out': [{ scale: 1.18 }, { scale: 1 }],
      'pan-esq': [{ scale: 1.15, x: 60 * u }, { scale: 1.15, x: -60 * u }],
      'pan-dir': [{ scale: 1.15, x: -60 * u }, { scale: 1.15, x: 60 * u }],
      fixo: [{ scale: 1 }, { scale: 1 }],
    };
    const [de, para] = mapa[mov] || mapa['zoom-in'];
    return {
      id: novoId('m'), tag: 'div', classe: 'midia',
      tweens: [tw(a, d, de, para, 'linear')],
      filhos: [{
        id: novoId('mv'), tag: ehVideo ? 'video' : 'img', classe: 'midia-el', src: c.midia,
        inicioNoArquivo: c.inicioNoArquivo || 0, inicio: a, fim: a + d, video: ehVideo,
      }],
    };
  };

  roteiro.cenas.forEach((c, i) => {
    const d = Number(c.duracao) || 3;
    const a = t;
    const filhos = [];
    const m = midiaNo(c, a, d);
    if (m) {
      filhos.push(m);
      filhos.push({ id: novoId('g'), tag: 'div', classe: 'escurecer' });
    }

    switch (c.tipo) {
      case 'gancho': {
        if (c.chamada) filhos.push({ id: novoId('k'), tag: 'div', classe: 'chamada', html: esc(c.chamada),
          tweens: [tw(a, 0.4, { opacity: 0, y: -20 * u }, { opacity: 1, y: 0 })] });
        filhos.push({ id: novoId('h'), tag: 'h1', classe: 'titulo gigante', filhos: palavras(c.texto, a, { enfase: c.enfase }),
          tweens: [tw(a, d, { scale: 1 }, { scale: 1.06 }, 'linear')] });
        break;
      }
      case 'texto': {
        filhos.push({ id: novoId('h'), tag: 'h2', classe: 'titulo', filhos: palavras(c.titulo || c.texto, a, { y: 50 * u, enfase: c.enfase }) });
        if (c.subtitulo) filhos.push({ id: novoId('p'), tag: 'p', classe: 'sub', html: esc(c.subtitulo),
          tweens: [tw(a + 0.55, 0.6, { opacity: 0, y: 24 * u }, { opacity: 1, y: 0 })] });
        break;
      }
      case 'midia': {
        if (c.texto) filhos.push({ id: novoId('h'), tag: 'h2', classe: 'titulo rodape', filhos: palavras(c.texto, a + 0.2, { y: 40 * u, enfase: c.enfase }) });
        break;
      }
      case 'dado': {
        filhos.push({ id: novoId('n'), tag: 'div', classe: 'numero', html: '0',
          contador: { de: 0, para: Number(c.valor), t0: a + 0.15, dur: Math.min(1.6, d * 0.6), prefixo: c.prefixo, sufixo: c.sufixo, casas: c.casas },
          tweens: [tw(a, 0.7, { scale: 0.7, opacity: 0 }, { scale: 1, opacity: 1 }, 'back.out')] });
        if (c.rotulo) filhos.push({ id: novoId('r'), tag: 'p', classe: 'rotulo', html: esc(c.rotulo),
          tweens: [tw(a + 0.6, 0.6, { opacity: 0, y: 30 * u }, { opacity: 1, y: 0 })] });
        if (c.fonte) filhos.push({ id: novoId('f'), tag: 'p', classe: 'fonte', html: `Fonte: ${esc(c.fonte)}`,
          tweens: [tw(a + 1.0, 0.5, { opacity: 0 }, { opacity: 0.85 })] });
        break;
      }
      case 'lista': {
        if (c.titulo) filhos.push({ id: novoId('h'), tag: 'h2', classe: 'titulo pequeno', filhos: palavras(c.titulo, a, { y: 40 * u, enfase: c.enfase }) });
        const passo = Math.min(0.5, (d - 1) / Math.max(1, c.itens.length));
        filhos.push({ id: novoId('l'), tag: 'ol', classe: 'lista', filhos: c.itens.map((it, k) => ({
          id: novoId('li'), tag: 'li', classe: 'item', html: `<b>${k + 1}</b><span>${esc(it)}</span>`,
          tweens: [tw(a + 0.45 + k * passo, 0.55, { opacity: 0, x: -70 * u, blur: 8 }, { opacity: 1, x: 0, blur: 0 })],
        })) });
        break;
      }
      case 'citacao': {
        filhos.push({ id: novoId('q'), tag: 'div', classe: 'aspas', html: '“',
          tweens: [tw(a, 0.6, { opacity: 0, scale: 1.6 }, { opacity: 1, scale: 1 })] });
        filhos.push({ id: novoId('h'), tag: 'h2', classe: 'titulo citacao', filhos: palavras(c.texto, a + 0.2, { passo: 0.06, y: 0, blur: 6, dur: 0.5, enfase: c.enfase }) });
        if (c.autor) filhos.push({ id: novoId('au'), tag: 'p', classe: 'sub', html: `— ${esc(c.autor)}`,
          tweens: [tw(a + 0.9, 0.6, { opacity: 0 }, { opacity: 1 })] });
        break;
      }
      case 'cta': {
        filhos.push({ id: novoId('h'), tag: 'h2', classe: 'titulo', filhos: palavras(c.texto, a, { y: 50 * u, enfase: c.enfase }) });
        if (c.acao) filhos.push({ id: novoId('b'), tag: 'div', classe: 'botao', html: esc(c.acao),
          tweens: [
            tw(a + 0.6, 0.6, { opacity: 0, scale: 0.6 }, { opacity: 1, scale: 1 }, 'back.out'),
            tw(a + 1.5, 0.35, { scale: 1 }, { scale: 1.07 }, 'sine.inOut'),
            tw(a + 1.85, 0.35, { scale: 1.07 }, { scale: 1 }, 'sine.inOut'),
          ] });
        break;
      }
      default:
        throw new Error(`cena ${i + 1}: tipo desconhecido "${c.tipo}"`);
    }

    // Transição de entrada da cena
    const tr = c.transicao || (i === 0 ? 'zoom' : TRANSICAO_PADRAO[c.tipo]);
    const trTweens = {
      corte: [],
      fade: [tw(a, 0.35, { opacity: 0 }, { opacity: 1 }, 'power2.out')],
      zoom: [tw(a, 0.45, { scale: 1.25, blur: 18 }, { scale: 1, blur: 0 })],
      deslize: [tw(a, 0.45, { y: H * 0.12, opacity: 0 }, { y: 0, opacity: 1 })],
      flash: [],
    }[tr] ?? [];
    if (tr === 'flash' || (tr === 'zoom' && i > 0 && fx.flashNoZoom)) {
      plano.globais.push({ id: novoId('fl'), tag: 'div', classe: 'flash', inicio: a, fim: a + 0.3,
        tweens: [tw(a, 0.3, { opacity: 0.9 }, { opacity: 0 }, 'power2.out')] });
    }
    if (fx.sfx && i > 0 && (tr === 'zoom' || tr === 'deslize')) plano.sfx.push({ tipo: 'whoosh', inicio: Math.max(0, a - 0.12) });
    if (fx.sfx && tr === 'flash') plano.sfx.push({ tipo: 'impacto', inicio: a });
    if (fx.sfx && i === 0) plano.sfx.push({ tipo: 'impacto', inicio: 0.02 });

    plano.cenas.push({
      id: `cena${i}`, tag: 'section', classe: `cena tipo-${c.tipo}${m ? ' com-midia' : ''}`,
      inicio: a, fim: a + d, tweens: trTweens, filhos, fala: c.fala, legendaOculta: !!c.legendaOculta,
    });
    t += d;
  });
  plano.duracao = +t.toFixed(3);

  // Legendas karaokê: usa timestamps reais (Whisper) se fornecidos; senão distribui a "fala" de cada cena.
  const n = roteiro.legendas?.palavrasPorPagina || 3;
  if (roteiro.legendas?.ativas !== false) {
    const enf = new Set((roteiro.legendas?.enfase || []).map(limpa));
    const paginar = (ws) => {
      for (let k = 0; k < ws.length; k += n) {
        const grupo = ws.slice(k, k + n).map((w) => ({ ...w, txt: esc(w.txt), enfase: enf.has(limpa(w.txt)) }));
        plano.legendas.push({ t0: grupo[0].t0, t1: grupo[grupo.length - 1].t1 + 0.05, palavras: grupo });
      }
    };
    if (Array.isArray(roteiro.legendas?.palavras)) {
      // timestamps reais (Whisper): quebra página também em pausas > 0,6s
      let bloco = [];
      for (const w of roteiro.legendas.palavras) {
        const ult = bloco[bloco.length - 1];
        if (ult && w.inicio - ult.t1 > 0.6) { paginar(bloco); bloco = []; }
        bloco.push({ txt: w.palavra, t0: w.inicio, t1: w.fim });
      }
      paginar(bloco);
    } else {
      // distribui a "fala" de cada cena dentro da própria cena (páginas nunca atravessam cortes)
      plano.cenas.forEach((c, i) => {
        const cena = roteiro.cenas[i];
        const oculta = cena.legenda === false || (cena.tipo === 'gancho' && cena.legenda !== true);
        if (!c.fala || oculta) return;
        const lista = c.fala.split(/\s+/).filter(Boolean);
        const pesos = lista.map((w) => 0.6 + w.length * 0.12);
        const total = pesos.reduce((s, p) => s + p, 0);
        const util = (c.fim - c.inicio) - 0.3;
        let cur = c.inicio + 0.12;
        const ws = lista.map((w, k) => { const d = (pesos[k] / total) * util; const o = { txt: w, t0: cur, t1: cur + d }; cur += d; return o; });
        paginar(ws);
      });
    }
  }

  // Áudios (música + narração). Os SFX são gerados no render.
  const au = roteiro.audio || {};
  if (au.musica) plano.audios.push({ papel: 'musica', src: au.musica, inicio: 0, volume: au.volumeMusica ?? (au.narracao ? 0.25 : 0.6) });
  if (au.narracao) plano.audios.push({ papel: 'narracao', src: au.narracao, inicio: au.inicioNarracao || 0, volume: au.volumeNarracao ?? 1 });

  plano.vertical = vertical;
  return plano;
}
