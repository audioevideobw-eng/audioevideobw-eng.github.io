#!/usr/bin/env node
// CONFERIR O VÍDEO PRONTO (25/11/2026 — pedido do dono, ideia do "raea check", feita do nosso jeito, sem a raea).
// Uso: node motor/conferir.mjs <video.mp4|.mov> [--json]
//      (o animar.mjs e o render.mjs chamam sozinhos no fim; o animar.mjs também confere o HTML: texto cortado, letra pequena,
//       contraste e área dos botões do Reels/TikTok)
//
// O que olha no ARQUIVO (ffmpeg/ffprobe):
//   • se abre, duração, tamanho e quadros por segundo
//   • imagem PARADA por mais de 1,5 s (freezedetect) — às vezes é de propósito (cartela final); vira aviso, não erro
//   • tela PRETA por mais de 0,4 s (blackdetect) — não vale para vídeo com transparência
//   • SOM: mudo, volume (LUFS integrado; redes pedem perto de −14), pico real acima de −1 dBTP (estoura), silêncio de mais de 2 s
//
// Cada item volta como { nivel: 'erro'|'aviso'|'ok'|'info', item, msg, t? }. Erro = o vídeo não deve sair assim.

import { spawnSync } from 'node:child_process';
import { existsSync } from 'node:fs';
import { resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const ff = (args) => spawnSync('ffmpeg', ['-hide_banner', '-nostats', ...args], { encoding: 'utf8', maxBuffer: 64 << 20 });
const dec = (n) => n.toFixed(1).replace('.', ',').replace('-', '−');
const seg = (s) => (s < 60 ? s.toFixed(1).replace('.', ',') + ' s' : Math.floor(s / 60) + ':' + String(Math.round(s % 60)).padStart(2, '0'));

export function conferirVideo(arquivo) {
  const R = [];
  const add = (nivel, item, msg, t) => R.push({ nivel, item, msg, ...(t != null ? { t } : {}) });
  if (!existsSync(arquivo)) { add('erro', 'arquivo', 'o arquivo não existe'); return R; }
  const p = spawnSync('ffprobe', ['-v', 'error', '-print_format', 'json', '-show_streams', '-show_format', arquivo], { encoding: 'utf8' });
  let info = null; try { info = JSON.parse(p.stdout); } catch { info = null; }
  const v = info && (info.streams || []).find((s) => s.codec_type === 'video');
  const a = info && (info.streams || []).find((s) => s.codec_type === 'audio');
  if (!v) { add('erro', 'arquivo', 'não abre como vídeo (sem trilha de imagem)'); return R; }
  const dur = Number(info.format && info.format.duration) || Number(v.duration) || 0;
  if (!(dur > 0)) { add('erro', 'arquivo', 'duração zero'); return R; }
  const [fn, fd] = String(v.avg_frame_rate || v.r_frame_rate || '0/1').split('/').map(Number);
  const fps = fd ? fn / fd : 0;
  const alfa = /a/.test(String(v.pix_fmt || '').replace(/^(yuv|rgb|gbr|bgr)/, '')) || /yuva|rgba|argb|bgra|gbrap/.test(v.pix_fmt || '');
  add('info', 'arquivo', `${v.width}×${v.height} · ${fps ? Math.round(fps * 100) / 100 : '?'} q/s · ${seg(dur)} · ${v.codec_name}${a ? ' + som ' + a.codec_name : ' · sem som'}${alfa ? ' · com transparência' : ''}`);

  // imagem parada
  const fz = ff(['-i', arquivo, '-map', '0:v:0', '-vf', 'freezedetect=n=0.001:d=1.5', '-f', 'null', '-']).stderr || '';
  const ini = [...fz.matchAll(/freeze_start: ([\d.]+)/g)].map((m) => Number(m[1]));
  const fim = [...fz.matchAll(/freeze_end: ([\d.]+)/g)].map((m) => Number(m[1]));
  let parado = 0;
  ini.forEach((s, i) => { const e = fim[i] != null ? fim[i] : dur; parado += e - s; if (e - s >= dur * 0.95) return;
    add('aviso', 'imagem parada', `imagem parada de ${seg(s)} a ${seg(e)} (${seg(e - s)}) — se não for de propósito, falta movimento ali`, s); });
  if (parado >= dur * 0.95) add('erro', 'imagem parada', 'o vídeo inteiro está parado (a animação não rodou?)');
  else if (!ini.length) add('ok', 'imagem parada', 'nenhum trecho parado por mais de 1,5 s');

  // tela preta
  if (!alfa) {
    const bk = ff(['-i', arquivo, '-map', '0:v:0', '-vf', 'blackdetect=d=0.4:pix_th=0.08', '-f', 'null', '-']).stderr || '';
    const pretos = [...bk.matchAll(/black_start:([\d.]+) black_end:([\d.]+)/g)].map((m) => [Number(m[1]), Number(m[2])]);
    let preto = 0;
    pretos.forEach(([s, e]) => { preto += e - s; add('aviso', 'tela preta', `tela preta de ${seg(s)} a ${seg(e)} (${seg(e - s)})`, s); });
    if (preto >= dur * 0.95) add('erro', 'tela preta', 'o vídeo inteiro está preto');
    else if (!pretos.length) add('ok', 'tela preta', 'nenhuma tela preta');
  }

  // som
  if (!a) add('info', 'som', 'o vídeo não tem trilha de som');
  else {
    const vd = ff(['-i', arquivo, '-map', '0:a:0', '-af', 'volumedetect', '-f', 'null', '-']).stderr || '';
    const media = Number((vd.match(/mean_volume: (-?[\d.]+|-inf) dB/) || [])[1]);
    if (!isFinite(media) || media < -60) add('erro', 'som', 'a trilha de som está muda');
    else {
      const eb = ff(['-i', arquivo, '-map', '0:a:0', '-af', 'ebur128=peak=true', '-f', 'null', '-']).stderr || '';
      const resumo = eb.slice(eb.lastIndexOf('Summary:'));
      const lufs = Number((resumo.match(/I:\s+(-?[\d.]+) LUFS/) || [])[1]);
      const pico = Number((resumo.match(/Peak:\s+(-?[\d.]+|-inf) dBFS/) || [])[1]);
      if (isFinite(lufs)) {
        if (lufs < -20) add('aviso', 'som', `som baixo (${dec(lufs)} LUFS) — nas redes o normal é perto de −14; use NORMALIZAR`);
        else if (lufs > -9) add('aviso', 'som', `som muito alto (${dec(lufs)} LUFS) — o celular vai abaixar e pode distorcer`);
        else add('ok', 'som', `volume bom (${dec(lufs)} LUFS)`);
      }
      if (isFinite(pico) && pico > -1) add('aviso', 'som', `pico de ${dec(pico)} dBTP — passa de −1 e pode estourar (chiado) depois que a rede comprimir`);
      if (dur > 4) {
        const sd = ff(['-i', arquivo, '-map', '0:a:0', '-af', 'silencedetect=n=-50dB:d=2', '-f', 'null', '-']).stderr || '';
        const si = [...sd.matchAll(/silence_start: (-?[\d.]+)/g)].map((m) => Math.max(0, Number(m[1])));
        const se = [...sd.matchAll(/silence_end: ([\d.]+)/g)].map((m) => Number(m[1]));
        si.forEach((s, i) => { const e = se[i] != null ? se[i] : dur; if (e - s < dur * 0.95) add('aviso', 'som', `silêncio de ${seg(s)} a ${seg(e)}`, s); });
      }
    }
  }
  return R;
}

// Confere o HTML da animação em alguns tempos (precisa da página já aberta no tamanho do vídeo, com window.__seek).
// opts.recorte: fundo transparente (não dá para medir contraste); opts.quadroPng(t): screenshot PNG do tempo t.
export async function conferirHtml(page, meta, opts = {}) {
  const R = [];
  const vistos = new Set();
  const add = (nivel, item, msg, t, chave) => { const k = item + '|' + (chave || msg); if (vistos.has(k)) return; vistos.add(k); R.push({ nivel, item, msg, ...(t != null ? { t } : {}) }); };
  const vertical = meta.h / meta.w > 1.6;
  const n = 8;
  const tempos = Array.from({ length: n }, (_, i) => (meta.dur * (i + 0.5)) / n);
  let algumTexto = false, problemas = 0;
  const pequenas = new Map();
  for (const t of tempos) {
    await page.evaluate((x) => window.__seek(x), t);
    const textos = await page.evaluate(({ W, H, vertical }) => {
      const out = [];
      const visivel = (el) => { for (let e = el; e && e.nodeType === 1; e = e.parentElement) { const cs = getComputedStyle(e);
        if (cs.display === 'none' || cs.visibility === 'hidden' || Number(cs.opacity) < 0.15) return false; } return true; };
      const it = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      for (let no = it.nextNode(); no && out.length < 60; no = it.nextNode()) {
        const txt = no.textContent.replace(/\s+/g, ' ').trim();
        if (txt.length < 2 || !/[\p{L}\p{N}]/u.test(txt)) continue;
        const el = no.parentElement; if (!el || /^(SCRIPT|STYLE|NOSCRIPT)$/.test(el.tagName) || !visivel(el)) continue;
        const rg = document.createRange(); rg.selectNodeContents(no);
        const r = rg.getBoundingClientRect(); if (r.width < 2 || r.height < 2) continue;
        const cs = getComputedStyle(el);
        // caixa que corta o texto (overflow escondido)
        let cortadoPor = null;
        for (let e = el; e && e !== document.body; e = e.parentElement) { const c = getComputedStyle(e);
          if (/hidden|clip/.test(c.overflow + c.overflowX + c.overflowY)) { const b = e.getBoundingClientRect();
            if (r.left < b.left - 2 || r.right > b.right + 2 || r.top < b.top - 2 || r.bottom > b.bottom + 2) { cortadoPor = e.tagName.toLowerCase() + (e.id ? '#' + e.id : ''); break; } } }
        const temContorno = cs.textShadow !== 'none' || parseFloat(cs.webkitTextStrokeWidth || '0') > 0;
        out.push({ txt: txt.slice(0, 40), x: r.left, y: r.top, w: r.width, h: r.height, fonte: parseFloat(cs.fontSize), cor: cs.color, temContorno, cortadoPor,
          fora: r.left < -2 || r.top < -2 || r.right > W + 2 || r.bottom > H + 2,
          dentroTela: r.right > 0 && r.bottom > 0 && r.left < W && r.top < H,
          botoes: vertical && (r.top < H * 0.07 || r.bottom > H * 0.86 || r.right > W * 0.9) });
      }
      return out;
    }, { W: meta.w, H: meta.h, vertical });
    if (!textos.length) continue;
    algumTexto = true;
    for (const x of textos.filter((y) => y.dentroTela)) {
      const q = `“${x.txt}”`;
      if (x.fora) { problemas++; add('erro', 'texto cortado', `${q} sai da tela (a partir de ${seg(t)})`, t, x.txt); }
      if (x.cortadoPor) { problemas++; add('erro', 'texto cortado', `${q} fica escondido dentro da caixa ${x.cortadoPor} (a partir de ${seg(t)})`, t, x.txt); }
      if (x.fonte < Math.min(meta.w, meta.h) * 0.022 && !pequenas.has(x.txt)) { problemas++; pequenas.set(x.txt, Math.round(x.fonte)); }
      if (x.botoes && !x.fora) { problemas++; add('aviso', 'área dos botões', `${q} encosta na borda onde o Reels/TikTok põe botões e legenda (a partir de ${seg(t)})`, t, x.txt); }
    }
    // contraste: foto do quadro SEM as letras → cor média atrás de cada texto × cor da letra
    if (!opts.recorte && opts.quadroPng) {
      const st = await page.evaluate(() => { const s = document.createElement('style'); s.id = '__semLetra';
        s.textContent = '*{color:transparent!important;-webkit-text-fill-color:transparent!important;-webkit-text-stroke:0!important;text-shadow:none!important}'; document.head.appendChild(s); return true; });
      const png = st ? await opts.quadroPng(t) : null;
      await page.evaluate(() => { const s = document.getElementById('__semLetra'); if (s) s.remove(); });
      if (png) {
        const L = 270, A = Math.round((meta.h / meta.w) * L);
        const r = spawnSync('ffmpeg', ['-hide_banner', '-loglevel', 'error', '-i', '-', '-vf', `scale=${L}:${A}`, '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], { input: png, maxBuffer: 64 << 20 });
        const px = r.stdout || Buffer.alloc(0), k = L / meta.w;
        const lum = (R_, G, B) => { const c = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4); }; return 0.2126 * c(R_) + 0.7152 * c(G) + 0.0722 * c(B); };
        for (const x of textos.filter((y) => y.dentroTela && !y.temContorno)) {
          const m = x.cor.match(/rgba?\(([\d.]+),\s*([\d.]+),\s*([\d.]+)(?:,\s*([\d.]+))?/); if (!m) continue;
          if (m[4] != null && Number(m[4]) < 0.5) continue;
          const x0 = Math.max(0, Math.floor(x.x * k)), x1 = Math.min(L - 1, Math.ceil((x.x + x.w) * k));
          const y0 = Math.max(0, Math.floor(x.y * k)), y1 = Math.min(A - 1, Math.ceil((x.y + x.h) * k));
          const ls = [];
          for (let yy = y0; yy <= y1; yy++) for (let xx = x0; xx <= x1; xx++) { const i = (yy * L + xx) * 3; if (i + 2 < px.length) ls.push(lum(px[i], px[i + 1], px[i + 2])); }
          if (!ls.length) continue;
          ls.sort((u, v) => u - v);
          const fundo = ls[Math.floor(ls.length / 2)], letra = lum(+m[1], +m[2], +m[3]);
          const ratio = (Math.max(fundo, letra) + 0.05) / (Math.min(fundo, letra) + 0.05);
          const grande = x.fonte >= Math.min(meta.w, meta.h) * 0.045;
          if (ratio < (grande ? 2 : 3)) { problemas++; add('aviso', 'contraste', `“${x.txt}” com pouco contraste com o fundo (${ratio.toFixed(1).replace('.', ',')}:1; o recomendado é ${grande ? '3' : '4,5'}:1 ou mais) — escureça o fundo ou ponha contorno/sombra`, t, x.txt); }
        }
      }
    }
  }
  if (pequenas.size) { const lista = [...pequenas.entries()], menor = Math.min(...lista.map((e) => e[1]));
    add('aviso', 'letra pequena', (lista.length === 1 ? `“${lista[0][0]}” com letra de ${menor} px` : `${lista.length} textos com letra pequena (a menor tem ${menor} px): ` + lista.slice(0, 4).map((e) => `“${e[0]}”`).join(', ') + (lista.length > 4 ? '…' : ''))
      + ` — no celular fica difícil de ler (use ${Math.ceil(Math.min(meta.w, meta.h) * 0.022)} px ou mais)`); }
  if (algumTexto && !problemas) add('ok', 'textos', 'nenhum texto cortado, pequeno ou sem contraste');
  if (!algumTexto) add('info', 'textos', 'a animação não tem texto');
  return R;
}

export function imprimir(R, titulo = 'CONFERÊNCIA DO VÍDEO') {
  const ic = { erro: '✗', aviso: '⚠', ok: '✓', info: '·' };
  console.log(`\n  ${titulo}`);
  for (const r of R) console.log(`  ${ic[r.nivel]} ${r.msg}`);
  const e = R.filter((r) => r.nivel === 'erro').length, a = R.filter((r) => r.nivel === 'aviso').length;
  console.log(`  ${e ? '✗' : a ? '⚠' : '✓'} resultado: ${e} erro(s), ${a} aviso(s)`);
  return { erros: e, avisos: a };
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const args = process.argv.slice(2);
  const arq = args.find((x) => !x.startsWith('--'));
  if (!arq) { console.error('Uso: node motor/conferir.mjs <video.mp4|.mov> [--json]'); process.exit(2); }
  const R = conferirVideo(resolve(arq));
  if (args.includes('--json')) console.log(JSON.stringify(R, null, 2));
  else imprimir(R);
  process.exit(R.some((r) => r.nivel === 'erro') ? 1 : 0);
}
