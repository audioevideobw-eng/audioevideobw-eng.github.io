// CONECTORES DE IA DE VÍDEO — cada usuário conecta a PRÓPRIA conta (a chave é dele, a cobrança é da IA na conta dele).
// A chave fica só neste computador (~/.bw-reels/video-ias.json), nunca volta para a tela e nunca vai para a plataforma.
// Formatos de API lidos nas páginas oficiais em 18/11/2026 (fal.ai: fila queue.fal.run; Runway: api.dev.runwayml.com/v1).
// Preços = REFERÊNCIA com data; mudam sempre. Não testado com chave real neste código: o primeiro clipe é o teste.
import { readFileSync, writeFileSync, mkdirSync, existsSync, chmodSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';

const PASTA = join(homedir(), '.bw-reels');
const ARQ = join(PASTA, 'video-ias.json');
const TESTE = process.env.BWREELS_VIDEO_TESTE || '';          // só nos testes: troca os endereços por um servidor simulado
export const CONFERIDO = '18/11/2026';
export const MAX_SEG = 10;

export const PROVEDORES = {
  runway: { nome: 'Runway', site: 'https://dev.runwayml.com', ondeChave: 'dev.runwayml.com → API Keys (precisa comprar créditos na conta de desenvolvedor)',
    base: TESTE ? TESTE + '/runway' : 'https://api.dev.runwayml.com' },
  fal: { nome: 'fal.ai', site: 'https://fal.ai/dashboard/keys', ondeChave: 'fal.ai → Dashboard → Keys (uma chave dá acesso a Kling e a outras IAs; paga pelo uso)',
    base: TESTE ? TESTE + '/fal' : 'https://queue.fal.run' },
};
export const MODELOS = [
  { id: 'runway:gen4_turbo', prov: 'runway', nome: 'Runway Gen-4 Turbo', nivel: 'econômico', usd: 0.05, som: false, segs: [5, 10], obs: '720p, sem som' },
  { id: 'runway:gen4.5', prov: 'runway', nome: 'Runway Gen-4.5', nivel: 'qualidade', usd: 0.12, som: false, segs: [5, 10], obs: 'melhor movimento, sem som' },
  { id: 'fal:kling3', prov: 'fal', nome: 'Kling 3.0 Standard (pela fal.ai)', nivel: 'qualidade', usd: 0.084, som: false, segs: [5, 10], obs: 'sem som' },
  { id: 'fal:kling3-som', prov: 'fal', nome: 'Kling 3.0 Standard com som ambiente (pela fal.ai)', nivel: 'qualidade', usd: 0.126, som: true, segs: [5, 10], obs: 'som ambiente; fala só em inglês ou chinês' },
];

function ler() { try { return JSON.parse(readFileSync(ARQ, 'utf8')); } catch { return {}; } }
function gravar(d) { mkdirSync(PASTA, { recursive: true }); writeFileSync(ARQ, JSON.stringify(d, null, 2)); try { chmodSync(ARQ, 0o600); } catch { /* Windows */ } }
const dormir = (ms) => new Promise((ok) => setTimeout(ok, ms));
const curto = (t) => String(t || '').replace(/\s+/g, ' ').slice(0, 220);

/** O que a tela pode saber: quem está conectado, o final da chave e os modelos. NUNCA a chave. */
export function status() {
  const d = ler();
  const lista = Object.entries(PROVEDORES).map(([id, p]) => ({ id, nome: p.nome, site: p.site, ondeChave: p.ondeChave, conectado: !!d[id]?.chave,
    final: d[id]?.chave ? '…' + d[id].chave.slice(-4) : '', conferida: !!d[id]?.conferida, saldo: d[id]?.saldo ?? null, desde: d[id]?.desde || '' }));
  const on = new Set(lista.filter((p) => p.conectado).map((p) => p.id));
  const modelos = MODELOS.filter((m) => on.has(m.prov)).map(({ id, nome, nivel, usd, som, segs, obs }) => ({ id, nome, nivel, usd, som, segs, obs }));
  return { lista, modelos, padrao: modelos.find((m) => m.id === d.padrao)?.id || modelos[0]?.id || '', conferido: CONFERIDO, maxSeg: MAX_SEG };
}

async function pedir(url, opc = {}, espera = 30000) {
  const c = new AbortController(); const t = setTimeout(() => c.abort(), espera);
  try { const r = await fetch(url, { ...opc, signal: c.signal }); const txt = await r.text(); let j = null; try { j = JSON.parse(txt); } catch { /* não é JSON */ } return { ok: r.ok, status: r.status, j, txt }; }
  catch (e) { throw new Error(e.name === 'AbortError' ? 'a IA demorou demais para responder' : 'sem conexão com a IA (' + (e.message || e) + ')'); }
  finally { clearTimeout(t); }
}
const cabRunway = (chave) => ({ Authorization: 'Bearer ' + chave, 'X-Runway-Version': '2024-11-06', 'Content-Type': 'application/json' });
const cabFal = (chave) => ({ Authorization: 'Key ' + chave, 'Content-Type': 'application/json', Accept: 'application/json' });
function motivo(r, prov) {
  const m = r.j && (r.j.error || r.j.detail || r.j.message); const txt = curto(typeof m === 'string' ? m : JSON.stringify(m || r.txt));
  if (r.status === 401 || r.status === 403) return 'a chave da ' + PROVEDORES[prov].nome + ' não foi aceita (confira se copiou inteira e se a conta está ativa)';
  if (r.status === 402 || /credit|balance|saldo|payment/i.test(txt)) return 'a conta da ' + PROVEDORES[prov].nome + ' está sem créditos: ' + txt;
  if (r.status === 429) return 'limite de pedidos da ' + PROVEDORES[prov].nome + ' atingido; tente daqui a pouco';
  return PROVEDORES[prov].nome + ' respondeu ' + r.status + ': ' + txt;
}

/** Guarda a chave. Runway: confere na hora (consulta de saldo, grátis). fal.ai: sem consulta grátis conhecida — confere no primeiro clipe. */
export async function conectar(id, chave) {
  const p = PROVEDORES[id]; if (!p) throw new Error('IA desconhecida');
  chave = String(chave || '').trim();
  if (chave.length < 12 || /\s/.test(chave)) throw new Error('isso não parece uma chave: cole a chave inteira, sem espaços');
  const reg = { chave, desde: new Date().toISOString().slice(0, 10), conferida: false, saldo: null };
  if (id === 'runway') {
    const r = await pedir(p.base + '/v1/organization', { headers: cabRunway(chave) });
    if (!r.ok) throw new Error(motivo(r, id));
    reg.conferida = true; reg.saldo = typeof r.j?.creditBalance === 'number' ? r.j.creditBalance : null;
  }
  const d = ler(); d[id] = reg; gravar(d);
  return status();
}
export function desconectar(id) { const d = ler(); delete d[id]; gravar(d); return status(); }
export function escolherPadrao(modeloId) { const d = ler(); if (MODELOS.some((m) => m.id === modeloId)) { d.padrao = modeloId; gravar(d); } return status(); }

export function estimar(modeloId, seg) { const m = MODELOS.find((x) => x.id === modeloId); if (!m) return null; const s = m.segs.includes(Number(seg)) ? Number(seg) : m.segs[0]; return { seg: s, usd: +(m.usd * s).toFixed(3), modelo: m.nome }; }

/** Gera UM clipe a partir de uma imagem + texto. Devolve { arquivo, bytes, seg, modelo, usd }. A imagem vai para a IA escolhida pelo usuário. */
let ocupado = false;
export async function gerar({ modelo, prompt, imagem, seg, destino }, aoProgredir = () => {}) {
  const m = MODELOS.find((x) => x.id === modelo); if (!m) throw new Error('modelo de vídeo desconhecido');
  const chave = ler()[m.prov]?.chave; if (!chave) throw new Error('conecte a ' + PROVEDORES[m.prov].nome + ' primeiro (início do aplicativo › IA DE VÍDEO)');
  if (!/^data:image\/(png|jpe?g|webp);base64,/.test(String(imagem || ''))) throw new Error('a cena precisa de uma imagem (PNG ou JPG) para virar vídeo');
  if (imagem.length > 9e6) throw new Error('imagem grande demais para enviar');
  prompt = String(prompt || '').trim().slice(0, 950); if (prompt.length < 8) throw new Error('falta o texto dizendo o que acontece na cena');
  const dur = m.segs.includes(Number(seg)) ? Number(seg) : m.segs[0];
  if (dur > MAX_SEG) throw new Error('duração acima do limite');
  if (ocupado) throw new Error('já existe um clipe sendo gerado; espere terminar');
  ocupado = true;
  try {
    const p = PROVEDORES[m.prov]; let url = '';
    aoProgredir({ etapa: 'Enviando a cena para ' + m.nome, pct: 4 });
    if (m.prov === 'runway') {
      const r = await pedir(p.base + '/v1/image_to_video', { method: 'POST', headers: cabRunway(chave), body: JSON.stringify({ model: m.id.split(':')[1], promptImage: imagem, promptText: prompt, ratio: '720:1280', duration: dur }) }, 60000);
      if (!r.ok || !r.j?.id) throw new Error(motivo(r, m.prov));
      for (let i = 0; i < 150; i++) {
        await dormir(TESTE ? 60 : 5000);
        const t = await pedir(p.base + '/v1/tasks/' + encodeURIComponent(r.j.id), { headers: cabRunway(chave) });
        if (!t.ok) throw new Error(motivo(t, m.prov));
        const st = t.j?.status;
        if (st === 'SUCCEEDED') { url = Array.isArray(t.j.output) ? t.j.output[0] : ''; break; }
        if (st === 'FAILED' || st === 'CANCELLED') throw new Error('a ' + p.nome + ' não conseguiu gerar: ' + curto(t.j.failure || t.j.failureCode || st));
        aoProgredir({ etapa: 'A ' + p.nome + ' está gerando o clipe', pct: Math.min(88, 8 + Math.round((t.j?.progress || i / 60) * 80)) });
      }
    } else {
      const entrada = { prompt, start_image_url: imagem, duration: String(dur), generate_audio: !!m.som };
      const r = await pedir(p.base + '/fal-ai/kling-video/v3/standard/image-to-video', { method: 'POST', headers: cabFal(chave), body: JSON.stringify(entrada) }, 60000);
      if (!r.ok || !r.j?.status_url || !r.j?.response_url) throw new Error(motivo(r, m.prov));
      const d = ler(); if (d.fal && !d.fal.conferida) { d.fal.conferida = true; gravar(d); }
      const noLugar = (u) => (TESTE ? u : (String(u).startsWith('https://queue.fal.run/') ? u : null));
      const su = noLugar(r.j.status_url), ru = noLugar(r.j.response_url); if (!su || !ru) throw new Error('resposta inesperada da fal.ai');
      for (let i = 0; i < 150; i++) {
        await dormir(TESTE ? 60 : 5000);
        const t = await pedir(su, { headers: cabFal(chave) });
        if (!t.ok) throw new Error(motivo(t, m.prov));
        if (t.j?.status === 'COMPLETED') { const f = await pedir(ru, { headers: cabFal(chave) }); if (!f.ok) throw new Error(motivo(f, m.prov)); url = f.j?.video?.url || ''; break; }
        if (/FAIL|ERROR/i.test(t.j?.status || '')) throw new Error('a fal.ai não conseguiu gerar o clipe');
        aoProgredir({ etapa: t.j?.status === 'IN_QUEUE' ? 'Na fila da fal.ai' : 'A fal.ai está gerando o clipe', pct: Math.min(88, 8 + i) });
      }
    }
    if (!url || !/^https?:\/\//.test(url)) throw new Error('a IA não devolveu o vídeo a tempo (10 min). Veja na sua conta da IA se o clipe saiu.');
    aoProgredir({ etapa: 'Baixando o clipe', pct: 92 });
    const c = new AbortController(); const tm = setTimeout(() => c.abort(), 180000);
    let buf;
    try { const v = await fetch(url, { signal: c.signal }); if (!v.ok) throw new Error('download ' + v.status); buf = Buffer.from(await v.arrayBuffer()); } finally { clearTimeout(tm); }
    if (buf.length < 2000 || buf.length > 120e6) throw new Error('o arquivo do clipe veio com tamanho estranho');
    mkdirSync(destino, { recursive: true });
    const dt = new Date(), z = (n) => String(n).padStart(2, '0');
    const arquivo = join(destino, `clipe-${dt.getFullYear()}${z(dt.getMonth() + 1)}${z(dt.getDate())}-${z(dt.getHours())}${z(dt.getMinutes())}${z(dt.getSeconds())}.mp4`);
    writeFileSync(arquivo, buf);
    aoProgredir({ etapa: 'Pronto', pct: 100 });
    return { arquivo, bytes: buf.length, seg: dur, modelo: m.nome, usd: +(m.usd * dur).toFixed(3), existe: existsSync(arquivo) };
  } finally { ocupado = false; }
}
