import { envNode } from './node-exe.mjs';
// ATUALIZAÇÕES do aplicativo BW (19/11/2026).
// 1) checar(): quando há internet, lê SITE/downloads/app-versao.json e diz se há versão nova + o que muda.
// 2) atualizar(): SÓ quando a pessoa toca em ATUALIZAR — baixa o pacote do próprio site, confere o SHA-256,
//    copia por cima da pasta do app (nunca mexe em projetos/, node_modules/ nem nas chaves e configurações em ~/.bw-reels),
//    instala as dependências se o package.json mudou, guarda "o que mudou" e reabre o app.
// 3) novidades(): na 1ª abertura da versão nova devolve a lista do que mudou (o tutorial) uma vez só.
import { join, dirname, relative, sep } from 'node:path';
import { mkdirSync, existsSync, readFileSync, writeFileSync, rmSync, readdirSync, statSync, copyFileSync, unlinkSync, mkdtempSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { spawnSync } from 'node:child_process';
import { tmpdir, homedir } from 'node:os';

const PASTA_CFG = process.env.BWREELS_HOME_TESTE || join(homedir(), '.bw-reels');
const ARQ_ESTADO = join(PASTA_CFG, 'atualizacao.json');
const ARQ_NOVIDADES = join(PASTA_CFG, 'novidades-pendentes.json');
const NUNCA = new Set(['projetos', 'node_modules', 'instalador', 'site-offline', '.git', 'clipes-ia']);   // pastas do usuário: a atualização não toca
const WIN = process.platform === 'win32';

export function comparar(a, b) {   // "1.10" > "1.9"
  const x = String(a || '0').split('.').map(Number), y = String(b || '0').split('.').map(Number);
  for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d > 0 ? 1 : -1; }
  return 0;
}
function ler(arq, padrao) { try { return JSON.parse(readFileSync(arq, 'utf8')); } catch { return padrao; } }
function gravar(arq, obj) { mkdirSync(dirname(arq), { recursive: true }); writeFileSync(arq, JSON.stringify(obj, null, 2)); }
function limparTexto(s, n) { return String(s == null ? '' : s).replace(/[\u0000-\u001f]/g, ' ').slice(0, n); }

async function baixarJSON(url, ms = 9000) {
  const ac = new AbortController(), t = setTimeout(() => ac.abort(), ms);
  try { const r = await fetch(url + (url.includes('?') ? '&' : '?') + 't=' + Date.now(), { cache: 'no-store', signal: ac.signal }); if (!r.ok) throw new Error('HTTP ' + r.status); return await r.json(); }
  finally { clearTimeout(t); }
}

/* ---------- 1) tem versão nova? ---------- */
export async function checar({ site, versao }) {
  let info;
  try { info = await baixarJSON(site + '/downloads/app-versao.json'); }
  catch (e) { return { online: false, atual: versao, motivo: e.name === 'AbortError' ? 'sem resposta' : 'sem internet' }; }
  const nova = limparTexto(info.versao, 20), est = ler(ARQ_ESTADO, {});
  const temNova = comparar(nova, versao) > 0;
  gravar(ARQ_ESTADO, { ...est, ultimaChecagem: Date.now() });
  return {
    online: true, atual: versao, nova, temNova,
    adiada: temNova && est.adiadaVersao === nova && Date.now() < (est.adiadaAte || 0),
    data: limparTexto(info.data, 20), tamanhoMB: Math.round((Number(info.bytes) || 0) / 1e5) / 10,
    novidades: (Array.isArray(info.novidades) ? info.novidades : []).slice(0, 20).map((n) => ({ titulo: limparTexto(n.titulo, 80), texto: limparTexto(n.texto, 400), abrir: limparTexto(n.abrir, 30) })),
  };
}
export function adiar(versao, horas = 24) { gravar(ARQ_ESTADO, { ...ler(ARQ_ESTADO, {}), adiadaVersao: versao, adiadaAte: Date.now() + horas * 3600e3 }); return true; }

/* ---------- 2) atualizar ---------- */
function extrair(zip, destino) {
  mkdirSync(destino, { recursive: true });
  const tentativas = WIN
    ? [['tar', ['-xf', zip, '-C', destino]], ['powershell', ['-NoProfile', '-Command', `Expand-Archive -LiteralPath '${zip.replace(/'/g, "''")}' -DestinationPath '${destino.replace(/'/g, "''")}' -Force`]]]
    : [['unzip', ['-o', '-q', zip, '-d', destino]], ['python3', ['-m', 'zipfile', '-e', zip, destino]], ['tar', ['-xf', zip, '-C', destino]]];
  for (const [cmd, a] of tentativas) { const r = spawnSync(cmd, a, { stdio: 'ignore', windowsHide: true }); if (r.status === 0) return true; }
  return false;
}
function acharRaiz(pasta, nivel = 0) {   // a pasta que tem motor/app.mjs (o zip vem com bw-reels-studio/ por fora)
  if (existsSync(join(pasta, 'motor', 'app.mjs'))) return pasta;
  if (nivel > 2) return null;
  for (const n of readdirSync(pasta)) { const p = join(pasta, n); if (statSync(p).isDirectory()) { const r = acharRaiz(p, nivel + 1); if (r) return r; } }
  return null;
}
function listar(raiz, pasta = raiz, lista = []) {
  for (const n of readdirSync(pasta)) {
    const p = join(pasta, n), rel = relative(raiz, p), topo = rel.split(sep)[0];
    if (NUNCA.has(topo)) continue;
    if (statSync(p).isDirectory()) listar(raiz, p, lista); else lista.push(rel);
  }
  return lista;
}
function copiar(de, para) {
  mkdirSync(dirname(para), { recursive: true });
  try { copyFileSync(de, para); }
  catch (e) { if (e.code !== 'EPERM' && e.code !== 'EACCES') throw e; unlinkSync(para); copyFileSync(de, para); }   // arquivo escondido pelo "8 - ORGANIZAR": apaga e copia de novo
}
function ocultosNoTopo(raiz) {   // o "8 - ORGANIZAR" esconde arquivos do topo da pasta; a atualização mantém escondidos
  if (!WIN) return [];
  const r = spawnSync('cmd', ['/c', 'attrib', join(raiz, '*')], { encoding: 'latin1', windowsHide: true });
  return String(r.stdout || '').split(/\r?\n/).filter((l) => /^[ A-Z]{2,}/.test(l) && l.slice(0, 13).includes('H')).map((l) => l.slice(l.indexOf(raiz))).filter(Boolean);
}

export async function atualizar({ site, versao, raiz, aviso = () => {} }) {
  const info = await baixarJSON(site + '/downloads/app-versao.json');
  if (comparar(info.versao, versao) <= 0) return { jaAtual: true, versao };
  const url = new URL(String(info.pacote || ''), site + '/').href;
  if (!url.startsWith(site + '/')) throw new Error('pacote fora do site da Brightway — recusado');
  if (!/^[a-f0-9]{64}$/.test(String(info.sha256 || ''))) throw new Error('atualização sem conferência (sha256)');

  const tmp = mkdtempSync(join(tmpdir(), 'bw-atualiza-')), zip = join(tmp, 'pacote.zip');
  try {
    aviso({ etapa: 'Baixando a versão ' + info.versao, pct: 2 });
    const r = await fetch(url, { cache: 'no-store' }); if (!r.ok || !r.body) throw new Error('não consegui baixar (HTTP ' + r.status + ')');
    const total = Number(r.headers.get('content-length')) || Number(info.bytes) || 0, partes = [], hash = createHash('sha256'); let n = 0;
    for await (const c of r.body) { partes.push(c); hash.update(c); n += c.length; if (total) aviso({ etapa: 'Baixando a versão ' + info.versao, pct: Math.min(60, 2 + Math.round(58 * n / total)) }); }
    if (hash.digest('hex') !== info.sha256) throw new Error('o arquivo baixado não confere (sha256) — nada foi mudado');
    writeFileSync(zip, Buffer.concat(partes));

    aviso({ etapa: 'Abrindo o pacote', pct: 65 });
    const pasta = join(tmp, 'x'); if (!extrair(zip, pasta)) throw new Error('não consegui abrir o pacote');
    const nova = acharRaiz(pasta); if (!nova) throw new Error('pacote sem o aplicativo dentro');

    aviso({ etapa: 'Instalando os arquivos novos', pct: 72 });
    const pkgAntes = existsSync(join(raiz, 'package.json')) ? readFileSync(join(raiz, 'package.json'), 'utf8') : '';
    const escondidos = ocultosNoTopo(raiz), arquivos = listar(nova);
    arquivos.forEach((rel, i) => { copiar(join(nova, rel), join(raiz, rel)); if (i % 20 === 0) aviso({ etapa: 'Instalando os arquivos novos', pct: 72 + Math.round(18 * i / arquivos.length) }); });
    if (WIN) for (const e of escondidos) if (existsSync(e)) spawnSync('cmd', ['/c', 'attrib', '+h', e], { windowsHide: true });

    if (readFileSync(join(raiz, 'package.json'), 'utf8') !== pkgAntes) {
      aviso({ etapa: 'Atualizando os componentes (pode levar alguns minutos)', pct: 92 });
      const np = spawnSync(WIN ? 'npm.cmd' : 'npm', ['install', '--omit=dev', '--no-audit', '--no-fund'], { cwd: raiz, stdio: 'ignore', windowsHide: true, shell: WIN });
      if (np.status !== 0) aviso({ etapa: 'Componentes: rode 2 - INSTALAR se algo não abrir', pct: 95 });
    }
    /* 24/11: o componente do BW novo (electron) às vezes fica sem o programa baixado (dist/) depois do npm — baixa de novo e monta o BW.exe */
    try {
      const el = join(raiz, 'node_modules', 'electron');
      if (existsSync(join(el, 'install.js')) && !existsSync(join(el, 'dist'))) {
        aviso({ etapa: 'Baixando o componente do BW novo (pode levar alguns minutos)', pct: 96 });
        spawnSync(process.execPath, [join(el, 'install.js')], { cwd: raiz, stdio: 'ignore', windowsHide: true, env: envNode() });
      }
      if (existsSync(join(el, 'dist')) && !existsSync(join(raiz, 'programa', '.bw-pronto')))
        spawnSync(process.execPath, [join(raiz, 'motor', 'preparar-bw.mjs'), '--quieto'], { cwd: raiz, stdio: 'ignore', windowsHide: true, env: envNode() });
    } catch { /* o BW de sempre continua */ }
    gravar(ARQ_NOVIDADES, { versao: String(info.versao), de: versao, data: info.data || '', novidades: info.novidades || [] });
    aviso({ etapa: 'Pronto! Reabrindo o BW…', pct: 100 });
    return { atualizado: true, versao: String(info.versao), arquivos: arquivos.length };
  } finally { try { rmSync(tmp, { recursive: true, force: true }); } catch { /* fica no temp */ } }
}

/* ---------- 3) o que mudou (mostrado uma vez, na 1ª abertura da versão nova) ---------- */
export function novidades(versao, { marcar = true } = {}) {
  const p = ler(ARQ_NOVIDADES, null);
  if (!p || comparar(p.versao, versao) > 0) return null;   // ainda não reabriu na versão nova
  if (marcar) try { unlinkSync(ARQ_NOVIDADES); } catch { /* já apagado */ }
  return { versao: p.versao, de: p.de, data: p.data, novidades: (p.novidades || []).slice(0, 20).map((n) => ({ titulo: limparTexto(n.titulo, 80), texto: limparTexto(n.texto, 400), abrir: limparTexto(n.abrir, 30) })) };
}
