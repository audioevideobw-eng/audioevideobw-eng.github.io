// Transcrição de fala NO COMPUTADOR (sem internet), com o tempo de cada palavra.
// Motor: sherpa-onnx (Apache-2.0) + modelo Parakeet TDT 0.6B v3 da NVIDIA (CC BY 4.0, 25 idiomas, português incluído).
// Instalação: node motor/instalar-legendas.mjs  (biblioteca + modelo, ~500 MB, uma vez só).
import { existsSync, mkdtempSync, rmSync, readFileSync } from 'node:fs';
import { join, resolve, dirname } from 'node:path';
import { tmpdir, homedir } from 'node:os';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import { fileURLToPath, pathToFileURL } from 'node:url';

const RAIZ = resolve(dirname(fileURLToPath(import.meta.url)), '..');
export const NOME_MODELO = 'sherpa-onnx-nemo-parakeet-tdt-0.6b-v3-int8';
export const PASTA_MODELOS = join(homedir(), '.bw-reels', 'modelos');
export const PASTA_MODELO = join(PASTA_MODELOS, NOME_MODELO);
const ARQS = ['encoder.int8.onnx', 'decoder.int8.onnx', 'joiner.int8.onnx', 'tokens.txt'];
const SR = 16000;
const TESTE = process.env.BWREELS_TRANSCRICAO_TESTE || '';

function acharBiblioteca() {
  const req = createRequire(join(RAIZ, 'package.json'));
  try { return { req, caminho: dirname(req.resolve('sherpa-onnx-node/package.json')) }; } catch { return null; }
}

/** O que falta para transcrever neste computador. */
export function estado() {
  if (TESTE) return { pronto: true, biblioteca: true, modelo: true, teste: true };
  const biblioteca = !!acharBiblioteca();
  const modelo = ARQS.every((a) => existsSync(join(PASTA_MODELO, a)));
  return { pronto: biblioteca && modelo, biblioteca, modelo, pastaModelo: PASTA_MODELO };
}

let reconhecedor = null;
async function carregar() {
  if (reconhecedor) return reconhecedor;
  if (TESTE) { reconhecedor = await import(pathToFileURL(resolve(TESTE)).href); return reconhecedor; }
  const e = estado();
  if (!e.pronto) throw new Error('A legenda automática ainda não está instalada neste computador. Rode o INSTALAR-LEGENDAS.bat (uma vez só).');
  const { req, caminho } = acharBiblioteca();
  // no Windows as DLLs ficam em pacotes ao lado; o caminho entra no PATH antes de carregar
  const sep = process.platform === 'win32' ? ';' : ':';
  const viz = [join(caminho, '..', `sherpa-onnx-${process.platform === 'win32' ? 'win' : process.platform}-${process.arch}`), join(caminho, 'lib')].filter(existsSync);
  for (const v of ['PATH', 'LD_LIBRARY_PATH', 'DYLD_LIBRARY_PATH']) process.env[v] = viz.join(sep) + (process.env[v] ? sep + process.env[v] : '');
  const sherpa = req('sherpa-onnx-node');
  const rec = new sherpa.OfflineRecognizer({
    featConfig: { sampleRate: SR, featureDim: 80 },
    modelConfig: {
      transducer: { encoder: join(PASTA_MODELO, ARQS[0]), decoder: join(PASTA_MODELO, ARQS[1]), joiner: join(PASTA_MODELO, ARQS[2]) },
      tokens: join(PASTA_MODELO, ARQS[3]), modelType: 'nemo_transducer',
      numThreads: Math.max(2, Math.min(6, (await import('node:os')).cpus().length - 1)), provider: 'cpu', debug: 0,
    },
  });
  reconhecedor = {
    decodificar(amostras) {
      const st = rec.createStream();
      st.acceptWaveform({ sampleRate: SR, samples: amostras });
      rec.decode(st);
      const r = rec.getResult(st);
      return { tokens: r.tokens || [], timestamps: r.timestamps || [], texto: r.text || '' };
    },
  };
  return reconhecedor;
}

function ffmpeg(argv) {
  const r = spawnSync('ffmpeg', ['-hide_banner', '-nostdin', ...argv], { encoding: 'buffer', maxBuffer: 1 << 30 });
  if (r.error) throw new Error('FFmpeg não encontrado. Rode o INSTALAR.bat.');
  return { ok: r.status === 0, err: (r.stderr || Buffer.alloc(0)).toString('utf8') };
}

/** Tem faixa de som? */
export function temSom(arquivo) {
  const r = spawnSync('ffprobe', ['-v', 'error', '-select_streams', 'a', '-show_entries', 'stream=index', '-of', 'csv=p=0', arquivo], { encoding: 'utf8' });
  return r.status === 0 && !!String(r.stdout).trim();
}

/** Pedaços de até ~24 s, cortando de preferência num silêncio (nunca no meio de uma palavra, se der). */
export function cortesEm(duracao, silencios, max = 24, min = 10) {
  const cortes = [0];
  let t = 0;
  while (duracao - t > max + 2) {
    const cand = silencios.filter((s) => s.meio > t + min && s.meio <= t + max).sort((a, b) => b.dur - a.dur)[0];
    t = cand ? cand.meio : t + max;
    cortes.push(+t.toFixed(3));
  }
  cortes.push(duracao);
  return cortes;
}

/** Junta os pedacinhos de palavra do modelo em palavras com início e fim. */
export function palavrasDe(tokens, tempos, desloc = 0, fimTrecho = Infinity) {
  const ws = [];
  tokens.forEach((tk, i) => {
    const bruto = String(tk), txt = bruto.replace(/^[\s\u2581]+/, ''), t = (tempos[i] ?? 0) + desloc;
    if (!txt) return;
    const novo = /^[\s\u2581]/.test(bruto) || !ws.length;
    const pont = /^[.,!?;:…]+$/.test(txt);
    if (novo && !pont) ws.push({ palavra: txt, inicio: t, ult: t });
    else { const w = ws[ws.length - 1]; if (w) { w.palavra += txt; if (!pont) w.ult = t; } }
  });
  return ws.map((w, k) => {
    const prox = ws[k + 1] ? ws[k + 1].inicio : fimTrecho + desloc;
    const fim = Math.max(w.inicio + 0.08, Math.min(prox - 0.01, w.ult + 0.22 + 0.045 * w.palavra.length));
    return { palavra: w.palavra, inicio: +w.inicio.toFixed(3), fim: +fim.toFixed(3) };
  });
}

/**
 * Transcreve um arquivo de vídeo ou áudio (ou só um trecho dele).
 * @returns {{palavras: {palavra, inicio, fim}[], texto: string, duracao: number, pedacos: number}} tempos em segundos a partir de `de`.
 */
export async function transcrever(arquivo, { de = 0, dur = 0, aviso = () => {} } = {}) {
  if (!existsSync(arquivo)) throw new Error('arquivo não encontrado: ' + arquivo);
  const rec = await carregar();
  const tmp = mkdtempSync(join(tmpdir(), 'bwleg-'));
  try {
    const cru = join(tmp, 'a.raw');
    const corte = [...(de ? ['-ss', String(de)] : []), ...(dur ? ['-t', String(dur)] : [])];
    const r = ffmpeg(['-y', ...corte, '-i', arquivo, '-vn', '-ac', '1', '-ar', String(SR), '-af', 'silencedetect=noise=-34dB:d=0.28', '-f', 's16le', cru]);
    if (!r.ok || !existsSync(cru)) throw new Error('não deu para ler o som de ' + arquivo + ' (o arquivo tem áudio?)');
    const buf = readFileSync(cru);
    const n = Math.floor(buf.length / 2);
    const duracao = n / SR;
    if (duracao < 0.3) return { palavras: [], texto: '', duracao, pedacos: 0 };
    const pcm = new Float32Array(n);
    for (let i = 0; i < n; i++) pcm[i] = buf.readInt16LE(i * 2) / 32768;
    const sil = [];
    const re = /silence_end: ([\d.]+) \| silence_duration: ([\d.]+)/g;
    let m; while ((m = re.exec(r.err))) { const fim = +m[1], d = +m[2]; sil.push({ meio: fim - d / 2, dur: d }); }
    const cortes = cortesEm(duracao, sil);
    const palavras = [];
    for (let k = 0; k < cortes.length - 1; k++) {
      const a = cortes[k], b = cortes[k + 1];
      aviso(`ouvindo ${Math.round(a)}–${Math.round(b)} s de ${Math.round(duracao)} s`);
      const res = await rec.decodificar(pcm.subarray(Math.round(a * SR), Math.round(b * SR)), { de: a, dur: b - a });
      palavras.push(...palavrasDe(res.tokens, res.timestamps, a, b - a));
    }
    return { palavras, texto: palavras.map((w) => w.palavra).join(' '), duracao, pedacos: cortes.length - 1 };
  } finally { rmSync(tmp, { recursive: true, force: true }); }
}

/** Arquivo .srt (para o CapCut, Premiere, YouTube…) com até `porLinha` palavras por legenda. */
export function srtDe(palavras, porLinha = 5) {
  const hora = (t) => { const ms = Math.round(t * 1000), h = Math.floor(ms / 3600000), mi = Math.floor(ms / 60000) % 60, s = Math.floor(ms / 1000) % 60; return `${String(h).padStart(2, '0')}:${String(mi).padStart(2, '0')}:${String(s).padStart(2, '0')},${String(ms % 1000).padStart(3, '0')}`; };
  const blocos = []; let b = [];
  palavras.forEach((w, i) => {
    const ant = palavras[i - 1];
    if (b.length && (b.length >= porLinha || (ant && w.inicio - ant.fim > 0.6) || (ant && /[.!?]$/.test(ant.palavra)))) { blocos.push(b); b = []; }
    b.push(w);
  });
  if (b.length) blocos.push(b);
  return blocos.map((x, i) => `${i + 1}\n${hora(x[0].inicio)} --> ${hora(x[x.length - 1].fim)}\n${x.map((w) => w.palavra).join(' ')}\n`).join('\n');
}
