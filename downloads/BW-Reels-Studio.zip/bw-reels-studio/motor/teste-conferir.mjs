#!/usr/bin/env node
// Teste da CONFERÊNCIA DO VÍDEO (motor/conferir.mjs, 25/11/2026). Uso: node motor/teste-conferir.mjs
// Monta vídeos com defeitos DE PROPÓSITO (texto fora da tela, caixa que corta, letra pequena, sem contraste, área dos botões,
// tudo parado, tela preta, som mudo/baixo/estourado) e um vídeo certo, e confere que cada defeito é apontado e o certo passa limpo.
import { spawnSync } from 'node:child_process';
import { mkdtempSync, writeFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';
import { conferirVideo } from './conferir.mjs';

const AQUI = dirname(fileURLToPath(import.meta.url));
const T = mkdtempSync(join(tmpdir(), 'bw-conferir-'));
let falhas = 0;
const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) falhas++; };
const ff = (a) => spawnSync('ffmpeg', ['-v', 'error', '-y', ...a]);
const tem = (R, nivel, re) => R.some((r) => r.nivel === nivel && re.test(r.msg));

const cab = '<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;width:1080px;height:1920px;overflow:hidden;font-family:sans-serif}div{position:absolute}</style></head>';
writeFileSync(join(T, 'ruim.html'), cab + `<body style="background:#202020">
<div style="left:700px;top:600px;font-size:120px;color:#fff;white-space:nowrap">SAINDO DA TELA</div>
<div style="left:100px;top:900px;font-size:14px;color:#fff">letra pequena demais</div>
<div style="left:100px;top:1100px;font-size:80px;color:#2a2a2a">sem contraste</div>
<div style="left:100px;top:1750px;font-size:70px;color:#fff">rodapé dos botões</div>
<div style="left:100px;top:1300px;width:200px;height:90px;overflow:hidden"><span style="font-size:80px;color:#fff;white-space:nowrap">dentro da caixa</span></div>
<script>window.__DUR=3;window.__seek=function(){}</script></body></html>`);
writeFileSync(join(T, 'bom.html'), cab + `<body style="background:#101828"><div id="a" style="left:120px;top:800px;font-size:110px;color:#fff;font-weight:700">TUDO CERTO</div>
<div id="q" style="left:0;top:1100px;width:120px;height:120px;background:#FFB547"></div>
<script>window.__DUR=3;window.__seek=function(t){q.style.left=(t/3*900)+'px';a.style.opacity=Math.min(1,t*3)}</script></body></html>`);

console.log('Textos e imagem (animar.mjs → conferência no fim):');
const ruim = spawnSync(process.execPath, [join(AQUI, 'animar.mjs'), join(T, 'ruim.html'), '--rascunho'], { encoding: 'utf8' }).stdout || '';
ok(/✗ “SAINDO DA TELA” sai da tela/.test(ruim), 'texto que sai da tela = erro');
ok(/✗ “dentro da caixa” fica escondido dentro da caixa/.test(ruim), 'texto cortado pela caixa = erro');
ok(/⚠ “letra pequena demais” com letra de 14 px/.test(ruim), 'letra pequena = aviso');
ok(/⚠ “sem contraste” com pouco contraste/.test(ruim), 'pouco contraste = aviso');
ok(/⚠ “rodapé dos botões” encosta na borda/.test(ruim), 'texto na área dos botões do Reels = aviso');
ok(!/⚠ “SAINDO DA TELA” com pouco contraste/.test(ruim), 'texto branco no fundo escuro NÃO acusa contraste');
ok(/✗ o vídeo inteiro está parado/.test(ruim), 'vídeo todo parado = erro');
ok((ruim.match(/“SAINDO DA TELA” sai da tela/g) || []).length === 1, 'o mesmo problema aparece uma vez só (sem repetir por tempo)');
const bom = spawnSync(process.execPath, [join(AQUI, 'animar.mjs'), join(T, 'bom.html'), '--rascunho'], { encoding: 'utf8' }).stdout || '';
ok(/✓ resultado: 0 erro\(s\), 0 aviso\(s\)/.test(bom), 'animação certa passa limpa');
const sem = spawnSync(process.execPath, [join(AQUI, 'animar.mjs'), join(T, 'bom.html'), '--rascunho', '--sem-conferir'], { encoding: 'utf8' }).stdout || '';
ok(!/CONFERÊNCIA/.test(sem), '--sem-conferir pula a conferência');
const chk = spawnSync(process.execPath, [join(AQUI, 'animar.mjs'), join(T, 'ruim.html'), '--checar'], { encoding: 'utf8' });
ok(chk.status === 1 && /TEXTOS NA TELA/.test(chk.stdout), '--checar também confere os textos (e falha com texto cortado)');

console.log('Arquivo de vídeo (conferir.mjs):');
const v = (n) => join(T, n);
ff(['-f', 'lavfi', '-i', 'testsrc2=s=640x360:r=30:d=5', '-f', 'lavfi', '-i', 'color=black:s=640x360:r=30:d=1', '-f', 'lavfi', '-i', 'sine=f=440:d=6',
  '-filter_complex', '[0:v][1:v]concat=n=2:v=1[v];[2:a]volume=-30dB[a]', '-map', '[v]', '-map', '[a]', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', v('baixo-preto.mp4')]);
ff(['-f', 'lavfi', '-i', 'testsrc2=s=640x360:r=30:d=5', '-f', 'lavfi', '-i', 'sine=f=440:d=5', '-af', 'volume=14dB', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', v('estoura.mp4')]);
ff(['-f', 'lavfi', '-i', 'testsrc2=s=640x360:r=30:d=5', '-f', 'lavfi', '-i', 'anullsrc=r=48000:cl=stereo', '-t', '5', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', v('mudo.mp4')]);
ff(['-f', 'lavfi', '-i', 'testsrc2=s=640x360:r=30:d=5', '-f', 'lavfi', '-i', 'sine=f=440:d=5', '-af', 'loudnorm=I=-14:TP=-2', '-ar', '48000', '-c:v', 'libx264', '-pix_fmt', 'yuv420p', '-c:a', 'aac', v('certo.mp4')]);
const a = conferirVideo(v('baixo-preto.mp4')), b = conferirVideo(v('estoura.mp4')), c = conferirVideo(v('mudo.mp4')), d = conferirVideo(v('certo.mp4'));
ok(tem(a, 'aviso', /tela preta de 5,0 s/), 'tela preta no fim = aviso com o tempo');
ok(tem(a, 'aviso', /som baixo/), 'som baixo = aviso (NORMALIZAR)');
ok(tem(b, 'aviso', /dBTP/), 'pico acima de −1 dBTP = aviso');
ok(tem(c, 'erro', /muda/), 'som mudo = erro');
ok(!d.some((r) => r.nivel === 'erro' || r.nivel === 'aviso'), 'vídeo certo (−14 LUFS) passa limpo: ' + d.filter((r) => r.nivel !== 'info').map((r) => r.msg).join(' | ').slice(0, 120));
ok(conferirVideo(v('nao-existe.mp4'))[0].nivel === 'erro', 'arquivo que não existe = erro');
const cli = spawnSync(process.execPath, [join(AQUI, 'conferir.mjs'), v('mudo.mp4'), '--json'], { encoding: 'utf8' });
ok(cli.status === 1 && Array.isArray(JSON.parse(cli.stdout)), 'linha de comando: --json e código de saída 1 quando há erro');

console.log(falhas ? `\n✗ ${falhas} falha(s)` : '\n✓ Tudo certo.');
process.exit(falhas ? 1 : 0);
