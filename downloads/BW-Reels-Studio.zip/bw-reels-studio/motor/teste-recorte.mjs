#!/usr/bin/env node
// Teste das saídas de recorte do animar.mjs (--chroma e --alfa). Uso: node motor/teste-recorte.mjs
import { spawnSync } from 'node:child_process';
import { mkdtempSync, rmSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { tmpdir } from 'node:os';
import { fileURLToPath } from 'node:url';
const RAIZ = join(dirname(fileURLToPath(import.meta.url)), '..');
const tmp = mkdtempSync(join(tmpdir(), 'bw-recorte-'));
let falhas = 0; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) falhas++; };
const animar = (...a) => spawnSync('node', [join(RAIZ, 'motor/animar.mjs'), ...a], { encoding: 'utf8' });
const probe = (f) => spawnSync('ffprobe', ['-v', 'error', '-show_entries', 'stream=codec_name,pix_fmt,width,height', '-of', 'csv=p=0', f], { encoding: 'utf8' }).stdout.trim();
const pixel = (f, t, x, y) => [...spawnSync('ffmpeg', ['-v', 'error', '-ss', String(t), '-i', f, '-frames:v', '1', '-vf', `crop=4:4:${x}:${y},scale=1:1`, '-f', 'rawvideo', '-pix_fmt', 'rgb24', '-'], { maxBuffer: 1 << 20 }).stdout];
const cartao = join(RAIZ, 'modelos/animacoes/cartao-ui.html'), pers = join(RAIZ, 'modelos/animacoes/personagem-bw.html');

console.log('RECORTE');
ok(animar(cartao, '--checar').status === 0, 'cartao-ui.html determinístico e sem erro de JS');
let r = animar(cartao, '--chroma', 'verde', '--rascunho', '--saida', join(tmp, 'v.mp4'));
ok(r.status === 0 && /nenhuma cor da animação colide/.test(r.stdout), '--chroma verde gera e não acusa colisão');
ok(/^h264,540,960,yuv420p$/.test(probe(join(tmp, 'v.mp4'))), 'chroma = MP4 H.264 leve');
let px = pixel(join(tmp, 'v.mp4'), 3, 20, 900);
ok(px[1] > 150 && px[0] < 40 && px[2] < 100, `fundo vira verde de recorte (rgb ${px.join(',')})`);
px = pixel(join(tmp, 'v.mp4'), 3, 270, 200);
ok(px[0] > 200 && px[1] > 200 && px[2] > 200, `cartão branco continua por cima (rgb ${px.join(',')})`);
r = animar(cartao, '--chroma', '#FF00FF', '--rascunho', '--saida', join(tmp, 'm.mp4'));
px = pixel(join(tmp, 'm.mp4'), 3, 20, 900);
ok(r.status === 0 && px[0] > 200 && px[1] < 60 && px[2] > 200, `cor #hex aceita (magenta: rgb ${px.join(',')})`);
r = animar(pers, '--chroma', 'azul', '--rascunho', '--saida', join(tmp, 'a.mp4'));
ok(/⚠ .*parecida com o fundo/.test(r.stdout) && /--chroma verde/.test(r.stdout), 'avisa quando a animação usa a cor do recorte (lente azul) e sugere outra');
r = animar(cartao, '--alfa', '--rascunho', '--saida', join(tmp, 't.mov'));
ok(r.status === 0 && /^prores,540,960,yuva444p/.test(probe(join(tmp, 't.mov'))), '--alfa = MOV ProRes 4444 com transparência');
r = animar(cartao, '--alfa', '--chroma', 'verde');
ok(r.status !== 0, 'recusa --alfa junto com --chroma');
const k = spawnSync('ffmpeg', ['-v', 'error', '-y', '-f', 'lavfi', '-i', 'color=c=0x202020:s=540x960:d=4:r=24', '-i', join(tmp, 'v.mp4'), '-filter_complex',
  '[1:v]chromakey=0x00B140:0.13:0.06[k];[0:v][k]overlay', '-t', '4', join(tmp, 'k.mp4')]);
px = pixel(join(tmp, 'k.mp4'), 3, 20, 900);
ok(k.status === 0 && Math.max(...px) < 60, `chroma key do editor tira o verde por completo (rgb ${px.join(',')})`);
rmSync(tmp, { recursive: true, force: true });
console.log(falhas ? `${falhas} falha(s)` : 'Tudo certo'); process.exit(falhas ? 1 : 0);
