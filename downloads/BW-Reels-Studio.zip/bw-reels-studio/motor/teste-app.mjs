// Teste do aplicativo BW Reels: janela escondida, plataforma SIMULADA (servidor só do teste), "ouvido" das legendas simulado.
// Uso: node motor/teste-app.mjs
import { mkdtempSync, writeFileSync, existsSync, readFileSync, mkdirSync, readdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import http from 'node:http';

const T = mkdtempSync(join(tmpdir(), 'bwapp-'));
const falhas = []; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) falhas.push(m); };

// pacote de pedido de render (como o botão RENDERIZAR NO PC baixa)
const pac = join(T, 'pac'); mkdirSync(pac);
writeFileSync(join(pac, 'roteiro.json'), JSON.stringify({ titulo: 'Teste do app', formato: '9:16', fps: 30, motor: 'nativo', estilo: 'cinema', marca: { handle: 'TESTE' },
  cenas: [{ tipo: 'gancho', duracao: 1.5, texto: 'Teste do aplicativo' }, { tipo: 'cta', duracao: 1.5, texto: 'Fim', acao: '@teste' }] }));
const zip = join(T, 'pedido.bwreels.zip');
spawnSync('python3', ['-c', `import zipfile,sys; z=zipfile.ZipFile(sys.argv[1],'w'); z.write(sys.argv[2],'roteiro.json'); z.close()`, zip, join(pac, 'roteiro.json')]);

const BWSYNC = `<script>window.BWSync={cliente:function(){return{auth:{getUser:async function(){return{data:{user:localStorage.getItem('logado')?{id:'u-123',email:'dono@exemplo.com',user_metadata:{full_name:'Marcos Teste'}}:null}}},signOut:async function(){localStorage.removeItem('logado')}}}}};</script>`;
const PAGINAS = {
  '/login.html': `<title>login</title>${BWSYNC}<button id="entrar" onclick="localStorage.setItem('logado','1');location.href='index.html'">entrar</button>`,
  '/index.html': `<title>painel</title>${BWSYNC}<p>painel</p>`,
  '/reels.html': `<title>reels</title>${BWSYNC}<button id="btQuadro" onclick="document.title='quadro aberto'">quadro</button><a id="baixar" href="/pedido.bwreels.zip" download="meu-reel.bwreels.zip">render</a><a id="outro" href="/nota.txt" download="nota.txt">nota</a>
    <script>window.tentar=function(a,d){return window.bwNode(a,d||{})}</script>`,
  '/fora.html': `<title>fora</title><script>window.tentar=function(a){return window.bwNode?window.bwNode(a,{}):{ok:false,erro:'sem ponte'}}</script>`,
};
const PEDIDOS_VIDEO = [];
const servir = (req, res) => {
  const u = req.url.split('?')[0];
  if (u === '/pedido.bwreels.zip') { res.writeHead(200, { 'Content-Type': 'application/zip' }); return res.end(readFileSync(zip)); }
  const aut = req.headers.authorization || '';
  const json = (st, o) => { res.writeHead(st, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
  const eu = 'http://' + req.headers.host;
  if (u === '/runway/v1/organization') return aut === 'Bearer chave-boa-runway-123' ? json(200, { creditBalance: 500 }) : json(401, { error: 'Invalid API key' });
  if (u === '/runway/v1/image_to_video') { let c = ''; req.on('data', (d) => { c += d; }); req.on('end', () => { PEDIDOS_VIDEO.push({ quem: 'runway', aut, corpo: JSON.parse(c) }); json(200, { id: 't1' }); }); return; }
  if (u === '/runway/v1/tasks/t1') return json(200, { status: 'SUCCEEDED', output: [eu + '/clipe.mp4'] });
  if (u === '/fal/fal-ai/kling-video/v3/standard/image-to-video') { let c = ''; req.on('data', (d) => { c += d; }); req.on('end', () => { PEDIDOS_VIDEO.push({ quem: 'fal', aut, corpo: JSON.parse(c) }); if (aut !== 'Key chave-boa-fal-1234567') return json(401, { detail: 'bad key' }); json(200, { status: 'IN_QUEUE', request_id: 'r1', status_url: eu + '/fal/st', response_url: eu + '/fal/re' }); }); return; }
  if (u === '/fal/st') return json(200, { status: 'COMPLETED' });
  if (u === '/fal/re') return json(200, { video: { url: eu + '/clipe.mp4' } });
  if (u === '/clipe.mp4') { res.writeHead(200, { 'Content-Type': 'video/mp4' }); return res.end(Buffer.alloc(5000, 7)); }
  if (u === '/nota.txt') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('ola'); }
  if (PAGINAS[u]) { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end('<!doctype html><meta charset="utf-8">' + PAGINAS[u]); }
  res.writeHead(404); res.end('nada');
};
const site = http.createServer(servir), fora = http.createServer(servir);
await new Promise((r) => site.listen(0, '127.0.0.1', r)); await new Promise((r) => fora.listen(0, '127.0.0.1', r));
const SITE = `http://127.0.0.1:${site.address().port}`, FORA = `http://127.0.0.1:${fora.address().port}`;

// legendas: "ouvido" simulado + um áudio de teste
const falso = join(T, 'ouvido.mjs');
writeFileSync(falso, `export function decodificar(a){ return { tokens:[' Ol','á',' mundo'], timestamps:[0.2,0.4,0.8], texto:' Olá mundo' }; }`);
const wav = join(T, 'fala.wav');
spawnSync('ffmpeg', ['-y', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=2', '-ar', '16000', wav], { stdio: 'ignore' });

const copia = join(T, 'copia'); mkdirSync(copia);
writeFileSync(join(copia, 'fotos.html'), '<!doctype html><meta charset="utf-8"><title>fotos da copia</title><p>editor</p>');
Object.assign(process.env, { HOME: T, USERPROFILE: T, BWREELS_TESTE: '1', BWREELS_NAO_ABRIR: '1', BWREELS_SITE_TESTE: SITE, BWREELS_TRANSCRICAO_TESTE: falso, BWREELS_ARQUIVO_TESTE: wav, BWREELS_VIDEO_TESTE: FORA, BWREELS_COPIA_TESTE: copia });
const { abrirApp } = await import('./app.mjs');
const conta = await import('./conta.mjs');
const { contexto, pagina: pg } = await abrirApp({ semJanela: true });
const erros = []; pg.on('pageerror', (e) => erros.push(e.message));
const foto = (n) => process.env.BWREELS_FOTOS && pg.screenshot({ path: join(process.env.BWREELS_FOTOS, n + '.png'), fullPage: true });
const noInicio = () => pg.waitForURL(/app\/index\.html/, { timeout: 15000 });

console.log('\nLOGIN');
await pg.waitForSelector('#btEntrar');
ok(!(await pg.locator('.fer').count()), 'sem login: só a tela ENTRAR, nenhuma ferramenta');
let r = await pg.evaluate(() => window.bwNode('videos', {}));
ok(!r.ok && /Entre com a sua conta/.test(r.erro), 'sem login: a ponte recusa as ferramentas');
r = await pg.evaluate(() => window.bwNode('abrir', { destino: 'assistente' }));
ok(!r.ok, 'sem login: não abre o assistente');
await foto('app-entrar');
await pg.click('#btEntrar'); await pg.waitForURL(/login\.html/);
ok(true, 'ENTRAR abre a página de login da plataforma');
await pg.waitForSelector('#bwAppInicio');
await pg.click('#entrar'); await noInicio(); await pg.waitForSelector('.fer');
const lic = JSON.parse(readFileSync(join(T, '.bw-reels', 'licenca.json'), 'utf8'));
ok(lic.email === 'dono@exemplo.com' && lic.id === 'u-123', 'depois do login a conta fica registrada (id + e-mail)');
ok(!/senha|token|access|refresh/i.test(JSON.stringify(lic)), 'o arquivo da conta não tem senha nem chave de acesso');
ok(conta.estado().liberado && conta.estado().dias >= 6, 'conta liberada por 7 dias sem internet');
ok((await pg.locator('#conta').innerText()).includes('Marcos Teste'), 'nome da conta no topo');
ok((await pg.locator('.fer:not(.breve)').count()) === 14 && (await pg.locator('.fer.breve').count()) === 2, '14 ferramentas + 2 "em breve"');
await pg.waitForTimeout(1400); await foto('app-inicio');

console.log('\nFERRAMENTAS ONLINE');
await pg.click('[data-f="reels"]'); await pg.waitForURL(/reels\.html/);
ok((await pg.title()) === 'reels', 'CRIAR REEL abre o editor da plataforma na mesma janela');
await pg.waitForSelector('#bwAppInicio');
r = await pg.evaluate(() => window.tentar('videos'));
ok(!r.ok && /recusado/.test(r.erro), 'a página da plataforma NÃO pode pedir arquivos do PC');
r = await pg.evaluate(() => window.tentar('salvarIA'));
ok(!r.ok && /recusado/.test(r.erro), 'a página da plataforma NÃO pode mexer nas chaves de IA');
await pg.click('#bwAppInicio'); await noInicio(); await pg.waitForSelector('.fer');
ok(true, 'botão ⌂ BW REELS volta para o início');
await pg.click('[data-f="quadro"]'); await pg.waitForURL(/reels\.html/);
await pg.waitForFunction(() => document.title === 'quadro aberto', null, { timeout: 15000 }).then(() => ok(true, 'QUADRO DE HISTÓRIA abre o quadro sozinho')).catch(() => ok(false, 'QUADRO DE HISTÓRIA abre o quadro sozinho'));

console.log('\nRENDER PELO APP');
await pg.click('#outro');
await pg.waitForFunction(() => /Salvo em Downloads: nota/.test(document.getElementById('bwAppAvisoTexto')?.textContent || ''), null, { timeout: 15000 });
ok(existsSync(join(T, 'nota.txt')), 'download comum é salvo e avisado');
await pg.click('#baixar');
await pg.waitForFunction(() => /Vídeo pronto|Não/.test(document.getElementById('bwAppAvisoTexto')?.textContent || ''), null, { timeout: 240000 });
const aviso = await pg.locator('#bwAppAvisoTexto').innerText();
ok(/Vídeo pronto/.test(aviso), 'RENDERIZAR NO PC dentro do app gera o vídeo sozinho — ' + aviso.slice(0, 70));
await pg.goto(FORA + '/fora.html');
r = await pg.evaluate(() => window.tentar('videos'));
ok(!r.ok, 'outro site não usa a ponte: ' + r.erro);
r = await pg.evaluate(() => window.tentar('inicio'));
ok(!r.ok, 'outro site não consegue nem navegar o app');
ok(!(await pg.locator('#bwAppInicio').count()), 'outro site não recebe o botão do app');

console.log('\nFERRAMENTAS DESTE PC');
const { pathToFileURL } = await import('node:url'); const N = await import('./assistente-nucleo.mjs');
await pg.goto(pathToFileURL(join(N.RAIZ, 'app', 'index.html')).href); await pg.waitForSelector('.vid');
ok((await pg.locator('.vid').count()) >= 1, 'MEUS VÍDEOS lista o vídeo renderizado');
r = await pg.evaluate(() => window.bwNode('abrirVideo', { arquivo: '/etc/passwd' }));
ok(!r.ok, 'só abre vídeo de dentro da pasta de projetos');
await pg.click('[data-f="legendas"]'); await pg.waitForSelector('#btLegendar');
await pg.click('#btLegendar'); await pg.waitForSelector('#legSrt', { timeout: 30000 });
ok(existsSync(join(T, 'fala.srt')) && /Olá mundo/.test(readFileSync(join(T, 'fala.srt'), 'utf8')), 'LEGENDAS: escolhe o arquivo e grava o .srt ao lado');
await foto('app-legenda');
await pg.click('#folhaCx .bt:last-child');
await pg.click('[data-f="assistente"]'); await pg.waitForURL(/assistente\/index\.html/); await pg.waitForSelector('.lista li');
ok((await pg.locator('#onde').innerText()).startsWith('Etapa 1 de'), 'ASSISTENTE abre na etapa 1');
ok((await pg.locator('#conta').innerText()).includes('Marcos Teste'), 'assistente mostra a conta');
ok(await pg.locator('#btAvancar').isEnabled(), 'assistente liberado (conta ativa)');
await pg.click('#bwAppInicio'); await noInicio(); await pg.waitForSelector('.fer');
await pg.click('[data-f="ias"]'); await pg.waitForURL(/assistente\/index\.html#ias/);
await pg.waitForFunction(() => /INSTALAR IAS|Minhas IAs/i.test(document.getElementById('tela').innerText), null, { timeout: 10000 }).then(() => ok(true, 'MINHAS IAS abre direto na tela das IAs')).catch(() => ok(false, 'MINHAS IAS abre direto na tela das IAs'));
await foto('app-ias');


console.log('\nIA DE VÍDEO (conectores, provedores SIMULADOS)');
await pg.click('#bwAppInicio'); await noInicio(); await pg.waitForSelector('.fer');
await pg.click('[data-f="videoia"]'); await pg.waitForSelector('#vk_runway');
await pg.fill('#vk_runway', 'chave-errada-runway-000'); await pg.click('[data-vc="runway"]');
await pg.waitForFunction(() => /não foi aceita/.test(document.getElementById('folhaCx').innerText), null, { timeout: 10000 }).then(() => ok(true, 'chave errada da Runway é recusada na hora')).catch(() => ok(false, 'chave errada da Runway é recusada na hora'));
await pg.fill('#vk_runway', 'chave-boa-runway-123'); await pg.click('[data-vc="runway"]');
await pg.waitForSelector('[data-vd="runway"]');
ok(/saldo: 500/.test(await pg.locator('#folhaCx').innerText()), 'chave certa: conectada, com o saldo de créditos');
await pg.fill('#vk_fal', 'chave-boa-fal-1234567'); await pg.click('[data-vc="fal"]'); await pg.waitForSelector('[data-vd="fal"]');
ok((await pg.locator('[name=vpad]').count()) === 4, 'com as duas conectadas aparecem os 4 modelos com preço');
const tela = await pg.content(); const st = await pg.evaluate(() => window.bwNode('videoIA', {}));
ok(!/chave-boa/.test(tela) && !/chave-boa/.test(JSON.stringify(st)) && /…-123/.test(JSON.stringify(st)), 'a chave nunca volta para a tela (só o final)');
ok(/chave-boa-runway-123/.test(readFileSync(join(T, '.bw-reels', 'video-ias.json'), 'utf8')), 'a chave fica só no arquivo deste PC');
await pg.click('#folhaCx .linha .bt');
await pg.click('[data-f="reels"]'); await pg.waitForURL(/reels\.html/); await pg.waitForSelector('#bwAppInicio');
r = await pg.evaluate(() => window.tentar('videoConectar', { id: 'runway', chave: 'outra-chave-qualquer-1' }));
ok(!r.ok && /recusado/.test(r.erro), 'a página da plataforma NÃO pode trocar nem ler chave');
r = await pg.evaluate(() => window.tentar('abrirFlow'));
ok(r.ok, 'a plataforma pode pedir para abrir o Flow no navegador do PC (endereço fixo)');
r = await pg.evaluate(() => window.tentar('videoIA'));
ok(r.ok && r.valor.modelos.length === 4 && !/chave-boa/.test(JSON.stringify(r.valor)), 'a plataforma só enxerga quais modelos estão liberados');
const IMG = 'data:image/jpeg;base64,' + Buffer.alloc(600, 1).toString('base64');
r = await pg.evaluate((img) => window.tentar('videoGerar', { modelo: 'runway:gen4_turbo', prompt: 'a pessoa entra no salão sorrindo, câmera acompanha', imagem: img, seg: 5 }), IMG);
ok(r.ok && r.valor.base64.length > 6000 && r.valor.usd === 0.25, 'GERAR pela Runway: devolve o clipe e o custo de referência (US$ 0,25)');
r = await pg.evaluate((img) => window.tentar('videoGerar', { modelo: 'fal:kling3', prompt: 'a pessoa entra no salão sorrindo, câmera acompanha', imagem: img, seg: 5 }), IMG);
ok(r.ok && r.valor.usd === 0.42, 'GERAR pela fal.ai (Kling 3.0): devolve o clipe (US$ 0,42)');
const pr = PEDIDOS_VIDEO.find((x) => x.quem === 'runway'), pf = PEDIDOS_VIDEO.filter((x) => x.quem === 'fal').pop();
ok(pr.corpo.model === 'gen4_turbo' && pr.corpo.ratio === '720:1280' && pr.corpo.duration === 5 && pr.corpo.promptImage === IMG, 'pedido da Runway no formato da API (modelo, vertical, 5 s, imagem)');
ok(pf.corpo.start_image_url === IMG && pf.corpo.duration === '5' && pf.corpo.generate_audio === false && pf.aut.startsWith('Key '), 'pedido da fal.ai no formato da API');
ok(readdirSync(join(N.RAIZ, 'projetos', 'clipes-ia')).filter((n) => n.endsWith('.mp4')).length >= 1, 'o clipe também fica guardado em projetos/clipes-ia');
r = await pg.evaluate(() => window.tentar('videoGerar', { modelo: 'runway:gen4_turbo', prompt: 'x', imagem: 'http://site/foto.jpg', seg: 5 }));
ok(!r.ok, 'recusa pedido sem imagem válida: ' + r.erro);
await pg.goto(FORA + '/fora.html');
r = await pg.evaluate(() => window.tentar('videoGerar'));
ok(!r.ok && /recusado/.test(r.erro), 'outro site não consegue gerar clipe na conta do usuário');

console.log('\nSEM INTERNET');
await pg.goto(pathToFileURL(join(N.RAIZ, 'app', 'index.html')).href); await pg.waitForSelector('#btOff');
ok(/prepare uma vez|Pronto para usar/.test(await pg.locator('#offBox').innerText()), 'a tela inicial mostra a situação do uso sem internet');
await new Promise((ok2) => { site.close(ok2); site.closeAllConnections(); });
await pg.click('[data-f="reels"]'); await pg.waitForURL(/reels\.html/);
ok((await pg.title()) === 'reels' && (await pg.locator('#btQuadro').count()) === 1, 'servidor da plataforma DESLIGADO: o editor abre pela cópia guardada');
await pg.click('#bwAppInicio'); await noInicio(); await pg.waitForSelector('.fer');
await pg.click('[data-f="fotos"]'); await pg.waitForURL(/fotos\.html/);
ok((await pg.title()) === 'fotos da copia', 'ferramenta nunca aberta antes abre pela cópia que veio no instalador');
await pg.click('#bwAppInicio'); await noInicio(); await pg.waitForSelector('.fer');
await pg.click('[data-f="pdf"]'); await pg.waitForTimeout(1500);
ok(!/pdf/i.test(await pg.title().catch(() => '')), 'página que não está em nenhuma cópia não abre (sem inventar conteúdo)');
await pg.goto(pathToFileURL(join(N.RAIZ, 'app', 'index.html')).href); await pg.waitForSelector('.fer');
console.log('\nSAIR E VALIDADE');
await pg.waitForSelector('#btSair:not([hidden])');
pg.once('dialog', (d) => d.accept());
await pg.click('#btSair'); await pg.waitForSelector('#btEntrar', { timeout: 15000 });
ok(!existsSync(join(T, '.bw-reels', 'licenca.json')), 'SAIR apaga a conta deste PC');
await pg.goto(SITE + '/index.html');
ok(!(await pg.evaluate(() => localStorage.getItem('logado'))), 'SAIR também sai da plataforma');
conta.registrar({ id: 'u-123', email: 'dono@exemplo.com' });
const arq = join(T, '.bw-reels', 'licenca.json'); const l2 = JSON.parse(readFileSync(arq, 'utf8')); l2.validade = new Date(Date.now() - 1000).toISOString(); writeFileSync(arq, JSON.stringify(l2));
ok(!conta.estado().liberado && /venceu/.test(conta.estado().aviso), 'conferência vencida (mais de 7 dias) pede login de novo');
ok(erros.length === 0, 'sem erros de JavaScript nas telas' + (erros.length ? ': ' + erros.join(' | ') : ''));

await contexto.close(); fora.close();
if (!process.env.BWREELS_GUARDAR) rmSync(T, { recursive: true, force: true });
for (const p of readdirSync(join(N.RAIZ, 'projetos'))) if (/^meu-reel-\d{8}-\d{6}$/.test(p) || p === 'clipes-ia') rmSync(join(N.RAIZ, 'projetos', p), { recursive: true, force: true });
console.log(falhas.length ? `\n${falhas.length} FALHA(S)\n` : '\nTudo certo.\n');
process.exit(falhas.length ? 1 : 0);
