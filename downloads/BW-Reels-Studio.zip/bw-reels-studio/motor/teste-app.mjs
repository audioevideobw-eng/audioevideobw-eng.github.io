// Teste do aplicativo BW Reels: janela escondida, plataforma SIMULADA (servidor só do teste), "ouvido" das legendas simulado.
// Uso: node motor/teste-app.mjs
import { mkdtempSync, writeFileSync, existsSync, readFileSync, mkdirSync, readdirSync, rmSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { spawnSync } from 'node:child_process';
import http from 'node:http';

const T = mkdtempSync(join(tmpdir(), 'bwapp-'));
const falhas = []; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) falhas.push(m); };

// pacote de pedido de render (como o botão RENDERIZAR NO PC baixa)
const pac = join(T, 'pac'); mkdirSync(pac);
writeFileSync(join(pac, 'roteiro.json'), JSON.stringify({ titulo: 'Teste do app', formato: '9:16', fps: 30, motor: 'nativo', estilo: 'cinema', marca: { handle: 'TESTE' },
  cenas: [{ tipo: 'gancho', duracao: 1.5, texto: 'Teste do aplicativo' }, { tipo: 'cta', duracao: 1.5, texto: 'Fim', acao: '@teste' }] }));
const zip = join(T, 'pedido.bwreels.zip');
spawnSync('python3', ['-c', `import zipfile,sys; z=zipfile.ZipFile(sys.argv[1],'w'); z.write(sys.argv[2],'roteiro.json'); z.close()`, zip, join(pac, 'roteiro.json')]);

const BWSYNC = `<script>window.BWSync={cliente:function(){return{auth:{getUser:async function(){return{data:{user:localStorage.getItem('logado')?{id:'u-123',email:'dono@exemplo.com',user_metadata:{full_name:'Marcos Teste'}}:null}}},signOut:async function(){localStorage.removeItem('logado')}}}}};</script>`;
const PAGINAS = {
  '/login.html': `<title>login</title>${BWSYNC}<button id="entrar" onclick="localStorage.setItem('logado','1');location.href='index.html'">entrar</button>`,
  '/index.html': `<title>painel</title>${BWSYNC}<p>painel</p>`,
  '/reels.html': `<title>reels</title>${BWSYNC}<button id="btQuadro" onclick="document.title='quadro aberto'">quadro</button><a id="baixar" href="/pedido.bwreels.zip" download="meu-reel.bwreels.zip">render</a><a id="outro" href="/nota.txt" download="nota.txt">nota</a>
    <script>window.tentar=function(a){return window.bwNode(a,{})}</script>`,
  '/fora.html': `<title>fora</title><script>window.tentar=function(a){return window.bwNode?window.bwNode(a,{}):{ok:false,erro:'sem ponte'}}</script>`,
};
const servir = (req, res) => {
  const u = req.url.split('?')[0];
  if (u === '/pedido.bwreels.zip') { res.writeHead(200, { 'Content-Type': 'application/zip' }); return res.end(readFileSync(zip)); }
  if (u === '/nota.txt') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('ola'); }
  if (PAGINAS[u]) { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end('<!doctype html><meta charset="utf-8">' + PAGINAS[u]); }
  res.writeHead(404); res.end('nada');
};
const site = http.createServer(servir), fora = http.createServer(servir);
await new Promise((r) => site.listen(0, '127.0.0.1', r)); await new Promise((r) => fora.listen(0, '127.0.0.1', r));
const SITE = `http://127.0.0.1:${site.address().port}`, FORA = `http://127.0.0.1:${fora.address().port}`;

// legendas: "ouvido" simulado + um áudio de teste
const falso = join(T, 'ouvido.mjs');
writeFileSync(falso, `export function decodificar(a){ return { tokens:[' Ol','á',' mundo'], timestamps:[0.2,0.4,0.8], texto:' Olá mundo' }; }`);
const wav = join(T, 'fala.wav');
spawnSync('ffmpeg', ['-y', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=2', '-ar', '16000', wav], { stdio: 'ignore' });

Object.assign(process.env, { HOME: T, USERPROFILE: T, BWREELS_TESTE: '1', BWREELS_NAO_ABRIR: '1', BWREELS_SITE_TESTE: SITE, BWREELS_TRANSCRICAO_TESTE: falso, BWREELS_ARQUIVO_TESTE: wav });
const { abrirApp } = await import('./app.mjs');
const conta = await import('./conta.mjs');
const { contexto, pagina: pg } = await abrirApp({ semJanela: true });
const erros = []; pg.on('pageerror', (e) => erros.push(e.message));
const foto = (n) => process.env.BWREELS_FOTOS && pg.screenshot({ path: join(process.env.BWREELS_FOTOS, n + '.png'), fullPage: true });
const noInicio = () => pg.waitForURL(/app\/index\.html/, { timeout: 15000 });

console.log('\nLOGIN');
await pg.waitForSelector('#btEntrar');
ok(!(await pg.locator('.fer').count()), 'sem login: só a tela ENTRAR, nenhuma ferramenta');
let r = await pg.evaluate(() => window.bwNode('videos', {}));
ok(!r.ok && /Entre com a sua conta/.test(r.erro), 'sem login: a ponte recusa as ferramentas');
r = await pg.evaluate(() => window.bwNode('abrir', { destino: 'assistente' }));
ok(!r.ok, 'sem login: não abre o assistente');
await foto('app-entrar');
await pg.click('#btEntrar'); await pg.waitForURL(/login\.html/);
ok(true, 'ENTRAR abre a página de login da plataforma');
await pg.waitForSelector('#bwAppInicio');
await pg.click('#entrar'); await noInicio(); await pg.waitForSelector('.fer');
const lic = JSON.parse(readFileSync(join(T, '.bw-reels', 'licenca.json'), 'utf8'));
ok(lic.email === 'dono@exemplo.com' && lic.id === 'u-123', 'depois do login a conta fica registrada (id + e-mail)');
ok(!/senha|token|access|refresh/i.test(JSON.stringify(lic)), 'o arquivo da conta não tem senha nem chave de acesso');
ok(conta.estado().liberado && conta.estado().dias >= 6, 'conta liberada por 7 dias sem internet');
ok((await pg.locator('#conta').innerText()).includes('Marcos Teste'), 'nome da conta no topo');
ok((await pg.locator('.fer:not(.breve)').count()) === 6 && (await pg.locator('.fer.breve').count()) === 3, '6 ferramentas + 3 "em breve"');
await foto('app-inicio');

console.log('\nFERRAMENTAS ONLINE');
await pg.click('[data-f="reels"]'); await pg.waitForURL(/reels\.html/);
ok((await pg.title()) === 'reels', 'CRIAR REEL abre o editor da plataforma na mesma janela');
await pg.waitForSelector('#bwAppInicio');
r = await pg.evaluate(() => window.tentar('videos'));
ok(!r.ok && /recusado/.test(r.erro), 'a página da plataforma NÃO pode pedir arquivos do PC');
r = await pg.evaluate(() => window.tentar('salvarIA'));
ok(!r.ok && /recusado/.test(r.erro), 'a página da plataforma NÃO pode mexer nas chaves de IA');
await pg.click('#bwAppInicio'); await noInicio(); await pg.waitForSelector('.fer');
ok(true, 'botão ⌂ BW REELS volta para o início');
await pg.click('[data-f="quadro"]'); await pg.waitForURL(/reels\.html/);
await pg.waitForFunction(() => document.title === 'quadro aberto', null, { timeout: 15000 }).then(() => ok(true, 'QUADRO DE HISTÓRIA abre o quadro sozinho')).catch(() => ok(false, 'QUADRO DE HISTÓRIA abre o quadro sozinho'));

console.log('\nRENDER PELO APP');
await pg.click('#outro');
await pg.waitForFunction(() => /Salvo em Downloads: nota/.test(document.getElementById('bwAppAvisoTexto')?.textContent || ''), null, { timeout: 15000 });
ok(existsSync(join(T, 'nota.txt')), 'download comum é salvo e avisado');
await pg.click('#baixar');
await pg.waitForFunction(() => /Vídeo pronto|Não/.test(document.getElementById('bwAppAvisoTexto')?.textContent || ''), null, { timeout: 240000 });
const aviso = await pg.locator('#bwAppAvisoTexto').innerText();
ok(/Vídeo pronto/.test(aviso), 'RENDERIZAR NO PC dentro do app gera o vídeo sozinho — ' + aviso.slice(0, 70));
await pg.goto(FORA + '/fora.html');
r = await pg.evaluate(() => window.tentar('videos'));
ok(!r.ok, 'outro site não usa a ponte: ' + r.erro);
r = await pg.evaluate(() => window.tentar('inicio'));
ok(!r.ok, 'outro site não consegue nem navegar o app');
ok(!(await pg.locator('#bwAppInicio').count()), 'outro site não recebe o botão do app');

console.log('\nFERRAMENTAS DESTE PC');
const { pathToFileURL } = await import('node:url'); const N = await import('./assistente-nucleo.mjs');
await pg.goto(pathToFileURL(join(N.RAIZ, 'app', 'index.html')).href); await pg.waitForSelector('.vid');
ok((await pg.locator('.vid').count()) >= 1, 'MEUS VÍDEOS lista o vídeo renderizado');
r = await pg.evaluate(() => window.bwNode('abrirVideo', { arquivo: '/etc/passwd' }));
ok(!r.ok, 'só abre vídeo de dentro da pasta de projetos');
await pg.click('[data-f="legendas"]'); await pg.waitForSelector('#btLegendar');
await pg.click('#btLegendar'); await pg.waitForSelector('#legSrt', { timeout: 30000 });
ok(existsSync(join(T, 'fala.srt')) && /Olá mundo/.test(readFileSync(join(T, 'fala.srt'), 'utf8')), 'LEGENDAS: escolhe o arquivo e grava o .srt ao lado');
await foto('app-legenda');
await pg.click('#folhaCx .bt:last-child');
await pg.click('[data-f="assistente"]'); await pg.waitForURL(/assistente\/index\.html/); await pg.waitForSelector('.lista li');
ok((await pg.locator('#onde').innerText()).startsWith('Etapa 1 de'), 'ASSISTENTE abre na etapa 1');
ok((await pg.locator('#conta').innerText()).includes('Marcos Teste'), 'assistente mostra a conta');
ok(await pg.locator('#btAvancar').isEnabled(), 'assistente liberado (conta ativa)');
await pg.click('#bwAppInicio'); await noInicio(); await pg.waitForSelector('.fer');
await pg.click('[data-f="ias"]'); await pg.waitForURL(/assistente\/index\.html#ias/);
await pg.waitForFunction(() => /INSTALAR IAS|Minhas IAs/i.test(document.getElementById('tela').innerText), null, { timeout: 10000 }).then(() => ok(true, 'MINHAS IAS abre direto na tela das IAs')).catch(() => ok(false, 'MINHAS IAS abre direto na tela das IAs'));
await foto('app-ias');

console.log('\nSAIR E VALIDADE');
await pg.click('#bwAppInicio'); await noInicio(); await pg.waitForSelector('#btSair:not([hidden])');
pg.once('dialog', (d) => d.accept());
await pg.click('#btSair'); await pg.waitForSelector('#btEntrar', { timeout: 15000 });
ok(!existsSync(join(T, '.bw-reels', 'licenca.json')), 'SAIR apaga a conta deste PC');
await pg.goto(SITE + '/index.html');
ok(!(await pg.evaluate(() => localStorage.getItem('logado'))), 'SAIR também sai da plataforma');
conta.registrar({ id: 'u-123', email: 'dono@exemplo.com' });
const arq = join(T, '.bw-reels', 'licenca.json'); const l2 = JSON.parse(readFileSync(arq, 'utf8')); l2.validade = new Date(Date.now() - 1000).toISOString(); writeFileSync(arq, JSON.stringify(l2));
ok(!conta.estado().liberado && /venceu/.test(conta.estado().aviso), 'conferência vencida (mais de 7 dias) pede login de novo');
ok(erros.length === 0, 'sem erros de JavaScript nas telas' + (erros.length ? ': ' + erros.join(' | ') : ''));

await contexto.close(); site.close(); fora.close();
if (!process.env.BWREELS_GUARDAR) rmSync(T, { recursive: true, force: true });
for (const p of readdirSync(join(N.RAIZ, 'projetos'))) if (/^meu-reel-\d{8}-\d{6}$/.test(p)) rmSync(join(N.RAIZ, 'projetos', p), { recursive: true, force: true });
console.log(falhas.length ? `\n${falhas.length} FALHA(S)\n` : '\nTudo certo.\n');
process.exit(falhas.length ? 1 : 0);
