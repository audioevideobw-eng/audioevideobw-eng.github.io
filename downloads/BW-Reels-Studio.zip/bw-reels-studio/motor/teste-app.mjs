// Teste do aplicativo BW Reels: janela escondida, plataforma SIMULADA (servidor só do teste), "ouvido" das legendas simulado.
// Uso: node motor/teste-app.mjs
import { mkdtempSync, writeFileSync, existsSync, readFileSync, mkdirSync, readdirSync, rmSync, statSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { pathToFileURL as paraURL } from 'node:url';
import { spawnSync } from 'node:child_process';
import http from 'node:http';

const T = mkdtempSync(join(tmpdir(), 'bwapp-'));
const falhas = []; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) falhas.push(m); };

// pacote de pedido de render (como o botão RENDERIZAR NO PC baixa)
const pac = join(T, 'pac'); mkdirSync(pac);
writeFileSync(join(pac, 'roteiro.json'), JSON.stringify({ titulo: 'Teste do app', formato: '9:16', fps: 30, motor: 'nativo', estilo: 'cinema', marca: { handle: 'TESTE' },
  cenas: [{ tipo: 'gancho', duracao: 1.5, texto: 'Teste do aplicativo' }, { tipo: 'cta', duracao: 1.5, texto: 'Fim', acao: '@teste' }] }));
const zip = join(T, 'pedido.bwreels.zip');
spawnSync('python3', ['-c', `import zipfile,sys; z=zipfile.ZipFile(sys.argv[1],'w'); z.write(sys.argv[2],'roteiro.json'); z.close()`, zip, join(pac, 'roteiro.json')]);

const BWSYNC = `<script>window.BWSync={cliente:function(){return{auth:{getUser:async function(){return{data:{user:localStorage.getItem('logado')?{id:'u-123',email:'dono@exemplo.com',user_metadata:{full_name:'Marcos Teste'}}:null}}},signOut:async function(){localStorage.removeItem('logado')}}}}};</script>`;
const PAGINAS = {
  '/login.html': `<title>login</title>${BWSYNC}<button id="entrar" onclick="localStorage.setItem('logado','1');location.href='index.html'">entrar</button>`,
  '/index.html': `<title>painel</title>${BWSYNC}<p>painel</p>`,
  '/reels.html': `<title>reels</title>${BWSYNC}<button id="btQuadro" onclick="document.title='quadro aberto'">quadro</button><a id="baixar" href="/pedido.bwreels.zip" download="meu-reel.bwreels.zip">render</a><a id="outro" href="/nota.txt" download="nota.txt">nota</a><a id="motion" href="/pedido-motion.json" download="teste.magenta.bwmotion.json">motion</a><a id="motionAlfa" href="/pedido-motion.json" download="teste.alfa.bwmotion.json">alfa</a><a id="motionMau" href="/motion-mau.json" download="mau.verde.bwmotion.json">mau</a>
    <script>window.tentar=function(a,d){return window.bwNode(a,d||{})}</script>`,
  '/fora.html': `<title>fora</title><script>window.tentar=function(a){return window.bwNode?window.bwNode(a,{}):{ok:false,erro:'sem ponte'}}</script>`,
};
const PEDIDOS_VIDEO = [];
// ESTÚDIO DE MOTION: projeto simulado (texto com marcação de HTML no meio — tem de sair como TEXTO, nunca virar código)
const MOTION_SIM = { v: 1, nome: 'teste', formato: '9:16', w: 540, h: 960, fps: 12, dur: 1.5, fundo: { tipo: 'escuro' }, meusEfeitos: [],
  itens: [{ id: 'a', tipo: 'texto', ini: 0, fim: 1.5, x: 270, y: 300, escala: 1, giro: 0, opac: 1, keys: {}, props: { texto: 'OI <img src=x onerror="document.title=1"> *BW*', estilo: 'neon', fonte: 'texto', tamanho: 60, cor: '#FFFFFF', destaque: '#B6FF3B', larg: 500, alinhar: 'center' },
    entrada: { efeito: 'pulo', dur: 0.4 }, saida: { efeito: 'aparecer', dur: 0.3 }, loop: { efeito: 'nenhum', forca: 1 } },
    { id: 'b', tipo: 'piso', ini: 0, fim: 1.5, x: 270, y: 800, escala: 1, giro: 0, opac: 1, keys: {}, props: { cor: '#7CFF3B', velocidade: 1 }, entrada: { efeito: 'aparecer', dur: 0.3 }, saida: { efeito: 'aparecer', dur: 0.3 }, loop: { efeito: 'nenhum', forca: 1 } }] };
// ATUALIZAÇÃO simulada: pasta "instalada" velha + pacote novo publicado no site
const velho = join(T, 'app-velho'); mkdirSync(join(velho, 'motor'), { recursive: true }); mkdirSync(join(velho, 'projetos'));
writeFileSync(join(velho, 'motor', 'app.mjs'), '// velho'); writeFileSync(join(velho, 'package.json'), '{"name":"x"}'); writeFileSync(join(velho, 'projetos', 'meu.txt'), 'meu projeto');
const novo = join(T, 'novo', 'bw-reels-studio'); mkdirSync(join(novo, 'motor'), { recursive: true }); mkdirSync(join(novo, 'projetos'));
writeFileSync(join(novo, 'motor', 'app.mjs'), '// novo'); writeFileSync(join(novo, 'package.json'), '{"name":"x"}'); writeFileSync(join(novo, 'NOVO.txt'), 'novidade'); writeFileSync(join(novo, 'projetos', 'meu.txt'), 'VAZIO DO PACOTE');
const zipAtu = join(T, 'atu.zip');
spawnSync('python3', ['-c', `import zipfile,os,sys
z=zipfile.ZipFile(sys.argv[1],'w'); b=sys.argv[2]
for r,d,f in os.walk(b):
  for n in f: p=os.path.join(r,n); z.write(p, os.path.relpath(p, os.path.dirname(b)))
z.close()`, zipAtu, novo]);
const shaAtu = (await import('node:crypto')).createHash('sha256').update(readFileSync(zipAtu)).digest('hex');
let VERSAO_SIM = null;
const servir = (req, res) => {
  const u = req.url.split('?')[0];
  if (u === '/downloads/app-versao.json') { if (!VERSAO_SIM) { res.writeHead(404); return res.end('nada'); } res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify(VERSAO_SIM)); }
  if (u === '/downloads/BW-atualizacao.zip') { res.writeHead(200, { 'Content-Type': 'application/zip' }); return res.end(readFileSync(zipAtu)); }
  if (u === '/pedido-motion.json') { res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify(MOTION_SIM)); }
  if (u === '/motion-mau.json') { res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ w: 99999, h: 1, dur: 2, itens: [] })); }
  if (u === '/pedido.bwreels.zip') { res.writeHead(200, { 'Content-Type': 'application/zip' }); return res.end(readFileSync(zip)); }
  const aut = req.headers.authorization || '';
  const json = (st, o) => { res.writeHead(st, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
  const eu = 'http://' + req.headers.host;
  if (u === '/runway/v1/organization') return aut === 'Bearer chave-boa-runway-123' ? json(200, { creditBalance: 500 }) : json(401, { error: 'Invalid API key' });
  if (u === '/runway/v1/image_to_video') { let c = ''; req.on('data', (d) => { c += d; }); req.on('end', () => { PEDIDOS_VIDEO.push({ quem: 'runway', aut, corpo: JSON.parse(c) }); json(200, { id: 't1' }); }); return; }
  if (u === '/runway/v1/tasks/t1') return json(200, { status: 'SUCCEEDED', output: [eu + '/clipe.mp4'] });
  if (u === '/fal/fal-ai/kling-video/v3/standard/image-to-video') { let c = ''; req.on('data', (d) => { c += d; }); req.on('end', () => { PEDIDOS_VIDEO.push({ quem: 'fal', aut, corpo: JSON.parse(c) }); if (aut !== 'Key chave-boa-fal-1234567') return json(401, { detail: 'bad key' }); json(200, { status: 'IN_QUEUE', request_id: 'r1', status_url: eu + '/fal/st', response_url: eu + '/fal/re' }); }); return; }
  if (u === '/fal/st') return json(200, { status: 'COMPLETED' });
  if (u === '/fal/re') return json(200, { video: { url: eu + '/clipe.mp4' } });
  if (u === '/clipe.mp4') { res.writeHead(200, { 'Content-Type': 'video/mp4' }); return res.end(Buffer.alloc(5000, 7)); }
  if (u === '/nota.txt') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('ola'); }
  if (PAGINAS[u]) { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end('<!doctype html><meta charset="utf-8">' + PAGINAS[u]); }
  res.writeHead(404); res.end('nada');
};
const site = http.createServer(servir), fora = http.createServer(servir);
await new Promise((r) => site.listen(0, '127.0.0.1', r)); await new Promise((r) => fora.listen(0, '127.0.0.1', r));
const SITE = `http://127.0.0.1:${site.address().port}`, FORA = `http://127.0.0.1:${fora.address().port}`;

// legendas: "ouvido" simulado + um áudio de teste
const falso = join(T, 'ouvido.mjs');
writeFileSync(falso, `export function decodificar(a){ return { tokens:[' Ol','á',' mundo'], timestamps:[0.2,0.4,0.8], texto:' Olá mundo' }; }`);
const wav = join(T, 'fala.wav');
spawnSync('ffmpeg', ['-y', '-f', 'lavfi', '-i', 'sine=frequency=440:duration=2', '-ar', '16000', wav], { stdio: 'ignore' });

const copia = join(T, 'copia'); mkdirSync(copia);
writeFileSync(join(copia, 'fotos.html'), '<!doctype html><meta charset="utf-8"><title>fotos da copia</title><p>editor</p>');
Object.assign(process.env, { HOME: T, USERPROFILE: T, BWREELS_TESTE: '1', BWREELS_NAO_ABRIR: '1', BWREELS_SITE_TESTE: SITE, BWREELS_RAIZ_ATU_TESTE: velho, BWREELS_TRANSCRICAO_TESTE: falso, BWREELS_ARQUIVO_TESTE: wav, BWREELS_VIDEO_TESTE: FORA, BWREELS_COPIA_TESTE: copia });
const { abrirApp } = await import('./app.mjs');
const conta = await import('./conta.mjs');
const { contexto, pagina: pg } = await abrirApp({ semJanela: true });
const erros = []; pg.on('pageerror', (e) => erros.push(e.message));
const foto = (n) => process.env.BWREELS_FOTOS && pg.screenshot({ path: join(process.env.BWREELS_FOTOS, n + '.png'), fullPage: true });
const noInicio = () => pg.waitForURL(/app\/index\.html/, { timeout: 15000 });

console.log('\nLOGIN');
await pg.waitForSelector('#btEntrar');
ok(!(await pg.locator('.fer').count()), 'sem login: só a tela ENTRAR, nenhuma ferramenta');
let r = await pg.evaluate(() => window.bwNode('videos', {}));
ok(!r.ok && /Entre com a sua conta/.test(r.erro), 'sem login: a ponte recusa as ferramentas');
r = await pg.evaluate(() => window.bwNode('abrir', { destino: 'assistente' }));
ok(!r.ok, 'sem login: não abre o assistente');
await foto('app-entrar');
await pg.click('#btEntrar'); await pg.waitForURL(/login\.html/);
ok(true, 'ENTRAR abre a página de login da plataforma');
await pg.waitForSelector('#bwAppInicio');
await pg.click('#entrar'); await noInicio(); await pg.waitForSelector('.fer');
ok(await pg.locator('#nucleo.cheia #btEntrarPlat').isVisible() && /BRIGHTWAY/.test(await pg.locator('#nucTit').innerText()), 'logado: 1ª tela = abertura BRIGHTWAY em tela cheia com o botão ENTRAR');
await pg.waitForFunction(() => /SEU SOFTWARE INTELIGENTE/.test(document.getElementById('nucSub').innerText), null, { timeout: 8000 }).then(() => ok(true, 'letreiro SEU SOFTWARE INTELIGENTE')).catch(() => ok(false, 'letreiro SEU SOFTWARE INTELIGENTE'));
await pg.click('#btPC'); ok(!(await pg.locator('#nucleo.cheia').count()) && await pg.locator('.fer').first().isVisible(), '"ferramentas deste PC" abre a área do PC');
await pg.click('#btMenu'); ok(await pg.locator('#gaveta.aberta').count() === 1, 'menu escondido abre pelo ☰'); await pg.click('#veu'); ok(!(await pg.locator('#gaveta.aberta').count()), 'tocar fora fecha o menu');
const lic = JSON.parse(readFileSync(join(T, '.bw-reels', 'licenca.json'), 'utf8'));
ok(lic.email === 'dono@exemplo.com' && lic.id === 'u-123', 'depois do login a conta fica registrada (id + e-mail)');
ok(!/senha|token|access|refresh/i.test(JSON.stringify(lic)), 'o arquivo da conta não tem senha nem chave de acesso');
ok(conta.estado().liberado && conta.estado().dias >= 6, 'conta liberada por 7 dias sem internet');
ok((await pg.locator('#conta').innerText()).includes('Marcos Teste'), 'nome da conta no topo');
ok((await pg.locator('.fer:not(.breve)').count()) === 24 && (await pg.locator('.fer.breve').count()) === 2, '24 ferramentas + 2 "em breve"');
await pg.waitForTimeout(1400); await foto('app-inicio');

console.log('\nFERRAMENTAS ONLINE');
await pg.click('[data-f="reels"]'); await pg.waitForURL(/reels\.html/);
ok((await pg.title()) === 'reels', 'CRIAR REEL abre o editor da plataforma na mesma janela');
await pg.waitForSelector('#bwAppInicio');
r = await pg.evaluate(() => window.tentar('videos'));
ok(!r.ok && /recusado/.test(r.erro), 'a página da plataforma NÃO pode pedir arquivos do PC');
r = await pg.evaluate(() => window.tentar('salvarIA'));
ok(!r.ok && /recusado/.test(r.erro), 'a página da plataforma NÃO pode mexer nas chaves de IA');
await pg.click('#bwAppInicio'); await noInicio(); await pg.waitForSelector('.fer');
ok(true, 'botão ⌂ BW REELS volta para o início');
await pg.click('[data-f="quadro"]'); await pg.waitForURL(/reels\.html/);
await pg.waitForFunction(() => document.title === 'quadro aberto', null, { timeout: 15000 }).then(() => ok(true, 'QUADRO DE HISTÓRIA abre o quadro sozinho')).catch(() => ok(false, 'QUADRO DE HISTÓRIA abre o quadro sozinho'));

console.log('\nRENDER PELO APP');
await pg.click('#outro');
await pg.waitForFunction(() => /Salvo em Downloads: nota/.test(document.getElementById('bwAppAvisoTexto')?.textContent || ''), null, { timeout: 15000 });
ok(existsSync(join(T, 'nota.txt')), 'download comum é salvo e avisado');
await pg.click('#baixar');
await pg.waitForFunction(() => /Vídeo pronto|Não/.test(document.getElementById('bwAppAvisoTexto')?.textContent || ''), null, { timeout: 240000 });
const aviso = await pg.locator('#bwAppAvisoTexto').innerText();
ok(/Vídeo pronto/.test(aviso), 'RENDERIZAR NO PC dentro do app gera o vídeo sozinho — ' + aviso.slice(0, 70));
console.log('\nESTÚDIO DE MOTION PELO APP');
const NM = await import('./assistente-nucleo.mjs'), SITE_REPO = process.env.BW_SITE || '/home/claude/audioevideobw-eng.github.io';
const meusVideosTem = (f) => !!f && /\.mov$/.test(f) && readFileSync(join(NM.RAIZ, 'motor', 'app.mjs'), 'utf8').includes('(mp4|mov)');
const pxDe = (f, t) => [...spawnSync('ffmpeg', ['-v', 'error', '-ss', String(t), '-i', f, '-frames:v', '1', '-vf', 'crop=4:4:2:2,scale=1:1', '-f', 'rawvideo', '-pix_fmt', 'rgba', '-'], { maxBuffer: 1 << 20 }).stdout];
const ultimoMotion = (ext) => { const ds = readdirSync(join(NM.RAIZ, 'projetos')).filter((n) => n.startsWith('motion-teste-')).map((n) => join(NM.RAIZ, 'projetos', n, 'render')).filter((p) => existsSync(p));
  const fs = ds.flatMap((p) => readdirSync(p).filter((n) => n.endsWith(ext)).map((n) => join(p, n))); return fs.sort((a, b) => statSync(b).mtimeMs - statSync(a).mtimeMs)[0]; };
await pg.goto(SITE + '/reels.html'); await pg.waitForSelector('#motion');
await pg.click('#motion');
await pg.waitForFunction(() => /Vídeo pronto|Não deu/.test(document.getElementById('bwAppAvisoTexto')?.textContent || ''), null, { timeout: 120000 });
let avm = await pg.locator('#bwAppAvisoTexto').innerText(); const mpm = ultimoMotion('-chroma.mp4');
ok(/Vídeo pronto/.test(avm) && mpm, 'GERAR NO APP BW: .magenta.bwmotion.json vira vídeo no PC — ' + avm.slice(0, 60));
const pm = mpm ? pxDe(mpm, 1) : [];
ok(pm[0] > 200 && pm[1] < 60 && pm[2] > 200, `fundo magenta de chroma key (o piso 3D some no recorte) (${pm.slice(0, 3)})`);
ok(mpm && readFileSync(join(dirname(mpm), '..', 'animacao.html'), 'utf8').includes(paraURL(join(NM.RAIZ, 'motor', 'motion-motor.js')).href), 'o HTML usa o motor LOCAL do app (nada de código vindo do download)');
ok((await pg.title()) === 'reels', 'texto com <img onerror> sai como texto e não executa nada');
await pg.click('#motionAlfa');
await pg.waitForFunction(() => /Vídeo pronto.*\.mov|Não deu/.test(document.getElementById('bwAppAvisoTexto')?.textContent || ''), null, { timeout: 120000 });
const mov = ultimoMotion('.mov'), prMov = mov ? spawnSync('ffprobe', ['-v', 'error', '-show_entries', 'stream=codec_name,pix_fmt', '-of', 'csv=p=0', mov]).stdout.toString().trim() : '';
ok(/^prores,yuva444/.test(prMov), 'TRANSPARENTE: .alfa.bwmotion.json vira .mov ProRes 4444 com alfa (' + prMov + ')');
ok(meusVideosTem(mov), 'o .mov aparece em MEUS VÍDEOS');
await pg.click('#motionMau');
await pg.waitForFunction(() => /não é um projeto válido/.test(document.getElementById('bwAppAvisoTexto')?.textContent || ''), null, { timeout: 20000 }).then(() => ok(true, 'arquivo de projeto inválido é recusado')).catch(() => ok(false, 'arquivo de projeto inválido é recusado'));
ok(readFileSync(join(NM.RAIZ, 'motor', 'motion-motor.js'), 'utf8') === readFileSync(join(SITE_REPO, 'assets', 'motion-motor.js'), 'utf8') || !existsSync(SITE_REPO), 'motor/motion-motor.js é IGUAL ao assets/motion-motor.js do site');
await pg.goto(FORA + '/fora.html');
r = await pg.evaluate(() => window.tentar('videos'));
ok(!r.ok, 'outro site não usa a ponte: ' + r.erro);
r = await pg.evaluate(() => window.tentar('inicio'));
ok(!r.ok, 'outro site não consegue nem navegar o app');
ok(!(await pg.locator('#bwAppInicio').count()), 'outro site não recebe o botão do app');

console.log('\nFERRAMENTAS DESTE PC');
const { pathToFileURL } = await import('node:url'); const N = await import('./assistente-nucleo.mjs');
await pg.goto(pathToFileURL(join(N.RAIZ, 'app', 'index.html')).href + '?r=' + Date.now() + '#pc'); await pg.waitForSelector('.vid');
ok((await pg.locator('.vid').count()) >= 1, 'MEUS VÍDEOS lista o vídeo renderizado');
r = await pg.evaluate(() => window.bwNode('abrirVideo', { arquivo: '/etc/passwd' }));
ok(!r.ok, 'só abre vídeo de dentro da pasta de projetos');
await pg.click('[data-f="legendas"]'); await pg.waitForSelector('#btLegendar');
await pg.click('#btLegendar'); await pg.waitForSelector('#legSrt', { timeout: 30000 });
ok(existsSync(join(T, 'fala.srt')) && /Olá mundo/.test(readFileSync(join(T, 'fala.srt'), 'utf8')), 'LEGENDAS: escolhe o arquivo e grava o .srt ao lado');
await foto('app-legenda');
await pg.click('#folhaCx .bt:last-child');
await pg.click('[data-f="assistente"]'); await pg.waitForURL(/assistente\/index\.html/); await pg.waitForSelector('.lista li');
ok((await pg.locator('#onde').innerText()).startsWith('Etapa 1 de'), 'ASSISTENTE abre na etapa 1');
ok((await pg.locator('#conta').innerText()).includes('Marcos Teste'), 'assistente mostra a conta');
ok(await pg.locator('#btAvancar').isEnabled(), 'assistente liberado (conta ativa)');
await pg.click('#bwAppInicio'); await noInicio(); await pg.waitForSelector('.fer');
await pg.click('[data-f="ias"]'); await pg.waitForURL(/assistente\/index\.html#ias/);
await pg.waitForFunction(() => /INSTALAR IAS|Minhas IAs/i.test(document.getElementById('tela').innerText), null, { timeout: 10000 }).then(() => ok(true, 'MINHAS IAS abre direto na tela das IAs')).catch(() => ok(false, 'MINHAS IAS abre direto na tela das IAs'));
await foto('app-ias');


console.log('\nIA DE VÍDEO (conectores, provedores SIMULADOS)');
await pg.click('#bwAppInicio'); await noInicio(); await pg.waitForSelector('.fer');
await pg.click('[data-f="videoia"]'); await pg.waitForSelector('#vk_runway');
await pg.fill('#vk_runway', 'chave-errada-runway-000'); await pg.click('[data-vc="runway"]');
await pg.waitForFunction(() => /não foi aceita/.test(document.getElementById('folhaCx').innerText), null, { timeout: 10000 }).then(() => ok(true, 'chave errada da Runway é recusada na hora')).catch(() => ok(false, 'chave errada da Runway é recusada na hora'));
await pg.fill('#vk_runway', 'chave-boa-runway-123'); await pg.click('[data-vc="runway"]');
await pg.waitForSelector('[data-vd="runway"]');
ok(/saldo: 500/.test(await pg.locator('#folhaCx').innerText()), 'chave certa: conectada, com o saldo de créditos');
await pg.fill('#vk_fal', 'chave-boa-fal-1234567'); await pg.click('[data-vc="fal"]'); await pg.waitForSelector('[data-vd="fal"]');
ok((await pg.locator('[name=vpad]').count()) === 4, 'com as duas conectadas aparecem os 4 modelos com preço');
const tela = await pg.content(); const st = await pg.evaluate(() => window.bwNode('videoIA', {}));
ok(!/chave-boa/.test(tela) && !/chave-boa/.test(JSON.stringify(st)) && /…-123/.test(JSON.stringify(st)), 'a chave nunca volta para a tela (só o final)');
ok(/chave-boa-runway-123/.test(readFileSync(join(T, '.bw-reels', 'video-ias.json'), 'utf8')), 'a chave fica só no arquivo deste PC');
await pg.click('#folhaCx .linha .bt');
await pg.click('[data-f="reels"]'); await pg.waitForURL(/reels\.html/); await pg.waitForSelector('#bwAppInicio');
r = await pg.evaluate(() => window.tentar('videoConectar', { id: 'runway', chave: 'outra-chave-qualquer-1' }));
ok(!r.ok && /recusado/.test(r.erro), 'a página da plataforma NÃO pode trocar nem ler chave');
r = await pg.evaluate(() => window.tentar('abrirFlow'));
ok(r.ok, 'a plataforma pode pedir para abrir o Flow no navegador do PC (endereço fixo)');
r = await pg.evaluate(() => window.tentar('videoIA'));
ok(r.ok && r.valor.modelos.length === 4 && !/chave-boa/.test(JSON.stringify(r.valor)), 'a plataforma só enxerga quais modelos estão liberados');
const IMG = 'data:image/jpeg;base64,' + Buffer.alloc(600, 1).toString('base64');
r = await pg.evaluate((img) => window.tentar('videoGerar', { modelo: 'runway:gen4_turbo', prompt: 'a pessoa entra no salão sorrindo, câmera acompanha', imagem: img, seg: 5 }), IMG);
ok(r.ok && r.valor.base64.length > 6000 && r.valor.usd === 0.25, 'GERAR pela Runway: devolve o clipe e o custo de referência (US$ 0,25)');
r = await pg.evaluate((img) => window.tentar('videoGerar', { modelo: 'fal:kling3', prompt: 'a pessoa entra no salão sorrindo, câmera acompanha', imagem: img, seg: 5 }), IMG);
ok(r.ok && r.valor.usd === 0.42, 'GERAR pela fal.ai (Kling 3.0): devolve o clipe (US$ 0,42)');
const pr = PEDIDOS_VIDEO.find((x) => x.quem === 'runway'), pf = PEDIDOS_VIDEO.filter((x) => x.quem === 'fal').pop();
ok(pr.corpo.model === 'gen4_turbo' && pr.corpo.ratio === '720:1280' && pr.corpo.duration === 5 && pr.corpo.promptImage === IMG, 'pedido da Runway no formato da API (modelo, vertical, 5 s, imagem)');
ok(pf.corpo.start_image_url === IMG && pf.corpo.duration === '5' && pf.corpo.generate_audio === false && pf.aut.startsWith('Key '), 'pedido da fal.ai no formato da API');
ok(readdirSync(join(N.RAIZ, 'projetos', 'clipes-ia')).filter((n) => n.endsWith('.mp4')).length >= 1, 'o clipe também fica guardado em projetos/clipes-ia');
r = await pg.evaluate(() => window.tentar('videoGerar', { modelo: 'runway:gen4_turbo', prompt: 'x', imagem: 'http://site/foto.jpg', seg: 5 }));
ok(!r.ok, 'recusa pedido sem imagem válida: ' + r.erro);
await pg.goto(FORA + '/fora.html');
r = await pg.evaluate(() => window.tentar('videoGerar'));
ok(!r.ok && /recusado/.test(r.erro), 'outro site não consegue gerar clipe na conta do usuário');

console.log('\nBW SKILL');
mkdirSync(join(T, '.claude'), { recursive: true }); mkdirSync(join(T, 'Downloads'), { recursive: true });
const pastaProj = join(T, 'EDICAO PROJETOS'); mkdirSync(pastaProj, { recursive: true }); process.env.BWREELS_PASTA_TESTE = pastaProj;
await pg.goto(pathToFileURL(join(N.RAIZ, 'app', 'index.html')).href + '?r=' + Date.now() + '#pc'); await pg.waitForSelector('.fer');
ok(await pg.locator('.fer[data-f="skills"]').count() === 1 && await pg.locator('.nav[data-abre="skills"]').count() === 1, 'BW SKILL no início (cartão e menu)');
await pg.click('#btMenu'); await pg.waitForTimeout(300); await pg.click('.nav[data-abre="skills"]'); await pg.waitForURL(/skills\.html/, { timeout: 10000 }); await pg.waitForSelector('.sk');
ok(await pg.locator('.sk').count() === 2, 'carrossel com as 2 skills (editor de vídeo e animação por código)');
await pg.click('[data-inst="0"]', { force: true }); await pg.waitForSelector('#mag.aberto');
ok(/EDITOR DE VÍDEO/.test(await pg.locator('.lado').innerText()) && await pg.locator('.passos li').count() === 9, 'instalador abre com as etapas na lateral (estilo Windows)');
await pg.click('#btAvan'); await pg.waitForSelector('.req');
ok(/FFmpeg/.test(await pg.locator('#cont').innerText()) && /Claude/.test(await pg.locator('#cont').innerText()), 'REQUISITOS: confere FFmpeg e acha a IA do computador');
await pg.click('#btAvan'); await pg.waitForSelector('[data-ia]');
ok(await pg.locator('[data-ia="claude"]').isChecked() && !(await pg.locator('[data-ia="codex"]').isChecked()), 'SUA IA: Claude encontrado e marcado sozinho; Codex/Gemini/outra para escolher');
await pg.click('#btAvan'); await pg.waitForSelector('[data-esc="PASTA_PROJETOS"]');
await pg.click('#btAvan'); ok(/Falta preencher/.test(await pg.locator('#cont').innerText()), 'não avança sem a pasta dos projetos');
await pg.click('[data-esc="PASTA_PROJETOS"]'); await pg.waitForFunction((p) => document.getElementById('pv_PASTA_PROJETOS').textContent === p, pastaProj);
ok(true, 'ESCOLHER abre a janela de pasta e preenche o caminho');
await pg.click('#btAvan'); await pg.waitForSelector('select[data-c="EDITOR"]');
await pg.fill('input[data-c="CAMERAS"]', 'Sony A7S III (S-Log3)');
await pg.click('#btAvan'); await pg.waitForSelector('input[data-c="MARCA"]');
await pg.fill('input[data-c="MARCA"]', 'Produtora Exemplo');
await pg.click('#btAvan'); await pg.waitForSelector('.resumo');
ok(/Produtora Exemplo/.test(await pg.locator('.resumo').innerText()) && (await pg.locator('#btAvan').innerText()).includes('INSTALAR'), 'CONFERIR mostra o resumo antes de instalar');
await pg.click('#btAvan'); await pg.waitForFunction(() => /Instalada|Não deu certo/.test(document.getElementById('cont').innerText), null, { timeout: 10000 });
ok(/Instalada/.test(await pg.locator('#cont').innerText()) && /tudo certo/.test(await pg.locator('#cont').innerText()), 'INSTALAR + teste rápido ✓');
const skEd = join(T, '.claude', 'skills', 'bw-editor-de-video', 'SKILL.md');
const txtEd = existsSync(skEd) ? readFileSync(skEd, 'utf8') : '';
ok(txtEd.includes(pastaProj) && txtEd.includes('Produtora Exemplo') && txtEd.includes('Sony A7S III') && !/\{\{[A-Z_]+\}\}/.test(txtEd) && /^name: "bw-editor-de-video"/m.test(txtEd), 'SKILL.md gravada em ~/.claude/skills com as pastas e a marca da pessoa');
ok(!/VALE MINA|FIEMG|E:\\EDI|ADOBE ARQUIVOS|C:\\Users\\audio/.test(txtEd), 'versão para usuários: sem pastas nem clientes do dono');
await pg.click('#btAvan'); await pg.waitForSelector('.md h1');
ok(/como usar/i.test(await pg.locator('.md').innerText()), 'TUTORIAL aparece no fim da instalação');
await pg.click('#btAvan'); await pg.waitForFunction(() => !document.getElementById('mag').classList.contains('aberto'));
await pg.waitForSelector('.sk .tag.ok');
ok(await pg.locator('[data-rem="0"]').count() === 1, 'cartão mostra INSTALADA, PASTA e REMOVER');
// segunda skill direto pela ponte: Codex + zip para outra IA, pasta padrão criada sozinha
let rs = await pg.evaluate(() => window.bwNode('skillInstalar', { id: 'bw-animacao-por-codigo', ias: ['codex', 'outra'], valores: { MARCA: 'Produtora Exemplo' } }));
if (!rs.ok) console.log('   erro:', rs.erro);
const zipSk = join(T, 'Downloads', 'BW-SKILL-bw-animacao-por-codigo.zip');
const listaZip = spawnSync('python3', ['-c', 'import zipfile,sys; z=zipfile.ZipFile(sys.argv[1]); print(z.testzip() is None, sorted(z.namelist()))', zipSk], { encoding: 'utf8' }).stdout || '';
ok(rs.ok && existsSync(join(T, '.codex', 'skills', 'bw-animacao-por-codigo', 'SKILL.md')) && /^True/.test(listaZip) && /SKILL\.md/.test(listaZip) && /TUTORIAL\.md/.test(listaZip), 'animação por código: Codex + .zip válido em Downloads para outra IA');
const txtAn = readFileSync(join(T, '.codex', 'skills', 'bw-animacao-por-codigo', 'SKILL.md'), 'utf8');
ok(txtAn.includes(N.RAIZ) && txtAn.includes(join(T, 'Videos', 'BW Animacoes')) && existsSync(join(T, 'Videos', 'BW Animacoes')), 'aponta para o motor do app BW e cria a pasta padrão das animações');
rs = await pg.evaluate(() => window.bwNode('skillInstalar', { id: 'bw-editor-de-video', ias: ['claude'], valores: { PASTA_PROJETOS: '/nao/existe', MARCA: 'X' } }));
ok(!rs.ok && /não existe/.test(rs.erro), 'pasta que não existe é recusada');
rs = await pg.evaluate(() => window.bwNode('skillInstalar', { id: '../../etc', ias: ['claude'], valores: {} }));
ok(!rs.ok, 'id de skill inválido é recusado');
rs = await pg.evaluate(() => window.bwNode('skillRemover', { id: 'bw-animacao-por-codigo' }));
ok(rs.ok && rs.valor.removidas === 1 && !existsSync(join(T, '.codex', 'skills', 'bw-animacao-por-codigo')) && existsSync(join(T, 'Videos', 'BW Animacoes')), 'REMOVER tira a skill da IA e não mexe nos projetos');
const sitePg = await contexto.newPage(); await sitePg.goto(SITE + '/index.html');
rs = await sitePg.evaluate(() => window.bwNode('skills'));
ok(!rs.ok && /recusado/.test(rs.erro), 'a página da plataforma NÃO pode listar nem instalar skills');
await sitePg.close();

console.log('\nATUALIZAÇÕES');
VERSAO_SIM = { versao: '9.9', data: '19/11/2026', pacote: 'downloads/BW-atualizacao.zip', sha256: shaAtu, bytes: readFileSync(zipAtu).length,
  novidades: [{ titulo: 'Editor de fotos turbinado', texto: 'Máscaras e camadas novas.', abrir: 'fotos' }, { titulo: 'Correções', texto: 'Mais estável.' }] };
await pg.goto(pathToFileURL(join(N.RAIZ, 'app', 'index.html')).href + '?r=' + Date.now() + '#pc'); await pg.waitForSelector('.fer');
await pg.waitForSelector('#btAtuAgora', { timeout: 8000 }).catch(() => {});
ok(/Nova versão do BW: 9\.9/.test(await pg.locator('#folha').innerText().catch(() => '')) && (await pg.locator('.nov').count()) === 2, 'com internet e versão nova: o BW avisa sozinho e mostra o que vem');
await pg.click('#btAtuDepois'); await pg.waitForTimeout(400);
await pg.goto(pathToFileURL(join(N.RAIZ, 'app', 'index.html')).href + '?r=' + Date.now() + '#pc'); await pg.waitForSelector('.fer'); await pg.waitForTimeout(1500);
ok(!(await pg.locator('#btAtuAgora').count()) && !(await pg.locator('#navAtuN').isHidden()), 'DEPOIS: não insiste ao abrir de novo, mas o menu Atualizações fica marcado');
await pg.click('#btMenu'); await pg.waitForTimeout(300); await pg.click('#navAtu'); await pg.waitForSelector('#btAtuAgora');
ok(true, 'menu Atualizações abre o aviso de novo');
await pg.click('#btAtuAgora'); await pg.waitForFunction(() => /Atualizado|Não deu certo/.test(document.getElementById('atuMsg')?.innerText || ''), null, { timeout: 20000 });
ok(/Atualizado/.test(await pg.locator('#atuMsg').innerText()), 'ATUALIZAR AGORA baixa, confere e instala');
ok(readFileSync(join(velho, 'motor', 'app.mjs'), 'utf8') === '// novo' && existsSync(join(velho, 'NOVO.txt')), 'arquivos do app trocados pela versão nova');
ok(readFileSync(join(velho, 'projetos', 'meu.txt'), 'utf8') === 'meu projeto', 'a pasta projetos do usuário NÃO é tocada');
// GERADOR 3D no PC: a plataforma pode perguntar o estado e mandar gerar; instalar/remover é só das telas do app
const g3 = await pg.evaluate(() => window.bwNode('g3dEstado'));
ok(g3 && g3.ok && g3.valor && 'instalado' in g3.valor && Array.isArray(g3.valor.etapasLista), 'o app responde o estado do gerador 3D');
ok(g3.valor.raiz.includes('.bw-reels'), 'o gerador 3D mora em ~/.bw-reels (a atualização não toca nele)');
ok(/tencent/i.test(g3.valor.licenca.url), 'o estado traz a licença do modelo para a tela mostrar');
const g3pasta = await pg.evaluate(() => window.bwNode('abrirPasta', { caminho: 'C:\\Windows' }));
ok(g3pasta && !g3pasta.ok && /fora do gerador/i.test(g3pasta.erro), 'abrirPasta recusa pasta fora do gerador 3D');
// a plataforma pode perguntar a PLACA DE VÍDEO ao PC (regra 129); um site de fora, não
const mq = await pg.evaluate(() => window.bwNode('maquina'));
ok(mq && mq.ok && typeof mq.valor === 'object' && 'vram' in mq.valor && 'nome' in mq.valor, 'o app responde a placa de vídeo do PC (' + JSON.stringify(mq && mq.valor) + ')');
const A2 = await import('./atualizar.mjs');
const { VERSAO: V_HOJE } = await import('./app.mjs');
ok(!A2.novidades(V_HOJE, { marcar: false }), 'o tutorial só aparece quando o BW reabre na versão nova');
const nv = A2.novidades('9.9', { marcar: false });
ok(nv && nv.novidades.length === 2 && nv.de === V_HOJE, 'o que mudou fica guardado para a 1ª abertura da versão nova');
writeFileSync(join(T, '.bw-reels', 'novidades-pendentes.json'), JSON.stringify({ versao: '1.8', de: '1.5', novidades: VERSAO_SIM.novidades }));
VERSAO_SIM = null;
await pg.goto(pathToFileURL(join(N.RAIZ, 'app', 'index.html')).href + '?r=' + Date.now() + '#pc'); await pg.waitForSelector('.fer'); await pg.waitForSelector('[data-nv]', { timeout: 8000 }).catch(() => {});
ok(/O que mudou no BW 1\.8/.test(await pg.locator('#folha').innerText()), 'depois de atualizar: tela O QUE MUDOU com cada novidade');
await pg.click('[data-nv="fotos"]'); await pg.waitForURL(/fotos\.html/, { timeout: 8000 }).catch(() => {});
ok(/fotos\.html/.test(pg.url()), 'cada novidade abre a ferramenta que mudou');
ok(!existsSync(join(T, '.bw-reels', 'novidades-pendentes.json')), 'o tutorial aparece uma vez só');
// pacote adulterado: recusa e não mexe em nada
VERSAO_SIM = { versao: '9.9', pacote: 'downloads/BW-atualizacao.zip', sha256: 'a'.repeat(64), novidades: [] };
writeFileSync(join(velho, 'motor', 'app.mjs'), '// velho');
let erroSha = ''; try { await A2.atualizar({ site: SITE, versao: '1.4', raiz: velho }); } catch (e) { erroSha = e.message; }
ok(/não confere/.test(erroSha) && readFileSync(join(velho, 'motor', 'app.mjs'), 'utf8') === '// velho', 'arquivo que não confere (sha256) é recusado e nada muda');
VERSAO_SIM = { versao: '9.9', pacote: 'https://fora.exemplo.com/x.zip', sha256: shaAtu, novidades: [] };
let erroFora = ''; try { await A2.atualizar({ site: SITE, versao: '1.4', raiz: velho }); } catch (e) { erroFora = e.message; }
ok(/fora do site/.test(erroFora), 'pacote fora do site da Brightway é recusado');
VERSAO_SIM = null;
await pg.goto(pathToFileURL(join(N.RAIZ, 'app', 'index.html')).href + '?r=' + Date.now() + '#pc'); await pg.waitForSelector('.fer');

console.log('\nGERADOR 3D: PYTHON E GIT QUE FALTAM');
/* 20/11: no PC do dono faltavam os dois e o botão ficava apagado sem caminho de saída */
process.env.BW3D_SIMULADO = '1'; process.env.BW3D_SIM_FALTA = '1';
await pg.goto(pathToFileURL(join(N.RAIZ, 'app', 'gerador3d.html')).href);
await pg.waitForSelector('#cBasicos:visible', { timeout: 8000 }).catch(() => {});
ok(await pg.locator('#cBasicos').isVisible(), 'faltando Python e Git, o cartão FALTA INSTALAR aparece na tela');
ok(/Python/.test(await pg.locator('#basNomes').innerText()) && /Git/.test(await pg.locator('#basNomes').innerText()),
  'diz quais são os dois que faltam');
ok(/python|Add to PATH/i.test(await pg.locator('#req').innerText()), 'a ficha da máquina explica o que falta');
await pg.check('#aceito');
ok(await pg.locator('#btInstalar').isDisabled(), 'o INSTALAR O GERADOR continua apagado enquanto falta algo');
await pg.click('#btBasicos');
await pg.waitForFunction(() => document.getElementById('cBasicos').style.display === 'none', null, { timeout: 15000 }).catch(() => {});
ok(!(await pg.locator('#cBasicos').isVisible()), 'depois de instalar os dois, o cartão some');
ok(await pg.locator('#btInstalar').isEnabled(), 'e o INSTALAR O GERADOR 3D acende');
delete process.env.BW3D_SIM_FALTA;
await pg.goto(pathToFileURL(join(N.RAIZ, 'app', 'gerador3d.html')).href); await pg.waitForSelector('#cLic');
ok(!(await pg.locator('#cBasicos').isVisible()), 'máquina completa: o cartão nem aparece');
process.env.BW3D_SIM_PY = '3.15';
await pg.goto(pathToFileURL(join(N.RAIZ, 'app', 'gerador3d.html')).href); await pg.waitForSelector('#cBasicos:visible', { timeout: 8000 }).catch(() => {});
ok(await pg.locator('#cBasicos').isVisible() && /novo demais/i.test(await pg.locator('#req').innerText()),
  'Python novo demais (3.15): avisa na ficha e oferece instalar o certo');
delete process.env.BW3D_SIM_PY; delete process.env.BW3D_SIMULADO;
await pg.goto(pathToFileURL(join(N.RAIZ, 'app', 'index.html')).href + '?r=' + Date.now() + '#pc'); await pg.waitForSelector('.fer');

console.log('\nSEM INTERNET');
await pg.goto(pathToFileURL(join(N.RAIZ, 'app', 'index.html')).href + '?r=' + Date.now() + '#pc'); await pg.waitForSelector('#btOff');
ok(/prepare uma vez|Pronto para usar/.test(await pg.locator('#offBox').innerText()), 'a tela inicial mostra a situação do uso sem internet');
await new Promise((ok2) => { site.close(ok2); site.closeAllConnections(); });
await pg.click('[data-f="reels"]'); await pg.waitForURL(/reels\.html/);
ok((await pg.title()) === 'reels' && (await pg.locator('#btQuadro').count()) === 1, 'servidor da plataforma DESLIGADO: o editor abre pela cópia guardada');
await pg.click('#bwAppInicio'); await noInicio(); await pg.waitForSelector('.fer');
await pg.click('[data-f="fotos"]'); await pg.waitForURL(/fotos\.html/);
ok((await pg.title()) === 'fotos da copia', 'ferramenta nunca aberta antes abre pela cópia que veio no instalador');
await pg.click('#bwAppInicio'); await noInicio(); await pg.waitForSelector('.fer');
await pg.click('[data-f="pdf"]'); await pg.waitForTimeout(1500);
ok(!/pdf/i.test(await pg.title().catch(() => '')), 'página que não está em nenhuma cópia não abre (sem inventar conteúdo)');
await pg.goto(pathToFileURL(join(N.RAIZ, 'app', 'index.html')).href + '?r=' + Date.now() + '#pc'); await pg.waitForSelector('.fer');
console.log('\nSAIR E VALIDADE');
await pg.waitForSelector('#btSair:not([hidden])');
pg.once('dialog', (d) => d.accept());
await pg.click('#btSair'); await pg.waitForSelector('#btEntrar', { timeout: 15000 });
ok(!existsSync(join(T, '.bw-reels', 'licenca.json')), 'SAIR apaga a conta deste PC');
await pg.goto(SITE + '/index.html');
ok(!(await pg.evaluate(() => localStorage.getItem('logado'))), 'SAIR também sai da plataforma');
conta.registrar({ id: 'u-123', email: 'dono@exemplo.com' });
const arq = join(T, '.bw-reels', 'licenca.json'); const l2 = JSON.parse(readFileSync(arq, 'utf8')); l2.validade = new Date(Date.now() - 1000).toISOString(); writeFileSync(arq, JSON.stringify(l2));
ok(!conta.estado().liberado && /venceu/.test(conta.estado().aviso), 'conferência vencida (mais de 7 dias) pede login de novo');
ok(erros.length === 0, 'sem erros de JavaScript nas telas' + (erros.length ? ': ' + erros.join(' | ') : ''));

await contexto.close(); fora.close();
if (!process.env.BWREELS_GUARDAR) rmSync(T, { recursive: true, force: true });
for (const p of readdirSync(join(N.RAIZ, 'projetos'))) if (/^meu-reel-\d{8}-\d{6}$/.test(p) || p === 'clipes-ia') rmSync(join(N.RAIZ, 'projetos', p), { recursive: true, force: true });
console.log(falhas.length ? `\n${falhas.length} FALHA(S)\n` : '\nTudo certo.\n');
process.exit(falhas.length ? 1 : 0);
