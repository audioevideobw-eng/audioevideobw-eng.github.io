/* CONVERSÃO DE TAKES DO IPHONE NO PC (28/11/2026, dono: "faça para takes de vídeo realizados de iPhone, todos os formatos").
   A página da plataforma (editor de vídeo, Telas, Álbum 3D) manda o take em pedaços para este PC, o FFmpeg do computador
   transforma em MP4 H.264 + AAC (NVIDIA quando há, senão o processador) e a página traz de volta. Nada sai do computador:
   os arquivos ficam na pasta temporária do sistema (bw-conversao) e são apagados no fim.
   Formatos: HEVC/H.265, HDR (HLG e Dolby Vision — vira SDR com mapa de tons), 4K 60p, câmera lenta, modo Cinema, vídeo
   espacial (MV-HEVC: fica o olho principal), ProRes 422/HQ/4444 e ProRes Log (fica plano: a cor se acerta na COR AVANÇADA). */
import { spawn, spawnSync } from 'node:child_process';
import { mkdirSync, appendFileSync, statSync, openSync, readSync, closeSync, rmSync, existsSync, writeFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { randomBytes } from 'node:crypto';

export const PASTA = process.env.BW_CONV_PASTA || join(tmpdir(), 'bw-conversao');
const FF = process.env.BW_FFMPEG || 'ffmpeg', FP = process.env.BW_FFPROBE || 'ffprobe';
const LIMITE = 12 * 1024 ** 3;   // até 12 GB por take (ProRes 4K de 2 min)
const TRAB = new Map();
let CAP = null;

function roda(cmd, args) { try { const r = spawnSync(cmd, args, { encoding: 'utf8', timeout: 15000, windowsHide: true, maxBuffer: 16 << 20 }); return r.status === 0 ? String(r.stdout || '') : ''; } catch (e) { return ''; } }
export function pode() {
  if (CAP) return CAP;
  const v = roda(FF, ['-hide_banner', '-version']); if (!v) return (CAP = { ffmpeg: false, motivo: 'FFmpeg não encontrado neste PC' });
  const enc = roda(FF, ['-hide_banner', '-encoders']), fil = roda(FF, ['-hide_banner', '-filters']);
  let nvenc = /h264_nvenc/.test(enc);
  if (nvenc) {   // a placa existe de verdade? (o FFmpeg lista o NVENC mesmo sem NVIDIA)
    const t = spawnSync(FF, ['-hide_banner', '-loglevel', 'error', '-f', 'lavfi', '-i', 'color=black:s=256x256:d=0.1', '-c:v', 'h264_nvenc', '-f', 'null', '-'], { timeout: 15000, windowsHide: true });
    nvenc = t.status === 0;
  }
  return (CAP = { ffmpeg: true, versao: (v.split('\n')[0] || '').replace(/ Copyright.*/, ''), nvenc, tonemap: /\bzscale\b/.test(fil) && /\btonemap\b/.test(fil) });
}

function idOk(id) { if (!/^[a-f0-9]{16}$/.test(String(id || '')) || !TRAB.has(id)) throw new Error('conversão desconhecida'); return TRAB.get(id); }
export function ini({ nome, bytes }) {
  if (!pode().ffmpeg) throw new Error('FFmpeg não encontrado neste PC');
  const n = Number(bytes) || 0; if (n <= 0 || n > LIMITE) throw new Error('take grande demais (até 12 GB)');
  mkdirSync(PASTA, { recursive: true });
  const id = randomBytes(8).toString('hex'), ext = /\.mp4$|\.m4v$/i.test(String(nome || '')) ? '.mp4' : '.mov';
  const t = { id, ent: join(PASTA, id + ext), sai: join(PASTA, id + '-bw.mp4'), esperado: n, recebido: 0, nome: String(nome || 'take').slice(0, 80) };
  writeFileSync(t.ent, Buffer.alloc(0)); TRAB.set(id, t); return { id };
}
export function pedaco({ id, b64 }) {
  const t = idOk(id), buf = Buffer.from(String(b64 || ''), 'base64');
  if (t.recebido + buf.length > t.esperado) throw new Error('pedaço a mais');
  appendFileSync(t.ent, buf); t.recebido += buf.length; return { recebido: t.recebido };
}
export function sonda(arq) {
  const j = roda(FP, ['-v', 'error', '-print_format', 'json', '-show_streams', '-show_format', arq]); let o = {}; try { o = JSON.parse(j || '{}'); } catch (e) { }
  const v = (o.streams || []).find((s) => s.codec_type === 'video'), a = (o.streams || []).find((s) => s.codec_type === 'audio');
  if (!v) return null;
  let rot = 0; (v.side_data_list || []).forEach((s) => { if (s.rotation != null) rot = Number(s.rotation); }); if (v.tags && v.tags.rotate) rot = -Number(v.tags.rotate);
  const [fn, fd] = String(v.avg_frame_rate || '30/1').split('/').map(Number), fps = fd ? fn / fd : 30;
  return { codec: v.codec_name, w: v.width, h: v.height, rot: ((rot % 360) + 360) % 360, fps, trc: v.color_transfer || '', prim: v.color_primaries || '', dur: Number((o.format || {}).duration || v.duration || 0), som: !!a, pix: v.pix_fmt || '' };
}
function argsVideo(s, curto, cap) {
  const f = [];
  const hdr = /arib-std-b67|smpte2084/.test(s.trc);
  if (hdr && cap.tonemap) f.push('zscale=t=linear:npl=203', 'format=gbrpf32le', 'zscale=p=bt709', 'tonemap=tonemap=hable:desat=0', 'zscale=t=bt709:m=bt709:r=tv');
  // o lado menor não passa de "curto" (o giro do vertical o FFmpeg já aplica antes deste filtro)
  f.push(`scale=w='if(lte(iw,ih),min(iw,${curto}),-2)':h='if(lte(iw,ih),-2,min(ih,${curto}))'`, 'format=yuv420p');
  return { vf: f.join(','), hdr };
}
export async function fazer({ id, curto }, aviso = () => {}) {
  const t = idOk(id); if (t.recebido !== t.esperado) throw new Error('o take não chegou inteiro');
  const cap = pode(), s = sonda(t.ent); if (!s) throw new Error('o FFmpeg não achou vídeo neste arquivo');
  const c = Math.max(240, Math.min(4320, Number(curto) || 2160)), { vf, hdr } = argsVideo(s, c, cap), g = String(Math.max(1, Math.round(Math.min(s.fps, 60))));
  const base = ['-hide_banner', '-y', '-nostats', '-loglevel', 'error', '-progress', 'pipe:1', '-i', t.ent, '-map', '0:v:0', '-map', '0:a:0?', '-vf', vf, '-fps_mode', 'passthrough'];
  const cor = hdr ? ['-color_primaries', 'bt709', '-color_trc', 'bt709', '-colorspace', 'bt709'] : [];
  const fimA = ['-g', g, ...cor, '-c:a', 'aac', '-b:a', '192k', '-ac', '2', '-movflags', '+faststart', t.sai];
  const modos = [];
  if (cap.nvenc) modos.push({ placa: 'NVIDIA', a: ['-c:v', 'h264_nvenc', '-preset', 'p5', '-rc', 'vbr', '-cq', '19', '-b:v', '0', '-profile:v', 'high'] });
  modos.push({ placa: 'processador', a: ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', '-profile:v', 'high'] });
  let ultimo = '';
  for (const m of modos) {
    const r = await new Promise((ok) => {
      const p = spawn(FF, [...base, ...m.a, ...fimA], { windowsHide: true }); let err = '', buf = '', t0 = Date.now();
      p.stdout.on('data', (d) => { buf += d; const k = buf.lastIndexOf('out_time_us='); if (k < 0) return; const us = Number(/out_time_us=(\d+)/.exec(buf.slice(k)) ? RegExp.$1 : 0); buf = buf.slice(-200);
        const pct = s.dur ? Math.min(99, us / 1e6 / s.dur * 100) : 0, gasto = (Date.now() - t0) / 1000; aviso({ id, pct, placa: m.placa, falta: pct > 2 ? gasto * (100 - pct) / pct : null }); });
      p.stderr.on('data', (d) => { err = (err + d).slice(-3000); });
      p.on('close', (code) => ok({ code, err })); p.on('error', (e) => ok({ code: -1, err: e.message }));
    });
    if (r.code === 0 && existsSync(t.sai) && statSync(t.sai).size > 0) {
      const o = sonda(t.sai) || {}; t.bytes = statSync(t.sai).size;
      return { bytes: t.bytes, w: o.w, h: o.h, placa: m.placa, comSom: !!o.som, hdr, de: s.codec };
    }
    ultimo = r.err.trim().split('\n').slice(-2).join(' ');
  }
  throw new Error('o FFmpeg não converteu: ' + (ultimo || 'erro desconhecido'));
}
export function ler({ id, de, ate }) {
  const t = idOk(id); if (!t.bytes) throw new Error('a conversão ainda não terminou');
  const a = Math.max(0, Number(de) || 0), b = Math.min(t.bytes, Number(ate) || 0); if (b <= a) return '';
  const buf = Buffer.alloc(b - a), fd = openSync(t.sai, 'r'); try { readSync(fd, buf, 0, b - a, a); } finally { closeSync(fd); }
  return buf.toString('base64');
}
export function fim({ id }) { const t = TRAB.get(String(id || '')); if (!t) return true; TRAB.delete(t.id); for (const f of [t.ent, t.sai]) try { rmSync(f, { force: true }); } catch (e) { } return true; }
