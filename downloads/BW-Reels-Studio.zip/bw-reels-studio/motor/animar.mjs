#!/usr/bin/env node
// Renderiza QUALQUER animação em HTML (personagem, motion livre, logo animado) para vídeo.
// Uso: node motor/animar.mjs <arquivo.html> [--saida clip.mp4] [--rascunho] [--alfa] [--folha] [--checar]
//
// Contrato do HTML (o mesmo do motor nativo):
//   window.__DUR = segundos            (duração)
//   window.__W / window.__H            (opcional, padrão 1080x1920)
//   window.__FPS                       (opcional, padrão 30)
//   window.__seek(t)                   desenha o quadro do tempo t — SÓ depende de t (nada de Math.random sem semente)
//   window.__pronto                    (opcional) Promise resolvida quando fontes/imagens carregaram
//
// --alfa     fundo transparente → .mov ProRes 4444 (para sobrepor no CapCut/Premiere/DaVinci). O HTML não pinta fundo.
// --folha    só gera a folha de contato (12 quadros) para revisar sem gastar tokens assistindo.
// --escala 0.333 / --fps 24   tamanho e quadros por segundo (miniaturas e exemplos)
// --checar   confere se a animação é determinística (mesmo t = mesma imagem) e se não há erro de JavaScript.

import { existsSync, mkdirSync, writeFileSync } from 'node:fs';
import { resolve, dirname, basename, join } from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { createHash } from 'node:crypto';

const args = process.argv.slice(2);
const opt = (n, d) => { const i = args.indexOf(`--${n}`); return i >= 0 ? args[i + 1] : d; };
const flag = (n) => args.includes(`--${n}`);
const arq = resolve(args.find((a) => a.endsWith('.html')) || '');
if (!existsSync(arq)) { console.error('Informe o arquivo .html da animação'); process.exit(1); }
const rascunho = flag('rascunho'), alfa = flag('alfa');
const nome = basename(arq, '.html');
const pasta = join(dirname(arq), 'render');
mkdirSync(pasta, { recursive: true });

let chromium;
try { ({ chromium } = await import('playwright')); } catch { ({ chromium } = await import('playwright-core')); }

const erros = [];
const browser = await chromium.launch({ args: ['--allow-file-access-from-files', '--disable-web-security', '--autoplay-policy=no-user-gesture-required'] });
const ctx0 = await browser.newPage();
await ctx0.goto('file://' + arq);
const meta = await ctx0.evaluate(async () => { if (window.__pronto) await window.__pronto;
  return { dur: window.__DUR, w: window.__W || 1080, h: window.__H || 1920, fps: window.__FPS || 30, seek: typeof window.__seek }; });
await ctx0.close();
if (meta.seek !== 'function' || !(meta.dur > 0)) { console.error('O HTML precisa definir window.__DUR e window.__seek(t).'); process.exit(1); }

const escala = Number(opt('escala', rascunho ? 0.5 : 1));
const fps = Number(opt('fps', rascunho ? Math.min(meta.fps, 24) : meta.fps));
const page = await browser.newPage({ viewport: { width: meta.w, height: meta.h }, deviceScaleFactor: escala });
page.on('pageerror', (e) => erros.push(e.message));
page.on('console', (m) => { if (m.type() === 'error' && !/Failed to load resource|Refused to apply style|net::ERR/.test(m.text())) erros.push(m.text()); }); // falta de internet (fontes) não é erro da animação
await page.goto('file://' + arq);
await page.evaluate(async () => { if (window.__pronto) await window.__pronto; });
const quadro = async (t, png = false) => { await page.evaluate((x) => window.__seek(x), t);
  return page.screenshot(png || alfa ? { type: 'png', omitBackground: alfa } : { type: 'jpeg', quality: rascunho ? 80 : 95 }); };

if (flag('checar')) {
  const ts = [0, meta.dur * 0.37, meta.dur * 0.81, meta.dur - 1 / fps];
  const h = async (t) => createHash('md5').update(await quadro(t, true)).digest('hex');
  for (const t of ts) await quadro(t, true); // aquece fontes/emoji carregadas na 1ª vez
  const a = []; for (const t of ts) a.push(await h(t));
  const b = []; for (const t of [...ts].reverse()) b.push(await h(t)); b.reverse();
  const ok = a.every((x, i) => x === b[i]);
  console.log(ok ? '✓ determinística (mesmo tempo = mesma imagem, em qualquer ordem)' : '✗ NÃO determinística: há aleatório sem semente ou estado entre quadros');
  console.log(erros.length ? '✗ erros de JavaScript:\n  ' + erros.join('\n  ') : '✓ sem erros de JavaScript');
  await browser.close(); process.exit(ok && !erros.length ? 0 : 1);
}

if (flag('folha')) {
  const n = 12, dir = join(pasta, '_folha'); mkdirSync(dir, { recursive: true });
  for (let i = 0; i < n; i++) writeFileSync(join(dir, `${String(i).padStart(2, '0')}.png`), await quadro((meta.dur * (i + 0.5)) / n, true));
  const saidaF = join(pasta, `${nome}-folha.jpg`);
  spawnSync('ffmpeg', ['-y', '-hide_banner', '-loglevel', 'error', '-i', join(dir, '%02d.png'), '-vf',
    `scale=270:-1,drawtext=text='%{n}':x=8:y=8:fontsize=22:fontcolor=white:box=1:boxcolor=black@0.6,tile=6x2:padding=6:color=0x111111`, '-frames:v', '1', saidaF], { stdio: 'inherit' });
  console.log('Folha de contato: ' + saidaF + ' (quadro i = tempo ' + (meta.dur / n).toFixed(2) + 's × (i+0,5))');
  await browser.close(); process.exit(0);
}

const total = Math.ceil(meta.dur * fps);
const saida = resolve(opt('saida', join(pasta, `${nome}${rascunho ? '-rascunho' : ''}${alfa ? '.mov' : '.mp4'}`)));
const codec = alfa
  ? ['-c:v', 'prores_ks', '-profile:v', '4444', '-pix_fmt', 'yuva444p10le']
  : ['-c:v', 'libx264', '-preset', 'veryfast', '-crf', opt('crf', rascunho ? '26' : '17'), '-pix_fmt', 'yuv420p', '-movflags', '+faststart'];
const enc = spawn('ffmpeg', ['-y', '-hide_banner', '-loglevel', 'error', '-f', 'image2pipe', '-c:v', alfa ? 'png' : 'mjpeg',
  '-framerate', String(fps), '-i', '-', ...codec, '-r', String(fps), saida], { stdio: ['pipe', 'inherit', 'inherit'] });
const t0 = Date.now();
for (let f = 0; f < total; f++) {
  const buf = await quadro(f / fps);
  if (!enc.stdin.write(buf)) await new Promise((r) => enc.stdin.once('drain', r));
  if (f % fps === 0) process.stdout.write(`\r  quadro ${f}/${total}`);
}
enc.stdin.end();
await new Promise((r) => enc.on('close', r));
await browser.close();
console.log(`\r  ${total} quadros em ${((Date.now() - t0) / 1000).toFixed(1)}s → ${saida}`);
if (erros.length) console.log('  ⚠ erros de JavaScript durante o render:\n  ' + erros.join('\n  '));
