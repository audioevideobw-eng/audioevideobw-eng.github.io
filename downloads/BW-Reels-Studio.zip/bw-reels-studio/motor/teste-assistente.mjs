// Teste do BW Reels Assistente: janela escondida, Claude e IAs da internet SIMULADOS. Uso: node motor/teste-assistente.mjs [--render]
import { mkdtempSync, writeFileSync, chmodSync, existsSync, readFileSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import http from 'node:http';
const T = mkdtempSync(join(tmpdir(), 'bwteste-'));
const ROTEIRO = { cenas: [{ tipo: 'gancho', duracao: 3, texto: 'Sua live cai por 3 motivos', enfase: ['live'], chamada: '**Dica**' }, { tipo: 'dado', duracao: 3, valor: 87, rotulo: 'inventado' },
  { tipo: 'checklist', duracao: 5, titulo: 'Antes de entrar no ar', itens: ['Internet testada', 'Áudio no mixer', 'Plano B'] }, { tipo: 'texto', duracao: 3.5, titulo: 'Teste um dia antes', subtitulo: 'Evita susto na hora' }], legenda: 'Salva! #eventos' };
const GANCHOS = { ganchos: [{ texto: 'Sua live cai por 3 motivos', nota: 9, porque: 'Lista curta' }, { texto: 'Ninguém testa a internet antes', nota: 8, porque: 'Dor real' }] };
const responde = (prompt) => { const r = /Crie 5 ganchos/.test(prompt) ? GANCHOS : JSON.parse(JSON.stringify(ROTEIRO)); const g = prompt.match(/Gancho escolhido.*: (.+)/); if (g && r.cenas) r.cenas[0].texto = g[1].trim(); return 'Aqui:\n```json\n' + JSON.stringify(r) + '\n```'; };
writeFileSync(join(T, 'claude'), `#!/usr/bin/env node
if (process.argv.includes('--version')) { console.log('9.9.9 (simulado)'); process.exit(0); }
if (require('fs').existsSync(${JSON.stringify(join(T, 'claude-fora'))})) { console.error('Please run /login'); process.exit(1); }
let s=''; process.stdin.on('data',d=>s+=d); process.stdin.on('end',()=>{ require('fs').appendFileSync(${JSON.stringify(join(T, 'chamadas'))}, 'claude:'+process.argv[process.argv.indexOf('--model')+1]+'\\n');
 const responde=${responde.toString()}; const ROTEIRO=${JSON.stringify(ROTEIRO)}, GANCHOS=${JSON.stringify(GANCHOS)};
 console.log(JSON.stringify({type:'result',is_error:false,result:responde(s)})); });`);
chmodSync(join(T, 'claude'), 0o755);
const chamadas = [];
const srv = http.createServer((req, res) => {
  let corpo = ''; req.on('data', (d) => { corpo += d; }); req.on('end', () => {
    const [, id, ...resto] = req.url.split('/'); const rota = resto.join('/'); const chave = (req.headers.authorization || '').replace('Bearer ', '');
    const manda = (st, o) => { res.writeHead(st, { 'Content-Type': 'application/json' }); res.end(JSON.stringify(o)); };
    if (id === 'local') return manda(500, {});
    if (chave === 'chave-errada') return manda(401, { error: 'invalid key' });
    if (rota === 'models') return manda(200, { data: id === 'groq' ? [{ id: 'whisper-large-v3' }, { id: 'llama-3.3-70b-versatile' }, { id: 'openai/gpt-oss-120b' }] : [{ id: 'models/gemini-embedding-001' }, { id: 'models/gemini-flash-latest' }] });
    chamadas.push(id); if (id === 'groq') return manda(429, { error: 'rate limit: daily quota' });
    manda(200, { choices: [{ message: { content: responde(JSON.parse(corpo).messages[0].content) } }] });
  });
});
await new Promise((r) => srv.listen(0, '127.0.0.1', r));
Object.assign(process.env, { HOME: T, USERPROFILE: T, BWREELS_TESTE: '1', BWREELS_SEM_CONTA: '1', BWREELS_NAO_ABRIR: '1', BWREELS_CLAUDE: join(T, 'claude'), BWREELS_IA_TESTE: `http://127.0.0.1:${srv.address().port}` });
const { abrirAssistente } = await import('./assistente.mjs');
const falhas = []; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) falhas.push(m); };
const { contexto, pagina: pg } = await abrirAssistente({ semJanela: true });
const erros = []; pg.on('pageerror', (e) => erros.push(e.message));
const txt = (s) => pg.locator(s).innerText();
const avancar = async () => { await pg.click('#btAvancar'); await pg.waitForTimeout(400); };
const foto = (n) => process.env.BWREELS_FOTOS && pg.screenshot({ path: join(process.env.BWREELS_FOTOS, n + '.png'), fullPage: true });
await pg.waitForSelector('.lista li');
ok((await pg.locator('.lista li').count()) === 4 && (await txt('#onde')).startsWith('Etapa 1 de'), 'checagem do PC com "Etapa 1 de N"');
await avancar();
ok((await pg.locator('.op').count()) === 4, '4 jeitos: BW IA FREE, ECONOMIZE, PRO e SEM IA');
ok(/BW IA PRO/.test(await txt('.op.sel')) && /RECOMENDADO/.test(await txt('.op.sel')), 'só IA paga conectada → recomenda BW IA PRO e explica como liberar os outros');
ok(await pg.isDisabled('[data-modo="free"]') && /Conecte pelo menos uma IA grátis/.test(await txt('[data-modo="free"]')), 'BW IA FREE desligado diz o que falta');
// ---- Minhas IAs ----
await pg.click('#btIAs'); await pg.waitForSelector('#btInstalar');
ok((await pg.locator('.lista li').count()) === 6, 'Minhas IAs lista 4 grátis (Groq, Gemini, OpenRouter, no computador) e 2 pagas');
await pg.fill('#k_groq', 'chave-errada'); await pg.click('[data-salvar="groq"]'); await pg.waitForTimeout(600);
ok(/chave não foi aceita/.test(await txt('#e_groq')), 'chave errada: aviso simples, nada salvo');
await pg.fill('#k_groq', 'gsk_teste_1234'); await pg.click('[data-salvar="groq"]'); await pg.waitForSelector('#m_groq');
ok((await pg.inputValue('#m_groq')) === 'openai/gpt-oss-120b' && !(await txt('#m_groq')).includes('whisper'), 'Groq testada; melhor modelo de texto escolhido sozinho');
await pg.fill('#k_gemini', 'AIza_teste_9876'); await pg.click('[data-salvar="gemini"]'); await pg.waitForSelector('#m_gemini');
ok(!(await pg.content()).includes('gsk_teste_1234') && /…1234/.test(await txt('#tela')), 'a chave nunca volta para a tela (só os 4 últimos)');
await pg.click('#btInstalar'); ok(/CONFIRMAR/.test(await txt('#btInstalar')), 'instalar com um botão pede confirmação antes');
await pg.click('#btInstalar'); await pg.waitForFunction(() => /Modelo Gemma 3/.test(document.querySelector('.aviso.o')?.textContent || ''), null, { timeout: 15000 });
ok(/✓ Claude Code.*✓ Ollama.*✓ Modelo Gemma 3/.test(await txt('.aviso.o')), 'instalação (simulada) percorre Claude Code, Ollama e modelo e mostra o resultado');
await foto('ias'); await avancar();
ok(/ECONOMIZE/.test(await txt('.op.sel')) && /Aberturas: Groq · Roteiro: Claude/.test(await txt('.op.sel')), 'com grátis + paga → recomenda BW IA ECONOMIZE e mostra quem faz o quê');
await foto('modos');
// ---- BW IA FREE: Groq sem cota → pula para o Gemini sozinho ----
await pg.click('[data-modo="free"]'); await avancar();
await pg.click('#btAvancar'); await pg.waitForTimeout(200);
ok(/Escreva o assunto/.test(await txt('#erroIdeia')), 'sem assunto não avança e explica');
await pg.fill('#fTema', '3 erros que derrubam a live de um evento'); await pg.fill('#fHandle', 'bwaudiovisual');
await pg.click('#btAvancar'); await pg.waitForSelector('#cenas .cena', { timeout: 20000 });
ok(chamadas.join() === 'groq,gemini' && await pg.evaluate(() => E.usadas.join() === 'Google Gemini' && /Groq: a cota de hoje acabou/.test(E.pulos.join())), 'FREE: cota da Groq acabou → passou para o Gemini sozinho');
const tipos = await pg.evaluate(() => E.roteiro.cenas.map((c) => c.tipo));
ok(tipos[0] === 'gancho' && tipos.at(-1) === 'cta' && !tipos.includes('dado'), 'roteiro com gancho e chamada; número inventado pela IA descartado');
ok(await pg.evaluate(() => E.roteiro.cenas[0].chamada === 'Dica' && E.roteiro.marca.handle === '@bwaudiovisual'), 'marcação da IA limpa e @ aplicado');
await pg.waitForFunction(() => document.querySelector('#quadro').contentWindow?.__seek, null, { timeout: 15000 });
await pg.fill('#c1itens', ''); await pg.waitForTimeout(900);
ok(/Falta ajustar/.test(await txt('#estado')) && await pg.isDisabled('#btAvancar'), 'lista vazia bloqueia com aviso simples');
await pg.fill('#c1itens', 'Internet testada\nÁudio no mixer'); await pg.waitForTimeout(900); await avancar();
ok(/1 pedido · Google Gemini/.test(await txt('table.res')), 'resumo mostra qual IA foi usada');
// ---- ECONOMIZE: aberturas na grátis, roteiro na paga ----
for (let i = 0; i < 3; i++) { await pg.click('#btVoltar'); await pg.waitForTimeout(150); }
await pg.click('[data-modo="economize"]'); await avancar();
await pg.click('#btAvancar'); await pg.waitForSelector('[data-g]', { timeout: 20000 });
await pg.click('[data-g="1"]'); await pg.click('#btAvancar'); await pg.waitForSelector('#cenas .cena', { timeout: 20000 });
ok(chamadas.join() === 'groq,gemini,gemini' && readFileSync(join(T, 'chamadas'), 'utf8').trim() === 'claude:opus', 'ECONOMIZE: aberturas no Gemini (Groq já marcada sem cota, nem tentou) e roteiro no Claude forte');
ok(await pg.evaluate(() => E.roteiro.cenas[0].texto === 'Ninguém testa a internet antes'), 'roteiro usa a abertura escolhida');
// ---- PRO com a IA paga fora do ar → mensagem + seguir sem IA ----
await pg.click('#btVoltar'); await pg.click('#btVoltar'); await pg.click('#btVoltar'); await pg.waitForTimeout(200);
await pg.click('[data-modo="pro"]'); await avancar(); writeFileSync(join(T, 'claude-fora'), '1');
await pg.click('#btAvancar'); await pg.waitForSelector('#btSemIA', { timeout: 20000 });
ok(/pediu login/.test(await txt('#erroIdeia')), 'PRO: IA fora → mensagem simples + "continuar sem IA"');
await pg.click('#btSemIA'); await pg.waitForTimeout(300);
await pg.click('[data-cat="graf"]'); await pg.click('[data-mod="graficos"]'); await avancar(); await pg.waitForSelector('#cenas .cena');
await pg.fill('#c1fonte', ''); await pg.waitForTimeout(900);
ok(/Fonte/.test(await txt('#estado')) && await pg.isDisabled('#btAvancar'), 'SEM IA: gráfico sem fonte bloqueia com aviso didático');
await pg.fill('#c1fonte', 'dados próprios'); await pg.waitForTimeout(900); await avancar();
ok((await pg.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth)) === 0, 'sem estouro horizontal');
if (process.argv.includes('--render')) {
  await pg.check('#fRasc'); await pg.click('#btAvancar'); await pg.waitForSelector('#btPasta', { timeout: 600000 });
  const v = await pg.evaluate(() => E.video.video); ok(existsSync(v), 'vídeo gerado de verdade: ' + v);
}
ok(!readFileSync(join(T, '.bw-reels', 'assistente.json'), 'utf8').includes('gsk_'), 'chaves ficam só em ias.json, fora das preferências');
ok(!erros.length, 'nenhum erro de JS ' + JSON.stringify(erros));
await contexto.close(); srv.close();
console.log('\nFALHAS: ' + falhas.length); process.exit(falhas.length ? 1 : 0);
