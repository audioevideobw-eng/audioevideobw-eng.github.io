// Teste do BW Reels Assistente (janela escondida, Claude simulado). Uso: BWREELS_CLAUDE=<falso> node motor/teste-assistente.mjs [--render]
process.env.BWREELS_TESTE = '1'; process.env.BWREELS_NAO_ABRIR = '1';
const { abrirAssistente } = await import('./assistente.mjs');
const { existsSync, readFileSync } = await import('node:fs');
const falhas = []; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) falhas.push(m); };
const { contexto, pagina: pg } = await abrirAssistente({ semJanela: true });
const erros = []; pg.on('pageerror', (e) => erros.push(e.message));
const txt = (s) => pg.locator(s).innerText();
const avancar = async () => { await pg.click('#btAvancar'); await pg.waitForTimeout(400); };
await pg.waitForSelector('.lista li');
ok((await pg.locator('.lista li').count()) === 4, 'checagem lista 4 itens do PC');
ok((await txt('#onde')).startsWith('Etapa 1 de'), 'mostra "Etapa 1 de N"');
ok(/Acesso livre/.test(await txt('#conta')), 'conta: acesso livre nesta versão (portão pronto)');
await avancar();
await pg.screenshot({ path: '/tmp/fk/modos.png' });
ok((await pg.locator('.op').count()) === 3, '3 modos: qualidade, econômico, sem IA');
ok(/ECONÔMICO/.test(await txt('.op.sel')) && /RECOMENDADO/.test(await txt('.op.sel')), 'com Claude instalado recomenda e marca ECONÔMICO');
// ---- modo econômico: 1 pedido ----
await avancar();
await pg.click('#btAvancar'); await pg.waitForTimeout(200);
ok(/Escreva o assunto/.test(await txt('#erroIdeia')), 'sem assunto não avança e explica o que falta');
await pg.fill('#fTema', '3 erros que derrubam a live de um evento'); await pg.fill('#fHandle', 'bwaudiovisual');
await pg.click('#btAvancar'); await pg.waitForSelector('#cenas .cena', { timeout: 20000 });
const tipos = await pg.evaluate(() => E.roteiro.cenas.map((c) => c.tipo));
ok(tipos[0] === 'gancho' && tipos.at(-1) === 'cta', 'roteiro da IA começa com gancho e termina com chamada (' + tipos.join(',') + ')');
ok(!tipos.includes('dado'), 'número inventado pela IA foi descartado');
ok(await pg.evaluate(() => E.roteiro.cenas[0].chamada === 'Dica' && E.roteiro.marca.handle === '@bwaudiovisual'), 'marcação da IA limpa e @ aplicado');
await pg.waitForFunction(() => document.querySelector('#quadro').contentWindow?.__seek, null, { timeout: 15000 });
await pg.waitForTimeout(2500); await pg.screenshot({ path: '/tmp/fk/roteiro.png' });
ok(/conferido/.test(await txt('#estado')), 'prévia animada carregou e roteiro conferido');
await pg.fill('#c1itens', ''); await pg.waitForTimeout(900);
ok(/Falta ajustar/.test(await txt('#estado')) && await pg.isDisabled('#btAvancar'), 'lista vazia bloqueia o avanço com aviso simples');
await pg.fill('#c1itens', 'Internet testada\nÁudio no mixer'); await pg.waitForTimeout(900);
ok(await pg.isEnabled('#btAvancar'), 'corrigido, libera de novo');
await avancar();
ok(/1 pedido ao Claude/.test(await txt('table.res')), 'resumo mostra o uso da IA (1 pedido)');
// ---- voltar e trocar para qualidade: ganchos + roteiro = 2 pedidos ----
for (let i = 0; i < 3; i++) { await pg.click('#btVoltar'); await pg.waitForTimeout(150); }
await pg.click('[data-modo="qualidade"]'); await avancar();
await pg.click('#btAvancar'); await pg.waitForSelector('[data-g]', { timeout: 20000 });
await pg.screenshot({ path: '/tmp/fk/ganchos.png' });
ok((await pg.locator('[data-g]').count()) === 3 && /RECOMENDADO/.test(await txt('.op.sel')), 'qualidade: ganchos com nota, o melhor já marcado');
await pg.click('[data-g="1"]'); await pg.click('#btAvancar'); await pg.waitForSelector('#cenas .cena', { timeout: 20000 });
ok(await pg.evaluate(() => E.roteiro.cenas[0].texto === 'Ninguém testa a internet antes'), 'roteiro usa o gancho escolhido');
const log = readFileSync('/tmp/fk/chamadas.log', 'utf8').trim().split('\n').map((l) => l.split(' ')[0]);
ok(log.join(',') === 'sonnet,sonnet,opus', 'modelos por modo: econômico=sonnet; qualidade=sonnet (ganchos) + opus (roteiro) [' + log + ']');
// ---- IA falha → oferece seguir sem IA ----
await pg.click('#btVoltar'); await pg.click('#btVoltar'); await pg.waitForTimeout(200);
await pg.evaluate(() => { E.ganchos = null; E.roteiro = null; });
process.env.FALSO_FALHA = '1';
await pg.click('#btAvancar'); await pg.waitForSelector('#btSemIA', { timeout: 20000 });
ok(/login|limite/.test(await txt('#erroIdeia')), 'falha da IA vira mensagem simples + botão "continuar sem IA"');
delete process.env.FALSO_FALHA;
await pg.click('#btSemIA'); await pg.waitForTimeout(300);
// ---- sem IA: modelo de gráfico ----
await pg.click('[data-cat="graf"]'); await pg.click('[data-mod="graficos"]'); await avancar();
await pg.waitForSelector('#cenas .cena');
ok(/@bwaudiovisual/.test(await pg.inputValue('#c3acao') + await pg.evaluate(() => JSON.stringify(E.roteiro))), 'modelo pronto já vem com o @ do usuário');
await pg.fill('#c1fonte', ''); await pg.waitForTimeout(900);
ok(/Fonte/.test(await txt('#estado')) && await pg.isDisabled('#btAvancar'), 'gráfico sem fonte bloqueia com aviso didático');
await pg.fill('#c1fonte', 'dados próprios'); await pg.waitForTimeout(900);
await avancar();
ok(/3 pedidos ao Claude/.test(await txt('table.res')) && /SEM IA/.test(await txt('table.res')), 'resumo conta os pedidos de IA realmente feitos na sessão (3)');
await pg.screenshot({ path: '/tmp/fk/resumo.png' });
ok((await pg.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth)) === 0, 'sem estouro horizontal');
if (process.argv.includes('--render')) {
  await pg.check('#fRasc'); await pg.click('#btAvancar');
  await pg.waitForSelector('#btPasta', { timeout: 600000 });
  const v = await pg.evaluate(() => E.video.video);
  ok(existsSync(v) && /rascunho/.test(v), 'vídeo gerado de verdade: ' + v);
}
ok(!erros.length, 'nenhum erro de JS ' + JSON.stringify(erros));
await contexto.close();
console.log(falhas.length ? '\nFALHAS: ' + falhas.length : '\nFALHAS: 0'); process.exit(falhas.length ? 1 : 0);
