// Dentro do app Electron (BW.exe), process.execPath é o próprio BW.exe: para rodar um script do motor (render, animar) como Node,
// o processo filho precisa de ELECTRON_RUN_AS_NODE=1. Fora do Electron (node motor/…), nada muda.
export function envNode(env = process.env) { return process.versions.electron ? { ...env, ELECTRON_RUN_AS_NODE: '1' } : env; }
