#!/usr/bin/env node
// Uso: node motor/render.mjs projetos/<slug>/roteiro.json [--motor nativo|hyperframes|remotion] [--rascunho] [--saida arquivo.mp4]
// O mesmo roteiro.json renderiza em qualquer um dos 3 motores.

import { readFileSync, writeFileSync, mkdirSync, existsSync, copyFileSync, statSync } from 'node:fs';
import { dirname, join, resolve, basename, relative } from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { criarPlano } from './plano.mjs';
import { construirHtml, css as cssDe } from './html.mjs';
import { GOOGLE_FONTS } from './estilos.mjs';
import { validarRoteiro } from './validar.mjs';
import { sintetizarSons, wavDe } from './sons.mjs';

const RAIZ = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const opt = (n, d) => { const i = args.indexOf(`--${n}`); return i >= 0 ? args[i + 1] : d; };
const flag = (n) => args.includes(`--${n}`);

const arqRoteiro = resolve(args.find((a) => a.endsWith('.json')) || '');
if (!existsSync(arqRoteiro)) { console.error('Informe o caminho do roteiro.json'); process.exit(1); }
const roteiro = JSON.parse(readFileSync(arqRoteiro, 'utf8'));
const proj = dirname(arqRoteiro);
const motor = opt('motor', roteiro.motor || 'nativo');
const rascunho = flag('rascunho');
const renderDir = join(proj, 'render');
mkdirSync(join(renderDir, 'sfx'), { recursive: true });

const avisos = [];
const erros = validarRoteiro(roteiro, proj, avisos);
avisos.forEach((a) => console.log('  ⚠ ' + a));
if (erros.length) { console.error('Roteiro com problemas:\n- ' + erros.join('\n- ')); process.exit(1); }

const plano = criarPlano(roteiro);
const saida = resolve(opt('saida', join(renderDir, `${basename(proj)}${rascunho ? '-rascunho' : ''}-${motor}.mp4`)));

function ff(argv, silencioso = true) {
  const r = spawnSync('ffmpeg', ['-y', '-hide_banner', '-loglevel', silencioso ? 'error' : 'info', ...argv], { stdio: 'inherit' });
  if (r.status !== 0) throw new Error('ffmpeg falhou: ' + argv.join(' '));
}

// ---------- SOM AUTOMÁTICO: trilha do estilo + efeitos da animação, compostos por código (motor/sons.mjs) ----------
plano.sfxArquivos = [];
{
  const s = sintetizarSons(plano, { sr: 48000 });
  if (s.trilha) { writeFileSync(join(renderDir, 'sfx', 'trilha.wav'), wavDe(s.trilha, 48000)); plano.audios.push({ papel: 'musica', src: 'render/sfx/trilha.wav', inicio: 0, volume: 1 }); }
  if (s.efeitos) { writeFileSync(join(renderDir, 'sfx', 'efeitos.wav'), wavDe(s.efeitos, 48000)); plano.sfxArquivos.push({ papel: 'sfx', src: 'render/sfx/efeitos.wav', inicio: 0, volume: 1, duracao: plano.duracao }); }
  if (s.trilha) console.log(`  ♪ trilha automática: ${plano.trilha}${s.efeitos ? ' + efeitos' : ''}`);
}

// Pré-corta e enquadra cada vídeo no trecho usado (cache). "intra" = todo quadro é keyframe -> seek instantâneo.
function prepararMidias(destino, prefixoSrc, { intra = false, copiarImagens = false } = {}) {
  mkdirSync(destino, { recursive: true });
  const busca = (ns) => ns.forEach((n) => {
    if (n.tag === 'video') {
      const dur = (n.fim - n.inicio + 0.25).toFixed(3);
      const nome = `${n.id}-${(n.inicioNoArquivo || 0).toFixed(2)}-${dur}${rascunho ? '-r' : ''}.mp4`;
      const alvo = join(destino, nome);
      if (!existsSync(alvo)) {
        const W = rascunho ? plano.largura / 2 : plano.largura, H = rascunho ? plano.altura / 2 : plano.altura;
        ff(['-ss', String(n.inicioNoArquivo || 0), '-t', dur, '-i', join(proj, n.src), '-an',
          '-vf', `scale=${W}:${H}:force_original_aspect_ratio=increase,crop=${W}:${H},fps=${plano.fps}`,
          '-c:v', 'libx264', '-preset', 'veryfast', '-crf', intra ? '18' : '16', ...(intra ? ['-g', '1'] : []), '-pix_fmt', 'yuv420p', alvo]);
      }
      n.src = `${prefixoSrc}${nome}`;
      n.inicioNoArquivo = 0;
    } else if (n.tag === 'img' && copiarImagens) {
      const nome = `${n.id}.${n.src.split('.').pop()}`;
      copyFileSync(join(proj, n.src), join(destino, nome));
      n.src = `${prefixoSrc}${nome}`;
    }
    if (n.filhos) busca(n.filhos);
  });
  busca(plano.cenas);
}

// ---------- Mixagem: música abaixa sozinha sob a narração (ducking) ----------
function mixarAudio(videoMudo, destino) {
  const faixas = [...plano.audios, ...plano.sfxArquivos];
  if (!faixas.length) { copyFileSync(videoMudo, destino); return; }
  const inputs = ['-i', videoMudo];
  faixas.forEach((f) => inputs.push('-i', join(proj, f.src)));
  const D = plano.duracao;
  const parts = [];
  const nomes = [];
  let narr = null, mus = null;
  faixas.forEach((f, k) => {
    const i = k + 1, ms = Math.round((f.inicio || 0) * 1000);
    let cad = `[${i}:a]aresample=48000,aformat=channel_layouts=stereo,volume=${f.volume ?? 1}`;
    if (f.papel === 'musica') cad += `,afade=t=in:d=0.4,afade=t=out:st=${Math.max(0, D - 1.5)}:d=1.5`;
    cad += `,adelay=${ms}|${ms},apad,atrim=0:${D}[a${i}]`;
    parts.push(cad);
    if (f.papel === 'narracao') narr = `a${i}`; else if (f.papel === 'musica') mus = `a${i}`; else nomes.push(`[a${i}]`);
  });
  if (narr && mus) {
    parts.push(`[${narr}]asplit=2[n1][n2]`, `[${mus}][n1]sidechaincompress=threshold=0.04:ratio=10:attack=15:release=350[duck]`);
    nomes.push('[duck]', '[n2]');
  } else {
    if (narr) nomes.push(`[${narr}]`);
    if (mus) nomes.push(`[${mus}]`);
  }
  parts.push(`${nomes.join('')}amix=inputs=${nomes.length}:normalize=0,alimiter=limit=0.95[aout]`);
  ff([...inputs, '-filter_complex', parts.join(';'), '-map', '0:v', '-map', '[aout]', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-shortest', '-movflags', '+faststart', destino]);
}

// ---------- Motor NATIVO: Chromium (Playwright) quadro a quadro -> FFmpeg ----------
async function renderNativo() {
  let chromium;
  try { ({ chromium } = await import('playwright')); }
  catch { ({ chromium } = await import('playwright-core')); }
  prepararMidias(join(renderDir, 'proxies'), 'render/proxies/', { intra: true });
  const html = join(proj, 'composicao.html');
  writeFileSync(html, construirHtml(plano, 'nativo'));
  const escala = rascunho ? 0.5 : 1;
  const fps = rascunho ? Math.min(plano.fps, 24) : plano.fps;
  const total = Math.ceil(plano.duracao * fps);
  const browser = await chromium.launch({ args: ['--autoplay-policy=no-user-gesture-required', '--disable-web-security', '--allow-file-access-from-files'] });
  const page = await browser.newPage({ viewport: { width: plano.largura, height: plano.altura }, deviceScaleFactor: escala });
  await page.goto('file://' + html);
  await page.evaluate(() => window.__pronto);
  const mudo = join(renderDir, '_video-mudo.mp4');
  const enc = spawn('ffmpeg', ['-y', '-hide_banner', '-loglevel', 'error', '-f', 'image2pipe', '-c:v', 'mjpeg', '-framerate', String(fps), '-i', '-',
    '-c:v', 'libx264', '-preset', 'veryfast', '-crf', rascunho ? '26' : '17', '-pix_fmt', 'yuv420p', '-r', String(fps), mudo], { stdio: ['pipe', 'inherit', 'inherit'] });
  const t0 = Date.now();
  for (let f = 0; f < total; f++) {
    await page.evaluate((t) => window.__seek(t), f / fps);
    const buf = await page.screenshot({ type: 'jpeg', quality: rascunho ? 80 : 95 });
    if (!enc.stdin.write(buf)) await new Promise((r) => enc.stdin.once('drain', r));
    if (f % fps === 0) process.stdout.write(`\r  quadro ${f}/${total}`);
  }
  enc.stdin.end();
  await new Promise((r) => enc.on('close', r));
  await browser.close();
  console.log(`\r  ${total} quadros em ${((Date.now() - t0) / 1000).toFixed(1)}s`);
  mixarAudio(mudo, saida);
}

// ---------- Motor HYPERFRAMES ----------
function renderHyperframes() {
  const dir = join(proj, 'hyperframes');
  mkdirSync(join(dir, 'midia'), { recursive: true });
  prepararMidias(join(dir, 'midia'), 'midia/', { copiarImagens: true });
  for (const a of [...plano.audios, ...plano.sfxArquivos]) {
    const destino = `midia/${basename(a.src)}`;
    copyFileSync(join(proj, a.src), join(dir, destino));
    a.src = destino;
  }
  writeFileSync(join(dir, 'index.html'), construirHtml(plano, 'hyperframes'));
  console.log(`  Composição HyperFrames em ${relative(RAIZ, dir)}/index.html`);
  // Argumentos depois de "--" vão direto para o CLI do HyperFrames
  const extra = args.includes('--') ? args.slice(args.indexOf('--') + 1) : [];
  const r = spawnSync('npx', ['--yes', 'hyperframes', 'render', ...extra],
    { cwd: dir, stdio: 'inherit', shell: process.platform === 'win32' });
  if (r.status !== 0) {
    console.error('\n  O render do HyperFrames não completou. Rode "npx hyperframes render --help" dentro da pasta acima e\n  peça ao Claude para usar a skill /hyperframes-cli. A composição já está pronta para preview: "npx hyperframes preview".');
    process.exit(1);
  }
  console.log('  Render concluído — o arquivo sai na pasta do HyperFrames (veja o log acima).');
}

// ---------- Motor REMOTION ----------
function renderRemotion() {
  const dir = join(RAIZ, 'motor', 'remotion');
  if (!existsSync(join(dir, 'node_modules'))) {
    console.log('  Instalando dependências do Remotion (1ª vez)...');
    const i = spawnSync('npm', ['install'], { cwd: dir, stdio: 'inherit', shell: process.platform === 'win32' });
    if (i.status !== 0) process.exit(1);
  }
  plano.audiosTodos = [...plano.audios, ...plano.sfxArquivos];
  plano.css = cssDe(plano);
  plano.fontesUrl = GOOGLE_FONTS;
  const props = join(renderDir, 'plano.json');
  writeFileSync(props, JSON.stringify({ plano }));
  const scale = rascunho ? ['--scale=0.5'] : [];
  const r = spawnSync('npx', ['remotion', 'render', 'src/index.js', 'Reel', saida, `--props=${props}`, `--public-dir=${proj}`, '--crf=17', ...scale],
    { cwd: dir, stdio: 'inherit', shell: process.platform === 'win32' });
  if (r.status !== 0) process.exit(1);
}

console.log(`▶ ${plano.titulo} — ${plano.duracao}s, ${plano.largura}x${plano.altura}, motor: ${motor}${rascunho ? ' (rascunho)' : ''}`);
if (motor === 'nativo') await renderNativo();
else if (motor === 'hyperframes') renderHyperframes();
else if (motor === 'remotion') renderRemotion();
else { console.error('motor desconhecido: ' + motor); process.exit(1); }
if (existsSync(saida)) console.log(`✔ ${relative(process.cwd(), saida)} (${(statSync(saida).size / 1e6).toFixed(1)} MB)`);
