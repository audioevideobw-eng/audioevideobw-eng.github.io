#!/usr/bin/env node
// BW REELS — o aplicativo: uma janela própria com login da conta Brightway e todas as ferramentas juntas
// (editor BW Reels Pro, Quadro de História, Assistente passo a passo, legendas offline, Minhas IAs, meus vídeos).
// Sem servidor local: as telas falam com este programa pela ponte do navegador, e só as telas do aplicativo
// e a plataforma Brightway podem usá-la (qualquer outro site é recusado).
// Uso: node motor/app.mjs [--assistente]     (teste: BWREELS_TESTE=1 e import { abrirApp })
import { join, resolve, basename, dirname, sep } from 'node:path';
import { pathToFileURL, fileURLToPath } from 'node:url';
import { mkdirSync, existsSync, readdirSync, statSync, readFileSync } from 'node:fs';
import { spawn, spawnSync } from 'node:child_process';
import { homedir } from 'node:os';
import * as N from './assistente-nucleo.mjs';
import { ACOES as ACOES_ASSISTENTE } from './assistente.mjs';
import { instalarRecomendadas } from './instalar-ias.mjs';
import * as V from './video-ia.mjs';
import * as O from './offline.mjs';

export const VERSAO = '1.0';
export const SITE = (process.env.BWREELS_SITE_TESTE || 'https://audioevideobw-eng.github.io').replace(/\/$/, '');
const WIN = process.platform === 'win32';
const URL_INICIO = pathToFileURL(join(N.RAIZ, 'app', 'index.html')).href;
const URL_ASSISTENTE = pathToFileURL(join(N.RAIZ, 'assistente', 'index.html')).href;
const PROJETOS = join(N.RAIZ, 'projetos');
const DESTINOS = { reels: '/reels.html', quadro: '/reels.html', plataforma: '/index.html', login: '/login.html', fotos: '/fotos.html', pdf: '/pdf.html',
  criador: '/criador.html', orcamentos: '/propostas.html', leitor: '/leitor.html' };
const LIVRES = new Set(['conta', 'entrar', 'inicio', 'fechar', 'info']);          // funcionam sem login
const DO_SITE = new Set(['inicio', 'info', 'videoIA', 'videoGerar']);                                         // o que a página da plataforma pode pedir

const daPlataforma = (url) => url === SITE || url.startsWith(SITE + '/');
const doApp = (url) => url.startsWith(pathToFileURL(N.RAIZ).href + '/');

/* ---------- conta: a própria página da plataforma confere no servidor e devolve só id/e-mail/nome ---------- */
async function contaNaPagina(pg, esperaMs = 9000) {
  try {
    return await pg.evaluate(async (ms) => {
      const fim = Date.now() + ms;
      while (Date.now() < fim) {
        try {
          if (window.BWSync && window.BWSync.cliente) {
            const r = await window.BWSync.cliente().auth.getUser();
            const u = r && r.data && r.data.user;
            if (u) return { id: u.id, email: u.email, nome: (u.user_metadata && (u.user_metadata.full_name || u.user_metadata.name)) || '' };
          }
        } catch (e) { /* tenta de novo */ }
        await new Promise((ok) => setTimeout(ok, 400));
      }
      return null;
    }, esperaMs);
  } catch { return null; }
}

/* ---------- arquivos ---------- */
function meusVideos() {
  const lista = [];
  const anda = (pasta, nivel) => {
    let nomes = []; try { nomes = readdirSync(pasta); } catch { return; }
    for (const n of nomes) {
      if (n === 'node_modules' || n.startsWith('.')) continue;
      const c = join(pasta, n); let s; try { s = statSync(c); } catch { continue; }
      if (s.isDirectory()) { if (nivel < 3) anda(c, nivel + 1); }
      else if (/\.mp4$/i.test(n) && !n.startsWith('_') && !/rascunho|quadros|tmp/i.test(c.slice(PROJETOS.length))) lista.push({ arquivo: c, nome: n, projeto: c.slice(PROJETOS.length + 1).split(sep)[0], quando: s.mtimeMs, mb: +(s.size / 1048576).toFixed(1) });
    }
  };
  anda(PROJETOS, 0);
  return lista.sort((a, b) => b.quando - a.quando).slice(0, 30);
}
function dentroDeProjetos(c) { const r = resolve(String(c || '')); return r.startsWith(PROJETOS + sep) && existsSync(r); }
function abrirArquivo(arquivo) {
  if (process.env.BWREELS_NAO_ABRIR) return true;
  if (WIN) spawn('cmd', ['/c', 'start', '""', `"${arquivo}"`], { shell: true, detached: true, stdio: 'ignore' }).unref();
  else spawn(process.platform === 'darwin' ? 'open' : 'xdg-open', [arquivo], { detached: true, stdio: 'ignore' }).on('error', () => {}).unref();
  return true;
}
function escolherArquivo() {
  if (process.env.BWREELS_ARQUIVO_TESTE) return process.env.BWREELS_ARQUIVO_TESTE;
  if (!WIN) throw new Error('Neste sistema, arraste o vídeo para cima do LEGENDAR (a escolha por janela é só no Windows).');
  const ps = "Add-Type -AssemblyName System.Windows.Forms; $f = New-Object System.Windows.Forms.Form; $f.TopMost = $true; $d = New-Object System.Windows.Forms.OpenFileDialog; $d.Title = 'BW Reels - escolha o video ou audio'; $d.Filter = 'Video ou audio|*.mp4;*.mov;*.mkv;*.webm;*.avi;*.mp3;*.wav;*.m4a;*.aac|Todos os arquivos|*.*'; [Console]::OutputEncoding = [Text.Encoding]::UTF8; if ($d.ShowDialog($f) -eq 'OK') { Write-Output $d.FileName }";
  const r = spawnSync('powershell', ['-NoProfile', '-STA', '-ExecutionPolicy', 'Bypass', '-Command', ps], { encoding: 'utf8', windowsHide: true });
  return (r.stdout || '').trim() || null;
}
function descompactar(zip, destino) {
  mkdirSync(destino, { recursive: true });
  for (const [cmd, a] of [['tar', ['-xf', zip, '-C', destino]], ['python3', ['-m', 'zipfile', '-e', zip, destino]], ['python', ['-m', 'zipfile', '-e', zip, destino]], ['unzip', ['-o', '-q', zip, '-d', destino]]]) {
    const r = spawnSync(cmd, a, { stdio: 'ignore' });
    if (r.status === 0 && existsSync(join(destino, 'roteiro.json'))) return true;
  }
  return false;
}
function livre(pasta, nome) {
  let alvo = join(pasta, nome), i = 1; const p = nome.lastIndexOf('.');
  while (existsSync(alvo)) alvo = join(pasta, (p > 0 ? nome.slice(0, p) : nome) + ` (${i++})` + (p > 0 ? nome.slice(p) : ''));
  return alvo;
}

/* ---------- script que entra nas páginas da janela (botão de voltar e avisos) ---------- */
function naPagina(cfg) {
  const noApp = location.protocol === 'file:' && location.href.indexOf(cfg.raiz) === 0;
  const noSite = location.origin === cfg.site || location.href.indexOf(cfg.site + '/') === 0;
  if (!noApp && !noSite) return;
  window.BW_APP = { versao: cfg.versao };
  const pronto = (f) => (document.readyState === 'loading' ? document.addEventListener('DOMContentLoaded', f) : f());
  window.__bwAviso = function (texto, pct, fechar) {
    pronto(function () {
      let c = document.getElementById('bwAppAviso');
      if (!texto) { if (c) c.remove(); return; }
      if (!c) { c = document.createElement('div'); c.id = 'bwAppAviso'; c.style.cssText = 'position:fixed;left:50%;bottom:24px;transform:translateX(-50%);z-index:2147483646;background:#141821;color:#eef0f5;border:1px solid #f5b544;border-radius:14px;padding:14px 18px;font:15px/1.4 "Segoe UI",system-ui,sans-serif;box-shadow:0 12px 40px rgba(0,0,0,.6);min-width:300px;max-width:min(560px,92vw)'; document.body.appendChild(c); }
      c.textContent = '';
      const t = document.createElement('div'); t.id = 'bwAppAvisoTexto'; t.textContent = texto; c.appendChild(t);
      if (typeof pct === 'number') { const b = document.createElement('div'); b.style.cssText = 'height:10px;border-radius:5px;background:#262c3a;margin-top:10px;overflow:hidden'; const i = document.createElement('i'); i.style.cssText = 'display:block;height:100%;background:#f5b544;width:' + Math.max(0, Math.min(100, pct)) + '%'; b.appendChild(i); c.appendChild(b); }
      if (fechar) { const x = document.createElement('button'); x.type = 'button'; x.textContent = 'OK'; x.style.cssText = 'margin-top:10px;background:#f5b544;color:#201400;border:0;border-radius:8px;padding:6px 18px;font-weight:700;cursor:pointer'; x.onclick = function () { c.remove(); }; c.appendChild(x); }
    });
  };
  if (noApp && /\/app\/index\.html$/.test(location.pathname)) return;
  pronto(function () {
    if (document.getElementById('bwAppInicio')) return;
    const b = document.createElement('button'); b.id = 'bwAppInicio'; b.type = 'button'; b.textContent = '⌂ BW REELS'; b.title = 'Voltar para o início do aplicativo';
    b.style.cssText = 'position:fixed;z-index:2147483645;' + (noSite ? 'left:12px;bottom:12px;' : 'left:50%;top:10px;transform:translateX(-50%);') + 'background:#f5b544;color:#201400;border:0;border-radius:99px;padding:8px 16px;font:700 13px "Segoe UI",system-ui,sans-serif;letter-spacing:.06em;cursor:pointer;box-shadow:0 6px 20px rgba(0,0,0,.45)';
    b.onclick = function () { if (window.bwNode) window.bwNode('inicio'); };
    document.body.appendChild(b);
  });
}

export async function abrirApp({ semJanela = false, inicio = URL_INICIO } = {}) {
  let chromium;
  try { ({ chromium } = await import('playwright')); } catch { ({ chromium } = await import('playwright-core')); }
  // Navegador do próprio Windows primeiro (Edge/Chrome tocam MP4 e aceitam login do Google); senão, o do motor.
  const canais = semJanela ? [null] : ['msedge', 'chrome', null];
  let contexto = null, canal = null, erro = null;
  for (const c of canais) {
    const perfil = join(N.conta.PASTA, 'app-' + (c || 'motor')); mkdirSync(perfil, { recursive: true });
    try {
      contexto = await chromium.launchPersistentContext(perfil, { headless: semJanela, acceptDownloads: true, serviceWorkers: 'block', ...(c ? { channel: c } : {}),
        viewport: semJanela ? { width: 1200, height: 820 } : null,
        ...(semJanela ? {} : { args: [`--app=${inicio}`, '--window-size=1280,860'], ignoreDefaultArgs: ['--enable-automation'] }) });
      canal = c || 'motor'; break;
    } catch (e) { erro = e; }
  }
  if (!contexto) throw erro || new Error('nenhum navegador disponível');

  const pastaCopia = process.env.BWREELS_COPIA_TESTE || O.abrirCopia(N.RAIZ);
  const rede = await O.ligar(contexto, SITE, pastaCopia);
  let principal = null, querEntrar = false, abrirQuadro = false, saindo = false;
  const avisar = (pg, texto, pct, fechar) => pg.evaluate(([t, p, f]) => window.__bwAviso && window.__bwAviso(t, p, f), [texto, pct ?? null, !!fechar]).catch(() => {});
  const irPara = (pg, url) => pg.goto(url).catch(() => {});

  const ACOES = {
    info: () => ({ versao: VERSAO, navegador: canal }),
    conta: () => N.conta.estado(),
    entrar: async (d, pg) => { querEntrar = true; await irPara(pg, SITE + DESTINOS.login); return true; },
    sair: async (d, pg) => {
      saindo = true;
      try {
        await irPara(pg, SITE + DESTINOS.login);
        await pg.evaluate(async () => { for (let i = 0; i < 20 && !(window.BWSync && window.BWSync.cliente); i++) await new Promise((ok) => setTimeout(ok, 250)); try { await window.BWSync.cliente().auth.signOut(); } catch (e) { /* já estava fora */ } }).catch(() => {});
        N.conta.sair();
        await irPara(pg, URL_INICIO);
      } finally { saindo = false; }
      return true;
    },
    inicio: async (d, pg) => { await irPara(pg, URL_INICIO); return true; },
    abrir: async (d, pg) => {
      if (d.destino === 'assistente' || d.destino === 'ias') { await irPara(pg, URL_ASSISTENTE + (d.destino === 'ias' ? '#ias' : '')); return true; }
      if (!DESTINOS[d.destino]) throw new Error('destino desconhecido');
      abrirQuadro = d.destino === 'quadro';
      await irPara(pg, SITE + DESTINOS[d.destino]); return true;
    },
    videos: () => meusVideos(),
    abrirVideo: (d) => { if (!dentroDeProjetos(d.arquivo)) throw new Error('arquivo fora da pasta de projetos'); return abrirArquivo(resolve(d.arquivo)); },
    abrirPastaVideo: (d) => { if (!dentroDeProjetos(d.arquivo)) throw new Error('arquivo fora da pasta de projetos'); return N.abrirPasta(dirname(resolve(d.arquivo))); },
    pastaProjetos: () => N.abrirPasta(PROJETOS),
    legendasEstado: async () => (await import('./transcrever.mjs')).estado(),
    legendasInstalar: async (d, pg) => { const { instalarLegendas } = await import('./instalar-legendas.mjs'); return instalarLegendas((m) => { pg.evaluate((x) => window.bwLegenda && window.bwLegenda(x), String(m)).catch(() => {}); }); },
    legendar: async (d, pg) => {
      const arq = escolherArquivo(); if (!arq) return { cancelado: true };
      const { legendarArquivo } = await import('./legendar.mjs');
      const r = await legendarArquivo(arq, { aviso: (m) => { pg.evaluate((x) => window.bwLegenda && window.bwLegenda(x), String(m)).catch(() => {}); } });
      return { arquivo: arq, srt: r.srt, texto: String(r.texto || '').slice(0, 4000), palavras: (r.palavras || []).length };
    },
    abrirLegenda: (d) => { const a = resolve(String(d.arquivo || '')); if (!/\.srt$/i.test(a) || !existsSync(a)) throw new Error('legenda não encontrada'); return N.abrirPasta(dirname(a)); },
    offline: () => ({ ...O.situacao(pastaCopia), rede }),
    offlinePreparar: async (d, pg) => O.preparar(SITE, pastaCopia, (p) => { pg.evaluate((x) => window.bwOffline && window.bwOffline(x), p).catch(() => {}); }),
    // conectores de IA de vídeo (a chave é do usuário e fica só neste PC; a tela nunca recebe a chave de volta)
    videoIA: () => V.status(),
    videoConectar: (d) => V.conectar(d.id, d.chave),
    videoDesconectar: (d) => V.desconectar(d.id),
    videoPadrao: (d) => V.escolherPadrao(d.modelo),
    videoSite: (d) => { const p = V.PROVEDORES[d.id]; if (!p) throw new Error('IA desconhecida'); return abrirArquivo(p.site); },
    videoGerar: async (d, pg) => {
      const r = await V.gerar({ modelo: d.modelo, prompt: d.prompt, imagem: d.imagem, seg: d.seg, destino: join(PROJETOS, 'clipes-ia') }, (p) => { avisar(pg, `${p.etapa}… ${p.pct}%`, p.pct); });
      avisar(pg, '');
      return { nome: basename(r.arquivo), seg: r.seg, modelo: r.modelo, usd: r.usd, mime: 'video/mp4', base64: readFileSync(r.arquivo).toString('base64') };
    },
    // ações do assistente passo a passo (as mesmas da janela antiga)
    render: async (d, pg) => N.renderizar(d.arquivo, { rascunho: !!d.rascunho }, (p) => { pg.evaluate((x) => window.bwProgresso && window.bwProgresso(x), p).catch(() => {}); }),
    instalarIAs: async (d, pg) => instalarRecomendadas((p) => { pg.evaluate((x) => window.bwInstalando && window.bwInstalando(x), p).catch(() => {}); }),
    fechar: async () => { setTimeout(() => contexto.close().catch(() => {}), 200); return true; },
  };

  await contexto.exposeBinding('bwNode', async (origem, acao, dados) => {
    try {
      const pg = origem.page, url = origem.frame.url();
      if (origem.frame !== pg.mainFrame()) throw new Error('pedido recusado');
      const site = daPlataforma(url), app = doApp(url);
      if (!app && !(site && DO_SITE.has(acao))) throw new Error('pedido recusado: só as telas do BW Reels usam esta ponte');
      if (!LIVRES.has(acao) && !N.conta.estado().liberado) throw new Error('Entre com a sua conta Brightway para usar.');
      const f = ACOES[acao] || ACOES_ASSISTENTE[acao];
      if (!f) throw new Error('ação desconhecida: ' + acao);
      return { ok: true, valor: await f(dados || {}, pg) };
    } catch (e) { return { ok: false, erro: e.message || String(e) }; }
  });
  await contexto.addInitScript(naPagina, { site: SITE, raiz: pathToFileURL(N.RAIZ).href + '/', versao: VERSAO });

  async function aoBaixar(pg, d) {
    const nome = d.suggestedFilename() || 'arquivo';
    try {
      if (/\.bwreels\.zip$/i.test(nome)) {
        if (!N.conta.estado().liberado) { await d.cancel().catch(() => {}); return avisar(pg, 'Entre com a sua conta para renderizar.', null, true); }
        const dt = new Date(), z = (n) => String(n).padStart(2, '0');
        const base = nome.replace(/\.bwreels\.zip$/i, '').replace(/[^a-zA-Z0-9-]+/g, '-').slice(0, 40) || 'reel';
        const destino = join(PROJETOS, `${base}-${dt.getFullYear()}${z(dt.getMonth() + 1)}${z(dt.getDate())}-${z(dt.getHours())}${z(dt.getMinutes())}${z(dt.getSeconds())}`);
        mkdirSync(destino, { recursive: true });
        await avisar(pg, 'Recebendo o pedido de vídeo…', 2);
        const zip = join(destino, 'pedido.bwreels.zip'); await d.saveAs(zip);
        if (!descompactar(zip, destino)) return avisar(pg, 'Não consegui abrir o pacote do vídeo. Toque em RENDERIZAR NO PC de novo.', null, true);
        const r = await N.renderizar(join(destino, 'roteiro.json'), {}, (p) => avisar(pg, `${p.etapa}… ${p.pct}%`, p.pct));
        abrirArquivo(r.video);
        return avisar(pg, '✓ Vídeo pronto: ' + basename(r.video) + ' — está em MEUS VÍDEOS, no início do aplicativo.', null, true);
      }
      const pasta = [join(homedir(), 'Downloads'), homedir()].find((p) => existsSync(p));
      const alvo = livre(pasta, nome.replace(/[\\/:*?"<>|]+/g, '-'));
      await d.saveAs(alvo);
      return avisar(pg, '✓ Salvo em Downloads: ' + basename(alvo), null, true);
    } catch (e) { return avisar(pg, 'Não deu certo: ' + (e.message || e), null, true); }
  }

  async function aoCarregar(pg) {
    const url = pg.url();
    if (!daPlataforma(url) || saindo) return;
    const u = await contaNaPagina(pg, querEntrar ? 9000 : 4000);
    if (u) {
      N.conta.registrar(u);
      if (querEntrar) { querEntrar = false; return irPara(pg, URL_INICIO); }
    }
    if (abrirQuadro && /\/reels\.html/.test(url)) {
      abrirQuadro = false;
      await pg.waitForSelector('#btQuadro', { timeout: 15000 }).catch(() => {});
      await pg.waitForTimeout(900);
      await pg.evaluate(() => { const b = document.getElementById('btQuadro'); if (b) b.click(); }).catch(() => {});
    }
  }
  const ligar = (pg) => { pg.on('download', (d) => aoBaixar(pg, d)); pg.on('load', () => aoCarregar(pg).catch(() => {})); };
  contexto.pages().forEach(ligar); contexto.on('page', ligar);

  principal = contexto.pages()[0] || await contexto.newPage();
  if (semJanela || principal.url() !== inicio) await principal.goto(inicio);
  return { contexto, pagina: principal, canal };
}

const DIRETO = process.argv[1] && resolve(process.argv[1]) === resolve(fileURLToPath(import.meta.url));
if (DIRETO && !process.env.BWREELS_TESTE) {
  try {
    const noAssistente = process.argv.includes('--assistente') && N.conta.estado().liberado;
    const { contexto } = await abrirApp(noAssistente ? { inicio: URL_ASSISTENTE } : {});
    contexto.on('close', () => process.exit(0));
  } catch (e) {
    console.error('\n  Não consegui abrir a janela do BW Reels: ' + e.message);
    console.error('  Rode o INSTALAR.bat de novo (ele instala o navegador do motor) e tente outra vez.\n');
    process.exit(1);
  }
}
