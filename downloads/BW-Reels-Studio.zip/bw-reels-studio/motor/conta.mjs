// Conta Brightway no aplicativo BW Reels.
// O login acontece NA JANELA do aplicativo, na própria página de login da plataforma (a senha nunca passa por este programa).
// Depois de entrar, a página confere a conta no servidor e o aplicativo guarda só: id, e-mail, nome e a validade (7 dias) —
// assim as ferramentas offline continuam abrindo sem internet. Nenhuma senha ou chave de acesso é gravada no disco.
// Obs.: esta trava é do aplicativo (programa aberto, no PC do usuário). O que protege de verdade os dados e a IA da
// plataforma é o servidor, que já exige a conta em cada pedido.
import { readFileSync, writeFileSync, existsSync, mkdirSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';

export const EXIGIR_CONTA = process.env.BWREELS_SEM_CONTA !== '1';
export const DIAS_OFFLINE = 7;
export const PASTA = join(homedir(), '.bw-reels');
const ARQ = join(PASTA, 'licenca.json');

function ler() { try { return JSON.parse(readFileSync(ARQ, 'utf8')); } catch { return null; } }

export function estado() {
  const lic = ler();
  if (!EXIGIR_CONTA) return { exigir: false, liberado: true, nome: lic?.nome || '', email: lic?.email || '', aviso: 'Acesso livre (modo de teste)' };
  const valida = !!(lic && lic.id && lic.validade && new Date(lic.validade) > new Date());
  const dias = valida ? Math.max(0, Math.ceil((new Date(lic.validade) - new Date()) / 864e5)) : 0;
  return { exigir: true, liberado: valida, nome: lic?.nome || '', email: lic?.email || '', dias,
    aviso: valida ? 'Conta ativa' : lic?.id ? 'A conferência da conta venceu — entre de novo' : 'Entre com a sua conta Brightway' };
}

/** Guarda a conta conferida pela página da plataforma (chamado só pelo aplicativo, com dados vindos do servidor). */
export function registrar(u) {
  if (!u || !u.id || !u.email) return estado();
  mkdirSync(PASTA, { recursive: true });
  const nome = String(u.nome || '').trim() || String(u.email).split('@')[0];
  writeFileSync(ARQ, JSON.stringify({ id: String(u.id), email: String(u.email), nome, conferido: new Date().toISOString(),
    validade: new Date(Date.now() + DIAS_OFFLINE * 864e5).toISOString() }, null, 2));
  return estado();
}

export async function ativar() { return estado(); }   // compatibilidade com o assistente antigo
export function sair() { if (existsSync(ARQ)) rmSync(ARQ, { force: true }); return estado(); }
