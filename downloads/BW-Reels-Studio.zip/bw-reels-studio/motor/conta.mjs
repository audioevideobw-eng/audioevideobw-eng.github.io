// Conta Brightway no BW Reels Assistente.
// Hoje: acesso livre (EXIGIR_CONTA = false). Quando a plataforma passar a exigir cadastro,
// basta ligar EXIGIR_CONTA e implementar verificarNoServidor() — o resto do assistente já pergunta por aqui.
//
// Como vai funcionar (regra do site: nada de servidor local, a ponte é um ARQUIVO):
//   1. No site, logado: BW Reels Pro › ⚙ MOTOR NO PC › ATIVAR NESTE PC → baixa "bw-reels-ativacao.json"
//      (código de ativação emitido por uma Edge Function do Supabase; nunca a senha, nunca a chave secreta).
//   2. O assistente acha esse arquivo em Downloads, confere o código no servidor e guarda a licença em ~/.bw-reels/licenca.json.
//   3. A cada abertura confere a validade; sem licença válida mostra a tela "Ative sua conta".
import { readFileSync, writeFileSync, existsSync, mkdirSync, readdirSync, rmSync } from 'node:fs';
import { join } from 'node:path';
import { homedir } from 'node:os';

export const EXIGIR_CONTA = false;
export const PASTA = join(homedir(), '.bw-reels');
const ARQ = join(PASTA, 'licenca.json');
const NOME_ATIVACAO = /^bw-reels-ativacao.*\.json$/i;

function ler() { try { return JSON.parse(readFileSync(ARQ, 'utf8')); } catch { return null; } }

// Ponto único de verificação no servidor. Enquanto EXIGIR_CONTA for false, não é chamado.
async function verificarNoServidor(/* codigo */) {
  throw new Error('verificação de conta ainda não ligada nesta versão');
}

export function estado() {
  const lic = ler();
  if (!EXIGIR_CONTA) return { exigir: false, liberado: true, nome: lic?.nome || '', aviso: 'Acesso livre nesta versão' };
  const valida = !!(lic && lic.validade && new Date(lic.validade) > new Date());
  return { exigir: true, liberado: valida, nome: lic?.nome || '', aviso: valida ? 'Conta ativa' : 'Ative sua conta Brightway para usar' };
}

// Procura o arquivo de ativação baixado do site e troca por uma licença.
export async function ativar(pastaDownloads = join(homedir(), 'Downloads')) {
  if (!EXIGIR_CONTA) return estado();
  let arq = null;
  try { arq = readdirSync(pastaDownloads).filter((n) => NOME_ATIVACAO.test(n)).sort().pop(); } catch { /* sem pasta */ }
  if (!arq) return { ...estado(), erro: 'Não achei o arquivo de ativação em Downloads. No site: BW Reels Pro › ⚙ MOTOR NO PC › ATIVAR NESTE PC.' };
  try {
    const dados = JSON.parse(readFileSync(join(pastaDownloads, arq), 'utf8'));
    const lic = await verificarNoServidor(dados.codigo);
    mkdirSync(PASTA, { recursive: true });
    writeFileSync(ARQ, JSON.stringify(lic, null, 2));
    rmSync(join(pastaDownloads, arq), { force: true });
    return estado();
  } catch (e) { return { ...estado(), erro: 'Não consegui ativar: ' + e.message }; }
}

export function sair() { if (existsSync(ARQ)) rmSync(ARQ, { force: true }); return estado(); }
