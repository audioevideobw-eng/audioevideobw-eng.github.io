// Som automático do motor (sem direito autoral): TRILHA de fundo composta por código para cada estilo e EFEITOS
// que acompanham a animação (balão, fala, pulo, confete, lista, contador, botão, transições).
// Funções puras, determinísticas (mesmo plano = mesmo som), sem dependências: rodam no Node (render) e no navegador (prévia).

const TAU = Math.PI * 2;
const mtof = (m) => 440 * Math.pow(2, (m - 69) / 12);

// Progressões (MIDI) e instrumentos por estilo. Cada acorde dura 2 compassos (8 tempos).
export const TRILHAS = {
  cinema:      { nome: 'Cinema (épica suave)', bpm: 84,  acordes: [[57, 60, 64], [53, 57, 60], [48, 52, 55], [55, 59, 62]], pad: 1, baixo: 'pulso', bumbo: [0], chimbal: false, palma: false, arpejo: false, sino: false },
  corporativo: { nome: 'Corporativa (leve e confiante)', bpm: 112, acordes: [[60, 64, 67], [55, 59, 62], [57, 60, 64], [53, 57, 60]], pad: 0.6, baixo: 'tempo', bumbo: [0, 2], chimbal: true, palma: true, arpejo: 8, sino: false },
  neon:        { nome: 'Neon (eletrônica)', bpm: 124, acordes: [[57, 60, 64], [53, 57, 60], [48, 52, 55], [55, 59, 62]], pad: 0.7, baixo: 'contra', bumbo: [0, 1, 2, 3], chimbal: true, palma: true, arpejo: 16, sino: false },
  editorial:   { nome: 'Editorial (lo-fi)', bpm: 88,  acordes: [[62, 65, 69, 72], [55, 59, 62, 65], [60, 64, 67, 71], [57, 60, 64, 67]], pad: 0.5, baixo: 'tempo', bumbo: [0, 2.5], chimbal: true, palma: true, arpejo: false, sino: true },
  luxo:        { nome: 'Luxo (piano e cordas)', bpm: 72,  acordes: [[60, 64, 67, 71], [53, 57, 60, 64], [57, 60, 64, 67], [55, 59, 62, 64]], pad: 0.8, baixo: 'pulso', bumbo: false, chimbal: false, palma: false, arpejo: false, sino: true },
};

function rng(seed) { let s = seed >>> 0 || 1; return () => { s = (s * 1664525 + 1013904223) >>> 0; return s / 4294967296; }; }

/** Trilha de fundo do estilo `nome`, `dur` segundos. Devolve {L, R}. */
export function sintetizarTrilha(nome, dur, sr = 44100) {
  const T = TRILHAS[nome] || TRILHAS.cinema;
  const N = Math.ceil(dur * sr), L = new Float32Array(N), R = new Float32Array(N);
  const tempo = 60 / T.bpm, acordeDur = tempo * 8;
  const rnd = rng(7 + T.bpm);
  const acordeEm = (t) => T.acordes[Math.floor(t / acordeDur) % T.acordes.length];
  // PAD: dente-de-serra suave (4 harmônicos) levemente desafinado entre L e R, com filtro passa-baixa
  if (T.pad) {
    let yl = 0, yr = 0; const a = 1 - Math.exp(-TAU * 1300 / sr);
    for (let i = 0; i < N; i++) {
      const t = i / sr, ci = Math.floor(t / acordeDur), tc = t - ci * acordeDur, ac = acordeEm(t);
      const env = Math.min(1, tc / 0.7) * (tc > acordeDur - 0.35 ? Math.max(0, (acordeDur - tc) / 0.35) : 1);
      let sl = 0, sr2 = 0;
      for (const m of ac) {
        const f = mtof(m);
        for (let k = 1; k <= 4; k++) { sl += Math.sin(TAU * f * k * t) / k; sr2 += Math.sin(TAU * f * 1.0025 * k * t) / k; }
      }
      yl += a * (sl - yl); yr += a * (sr2 - yr);
      L[i] += yl * env * 0.045 * T.pad; R[i] += yr * env * 0.045 * T.pad;
    }
  }
  const nota = (t0, d, gera) => { const i0 = Math.floor(t0 * sr), n = Math.min(N - i0, Math.floor(d * sr)); for (let j = 0; j < n; j++) { const v = gera(j / sr); L[i0 + j] += v[0]; R[i0 + j] += v[1]; } };
  const batidas = Math.ceil(dur / tempo);
  for (let b = 0; b < batidas; b++) {
    const t0 = b * tempo, compasso = b % 4, ac = acordeEm(t0 + 0.01), raiz = mtof(ac[0] - 24);
    // BAIXO
    const tocaBaixo = T.baixo === 'tempo' || (T.baixo === 'pulso' && compasso % 2 === 0) || T.baixo === 'contra';
    if (tocaBaixo) {
      const tb = T.baixo === 'contra' ? t0 + tempo / 2 : t0, db = T.baixo === 'pulso' ? tempo * 2 : tempo * 0.9;
      let ph = 0; nota(tb, db, (t) => { ph += TAU * raiz / sr; const v = (Math.sin(ph) + 0.35 * Math.sin(2 * ph)) * Math.exp(-t * (T.baixo === 'pulso' ? 1.6 : 4)) * 0.2; return [v, v]; });
    }
    // BUMBO
    if (T.bumbo) for (const p of T.bumbo) if (Math.floor(p) === compasso) {
      let ph = 0; nota(t0 + (p - Math.floor(p)) * tempo, 0.4, (t) => { ph += TAU * (45 + 80 * Math.exp(-t * 32)) / sr; const v = Math.sin(ph) * Math.exp(-t * 7.5) * 0.5; return [v, v]; });
    }
    // CHIMBAL (contratempo) e PALMA (2 e 4)
    if (T.chimbal) { let p0 = 0; nota(t0 + tempo / 2, 0.07, (t) => { const n = rnd() * 2 - 1, v = (n - p0) * Math.exp(-t * 70) * 0.05; p0 = n; return [v * 0.8, v]; }); }
    if (T.palma && (compasso === 1 || compasso === 3)) nota(t0, 0.25, (t) => { const v = ((rnd() * 2 - 1) * Math.exp(-t * 22) * 0.16 + Math.sin(TAU * 190 * t) * Math.exp(-t * 25) * 0.08); return [v, v]; });
    // ARPEJO (notas do acorde, uma oitava acima)
    if (T.arpejo) {
      const passos = T.arpejo / 4, dp = tempo / passos;
      for (let s = 0; s < passos; s++) {
        const m = ac[(b * passos + s) % ac.length] + 12, f = mtof(m), pan = ((b * passos + s) % 3 - 1) * 0.35;
        nota(t0 + s * dp, dp * 1.6, (t) => { const v = (Math.sin(TAU * f * t) + Math.sin(TAU * 3 * f * t) / 9) * Math.exp(-t * 9) * 0.05; return [v * (1 - pan), v * (1 + pan)]; });
      }
    }
    // SINO / TECLADO (a cada 2 tempos, notas do acorde espalhadas)
    if (T.sino && b % 2 === 0) ac.forEach((m, k) => {
      const f = mtof(m + 12), atraso = k * 0.07 + (rnd() * 0.02);
      nota(t0 + atraso, tempo * 2.2, (t) => { const v = (Math.sin(TAU * f * t + 0.8 * Math.sin(TAU * f * 2.01 * t) * Math.exp(-t * 3))) * Math.exp(-t * 2.4) * 0.05; return [v * (1 - k * 0.12), v * (0.7 + k * 0.12)]; });
    });
  }
  // entrada e saída suaves + saturação leve (sem estourar)
  for (let i = 0; i < N; i++) {
    const t = i / sr, g = Math.min(1, t / 0.8) * Math.min(1, (dur - t) / 1.6);
    L[i] = Math.tanh(L[i] * 1.6 * g) * 0.7; R[i] = Math.tanh(R[i] * 1.6 * g) * 0.7;
  }
  return { L, R };
}

/** Efeitos sonoros a partir de plano.sfx ({tipo, inicio, fim?, dur?, voz?}). Devolve {L, R}. */
export function sintetizarEfeitos(eventos, dur, sr = 44100) {
  const N = Math.ceil(dur * sr) + sr, L = new Float32Array(N), R = new Float32Array(N);
  const rnd = rng(99);
  const som = (t0, d, gera, pan = 0) => { const i0 = Math.max(0, Math.floor(t0 * sr)), n = Math.min(N - i0, Math.floor(d * sr)); for (let j = 0; j < n; j++) { const v = gera(j / sr); L[i0 + j] += v * (1 - pan); R[i0 + j] += v * (1 + pan); } };
  const sino = (t0, f, amp, decai = 5) => som(t0, 1.2, (t) => Math.sin(TAU * f * t + 0.6 * Math.sin(TAU * f * 2.76 * t) * Math.exp(-t * 6)) * Math.exp(-t * decai) * amp);
  for (const e of eventos || []) {
    const t0 = e.inicio || 0;
    if (e.tipo === 'whoosh') { let y = 0; som(t0, 0.55, (t) => { const fc = 300 + 3800 * (t / 0.55), a = 1 - Math.exp(-TAU * fc / sr); y += a * ((rnd() * 2 - 1) - y); return y * Math.sin(Math.PI * t / 0.55) * 0.26; }); }
    else if (e.tipo === 'impacto') { let ph = 0; som(t0, 1.2, (t) => { ph += TAU * (30 + 45 * Math.exp(-t * 6)) / sr; return Math.sin(ph) * Math.exp(-t * 3.2) * 0.5 + (rnd() * 2 - 1) * Math.exp(-t * 28) * 0.1; }); }
    else if (e.tipo === 'pop') { let ph = 0; som(t0, 0.1, (t) => { ph += TAU * (480 + 700 * (t / 0.1)) / sr; return Math.sin(ph) * Math.exp(-t * 38) * 0.32; }); }
    else if (e.tipo === 'fala') {
      const base = e.voz || 420, fim = e.fim || t0 + 1;
      for (let t = t0, k = 0; t < fim - 0.05; t += 0.105 + rnd() * 0.03, k++) {
        const f = base * (0.85 + rnd() * 0.35);
        som(t, 0.06, (x) => (Math.sin(TAU * f * x) + 0.3 * Math.sin(TAU * 3 * f * x)) * Math.sin(Math.PI * x / 0.06) * 0.075, (k % 2 ? 0.1 : -0.1));
      }
    }
    else if (e.tipo === 'boing') { let ph = 0; som(t0, 0.5, (t) => { ph += TAU * (150 + 230 * (1 - Math.exp(-t * 7)) + 30 * Math.sin(TAU * 13 * t) * Math.exp(-t * 4)) / sr; return Math.sin(ph) * Math.exp(-t * 5) * 0.3; }); }
    else if (e.tipo === 'confete') { for (let k = 0; k < 14; k++) sino(t0 + rnd() * 0.7, 1700 + rnd() * 1700, 0.05, 14); som(t0, 0.5, (t) => (rnd() * 2 - 1) * Math.exp(-t * 9) * 0.05); }
    else if (e.tipo === 'susto') { let ph = 0; som(t0, 0.38, (t) => { ph += TAU * (320 + 900 * (t / 0.38) ** 1.5) / sr; return Math.sin(ph) * Math.sin(Math.PI * t / 0.38) * 0.22; }); }
    else if (e.tipo === 'clique') som(t0, 0.04, (t) => ((rnd() * 2 - 1) * 0.5 + Math.sin(TAU * 2100 * t)) * Math.exp(-t * 160) * 0.28);
    else if (e.tipo === 'contador') {
      const d = e.dur || 1.2; let t = 0;
      while (t < d) { som(t0 + t, 0.03, (x) => Math.sin(TAU * 1650 * x) * Math.exp(-x * 120) * 0.13); t += 0.045 + 0.2 * (t / d) ** 2; }
      sino(t0 + d, 1320, 0.14); sino(t0 + d + 0.07, 1760, 0.1);
    }
    else if (e.tipo === 'brilho') { sino(t0, 1318.5, 0.13, 4); sino(t0 + 0.09, 1975.5, 0.1, 4); }
  }
  return { L, R };
}

/** Trilha + efeitos do plano (o que o render e a prévia tocam). opcoes: {sr} */
export function sintetizarSons(plano, opcoes = {}) {
  const sr = opcoes.sr || 44100, dur = Math.max(0.5, plano.duracao);
  const nomeTrilha = plano.trilha && plano.trilha !== 'nenhuma' ? plano.trilha : null;
  const trilha = nomeTrilha ? sintetizarTrilha(nomeTrilha, dur, sr) : null;
  if (trilha) { const v = plano.volumeTrilha ?? 0.5; for (let i = 0; i < trilha.L.length; i++) { trilha.L[i] *= v; trilha.R[i] *= v; } }
  const efeitos = plano.sfx && plano.sfx.length ? sintetizarEfeitos(plano.sfx, dur, sr) : null;
  if (efeitos) { const N = Math.ceil(dur * sr); efeitos.L = efeitos.L.subarray(0, N); efeitos.R = efeitos.R.subarray(0, N); }
  return { sr, trilha, efeitos };
}

/** Junta faixas {L,R} (mesma taxa) somando e limitando. */
export function misturar(...faixas) {
  const fs = faixas.filter(Boolean); if (!fs.length) return null;
  const N = Math.max(...fs.map((f) => f.L.length)), L = new Float32Array(N), R = new Float32Array(N);
  for (const f of fs) for (let i = 0; i < f.L.length; i++) { L[i] += f.L[i]; R[i] += f.R[i]; }
  for (let i = 0; i < N; i++) { L[i] = Math.max(-1, Math.min(1, L[i])); R[i] = Math.max(-1, Math.min(1, R[i])); }
  return { L, R };
}

/** WAV estéreo 16 bits (Uint8Array) a partir de {L, R}. */
export function wavDe(f, sr = 44100) {
  const N = f.L.length, buf = new ArrayBuffer(44 + N * 4), v = new DataView(buf);
  const txt = (o, s) => { for (let i = 0; i < s.length; i++) v.setUint8(o + i, s.charCodeAt(i)); };
  txt(0, 'RIFF'); v.setUint32(4, 36 + N * 4, true); txt(8, 'WAVE'); txt(12, 'fmt '); v.setUint32(16, 16, true);
  v.setUint16(20, 1, true); v.setUint16(22, 2, true); v.setUint32(24, sr, true); v.setUint32(28, sr * 4, true); v.setUint16(32, 4, true); v.setUint16(34, 16, true);
  txt(36, 'data'); v.setUint32(40, N * 4, true);
  for (let i = 0, o = 44; i < N; i++, o += 4) { v.setInt16(o, Math.max(-1, Math.min(1, f.L[i])) * 32767, true); v.setInt16(o + 2, Math.max(-1, Math.min(1, f.R[i])) * 32767, true); }
  return new Uint8Array(buf);
}
