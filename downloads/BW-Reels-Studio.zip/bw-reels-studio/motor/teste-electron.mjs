// Teste do app BW como PROGRAMA (Electron): plataforma SIMULADA, janela de verdade (Xvfb no Linux) dirigida pelo Playwright _electron.
// Confere: abre as telas do app; ponte bwNode com o mesmo filtro (app tudo, plataforma só DO_SITE, site de fora nada); login registra a conta;
// render .bwreels.zip e Estúdio de motion pelo download (este roda o motor como Node via ELECTRON_RUN_AS_NODE); download comum vai para Downloads;
// sem internet a cópia do disco entra; sw.js recusado; placa de alto desempenho pedida; user agent sem "Electron"; nome "BW".
// Uso: node motor/teste-electron.mjs   (precisa do pacote electron em node_modules)
import { mkdtempSync, writeFileSync, existsSync, readFileSync, mkdirSync, readdirSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { createRequire } from 'node:module';
import http from 'node:http';

const RAIZ = join(dirname(fileURLToPath(import.meta.url)), '..');
const T = mkdtempSync(join(tmpdir(), 'bwele-'));
const falhas = []; const ok = (c, m) => { console.log((c ? '  ✓ ' : '  ✗ ') + m); if (!c) falhas.push(m); };
let _electron; try { ({ _electron } = await import('playwright')); } catch { ({ _electron } = await import('playwright-core')); }
const ELECTRON = createRequire(join(RAIZ, 'package.json'))('electron');

const pac = join(T, 'pac'); mkdirSync(pac);
writeFileSync(join(pac, 'roteiro.json'), JSON.stringify({ titulo: 'Teste electron', formato: '9:16', fps: 30, motor: 'nativo', estilo: 'cinema', marca: { handle: 'TESTE' },
  cenas: [{ tipo: 'gancho', duracao: 1.2, texto: 'Teste do programa' }, { tipo: 'cta', duracao: 1.2, texto: 'Fim', acao: '@teste' }] }));
const zip = join(T, 'pedido.bwreels.zip');
spawnSync('python3', ['-c', `import zipfile,sys; z=zipfile.ZipFile(sys.argv[1],'w'); z.write(sys.argv[2],'roteiro.json'); z.close()`, zip, join(pac, 'roteiro.json')]);
const MOTION = { v: 1, nome: 'teste', formato: '9:16', w: 540, h: 960, fps: 12, dur: 1.2, fundo: { tipo: 'escuro' }, meusEfeitos: [],
  itens: [{ id: 'a', tipo: 'texto', ini: 0, fim: 1.2, x: 270, y: 300, escala: 1, giro: 0, opac: 1, keys: {}, props: { texto: 'OI *BW*', estilo: 'neon', fonte: 'texto', tamanho: 60, cor: '#ffffff', destaque: '#7CFF3B', alinhar: 'center' },
    entrada: { efeito: 'aparecer', dur: 0.3 }, saida: { efeito: 'aparecer', dur: 0.3 }, loop: { efeito: 'nenhum', forca: 1 } }] };
const BWSYNC = `<script>window.BWSync={cliente:function(){return{auth:{getUser:async function(){return{data:{user:localStorage.getItem('logado')?{id:'u-9',email:'dono@exemplo.com',user_metadata:{full_name:'Marcos Teste'}}:null}}},signOut:async function(){localStorage.removeItem('logado')}}}}};</script>`;
const PAG = {
  '/login.html': `<title>login</title>${BWSYNC}<button id="entrar" onclick="localStorage.setItem('logado','1');location.href='index.html'">entrar</button>`,
  '/index.html': `<title>painel</title>${BWSYNC}<p>painel</p><script>window.tentar=function(a,d){return window.bwNode(a,d||{})}</script>`,
  '/fotos.html': `<title>fotos online</title><p>online</p>`,
  '/reels.html': `<title>reels</title>${BWSYNC}<a id="baixar" href="/pedido.bwreels.zip" download="meu-reel.bwreels.zip">render</a><a id="outro" href="/nota.txt" download="nota.txt">nota</a><a id="motion" href="/pedido-motion.json" download="teste.verde.bwmotion.json">motion</a><script>window.tentar=function(a,d){return window.bwNode(a,d||{})}</script>`,
  '/fora.html': `<title>fora</title><script>window.tentar=function(a){return window.bwNode?window.bwNode(a,{}):{ok:false,erro:'sem ponte'}}</script>`,
};
let ligado = true;
const servir = (req, res) => {
  const u = req.url.split('?')[0];
  if (!ligado) { req.socket.destroy(); return; }
  if (u === '/pedido.bwreels.zip') { res.writeHead(200, { 'Content-Type': 'application/zip' }); return res.end(readFileSync(zip)); }
  if (u === '/pedido-motion.json') { res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify(MOTION)); }
  if (u === '/nota.txt') { res.writeHead(200, { 'Content-Type': 'text/plain' }); return res.end('ola'); }
  if (u === '/sw.js') { res.writeHead(200, { 'Content-Type': 'text/javascript' }); return res.end('self.x=1'); }
  if (u === '/downloads/app-versao.json') { res.writeHead(404); return res.end('nada'); }
  if (PAG[u]) { res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8' }); return res.end('<!doctype html><meta charset="utf-8">' + PAG[u]); }
  res.writeHead(404); res.end('nada');
};
const site = http.createServer(servir), fora = http.createServer(servir);
await new Promise((r) => site.listen(0, '127.0.0.1', r)); await new Promise((r) => fora.listen(0, '127.0.0.1', r));
const SITE = `http://127.0.0.1:${site.address().port}`, FORA = `http://127.0.0.1:${fora.address().port}`;
const copia = join(T, 'copia'); mkdirSync(copia);
writeFileSync(join(copia, 'fotos.html'), '<!doctype html><meta charset="utf-8"><title>fotos da copia</title><p>editor</p>');
writeFileSync(join(copia, 'pdf.html'), '<!doctype html><meta charset="utf-8"><title>pdf da copia</title><p>pdf</p>');

const env = { ...process.env, HOME: T, USERPROFILE: T, BWREELS_TESTE: '1', BWREELS_NAO_ABRIR: '1', BWREELS_SITE_TESTE: SITE, BWREELS_COPIA_TESTE: copia, BWREELS_PERFIL_TESTE: join(T, 'perfil') };
delete env.ELECTRON_RUN_AS_NODE;
// BW_EXE = testar o programa montado (programa/bw ou BW.exe, que acha o app sozinho em resources/app)
const app = await _electron.launch(process.env.BW_EXE ? { executablePath: process.env.BW_EXE, args: ['--no-sandbox'], env, timeout: 60000 }
  : { executablePath: ELECTRON, args: ['--no-sandbox', join(RAIZ, 'electron', 'main.mjs')], env, timeout: 60000 });
if (process.env.BW_EXE) console.log('  (programa montado: ' + process.env.BW_EXE + ')');
const pg = await app.firstWindow();
const erros = []; pg.on('pageerror', (e) => erros.push(e.message));
await pg.waitForLoadState('domcontentloaded');

console.log('\nJANELA');
ok(/app\/index\.html/.test(pg.url()), 'abre a tela do app (app/index.html)');
ok(await pg.evaluate(() => !!(window.BW_APP && window.BW_APP.versao && window.BW_APP.janela === 'electron')), 'BW_APP presente antes dos scripts (janela electron)');
const prin = await app.evaluate(({ app }) => ({ nome: app.getName(), gpu: app.commandLine.hasSwitch('force_high_performance_gpu'), feat: app.commandLine.getSwitchValue('enable-features'), ua: app.userAgentFallback }));
ok(prin.nome === 'BW', 'o programa se chama BW');
ok(prin.gpu && /PlatformHEVCDecoderSupport/.test(prin.feat), 'pede a placa de ALTO DESEMPENHO e a decodificação HEVC pela placa');
ok(!/Electron/.test(prin.ua) && !/Electron/.test(await pg.evaluate(() => navigator.userAgent)), 'user agent sem "Electron" (login do Google não recusa)');
ok(await app.evaluate(({ BrowserWindow }) => BrowserWindow.getAllWindows()[0].getTitle().length > 0 && !BrowserWindow.getAllWindows()[0].isMenuBarVisible()), 'janela sem barra de menu');

console.log('\nPONTE');
let r = await pg.evaluate(() => window.bwNode('info', {}));
ok(r.ok && r.valor.navegador === 'electron', 'tela do app: info responde (janela electron)');
r = await pg.evaluate(() => window.bwNode('videos', {}));
ok(!r.ok && /Entre com a sua conta/.test(r.erro), 'sem login: a ponte recusa as ferramentas');
pg.evaluate(() => window.bwNode('entrar', {})).catch(() => {});
await pg.waitForURL(/login\.html/, { timeout: 15000 });
ok(true, 'ENTRAR abre a página de login da plataforma na mesma janela');
await pg.waitForSelector('#bwAppInicio', { timeout: 10000 }).then(() => ok(true, 'botão ⌂ BW aparece nas páginas da plataforma')).catch(() => ok(false, 'botão ⌂ BW aparece nas páginas da plataforma'));
await pg.click('#entrar');
await pg.waitForURL(/app\/index\.html/, { timeout: 20000 }).then(() => ok(true, 'depois do login volta sozinho para o app')).catch(() => ok(false, 'depois do login volta sozinho para o app'));
const lic = JSON.parse(readFileSync(join(T, '.bw-reels', 'licenca.json'), 'utf8'));
ok(lic.email === 'dono@exemplo.com' && !/senha|token/i.test(JSON.stringify(lic)), 'conta registrada (id + e-mail, sem senha nem token)');
r = await pg.evaluate(() => window.bwNode('videos', {}));
ok(r.ok && Array.isArray(r.valor), 'logado: tela do app usa as ferramentas');
await pg.goto(SITE + '/reels.html'); await pg.waitForSelector('#baixar');
r = await pg.evaluate(() => window.tentar('videos'));
ok(!r.ok && /recusado/.test(r.erro), 'plataforma NÃO pode pedir arquivos do PC');
r = await pg.evaluate(() => window.tentar('info'));
ok(r.ok, 'plataforma pode pedir o que está na lista (info)');
await pg.goto(FORA + '/fora.html');
r = await pg.evaluate(() => window.tentar('info'));
ok(!r.ok && /recusado|sem ponte/.test(r.erro), 'site de fora é recusado');

console.log('\nDOWNLOADS E RENDER');
await pg.goto(SITE + '/reels.html'); await pg.waitForSelector('#outro');
const textoAviso = () => pg.evaluate(() => (document.getElementById('bwAppAvisoTexto') || {}).textContent || '');
await pg.click('#outro');
await pg.waitForFunction(() => /Salvo em Downloads/.test((document.getElementById('bwAppAvisoTexto') || {}).textContent || ''), null, { timeout: 20000 }).catch(() => {});
ok(existsSync(join(T, 'nota.txt')) && readFileSync(join(T, 'nota.txt'), 'utf8') === 'ola', 'download comum salvo e avisado — ' + (await textoAviso()).slice(0, 60));
await pg.evaluate(() => { const c = document.getElementById('bwAppAviso'); if (c) c.remove(); });
await pg.click('#baixar');
await pg.waitForFunction(() => /Vídeo pronto|Não/.test((document.getElementById('bwAppAvisoTexto') || {}).textContent || ''), null, { timeout: 240000 }).catch(() => {});
ok(/Vídeo pronto/.test(await textoAviso()), 'RENDERIZAR NO PC gera o vídeo — ' + (await textoAviso()).slice(0, 70));
await pg.evaluate(() => { const c = document.getElementById('bwAppAviso'); if (c) c.remove(); });
await pg.click('#motion');
await pg.waitForFunction(() => /Vídeo pronto|Não/.test((document.getElementById('bwAppAvisoTexto') || {}).textContent || ''), null, { timeout: 240000 }).catch(() => {});
const avM = await textoAviso();
ok(/Vídeo pronto/.test(avM), 'Estúdio de motion: o motor roda como Node dentro do BW (ELECTRON_RUN_AS_NODE) — ' + avM.slice(0, 80));
const NM = await import('./assistente-nucleo.mjs');
const mot = readdirSync(join(NM.RAIZ, 'projetos')).filter((n) => n.startsWith('motion-teste-')).map((n) => join(NM.RAIZ, 'projetos', n, 'render')).filter(existsSync).flatMap((p) => readdirSync(p).filter((n) => n.endsWith('.mp4')).map((n) => join(p, n)));
ok(mot.length > 0, 'vídeo do motion salvo no projeto');

console.log('\nSEM INTERNET');
await pg.goto(SITE + '/fotos.html'); ok((await pg.title()) === 'fotos online', 'com rede: página da plataforma');
r = await pg.evaluate(async () => (await fetch('/sw.js')).status);
ok(r === 404, 'sw.js da plataforma recusado (o cache é do app)');
await pg.goto(SITE + '/index.html');
ligado = false;
await pg.goto(SITE + '/fotos.html').catch(() => {});
ok((await pg.title()) === 'fotos online', 'sem rede: a página já visitada abre da cópia guardada — ' + (await pg.title()));
await pg.goto(SITE + '/pdf.html').catch(() => {});
ok((await pg.title()) === 'pdf da copia', 'sem rede: página nunca visitada abre da cópia que vem no instalador — ' + (await pg.title()));
ligado = true;

ok(!erros.length, 'sem erros de JavaScript nas telas' + (erros.length ? ': ' + erros.slice(0, 2).join(' | ') : ''));
await app.close();
site.close(); fora.close();
console.log(falhas.length ? `\n✗ ${falhas.length} falha(s)` : '\nTudo certo.');
process.exit(falhas.length ? 1 : 0);
