// Presets visuais. Cada estilo vira variáveis CSS usadas por todos os motores.
// Para criar um novo estilo, copie um bloco e ajuste — o roteiro só referencia o nome.

export const ESTILOS = {
  cinema: {
    fundo: '#0b0b0c', texto: '#f3eee4', destaque: '#e8b04a', suave: '#9a948a',
    fonteTitulo: "'Anton', 'Bebas Neue', 'BWPesada', sans-serif",
    fonteTexto: "'Inter', 'Inter Display', sans-serif",
    pesoTitulo: 400, caixaAlta: true, gradiente: 'radial-gradient(120% 80% at 50% 30%, #1c1a17 0%, #0b0b0c 70%)',
  },
  corporativo: {
    fundo: '#0a1626', texto: '#ffffff', destaque: '#3ec7f2', suave: '#8fa3b8',
    fonteTitulo: "'Inter', 'BWPesada', sans-serif",
    fonteTexto: "'Inter', sans-serif",
    pesoTitulo: 800, caixaAlta: false, gradiente: 'linear-gradient(160deg, #10243d 0%, #0a1626 60%, #060d17 100%)',
  },
  neon: {
    fundo: '#07060d', texto: '#ffffff', destaque: '#ff3db8', suave: '#7cf7ff',
    fonteTitulo: "'Bebas Neue', 'Anton', 'BWPesada', sans-serif",
    fonteTexto: "'Inter', sans-serif",
    pesoTitulo: 400, caixaAlta: true, brilho: true,
    gradiente: 'radial-gradient(90% 60% at 50% 40%, #241046 0%, #07060d 75%)',
  },
  editorial: {
    fundo: '#f2eee6', texto: '#141210', destaque: '#d6452b', suave: '#6f6a62',
    fonteTitulo: "'Playfair Display', 'DM Serif Display', Georgia, serif",
    fonteTexto: "'Inter', sans-serif",
    pesoTitulo: 700, caixaAlta: false, gradiente: 'linear-gradient(180deg, #f6f3ec 0%, #ebe5d9 100%)',
  },
  luxo: {
    fundo: '#0e0d0b', texto: '#efe6d2', destaque: '#c9a96e', suave: '#8c826f',
    fonteTitulo: "'Cormorant Garamond', 'Playfair Display', Georgia, serif",
    fonteTexto: "'Inter', sans-serif",
    pesoTitulo: 500, caixaAlta: true, espacamento: 0.08,
    gradiente: 'radial-gradient(100% 70% at 50% 35%, #1d1a15 0%, #0e0d0b 70%)',
  },
  tech: {
    fundo: '#07090f', texto: '#f2f5fa', destaque: '#8be36a', suave: '#8790a3',
    fonteTitulo: "'Inter', 'BWPesada', sans-serif",
    fonteTexto: "'Inter', sans-serif",
    pesoTitulo: 900, caixaAlta: false, enfaseItalica: true, grade: true,
    gradiente: 'radial-gradient(90% 60% at 50% 35%, #121826 0%, #07090f 75%)',
  },
  impacto: {
    fundo: '#0a0a0c', texto: '#ffffff', destaque: '#ff2d6f', suave: '#b9b3bd',
    fonteTitulo: "'Anton', 'Bebas Neue', 'BWPesada', sans-serif",
    fonteTexto: "'Inter', sans-serif",
    pesoTitulo: 400, caixaAlta: true, brilho: true,
    gradiente: 'radial-gradient(100% 60% at 50% 100%, #4a0b22 0%, #0a0a0c 65%)',
  },
};

export const FORMATOS = {
  '9:16': { largura: 1080, altura: 1920 },
  '4:5': { largura: 1080, altura: 1350 },
  '1:1': { largura: 1080, altura: 1080 },
  '16:9': { largura: 1920, altura: 1080 },
};

export const GOOGLE_FONTS =
  'https://fonts.googleapis.com/css2?family=Anton&family=Bebas+Neue&family=Cormorant+Garamond:wght@500;700&family=Inter:wght@400;600;800;900&family=Playfair+Display:wght@700;900&display=swap';
