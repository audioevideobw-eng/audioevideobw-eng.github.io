// Personagens animados por código (vetor/SVG), usados pela cena "personagem" nos 3 motores.
// - svgPersonagem(): desenha o personagem (partes marcadas com data-p)
// - animarPersonagem(): mexe as partes SÓ em função do tempo t (determinístico: mesmo t = mesma imagem)
// Para criar um personagem novo: copie um bloco de PERSONAGENS e ajuste cores/cabelo, ou um "desenho" novo em svgPersonagem.

export const PERSONAGENS = {
  be:  { nome: 'Bê (câmera BW)', desenho: 'camera', cores: { corpo: '#232937', detalhe: '#FFB547', lente: '#3aa7e0', pe: '#FFB547' } },
  ana: { nome: 'Ana', desenho: 'pessoa', cabelo: 'longo', cores: { pele: '#f1c7a5', cabelo: '#5a3424', roupa: '#e8505b', calca: '#2b3550', sapato: '#1b1f2a' } },
  leo: { nome: 'Léo', desenho: 'pessoa', cabelo: 'curto', cores: { pele: '#c98d63', cabelo: '#1d1a19', roupa: '#2f80ed', calca: '#273043', sapato: '#111' } },
  bia: { nome: 'Bia', desenho: 'pessoa', cabelo: 'coque', cores: { pele: '#8a5a3b', cabelo: '#24160f', roupa: '#22b07d', calca: '#3a2f4f', sapato: '#161616' } },
  rui: { nome: 'Rui', desenho: 'pessoa', cabelo: 'careca', barba: true, cores: { pele: '#e3b08e', cabelo: '#6b6b6b', roupa: '#f2b134', calca: '#2c2c34', sapato: '#121212' } },
  robo: { nome: 'Robô', desenho: 'robo', cores: { corpo: '#cfd6e2', detalhe: '#ff4d6d', lente: '#5ef0ff', pe: '#8a94a6' } },
  cinegrafista: { nome: 'Cinegrafista', desenho: 'pessoa', cabelo: 'curto', barba: 'cavanhaque', roupa: 'jaqueta', acessorio: 'camera', bone: true, cores: { pele: '#d8a07a', cabelo: '#2b1d14', roupa: '#24272f', calca: '#3b4250', sapato: '#111', detalhe: '#FFB547' } },
  tecnico: { nome: 'Técnico de som', desenho: 'pessoa', cabelo: 'curto', barba: 'cheia', roupa: 'camiseta', acessorio: 'headset', cores: { pele: '#b97d55', cabelo: '#1a1410', roupa: '#1d1f26', calca: '#2c3446', sapato: '#111', detalhe: '#FFB547' } },
  dj: { nome: 'DJ', desenho: 'pessoa', cabelo: 'moicano', oculos: 'escuro', roupa: 'jaqueta', acessorio: 'headset', cores: { pele: '#7a4a2e', cabelo: '#ff3db8', roupa: '#3a1f6b', calca: '#18181f', sapato: '#f5f1ea', detalhe: '#7cf7ff' } },
  palestrante: { nome: 'Palestrante', desenho: 'pessoa', cabelo: 'franja', roupa: 'social', acessorio: 'microfone', cores: { pele: '#f0c4a2', cabelo: '#7a4b2a', roupa: '#f4f4f4', calca: '#2b2f3a', sapato: '#1a1a1a', detalhe: '#c8102e' } },
  executivo: { nome: 'Executivo', desenho: 'pessoa', cabelo: 'curto', roupa: 'terno', cores: { pele: '#e9b996', cabelo: '#3b2a1d', roupa: '#1f2a44', calca: '#1f2a44', sapato: '#111', detalhe: '#c8102e' } },
  executiva: { nome: 'Executiva', desenho: 'pessoa', cabelo: 'coque', oculos: 'quadrado', roupa: 'terno', cores: { pele: '#9b6343', cabelo: '#1c120c', roupa: '#2b2b33', calca: '#2b2b33', sapato: '#111', detalhe: '#FFB547' } },
  noiva: { nome: 'Noiva', desenho: 'pessoa', cabelo: 'longo', roupa: 'vestido', acessorio: 'veu', cores: { pele: '#f2cdb0', cabelo: '#4a2c1a', roupa: '#fbf8f2', calca: '#fbf8f2', sapato: '#efe6d6', detalhe: '#e8c26a' } },
  noivo: { nome: 'Noivo', desenho: 'pessoa', cabelo: 'curto', barba: 'bigode', roupa: 'terno', cores: { pele: '#c48a64', cabelo: '#16110d', roupa: '#121218', calca: '#121218', sapato: '#0a0a0a', detalhe: '#f4f4f4' } },
  fotografa: { nome: 'Fotógrafa', desenho: 'pessoa', cabelo: 'cacheado', roupa: 'jaqueta', acessorio: 'camera', cores: { pele: '#6e432b', cabelo: '#1b120c', roupa: '#c9772f', calca: '#2a3142', sapato: '#111', detalhe: '#111' } },
  cliente: { nome: 'Cliente', desenho: 'pessoa', cabelo: 'rabo', roupa: 'camiseta', acessorio: 'cracha', cores: { pele: '#f3cfb3', cabelo: '#c98a2f', roupa: '#7b5cff', calca: '#2b3550', sapato: '#1b1f2a', detalhe: '#ff4d6d' } },
  garcom: { nome: 'Garçom', desenho: 'pessoa', cabelo: 'curto', barba: 'bigode', roupa: 'avental', cores: { pele: '#d9a47f', cabelo: '#222', roupa: '#f4f4f4', calca: '#151515', sapato: '#0a0a0a', detalhe: '#1b1b1b' } },
  cachorro: { nome: 'Cachorro', desenho: 'pessoa', bicho: 'cachorro', roupa: 'camiseta', cores: { pele: '#c08a55', cabelo: '#7a4f2a', roupa: '#2f80ed', calca: '#c08a55', sapato: '#7a4f2a', detalhe: '#ff4d6d' } },
  gato: { nome: 'Gato', desenho: 'pessoa', bicho: 'gato', roupa: 'camiseta', cores: { pele: '#9aa3ad', cabelo: '#5f6873', roupa: '#22b07d', calca: '#9aa3ad', sapato: '#5f6873', detalhe: '#ffb3c7' } },
};

/** Opções do CRIAR PERSONAGEM (montador). Um personagem montado vai no roteiro como {personagem:'meu', look:{…}}. */
export const MONTADOR = {
  bicho: { nenhum: 'Pessoa', cachorro: 'Cachorro', gato: 'Gato' },
  cabelo: { curto: 'Curto', longo: 'Longo', coque: 'Coque', cacheado: 'Cacheado', rabo: 'Rabo de cavalo', franja: 'Franja', moicano: 'Moicano', careca: 'Careca' },
  barba: { nenhuma: 'Sem barba', cheia: 'Barba cheia', bigode: 'Bigode', cavanhaque: 'Cavanhaque' },
  oculos: { nenhum: 'Sem óculos', redondo: 'Redondo', quadrado: 'Quadrado', escuro: 'Escuro' },
  roupa: { camiseta: 'Camiseta', social: 'Camisa e gravata', terno: 'Terno', jaqueta: 'Jaqueta', vestido: 'Vestido', avental: 'Avental' },
  acessorio: { nenhum: 'Nenhum', headset: 'Headset', camera: 'Câmera na mão', microfone: 'Microfone', cracha: 'Crachá', veu: 'Véu' },
  bone: { nao: 'Sem boné', sim: 'Com boné' },
  peles: ['#f6d7bf', '#f0c4a2', '#e3b08e', '#d8a07a', '#c48a64', '#a86e4a', '#8a5a3b', '#6e432b', '#4e2f1f'],
};

export const ACOES = ['parado', 'acena', 'fala', 'aponta', 'comemora', 'pensa', 'surpresa'];
// "foto" = personagem do PRÓPRIO usuário (PNG recortado): {personagem:'foto', imagem:'midia/avatar.png', contorno:true, espelhar:false}
export const FOTO = 'foto';

const L = '#0b0d12'; // contorno (estilo desenho animado)

function membro(id, x1, y1, x2, y2, cor, mao, extra = '') {
  return `<g data-p="${id}" data-ox="${x1}" data-oy="${y1}">
    <path d="M${x1} ${y1} L${x2} ${y2}" stroke="${L}" stroke-width="40" stroke-linecap="round"/>
    <path d="M${x1} ${y1} L${x2} ${y2}" stroke="${cor}" stroke-width="26" stroke-linecap="round"/>
    ${extra}<circle cx="${x2}" cy="${y2 + 6}" r="20" fill="${mao}" stroke="${L}" stroke-width="7"/></g>`;
}
const sorriso = (cx, cy, w) => `M${cx - w / 2} ${cy} Q${cx} ${cy + w * 0.42} ${cx + w / 2} ${cy} Q${cx} ${cy + w * 0.15} ${cx - w / 2} ${cy}Z`;
function olho(cx, cy, r, rp) {
  return `<ellipse cx="${cx}" cy="${cy}" rx="${r}" ry="${r * 1.12}" fill="#fff" stroke="${L}" stroke-width="6"/>
    <g data-p="pupila" data-cx="${cx}" data-cy="${cy}"><circle cx="${cx}" cy="${cy}" r="${rp}" fill="${L}"/><circle cx="${cx - rp * .35}" cy="${cy - rp * .4}" r="${rp * .35}" fill="#fff"/></g>`;
}

/** SVG do personagem. `p` = chave de PERSONAGENS ou objeto {desenho, cabelo, cores}. viewBox 400×640, pés em y≈615. */
export function svgPersonagem(p, coresExtra) {
  const base = typeof p === 'string' ? (PERSONAGENS[p] || PERSONAGENS.be) : { desenho: 'pessoa', ...p, cores: { ...PERSONAGENS.leo.cores, ...(p && p.cores) } };
  const c = { ...base.cores, ...(coresExtra || {}) };
  let corpo = '';
  if (base.desenho === 'pessoa') {
    const bicho = base.bicho && base.bicho !== 'nenhum' ? base.bicho : null;
    const cab = bicho ? 'nenhum' : (base.cabelo || 'curto');
    const roupa = base.roupa || 'camiseta', ac = base.acessorio || 'nenhum', det = c.detalhe || '#c8102e';
    const barbaT = base.barba === true ? 'cheia' : (base.barba || 'nenhuma');
    const manga = roupa === 'social' || roupa === 'avental' ? '#f4f4f4' : c.roupa;
    const atras = {
      longo: `<path d="M105 190 Q100 330 140 395 L262 395 Q300 330 295 190 Z" fill="${c.cabelo}" stroke="${L}" stroke-width="8"/>`,
      rabo: `<path d="M286 150 Q352 190 330 300 Q322 340 300 352 Q312 290 280 200 Z" fill="${c.cabelo}" stroke="${L}" stroke-width="8"/>`,
      franja: `<path d="M104 196 Q100 300 130 330 L270 330 Q300 300 296 196 Z" fill="${c.cabelo}" stroke="${L}" stroke-width="8"/>`,
    }[cab] || '';
    const veuAtras = ac === 'veu' ? `<path d="M112 130 Q60 330 92 520 L308 520 Q340 330 288 130 Z" fill="#ffffff" opacity=".55" stroke="${L}" stroke-width="5"/>` : '';
    const topo = {
      curto: `<path d="M108 190 Q110 92 200 88 Q292 92 292 190 Q270 140 200 140 Q140 140 108 190Z" fill="${c.cabelo}" stroke="${L}" stroke-width="8"/>`,
      longo: `<path d="M104 200 Q100 90 200 86 Q300 90 296 200 Q262 128 200 138 Q160 130 128 168 Q116 186 104 200Z" fill="${c.cabelo}" stroke="${L}" stroke-width="8"/>`,
      coque: `<circle cx="200" cy="74" r="40" fill="${c.cabelo}" stroke="${L}" stroke-width="8"/><path d="M108 188 Q110 96 200 92 Q290 96 292 188 Q262 132 200 134 Q138 132 108 188Z" fill="${c.cabelo}" stroke="${L}" stroke-width="8"/>`,
      careca: `<path d="M110 178 Q112 162 120 152" stroke="${c.cabelo}" stroke-width="14" stroke-linecap="round" fill="none"/><path d="M290 178 Q288 162 280 152" stroke="${c.cabelo}" stroke-width="14" stroke-linecap="round" fill="none"/>`,
      cacheado: [[120, 150, 34], [150, 110, 36], [200, 96, 38], [250, 110, 36], [280, 150, 34], [102, 196, 26], [298, 196, 26]].map(([x, y, r]) => `<circle cx="${x}" cy="${y}" r="${r}" fill="${c.cabelo}" stroke="${L}" stroke-width="7"/>`).join('') +
        [[150, 110, 30], [200, 98, 32], [250, 110, 30]].map(([x, y, r]) => `<circle cx="${x}" cy="${y + 6}" r="${r}" fill="${c.cabelo}"/>`).join(''),
      rabo: `<path d="M106 192 Q108 92 200 88 Q292 92 294 192 Q268 132 200 136 Q140 132 106 192Z" fill="${c.cabelo}" stroke="${L}" stroke-width="8"/>`,
      franja: `<path d="M104 210 Q98 90 200 86 Q302 90 296 210 L282 214 Q276 160 240 150 L232 172 Q196 150 168 168 L160 150 Q124 160 118 214 Z" fill="${c.cabelo}" stroke="${L}" stroke-width="8"/>`,
      moicano: `<path d="M176 160 Q170 70 200 40 Q230 70 224 160 Z" fill="${c.cabelo}" stroke="${L}" stroke-width="8"/>`,
    }[cab] || '';
    const barba = {
      cheia: `<path d="M128 236 Q140 318 200 322 Q260 318 272 236 Q250 286 200 288 Q150 286 128 236Z" fill="${c.cabelo}" stroke="${L}" stroke-width="6"/>`,
      bigode: `<path d="M168 246 Q184 234 200 244 Q216 234 232 246 Q216 256 200 250 Q184 256 168 246Z" fill="${c.cabelo}" stroke="${L}" stroke-width="5"/>`,
      cavanhaque: `<path d="M180 286 Q200 312 220 286 Q210 296 200 296 Q190 296 180 286Z" fill="${c.cabelo}" stroke="${L}" stroke-width="5"/><path d="M174 248 Q200 238 226 248" stroke="${c.cabelo}" stroke-width="9" fill="none" stroke-linecap="round"/>`,
    }[barbaT] || '';
    const oc = base.oculos || 'nenhum';
    const oculos = oc === 'redondo' ? `<g fill="none" stroke="${L}" stroke-width="7"><circle cx="162" cy="196" r="30"/><circle cx="238" cy="196" r="30"/><path d="M192 194 Q200 186 208 194"/></g>`
      : oc === 'quadrado' ? `<g fill="none" stroke="${L}" stroke-width="7"><rect x="130" y="172" width="64" height="48" rx="10"/><rect x="206" y="172" width="64" height="48" rx="10"/><path d="M194 192 L206 192"/></g>`
      : oc === 'escuro' ? `<g stroke="${L}" stroke-width="7"><rect x="128" y="174" width="68" height="44" rx="16" fill="#111"/><rect x="204" y="174" width="68" height="44" rx="16" fill="#111"/><path d="M196 190 L204 190"/></g><path d="M140 182 L160 182" stroke="#fff" stroke-width="5" opacity=".5"/>` : '';
    const orelhas = bicho === 'cachorro' ? `<path d="M112 130 Q70 150 84 250 Q100 280 124 240 Q122 180 140 140Z" fill="${c.cabelo}" stroke="${L}" stroke-width="8"/><path d="M288 130 Q330 150 316 250 Q300 280 276 240 Q278 180 260 140Z" fill="${c.cabelo}" stroke="${L}" stroke-width="8"/>`
      : bicho === 'gato' ? `<path d="M118 150 L120 72 L176 112 Z" fill="${c.pele}" stroke="${L}" stroke-width="8" stroke-linejoin="round"/><path d="M282 150 L280 72 L224 112 Z" fill="${c.pele}" stroke="${L}" stroke-width="8" stroke-linejoin="round"/><path d="M128 128 L130 92 L160 112Z" fill="${det}"/><path d="M272 128 L270 92 L240 112Z" fill="${det}"/>` : '';
    const focinho = bicho ? `<ellipse cx="200" cy="246" rx="${bicho === 'gato' ? 40 : 50}" ry="${bicho === 'gato' ? 28 : 34}" fill="#f4ece2" stroke="${L}" stroke-width="6"/><ellipse cx="200" cy="232" rx="${bicho === 'gato' ? 10 : 16}" ry="${bicho === 'gato' ? 7 : 11}" fill="${bicho === 'gato' ? det : L}"/>` +
      (bicho === 'gato' ? `<g stroke="${L}" stroke-width="3"><path d="M150 240 L104 232"/><path d="M150 250 L104 256"/><path d="M250 240 L296 232"/><path d="M250 250 L296 256"/></g>` : '') : '';
    const bone = base.bone ? `<path d="M110 150 Q120 78 200 76 Q280 78 290 150 Z" fill="${det === '#111' ? '#333' : c.roupa}" stroke="${L}" stroke-width="8"/><path d="M200 140 Q290 136 330 150 Q300 162 200 156Z" fill="${det}" stroke="${L}" stroke-width="7"/>` : '';
    const headset = ac === 'headset' ? `<path d="M100 200 Q100 70 200 66 Q300 70 300 200" fill="none" stroke="${L}" stroke-width="16"/><path d="M100 200 Q100 70 200 66 Q300 70 300 200" fill="none" stroke="${det}" stroke-width="7"/>
      <rect x="82" y="168" width="34" height="60" rx="12" fill="${det}" stroke="${L}" stroke-width="7"/><rect x="284" y="168" width="34" height="60" rx="12" fill="${det}" stroke="${L}" stroke-width="7"/><path d="M100 226 Q110 280 160 270" fill="none" stroke="${L}" stroke-width="7"/><circle cx="162" cy="270" r="9" fill="${L}"/>` : '';
    const veuTopo = ac === 'veu' ? `<path d="M130 118 Q200 92 270 118" fill="none" stroke="${det}" stroke-width="10" stroke-linecap="round"/>` : '';
    // tronco por tipo de roupa
    const corpoRoupa = roupa === 'vestido'
      ? `<path d="M138 322 Q200 300 262 322 L300 548 Q200 568 100 548 Z" fill="${c.roupa}" stroke="${L}" stroke-width="8" stroke-linejoin="round"/><path d="M146 420 Q200 432 254 420" stroke="${det}" stroke-width="8" fill="none"/>`
      : `<path d="M128 322 Q200 296 272 322 L284 488 Q200 504 116 488 Z" fill="${roupa === 'social' ? '#f4f4f4' : c.roupa}" stroke="${L}" stroke-width="8" stroke-linejoin="round"/>` +
        (roupa === 'camiseta' ? `<path d="M176 312 L200 352 L224 312" fill="none" stroke="${L}" stroke-width="6" opacity=".55"/>` : '') +
        (roupa === 'social' ? `<path d="M178 310 L200 336 L222 310" fill="#fff" stroke="${L}" stroke-width="5"/><path d="M192 336 L208 336 L214 430 L200 446 L186 430 Z" fill="${det}" stroke="${L}" stroke-width="5"/>` : '') +
        (roupa === 'terno' ? `<path d="M168 306 L200 380 L232 306 Z" fill="#f4f4f4" stroke="${L}" stroke-width="5"/><path d="M193 330 L207 330 L211 384 L200 396 L189 384 Z" fill="${det}" stroke="${L}" stroke-width="4"/><path d="M168 306 L200 396 L156 488" fill="none" stroke="${L}" stroke-width="6"/><path d="M232 306 L200 396 L244 488" fill="none" stroke="${L}" stroke-width="6"/>` : '') +
        (roupa === 'jaqueta' ? `<path d="M200 316 L200 494" stroke="${L}" stroke-width="6"/><path d="M160 308 L186 360 L200 316 L214 360 L240 308" fill="none" stroke="${L}" stroke-width="6"/><circle cx="214" cy="410" r="5" fill="${det}"/>` : '') +
        (roupa === 'avental' ? `<path d="M150 360 L250 360 L262 500 L138 500 Z" fill="${det}" stroke="${L}" stroke-width="6"/><path d="M150 360 Q200 320 250 360" fill="none" stroke="${det}" stroke-width="8"/><path d="M190 330 L200 342 L210 330 L200 320Z" fill="${L}"/>` : '');
    const cracha = ac === 'cracha' ? `<path d="M170 316 L200 400 L230 316" fill="none" stroke="${det}" stroke-width="6"/><rect x="182" y="398" width="36" height="48" rx="5" fill="#fff" stroke="${L}" stroke-width="5"/><rect x="188" y="406" width="24" height="10" fill="${det}"/>` : '';
    const naMao = ac === 'camera' ? `<g transform="translate(296 450)"><rect x="-34" y="-26" width="68" height="44" rx="8" fill="#222" stroke="${L}" stroke-width="6"/><circle cx="6" cy="-4" r="15" fill="#4aa8e8" stroke="${L}" stroke-width="5"/><rect x="-26" y="-36" width="20" height="12" rx="3" fill="${det}" stroke="${L}" stroke-width="4"/></g>`
      : ac === 'microfone' ? `<g transform="translate(300 440) rotate(-28)"><rect x="-8" y="-6" width="16" height="70" rx="6" fill="#222" stroke="${L}" stroke-width="5"/><circle cx="0" cy="-14" r="20" fill="#9aa3ad" stroke="${L}" stroke-width="6"/></g>` : '';
    const pernas = roupa === 'vestido'
      ? `<path d="M172 540 L168 590" stroke="${L}" stroke-width="30" stroke-linecap="round"/><path d="M172 540 L168 590" stroke="${c.pele}" stroke-width="18" stroke-linecap="round"/><path d="M228 540 L232 590" stroke="${L}" stroke-width="30" stroke-linecap="round"/><path d="M228 540 L232 590" stroke="${c.pele}" stroke-width="18" stroke-linecap="round"/>`
      : `<path d="M172 470 L166 590" stroke="${L}" stroke-width="44" stroke-linecap="round"/><path d="M172 470 L166 590" stroke="${c.calca}" stroke-width="30" stroke-linecap="round"/><path d="M228 470 L234 590" stroke="${L}" stroke-width="44" stroke-linecap="round"/><path d="M228 470 L234 590" stroke="${c.calca}" stroke-width="30" stroke-linecap="round"/>`;
    corpo = `
      ${veuAtras}
      <g data-p="pernas">${pernas}
        <ellipse cx="158" cy="604" rx="40" ry="18" fill="${c.sapato}" stroke="${L}" stroke-width="6"/><ellipse cx="242" cy="604" rx="40" ry="18" fill="${c.sapato}" stroke="${L}" stroke-width="6"/>
      </g>
      ${membro('bracoE', 140, 330, 104, 448, manga, c.pele)}
      ${corpoRoupa}${cracha}
      ${membro('bracoD', 260, 330, 296, 448, manga, c.pele, naMao)}
      <g data-p="cabeca" data-ox="200" data-oy="300">
        ${atras}${orelhas}
        <rect x="178" y="270" width="44" height="46" fill="${c.pele}" stroke="${L}" stroke-width="6"/>
        <ellipse cx="200" cy="198" rx="98" ry="108" fill="${c.pele}" stroke="${L}" stroke-width="8"/>
        ${barba}
        ${bicho ? '' : `<circle cx="140" cy="236" r="16" fill="#ff7a7a" opacity=".35"/><circle cx="260" cy="236" r="16" fill="#ff7a7a" opacity=".35"/>`}
        ${olho(162, 196, 20, 10)}${olho(238, 196, 20, 10)}
        <rect data-p="palpebra" data-h="48" x="138" y="170" width="48" height="0" fill="${c.pele}"/>
        <rect data-p="palpebra" data-h="48" x="214" y="170" width="48" height="0" fill="${c.pele}"/>
        <path data-p="sobrancelha" data-oy="160" d="M140 164 Q162 150 184 162" stroke="${L}" stroke-width="8" fill="none" stroke-linecap="round"/>
        <path data-p="sobrancelha" data-oy="160" d="M216 162 Q238 150 260 164" stroke="${L}" stroke-width="8" fill="none" stroke-linecap="round"/>
        ${focinho}
        <path data-p="boca" data-cx="200" data-cy="${bicho ? 270 : 258}" data-w="${bicho ? 40 : 52}" d="${sorriso(200, bicho ? 270 : 258, bicho ? 40 : 52)}" fill="#6e1b23" stroke="${L}" stroke-width="7" stroke-linejoin="round"/>
        ${oculos}${topo}${bone}${headset}${veuTopo}
      </g>`;
  } else {
    // câmera BW (be) e robô: a cabeça é o próprio corpo
    const robo = base.desenho === 'robo';
    corpo = `
      <g data-p="pernas" stroke="${L}" stroke-width="10" stroke-linecap="round">
        <path d="M168 500 L160 596" stroke="${robo ? c.pe : L}" stroke-width="${robo ? 22 : 12}"/><path d="M232 500 L240 596" stroke="${robo ? c.pe : L}" stroke-width="${robo ? 22 : 12}"/>
        <ellipse cx="152" cy="604" rx="42" ry="18" fill="${c.pe}" stroke-width="7"/><ellipse cx="248" cy="604" rx="42" ry="18" fill="${c.pe}" stroke-width="7"/>
      </g>
      ${membro('bracoE', 96, 360, 64, 470, robo ? c.pe : '#c9ced9', '#F5F1EA')}
      ${membro('bracoD', 304, 360, 336, 470, robo ? c.pe : '#c9ced9', '#F5F1EA')}
      <g data-p="cabeca" data-ox="200" data-oy="520">
        ${robo ? `<path d="M200 220 L200 168" stroke="${L}" stroke-width="8"/><circle data-p="luzinha" cx="200" cy="160" r="16" fill="${c.detalhe}" stroke="${L}" stroke-width="6"/>`
          : `<rect x="122" y="208" width="104" height="54" rx="14" fill="${c.detalhe}" stroke="${L}" stroke-width="8"/>`}
        <rect x="86" y="236" width="228" height="282" rx="${robo ? 70 : 46}" fill="${c.corpo}" stroke="${L}" stroke-width="10"/>
        ${robo ? `<rect x="120" y="300" width="160" height="110" rx="40" fill="#1a1f2b" stroke="${L}" stroke-width="6"/>` : `<circle data-p="luzinha" cx="276" cy="276" r="13" fill="#ff3b3b"/>`}
        ${robo ? `<ellipse cx="166" cy="352" rx="24" ry="26" fill="${c.lente}"/><g data-p="pupila" data-cx="166" data-cy="352"><circle cx="166" cy="352" r="10" fill="#08333a"/></g>
                  <ellipse cx="234" cy="352" rx="24" ry="26" fill="${c.lente}"/><g data-p="pupila" data-cx="234" data-cy="352"><circle cx="234" cy="352" r="10" fill="#08333a"/></g>
                  <rect data-p="palpebra" data-h="56" x="138" y="324" width="124" height="0" fill="#1a1f2b"/>`
          : `<circle cx="160" cy="372" r="72" fill="${L}"/><circle cx="160" cy="372" r="58" fill="${c.lente}"/><circle cx="160" cy="372" r="58" fill="url(#bwLente)"/>
             <g data-p="pupila" data-cx="160" data-cy="372"><circle cx="160" cy="372" r="24" fill="#04090f"/><circle cx="146" cy="356" r="10" fill="#fff"/></g>
             <circle cx="262" cy="352" r="30" fill="${L}"/><circle cx="262" cy="352" r="23" fill="${c.lente}"/>
             <g data-p="pupila" data-cx="262" data-cy="352"><circle cx="262" cy="352" r="10" fill="#04090f"/><circle cx="257" cy="346" r="4" fill="#fff"/></g>
             <rect data-p="palpebra" data-h="150" x="86" y="296" width="228" height="0" fill="${c.corpo}"/>`}
        <path data-p="sobrancelha" data-oy="0" d="" />
        <path data-p="boca" data-cx="${robo ? 200 : 228}" data-cy="${robo ? 388 : 468}" data-w="${robo ? 60 : 50}" d="${sorriso(robo ? 200 : 228, robo ? 388 : 468, robo ? 60 : 50)}" fill="${robo ? c.lente : '#7a1d1d'}" stroke="${robo ? c.lente : '#F5F1EA'}" stroke-width="7" stroke-linejoin="round"/>
      </g>`;
  }
  return `<svg viewBox="0 0 400 640" width="100%" height="100%" overflow="visible" xmlns="http://www.w3.org/2000/svg">
    <defs><radialGradient id="bwLente" cx="35%" cy="30%" r="75%"><stop offset="0" stop-color="#bfeaff" stop-opacity=".7"/><stop offset=".5" stop-color="#1b5d86" stop-opacity=".1"/><stop offset="1" stop-color="#071824" stop-opacity=".8"/></radialGradient></defs>
    <ellipse data-p="sombra" cx="200" cy="618" rx="130" ry="20" fill="#000" opacity=".45"/>
    <g data-p="tudo">${corpo}</g></svg>`;
}

/** Anima o personagem dentro de `raiz` no tempo t. r = {t0, t1, acao, entrada, falas:[[ini,fim]], olhar, semente}. */
export function animarPersonagem(raiz, r, t) {
  if (!raiz) return;
  if (r.foto) return animarRecorte(raiz, r, t);
  if (!raiz.__p) {
    const q = (s) => [...raiz.querySelectorAll(`[data-p="${s}"]`)];
    raiz.__p = { tudo: q('tudo')[0], sombra: q('sombra')[0], cabeca: q('cabeca')[0], bE: q('bracoE')[0], bD: q('bracoD')[0],
      pup: q('pupila'), palp: q('palpebra'), sob: q('sobrancelha'), boca: q('boca')[0], luz: q('luzinha')[0] };
  }
  const P = raiz.__p, lt = t - r.t0, dur = r.t1 - r.t0, sd = r.semente || 0;
  const cl = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
  const fx = (a, b) => cl((lt - a) / (b - a));
  const eOut = (x) => 1 - (1 - x) ** 3;
  const eBack = (x) => { const c = 1.70158; return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2; };
  const acao = r.acao || 'parado';

  // entrada
  let y = 0, x = 0, sq = 0;
  if (r.entrada === 'pula') { const e = fx(0, 0.6); y = (1 - eBack(e)) * -720; sq = Math.sin(fx(0.38, 0.62) * Math.PI) * 0.13; }
  else if (r.entrada === 'desliza') { x = (1 - eOut(fx(0, 0.55))) * (r.lado < 0 ? -520 : 520); }
  else if (r.entrada === 'surge') { sq = -0.25 * (1 - eBack(fx(0, 0.45))); }
  // respiração, pulinhos, susto
  const resp = Math.sin(lt * 2.3 + sd) * 5;
  if (acao === 'comemora') y += -Math.abs(Math.sin(lt * 6.5)) * 46 * fx(0.3, 0.5);
  if (acao === 'surpresa') { const k = fx(0.2, 0.45); y += -Math.sin(k * Math.PI) * 60; sq += -Math.sin(k * Math.PI) * 0.08; }
  const inc = acao === 'pensa' ? 7 * eOut(fx(0.2, 0.7)) : Math.sin(lt * 1.3 + sd) * 2.2;
  P.tudo.setAttribute('transform', `translate(${x} ${y + resp}) translate(200 615) scale(${1 + sq} ${1 - sq}) translate(-200 -615)`);
  if (P.sombra) { P.sombra.setAttribute('rx', 130 + Math.min(0, y) * 0.12); P.sombra.setAttribute('opacity', 0.45 * (r.entrada === 'pula' ? fx(0.1, 0.55) : 1)); }
  if (P.cabeca) P.cabeca.setAttribute('transform', `rotate(${inc} ${P.cabeca.dataset.ox} ${P.cabeca.dataset.oy})`);

  // braços (graus; negativo = sobe o braço direito)
  let aD = Math.sin(lt * 2.3 + sd + 1) * 4, aE = -Math.sin(lt * 2.3 + sd) * 4;
  if (acao === 'acena') { const on = fx(0.25, 0.5) * (1 - fx(Math.max(0.6, dur - 0.5), Math.max(0.9, dur - 0.2))); aD += (-122 + Math.sin(lt * 11) * 24) * on; }
  if (acao === 'aponta') aD += -78 * eOut(fx(0.2, 0.5));
  if (acao === 'comemora') { const k = eOut(fx(0.15, 0.4)); aD += (-150 + Math.sin(lt * 13) * 10) * k; aE += (150 - Math.sin(lt * 13) * 10) * k; }
  if (acao === 'pensa') aE += -145 * eOut(fx(0.2, 0.6));   // mão no queixo
  if (acao === 'surpresa') { const k = eOut(fx(0.15, 0.4)); aD += -60 * k; aE += 60 * k; }
  if (acao === 'fala') aD += (-28 + Math.sin(lt * 4) * 14) * fx(0.2, 0.5);
  const gira = (g, a) => g && g.setAttribute('transform', `rotate(${a} ${g.dataset.ox} ${g.dataset.oy})`);
  gira(P.bD, aD); gira(P.bE, aE);

  // olhos: piscadas em tempos fixos pela semente; olhar para o lado de quem fala
  let pis = 0;
  for (let k = 0; k < 8; k++) { const tp = 1.1 + k * 2.6 + ((sd * 7 + k * 3) % 10) / 10; const q = cl((lt - tp) / 0.16); pis = Math.max(pis, Math.sin(q * Math.PI)); }
  if (acao === 'surpresa') pis = 0;
  P.palp.forEach((p) => p.setAttribute('height', pis * Number(p.dataset.h)));
  const ox = acao === 'pensa' ? 6 : (r.olhar || 0) * 9 + Math.sin(lt * 0.8 + sd) * 3;
  const oy = acao === 'pensa' || acao === 'comemora' ? -8 : 0;
  const esc = acao === 'surpresa' ? 0.72 + 0.28 * (1 - fx(0.15, 0.35)) : 1;
  P.pup.forEach((p) => p.setAttribute('transform', `translate(${ox} ${oy}) translate(${p.dataset.cx} ${p.dataset.cy}) scale(${esc}) translate(${-p.dataset.cx} ${-p.dataset.cy})`));
  const sob = acao === 'surpresa' ? -14 : acao === 'pensa' ? -6 : 0;
  P.sob.forEach((s, i) => s.getAttribute('d') && s.setAttribute('transform', `translate(0 ${sob}) rotate(${acao === 'pensa' ? (i ? -8 : 0) : 0} 200 160)`));

  // boca: fala = abre/fecha no ritmo de sílabas; sorriso, "O" de surpresa
  if (P.boca) {
    const cx = +P.boca.dataset.cx, cy = +P.boca.dataset.cy, w = +P.boca.dataset.w;
    const falando = (r.falas || []).some(([a, b]) => t >= a && t < b - 0.12) || (acao === 'fala' && lt > 0.3 && lt < dur - 0.2 && !(r.falas || []).length);
    let d;
    if (falando) { const ab = (0.35 + 0.65 * Math.abs(Math.sin(lt * 12.5 + sd))) * w * 0.62; d = `M${cx - w / 2} ${cy} Q${cx} ${cy - 6} ${cx + w / 2} ${cy} Q${cx} ${cy + ab * 1.6} ${cx - w / 2} ${cy}Z`; }
    else if (acao === 'surpresa') { const rr = w * 0.26; d = `M${cx - rr} ${cy + 6} a${rr} ${rr * 1.25} 0 1 0 ${rr * 2} 0 a${rr} ${rr * 1.25} 0 1 0 ${-rr * 2} 0Z`; }
    else if (acao === 'pensa') d = `M${cx - w * 0.3} ${cy + 6} Q${cx} ${cy + 2} ${cx + w * 0.32} ${cy + 10} Q${cx} ${cy + 10} ${cx - w * 0.3} ${cy + 6}Z`;
    else { const s = acao === 'comemora' ? 0.75 : 0.42; d = `M${cx - w / 2} ${cy} Q${cx} ${cy + w * s} ${cx + w / 2} ${cy} Q${cx} ${cy + w * s * 0.35} ${cx - w / 2} ${cy}Z`; }
    P.boca.setAttribute('d', d);
  }
  if (P.luz) P.luz.setAttribute('opacity', Math.floor(lt * 2) % 2 ? 0.25 : 1);
}

/** Recorte animado (foto/PNG do usuário): a peça inteira se mexe — entra, respira, quica ao falar, acena balançando,
 *  comemora pulando, pensa inclinando, se assusta dando um pulo. Só depende de t (mesmo t = mesma imagem). */
export function animarRecorte(raiz, r, t) {
  if (!raiz.__p) raiz.__p = { corpo: raiz.querySelector('.foto-corpo'), sombra: raiz.querySelector('.foto-sombra') };
  const P = raiz.__p; if (!P.corpo) return;
  const lt = t - r.t0, dur = r.t1 - r.t0, sd = r.semente || 0, acao = r.acao || 'parado';
  const cl = (x, a = 0, b = 1) => Math.max(a, Math.min(b, x));
  const fx = (a, b) => cl((lt - a) / (b - a));
  const eOut = (x) => 1 - (1 - x) ** 3;
  const eBack = (x) => { const c = 1.70158; return 1 + (c + 1) * (x - 1) ** 3 + c * (x - 1) ** 2; };
  const h = raiz.offsetHeight || 600, k = h / 640;           // valores pensados para 640 px de altura
  let y = 0, x = 0, sx = 1, sy = 1, rot = 0, op = 1;
  if (r.entrada === 'pula') { y = (1 - eBack(fx(0, 0.6))) * -700 * k; const q = Math.sin(fx(0.38, 0.62) * Math.PI) * 0.12; sx += q; sy -= q; }
  else if (r.entrada === 'desliza') x = (1 - eOut(fx(0, 0.55))) * (r.lado < 0 ? -1 : 1) * 700 * k;
  else if (r.entrada === 'surge') { const e = eBack(fx(0, 0.45)); sx *= 0.4 + 0.6 * e; sy *= 0.4 + 0.6 * e; op = cl(fx(0, 0.2)); }
  sy *= 1 + Math.sin(lt * 2.3 + sd) * 0.012;                 // respiração
  const falando = (r.falas || []).some(([a, b]) => t >= a && t < b - 0.12) || (acao === 'fala' && lt > 0.3 && lt < dur - 0.2 && !(r.falas || []).length);
  if (falando) { y -= Math.abs(Math.sin(lt * 12.5 + sd)) * 9 * k; rot += Math.sin(lt * 5.5 + sd) * 1.8; }
  if (acao === 'acena') rot += Math.sin(lt * 9) * 6 * fx(0.25, 0.45);
  if (acao === 'aponta') rot += (r.olhar || 1) * 7 * eOut(fx(0.2, 0.5));
  if (acao === 'comemora') { y -= Math.abs(Math.sin(lt * 6.5)) * 50 * k * fx(0.2, 0.4); rot += Math.sin(lt * 13) * 4; }
  if (acao === 'pensa') { rot += -5 * eOut(fx(0.2, 0.7)) + Math.sin(lt * 1.4) * 1.5; }
  if (acao === 'surpresa') { const q = fx(0.15, 0.5); y -= Math.sin(q * Math.PI) * 70 * k; const p = Math.sin(q * Math.PI) * 0.1; sx += p; sy += p; }
  if (acao === 'parado') rot += Math.sin(lt * 1.3 + sd) * 1.2;
  if (r.espelhar) sx = -sx;
  P.corpo.style.transform = `translate(${x}px, ${y}px) rotate(${rot}deg) scale(${sx}, ${sy})`;
  P.corpo.style.opacity = op;
  if (P.sombra) { P.sombra.style.transform = `translateX(${x}px) scale(${1 + Math.min(0, y) / (500 * k)})`; P.sombra.style.opacity = String(0.45 * op * (r.entrada === 'pula' ? fx(0.1, 0.55) : 1)); }
}
