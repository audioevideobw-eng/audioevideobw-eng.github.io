/* motor/gerador3d.mjs — GERADOR 3D NO PC DO USUÁRIO (app BW, 20/11/2026).
   Instala no computador o Hunyuan3D 2 mini (só a FORMA, 0,6B) e gera MALHA a partir de uma foto,
   sem enviar nada para lugar nenhum. Tudo mora em ~/.bw-reels/3d (nunca na pasta do app: a
   atualização do BW não toca aqui — regra 104).
   Conferido em 20/11/2026: repo github.com/Tencent-Hunyuan/Hunyuan3D-2 (pip install -r requirements.txt
   + pip install -e .); modelo tencent/Hunyuan3D-2mini, subpasta hunyuan3d-dit-v2-mini; licença
   "tencent-hunyuan-community" (uso na União Europeia não é liberado pelo autor); mínimo oficial para
   só a forma: 6 GB de VRAM, 16 GB de RAM, 20 GB de disco, CUDA 11+. */
import { spawn, spawnSync } from 'node:child_process';
import { mkdirSync, existsSync, writeFileSync, readFileSync, readdirSync, rmSync, statfsSync } from 'node:fs';
import { join } from 'node:path';
import { homedir, totalmem, platform } from 'node:os';

const WIN = process.platform === 'win32';
export const RAIZ3D = join(homedir(), '.bw-reels', '3d');
const REPO = join(RAIZ3D, 'Hunyuan3D-2');
const VENV = join(RAIZ3D, 'venv');
const MODELOS = join(RAIZ3D, 'modelos');
const SAIDAS = join(RAIZ3D, 'saidas');
const ESTADO = join(RAIZ3D, 'estado.json');
const SIM = () => process.env.BW3D_SIMULADO === '1';
const pyVenv = () => (WIN ? join(VENV, 'Scripts', 'python.exe') : join(VENV, 'bin', 'python'));

export const LICENCA = {
  nome: 'Tencent Hunyuan Community License',
  url: 'https://huggingface.co/tencent/Hunyuan3D-2/blob/main/LICENSE.txt',
  resumo: 'O modelo é do Tencent e vem com licença própria (uso comunitário). O autor NÃO libera o uso na União Europeia. ' +
    'Leia antes de usar em trabalho de cliente — o que você modela com ele é seu, mas o modelo de IA continua sendo deles.'
};

/* ---------- o que a máquina tem ---------- */
function roda(cmd, args, op = {}) {
  try {
    const r = spawnSync(cmd, args, { encoding: 'utf8', timeout: op.timeout || 15000, windowsHide: true });
    return { ok: r.status === 0, saida: String(r.stdout || '').trim(), erro: String(r.stderr || '').trim() };
  } catch (e) { return { ok: false, saida: '', erro: e.message }; }
}
/* a versão da Microsoft Store mora numa pasta protegida (WindowsApps): o venv nasce, mas o
   `pip install -e .` e o PyTorch falham lá dentro — o dono instalou essa por engano em 20/11 */
const DA_STORE = /WindowsApps|PythonSoftwareFoundation\.Python/i;
function versaoPy(cmd, args) {
  const r = roda(cmd, args);
  const m = /Python (\d+)\.(\d+)/.exec(r.saida || r.erro || '');
  if (!r.ok || !m) return null;
  const onde = roda(cmd, [...args.filter((a) => a !== '--version'), '-c', 'import sys;print(sys.executable)']);
  const exe = (onde.saida || '').split('\n')[0].trim();
  return { versao: m[0], maior: +m[1], menor: +m[2], exe, daStore: DA_STORE.test(exe || String(cmd)) };
}
/* onde o instalador do python.org e o winget costumam deixar o python quando a caixinha
   "Add python.exe to PATH" passa batido (foi o que aconteceu no PC do dono em 20/11) */
function pythonsNoDisco() {
  if (!WIN) return [];
  const achados = [], pastas = [
    join(homedir(), 'AppData', 'Local', 'Programs', 'Python'),
    'C:\\Program Files', 'C:\\Program Files (x86)', 'C:\\'
  ];
  for (const base of pastas) {
    let itens = [];
    try { itens = readdirSync(base); } catch (e) { continue; }
    for (const it of itens) {
      if (!/^Python3\d+$/i.test(it)) continue;
      const exe = join(base, it, 'python.exe');
      if (existsSync(exe)) achados.push(exe);
    }
  }
  const launcher = join(process.env.WINDIR || 'C:\\Windows', 'py.exe');
  if (existsSync(launcher)) achados.push(launcher);
  return achados;
}
/* faixa em que existe roda do PyTorch COM CUDA no Windows + torchvision (conferido em 20/11/2026:
   o 3.15 ainda não tem torchvision, e as primeiras rodas de torch 3.15 saíram só para Linux) */
export const PY_FAIXA = { min: 10, max: 13, indicado: '3.12' };
const naFaixa = (v) => v && v.maior === 3 && v.menor >= PY_FAIXA.min && v.menor <= PY_FAIXA.max;
function candidatosPy() {
  const c = [];
  if (WIN) {
    for (let m = PY_FAIXA.max; m >= PY_FAIXA.min; m--) c.push({ cmd: 'py', base: ['-3.' + m] });
    c.push({ cmd: 'py', base: ['-3'] }, { cmd: 'python', base: [] });
  } else c.push({ cmd: 'python3', base: [] }, { cmd: 'python', base: [] });
  for (const exe of pythonsNoDisco()) c.push({ cmd: exe, base: /py\.exe$/i.test(exe) ? ['-3'] : [], foraDoPath: true });
  return c;
}
function acharPython() {
  let fora = null, store = null;
  for (const c of candidatosPy()) {
    const v = versaoPy(c.cmd, [...c.base, '--version']);
    if (!v || v.maior !== 3) continue;
    const achado = { ok: true, cmd: v.exe || c.cmd, base: v.exe ? [] : c.base, foraDoPath: !!c.foraDoPath, ...v };
    if (v.daStore) { if (!store) store = achado; continue; }         // a da Store nunca serve
    if (naFaixa(v)) return achado;                                   // serve: pega o primeiro (do mais novo da faixa para baixo)
    if (!fora || v.menor > fora.menor) fora = { ...achado, foraDaFaixa: true };
  }
  return fora || store || { ok: false };
}
function acharGit() {
  if (roda('git', ['--version']).ok) return 'git';
  if (!WIN) return '';
  for (const p of ['C:\\Program Files\\Git\\cmd\\git.exe', 'C:\\Program Files (x86)\\Git\\cmd\\git.exe',
    join(homedir(), 'AppData', 'Local', 'Programs', 'Git', 'cmd', 'git.exe')]) {
    if (existsSync(p) && roda(p, ['--version']).ok) return p;
  }
  return '';
}
function discoLivreGB(dir) {
  try { const s = statfsSync(existsSync(dir) ? dir : homedir()); return Math.round((s.bavail * s.bsize) / 1073741824); } catch (e) { return 0; }
}
export function requisitos() {
  if (SIM()) {
    /* BW3D_SIM_FALTA=1 finge a máquina do dono em 20/11: placa boa, sem Python e sem Git */
    const falta = process.env.BW3D_SIM_FALTA === '1';
    /* BW3D_SIM_PY=3.15 finge o Python novo demais que o dono instalou em 20/11 */
    const mv = /^3\.(\d+)$/.exec(process.env.BW3D_SIM_PY || '');
    const menor = mv ? +mv[1] : 11;
    const py = { ok: true, cmd: 'python', base: [], versao: 'Python 3.' + menor + '.0', maior: 3, menor };
    if (menor < PY_FAIXA.min || menor > PY_FAIXA.max) py.foraDaFaixa = true;
    if (process.env.BW3D_SIM_STORE === '1') py.daStore = true;      /* finge a versão da Microsoft Store */
    return julgar({ gpu: { nome: 'NVIDIA GeForce RTX 3050 6GB Laptop GPU', vram: 6, cuda: '12.4' },
      python: falta ? { ok: false } : py,
      git: !falta, gitCmd: falta ? '' : 'git', discoGB: 60, ramGB: 16, so: 'Windows' });
  }
  const nv = roda('nvidia-smi', ['--query-gpu=name,memory.total,driver_version', '--format=csv,noheader,nounits']);
  let gpu = { nome: '', vram: 0, cuda: '' };
  if (nv.ok && nv.saida) { const [n, m] = nv.saida.split('\n')[0].split(',').map((x) => x.trim()); gpu = { nome: n, vram: Math.round(Number(m || 0) / 1024), cuda: '' }; }
  const smi = roda('nvidia-smi', []); const mc = /CUDA Version: *([\d.]+)/.exec(smi.saida || ''); if (mc) gpu.cuda = mc[1];
  const py = acharPython(), gitCmd = acharGit();
  return julgar({ gpu, python: py, git: !!gitCmd, gitCmd, discoGB: discoLivreGB(RAIZ3D), ramGB: Math.round(totalmem() / 1073741824), so: WIN ? 'Windows' : platform() });
}
/* o julgamento é o MESMO para a máquina real e para o teste simulado */
function julgar(q) {
  const gpu = q.gpu, py = q.python, git = q.git, ramGB = q.ramGB, discoGB = q.discoGB;
  const motivos = [], aviso = [];
  if (!gpu.nome) motivos.push('Não achei uma placa NVIDIA neste computador. O gerador roda em CUDA (NVIDIA); em placa AMD, Intel ou Apple, não dá.');
  else if (gpu.vram && gpu.vram < 6) motivos.push('A sua placa tem ' + gpu.vram + ' GB; o mínimo oficial para gerar a forma é 6 GB.');
  if (!py.ok) motivos.push('Falta o Python 3 (instale em python.org e marque "Add to PATH").');
  else if (py.daStore) motivos.push('O Python deste PC veio da Microsoft Store — ele mora numa pasta protegida do Windows e o gerador não consegue instalar as peças dele lá. ' +
    'Desinstale esse (Aplicativos instalados → Python → Desinstalar) e use o do python.org.');
  else if (py.menor < PY_FAIXA.min) motivos.push('O Python é o ' + py.versao + '; o gerador pede 3.' + PY_FAIXA.min + ' ou mais novo.');
  else if (py.menor > PY_FAIXA.max) motivos.push('O Python deste PC é o ' + py.versao + ' — novo demais: o PyTorch com placa NVIDIA e o torchvision ainda não têm versão para ele no Windows. ' +
    'Instale o Python ' + PY_FAIXA.indicado + ' (pode ficar junto com o que você já tem, um não atrapalha o outro).');
  if (!git) motivos.push('Falta o Git (instale em git-scm.com) — é como o código do gerador é baixado.');
  if (discoGB && discoGB < 20) motivos.push('Faltam ' + (20 - discoGB) + ' GB de disco: a instalação ocupa cerca de 20 GB.');
  if (ramGB && ramGB < 16) aviso.push('Este PC tem ' + ramGB + ' GB de RAM. O mínimo é 16 GB — com menos, pode faltar memória no meio da geração.');
  if (gpu.vram && gpu.vram < 16) aviso.push('Com ' + gpu.vram + ' GB de vídeo sai a FORMA (a malha), sem textura — a textura pede 16 GB ou mais.');
  if (ramGB === 16 && gpu.vram && gpu.vram <= 8) aviso.push('Você está no mínimo da receita: feche os outros programas enquanto gera.');
  return { ...q, pronto: motivos.length === 0, motivos, aviso };
}

/* ---------- estado da instalação ---------- */
function lerEstado() { try { return JSON.parse(readFileSync(ESTADO, 'utf8')); } catch (e) { return { etapas: {}, log: [] }; } }
function gravarEstado(e) { mkdirSync(RAIZ3D, { recursive: true }); writeFileSync(ESTADO, JSON.stringify(e, null, 2)); }
export function estado() {
  const e = lerEstado(), feitas = Object.keys(e.etapas || {}).filter((k) => e.etapas[k] === 'ok');
  return { instalado: !!e.instalado, etapas: e.etapas || {}, feitas: feitas.length, total: ETAPAS.length,
    emAndamento: !!EM_ANDAMENTO, etapaAtual: EM_ANDAMENTO ? EM_ANDAMENTO.etapa : '', erro: e.erro || '',
    quando: e.quando || '', modelo: e.modelo || '', log: (e.log || []).slice(-80), raiz: RAIZ3D, licenca: LICENCA };
}

/* ---------- as etapas da instalação ---------- */
const ETAPAS = [
  { id: 'pastas', nome: 'Preparando as pastas' },
  { id: 'venv', nome: 'Criando o ambiente Python' },
  { id: 'torch', nome: 'Baixando o PyTorch com CUDA (o maior pedaço, ~2,5 GB)' },
  { id: 'codigo', nome: 'Baixando o código do gerador' },
  { id: 'deps', nome: 'Instalando o que o gerador precisa' },
  { id: 'pacote', nome: 'Instalando o gerador' },
  { id: 'modelo', nome: 'Baixando o modelo Hunyuan3D 2 mini (~3 GB)' },
  { id: 'roteiro', nome: 'Escrevendo o programa que gera a malha' },
  { id: 'teste', nome: 'Testando com uma imagem de prova' }
];
export { ETAPAS };

let EM_ANDAMENTO = null;
function logar(e, linha) { e.log = (e.log || []).concat(String(linha).trim().slice(0, 400)).slice(-200); gravarEstado(e); }

function execLongo(cmd, args, op, aoLog) {
  return new Promise((ok) => {
    if (SIM()) { aoLog('[simulado] ' + cmd + ' ' + args.join(' ')); return setTimeout(() => ok({ ok: true }), 5); }
    const p = spawn(cmd, args, { cwd: op.cwd || RAIZ3D, env: { ...process.env, ...(op.env || {}) }, windowsHide: true });
    let ultimo = '';
    const ler = (b) => { const t = String(b); ultimo = t.slice(-400); t.split('\n').filter((x) => x.trim()).slice(-3).forEach(aoLog); };
    p.stdout.on('data', ler); p.stderr.on('data', ler);
    p.on('error', (e) => ok({ ok: false, erro: e.message }));
    p.on('close', (c) => ok({ ok: c === 0, erro: c === 0 ? '' : 'terminou com erro ' + c + ': ' + ultimo }));
  });
}

const ROTEIRO = `# gerar.py - escrito pelo app BW. Foto -> malha 3D, tudo neste computador.
import sys, os, json
os.environ.setdefault("HY3DGEN_MODELS", os.path.join(os.path.dirname(os.path.abspath(__file__)), "modelos"))
from hy3dgen.shapegen import Hunyuan3DDiTFlowMatchingPipeline

def main():
    entrada, saida = sys.argv[1], sys.argv[2]
    passos = int(sys.argv[3]) if len(sys.argv) > 3 else 30
    resolucao = int(sys.argv[4]) if len(sys.argv) > 4 else 256
    pipe = Hunyuan3DDiTFlowMatchingPipeline.from_pretrained(
        "tencent/Hunyuan3D-2mini", subfolder="hunyuan3d-dit-v2-mini", use_safetensors=True, device="cuda")
    malha = pipe(image=entrada, num_inference_steps=passos, octree_resolution=resolucao)[0]
    malha.export(saida)
    print(json.dumps({"ok": True, "arquivo": saida}))

if __name__ == "__main__":
    main()
`;

/* ---------- Python e Git: o que falta, instalado pelo winget do Windows ----------
   (20/11: no PC do dono os dois faltavam e o botão de instalar ficava apagado) */
/* link DIRETO do arquivo certo (conferido na página oficial em 20/11/2026) — a página geral baixa a versão
   mais nova (3.15, que não serve) e a busca cai na Microsoft Store, que instala numa pasta protegida */
export const BASICOS = [
  { id: 'python', nome: 'Python ' + PY_FAIXA.indicado, winget: 'Python.Python.' + PY_FAIXA.indicado,
    site: 'https://www.python.org/ftp/python/3.12.10/python-3.12.10-amd64.exe',
    arquivo: 'python-3.12.10-amd64.exe',
    dica: 'marque "Add python.exe to PATH" na primeira tela; não use a versão da Microsoft Store' },
  { id: 'git', nome: 'Git', winget: 'Git.Git', site: 'https://git-scm.com/download/win',
    arquivo: 'Git para Windows', dica: 'é só ir no Next até o fim' }
];
export function temWinget() { return SIM() ? true : WIN && roda('winget', ['--version']).ok; }
export function faltamBasicos() {
  const r = requisitos();
  return BASICOS.filter((b) => (b.id === 'python' ? !r.python.ok || r.python.foraDaFaixa || r.python.daStore : !r.git));
}
export async function instalarBasicos(aoAndar) {
  if (EM_ANDAMENTO) return { ok: false, erro: 'já está instalando' };
  if (!WIN && !SIM()) return { ok: false, erro: 'Instalação automática só no Windows — instale o Python e o Git pelos sites.' };
  if (!temWinget()) return { ok: false, erro: 'Este Windows não tem o winget. Instale o Python (marcando "Add python.exe to PATH") e o Git pelos sites.' };
  const faltam = faltamBasicos();
  if (!faltam.length) return { ok: true, nada: true };
  const e = lerEstado();
  for (const b of faltam) {
    EM_ANDAMENTO = { etapa: 'basicos', texto: 'Instalando o ' + b.nome };
    logar(e, 'Instalando o ' + b.nome + '…'); if (aoAndar) aoAndar('basicos', 'Instalando o ' + b.nome + '…');
    const r = await execLongo('winget', ['install', '-e', '--id', b.winget, '--accept-source-agreements',
      '--accept-package-agreements', '--silent'], {}, (l) => logar(e, l));
    if (!r.ok) {
      EM_ANDAMENTO = null;
      return { ok: false, erro: 'Não consegui instalar o ' + b.nome + ' sozinho. Baixe em ' + b.site + ' (no Python, marque "Add python.exe to PATH").' };
    }
  }
  EM_ANDAMENTO = null;
  if (SIM()) delete process.env.BW3D_SIM_FALTA;
  const agora = requisitos();
  return { ok: true, pronto: agora.pronto, motivos: agora.motivos };
}

export async function instalar(aoAndar) {
  if (EM_ANDAMENTO) return { ok: false, erro: 'já está instalando' };
  const req = requisitos();
  if (!req.pronto) return { ok: false, erro: req.motivos.join(' ') };
  const e = lerEstado(); e.erro = ''; gravarEstado(e);
  const py = req.python, pyCmd = py.cmd, pyBase = py.base || [];
  const anda = (etapa, texto) => { EM_ANDAMENTO = { etapa, texto }; logar(e, texto); if (aoAndar) aoAndar(etapa, texto); };
  const falhar = (etapa, erro) => { e.etapas[etapa] = 'erro'; e.erro = erro; gravarEstado(e); EM_ANDAMENTO = null; return { ok: false, etapa, erro }; };
  try {
    for (const et of ETAPAS) {
      if (e.etapas[et.id] === 'ok' && et.id !== 'teste') { if (aoAndar) aoAndar(et.id, 'já feito'); continue; }
      anda(et.id, et.nome);
      let r = { ok: true };
      if (et.id === 'pastas') { for (const d of [RAIZ3D, MODELOS, SAIDAS]) mkdirSync(d, { recursive: true }); }
      else if (et.id === 'venv') r = await execLongo(pyCmd, [...pyBase, '-m', 'venv', VENV], {}, (l) => logar(e, l));
      else if (et.id === 'torch') r = await execLongo(pyVenv(), ['-m', 'pip', 'install', '--upgrade', 'torch', 'torchvision', '--index-url', 'https://download.pytorch.org/whl/cu124'], {}, (l) => logar(e, l));
      else if (et.id === 'codigo') r = existsSync(join(REPO, 'requirements.txt')) ? { ok: true }
        : await execLongo(req.gitCmd || 'git', ['clone', '--depth', '1', 'https://github.com/Tencent-Hunyuan/Hunyuan3D-2.git', REPO], {}, (l) => logar(e, l));
      else if (et.id === 'deps') r = await execLongo(pyVenv(), ['-m', 'pip', 'install', '-r', join(REPO, 'requirements.txt')], { cwd: REPO }, (l) => logar(e, l));
      else if (et.id === 'pacote') { r = await execLongo(pyVenv(), ['-m', 'pip', 'install', '-e', '.'], { cwd: REPO }, (l) => logar(e, l));
        if (r.ok) r = await execLongo(pyVenv(), ['-m', 'pip', 'install', 'huggingface_hub', 'trimesh', 'pillow'], {}, (l) => logar(e, l)); }
      else if (et.id === 'modelo') r = await execLongo(pyVenv(), ['-c',
        'from huggingface_hub import snapshot_download;p=snapshot_download(repo_id="tencent/Hunyuan3D-2mini",allow_patterns=["hunyuan3d-dit-v2-mini/*","*.json","*.txt"],local_dir=r"' + join(MODELOS, 'tencent', 'Hunyuan3D-2mini') + '");print(p)'],
        { env: { HY3DGEN_MODELS: MODELOS, HF_HUB_DISABLE_TELEMETRY: '1' } }, (l) => logar(e, l));
      else if (et.id === 'roteiro') { writeFileSync(join(RAIZ3D, 'gerar.py'), ROTEIRO); if (SIM()) writeFileSync(join(RAIZ3D, 'prova.glb'), 'glb'); }
      else if (et.id === 'teste') { const t = await gerarProva(); r = t.ok ? { ok: true } : { ok: false, erro: t.erro }; }
      if (!r.ok) return falhar(et.id, r.erro || 'não deu certo');
      e.etapas[et.id] = 'ok'; gravarEstado(e);
    }
    e.instalado = true; e.quando = new Date().toISOString(); e.modelo = 'Hunyuan3D-2mini (forma)'; gravarEstado(e);
    EM_ANDAMENTO = null;
    return { ok: true, raiz: RAIZ3D };
  } catch (err) { return falhar(EM_ANDAMENTO ? EM_ANDAMENTO.etapa : '?', err.message); }
}

/* ---------- gerar ---------- */
async function gerarProva() {
  if (SIM()) return { ok: true, arquivo: join(RAIZ3D, 'prova.glb') };
  const png = join(RAIZ3D, 'prova.png');
  const fazPng = await execLongo(pyVenv(), ['-c',
    'from PIL import Image,ImageDraw;i=Image.new("RGBA",(512,512),(0,0,0,0));d=ImageDraw.Draw(i);d.ellipse((120,120,392,392),fill=(220,200,160,255));i.save(r"' + png + '")'], {}, () => {});
  if (!fazPng.ok) return { ok: false, erro: 'não consegui criar a imagem de prova: ' + fazPng.erro };
  return gerar({ imagem: png, saida: join(RAIZ3D, 'prova.glb'), passos: 20, resolucao: 192 });
}
export async function gerar({ imagem, saida, passos, resolucao } = {}) {
  if (!imagem || !existsSync(imagem)) return { ok: false, erro: 'não achei a imagem' };
  const alvo = saida || join(SAIDAS, 'bw3d-' + Date.now() + '.glb');
  mkdirSync(SAIDAS, { recursive: true });
  if (SIM()) { writeFileSync(alvo, 'glb simulado'); return { ok: true, arquivo: alvo, segundos: 1 }; }
  const t0 = Date.now(), e = lerEstado();
  const r = await execLongo(pyVenv(), [join(RAIZ3D, 'gerar.py'), imagem, alvo, String(passos || 30), String(resolucao || 256)],
    { env: { HY3DGEN_MODELS: MODELOS } }, (l) => logar(e, l));
  if (!r.ok) return { ok: false, erro: r.erro };
  if (!existsSync(alvo)) return { ok: false, erro: 'o gerador terminou mas não gravou o arquivo' };
  return { ok: true, arquivo: alvo, segundos: Math.round((Date.now() - t0) / 1000) };
}
export function remover() {
  try { rmSync(RAIZ3D, { recursive: true, force: true }); EM_ANDAMENTO = null; return { ok: true }; }
  catch (e) { return { ok: false, erro: e.message }; }
}
