#!/usr/bin/env node
// Monta o PROGRAMA BW (Electron) a partir do pacote electron baixado pelo npm install: copia o runtime para programa/,
// renomeia electron.exe → BW.exe, troca ícone e nome do arquivo (rcedit, só no Windows) e aponta o app para electron/main.mjs.
// Cria também o atalho "BW (novo)" na Área de Trabalho e no menu Iniciar (o BW antigo continua igual, lado a lado).
// Rápido quando já está pronto (marca em programa/.bw-pronto). Uso: node motor/preparar-bw.mjs [--quieto] [--sem-atalho]
import { existsSync, cpSync, renameSync, writeFileSync, readFileSync, mkdirSync, rmSync } from 'node:fs';
import { join, relative, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawnSync } from 'node:child_process';
import { homedir } from 'node:os';

const RAIZ = join(dirname(fileURLToPath(import.meta.url)), '..');
const WIN = process.platform === 'win32';
const QUIETO = process.argv.includes('--quieto');
const diz = (m) => { if (!QUIETO) console.log('  ' + m); };
const DIST = join(RAIZ, 'node_modules', 'electron', 'dist');
const PROG = join(RAIZ, 'programa');
const EXE = WIN ? 'BW.exe' : 'bw';
const ICONE = join(RAIZ, 'bw-reels.ico');

export function caminhoExe() { return join(PROG, EXE); }

export async function preparar({ atalho = true } = {}) {
  let versaoEl = '';
  try { versaoEl = JSON.parse(readFileSync(join(RAIZ, 'node_modules', 'electron', 'package.json'), 'utf8')).version; } catch { /* sem electron */ }
  if (!versaoEl || !existsSync(DIST)) { diz('O componente do programa (electron) ainda não foi baixado: rode o 2 - INSTALAR.'); return { ok: false, motivo: 'sem-electron' }; }
  const marca = join(PROG, '.bw-pronto'), quero = 'electron ' + versaoEl;
  let pronto = false; try { pronto = readFileSync(marca, 'utf8') === quero && existsSync(join(PROG, EXE)); } catch { /* novo */ }
  if (!pronto) {
    diz('Montando o programa BW (electron ' + versaoEl + ')…');
    try { rmSync(PROG, { recursive: true, force: true }); } catch (e) { diz('O BW (novo) está aberto: feche e rode de novo.'); return { ok: false, motivo: 'aberto' }; }
    cpSync(DIST, PROG, { recursive: true });
    const orig = join(PROG, WIN ? 'electron.exe' : process.platform === 'darwin' ? 'Electron.app' : 'electron');
    if (existsSync(orig) && process.platform !== 'darwin') renameSync(orig, join(PROG, EXE));
    try { rmSync(join(PROG, 'resources', 'default_app.asar'), { force: true }); } catch { /* ok */ }
    const app = join(PROG, 'resources', 'app'); mkdirSync(app, { recursive: true });
    let versao = '0.0.0'; try { versao = (/VERSAO = '([\d.]+)'/.exec(readFileSync(join(RAIZ, 'motor', 'app.mjs'), 'utf8')) || [])[1] || versao; } catch { /* ok */ }
    writeFileSync(join(app, 'package.json'), JSON.stringify({ name: 'bw', productName: 'BW', version: versao, type: 'module',
      main: relative(app, join(RAIZ, 'electron', 'main.mjs')).split('\\').join('/') }, null, 2));
    if (WIN) {
      try {
        const m = await import('rcedit'); const rcedit = m.rcedit || (typeof m.default === 'function' ? m.default : m.default && m.default.rcedit);
        await rcedit(join(PROG, EXE), { icon: ICONE, 'file-version': versao, 'product-version': versao,
          'version-string': { FileDescription: 'BW', ProductName: 'BW', CompanyName: 'BW Audiovisual', InternalName: 'BW', OriginalFilename: 'BW.exe', LegalCopyright: 'BW Audiovisual' } });
        diz('Ícone e nome BW gravados no BW.exe.');
      } catch (e) { diz('Não consegui gravar o ícone no BW.exe (' + (e.message || e) + '); o programa abre mesmo assim.'); }
    }
    writeFileSync(marca, quero);
  }
  if (WIN && atalho) criarAtalhos();
  diz('Pronto: ' + join(PROG, EXE));
  return { ok: true, exe: join(PROG, EXE), montou: !pronto };
}

function criarAtalhos() {
  const alvo = join(PROG, EXE);
  const lugares = [join(homedir(), 'Desktop'), join(process.env.APPDATA || join(homedir(), 'AppData', 'Roaming'), 'Microsoft', 'Windows', 'Start Menu', 'Programs')];
  for (const pasta of lugares) {
    const lnk = join(pasta, 'BW (novo).lnk');
    if (!existsSync(pasta) || existsSync(lnk)) continue;
    const ps = `$s=(New-Object -ComObject WScript.Shell).CreateShortcut('${lnk.replace(/'/g, "''")}');$s.TargetPath='${alvo.replace(/'/g, "''")}';$s.WorkingDirectory='${RAIZ.replace(/'/g, "''")}';$s.IconLocation='${alvo.replace(/'/g, "''")},0';$s.Description='BW - programa';$s.Save()`;
    spawnSync('powershell', ['-NoProfile', '-ExecutionPolicy', 'Bypass', '-Command', ps], { windowsHide: true, stdio: 'ignore' });
  }
}

const DIRETO = process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1];
if (DIRETO) { const r = await preparar({ atalho: !process.argv.includes('--sem-atalho') }); process.exit(r.ok ? 0 : 1); }
