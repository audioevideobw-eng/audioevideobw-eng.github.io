#!/usr/bin/env node
// BW REELS RENDER — liga a plataforma (Brightway › BW Reels Pro) ao motor deste PC.
// Fica de olho na pasta Downloads: quando chega um pedido "*.bwreels.zip" (botão RENDERIZAR NO PC),
// descompacta em projetos/, renderiza o vídeo e abre o MP4 pronto. Deixe esta janela aberta.
// Uso: node motor/vigia-downloads.mjs [--pasta "C:\caminho\Downloads"] [--rascunho] [--uma-vez]

import { readdirSync, statSync, mkdirSync, renameSync, existsSync, readFileSync, copyFileSync } from 'node:fs';
import { join, resolve, dirname, basename } from 'node:path';
import { spawn, spawnSync } from 'node:child_process';
import { homedir, platform } from 'node:os';
import { fileURLToPath } from 'node:url';
import { envNode } from './node-exe.mjs';

const RAIZ = resolve(dirname(fileURLToPath(import.meta.url)), '..');
const args = process.argv.slice(2);
const opt = (n) => { const i = args.indexOf(`--${n}`); return i >= 0 ? args[i + 1] : null; };
const flag = (n) => args.includes(`--${n}`);
const hora = () => new Date().toLocaleTimeString('pt-BR');
const log = (m) => console.log(`[${hora()}] ${m}`);

function pastasDownloads() {
  const lista = [];
  if (opt('pasta')) lista.push(opt('pasta'));
  if (platform() === 'win32') {
    // pasta Downloads real (pode ter sido movida para outro disco ou para o OneDrive)
    const r = spawnSync('reg', ['query', 'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\User Shell Folders', '/v', '{374DE290-123F-4565-9164-39C4925E467B}'], { encoding: 'utf8' });
    const m = /REG_(?:EXPAND_)?SZ\s+(.+)/.exec(r.stdout || '');
    if (m) lista.push(m[1].trim().replace(/%([^%]+)%/g, (_, v) => process.env[v] || ''));
  }
  lista.push(join(homedir(), 'Downloads'));
  if (process.env.OneDrive) lista.push(join(process.env.OneDrive, 'Downloads'));
  return [...new Set(lista.map((p) => resolve(p)))].filter((p) => existsSync(p));
}

function descompactar(zip, destino) {
  mkdirSync(destino, { recursive: true });
  const tentativas = [
    ['tar', ['-xf', zip, '-C', destino]],                      // Windows 10/11 e Mac (bsdtar abre .zip)
    ['python3', ['-m', 'zipfile', '-e', zip, destino]],
    ['python', ['-m', 'zipfile', '-e', zip, destino]],
    ['unzip', ['-o', '-q', zip, '-d', destino]],
  ];
  for (const [cmd, a] of tentativas) {
    const r = spawnSync(cmd, a, { stdio: 'ignore' });
    if (r.status === 0 && existsSync(join(destino, 'roteiro.json'))) return true;
  }
  return false;
}

function abrir(arquivo) {
  if (process.env.BWREELS_NAO_ABRIR) return;
  if (platform() === 'win32') spawn('cmd', ['/c', 'start', '""', `"${arquivo}"`], { shell: true, detached: true, stdio: 'ignore' }).unref();
  else if (platform() === 'darwin') spawn('open', [arquivo], { detached: true, stdio: 'ignore' }).unref();
  else spawn('xdg-open', [arquivo], { detached: true, stdio: 'ignore' }).on('error', () => {}).unref();
}

function renderizar(roteiro) {
  return new Promise((ok) => {
    const a = [join(RAIZ, 'motor', 'render.mjs'), roteiro];
    if (flag('rascunho')) a.push('--rascunho');
    const p = spawn(process.execPath, a, { cwd: RAIZ, stdio: ['ignore', 'pipe', 'pipe'], env: envNode() });
    let saida = '';
    const mostrar = (b) => { const t = b.toString(); saida += t; const m = /quadro (\d+)\/(\d+)/g.exec(t); if (m) process.stdout.write(`\r          renderizando… ${Math.round((m[1] / m[2]) * 100)}%   `); };
    p.stdout.on('data', mostrar); p.stderr.on('data', (b) => { saida += b.toString(); });
    p.on('close', (cod) => { process.stdout.write('\n'); ok({ cod, saida }); });
  });
}

const vistos = new Map();   // arquivo -> tamanho na última olhada (espera o download terminar)
let ocupado = false;

async function processar(zip, pastaDl) {
  ocupado = true;
  const nome = basename(zip).replace(/\.bwreels\.zip$/i, '').replace(/[^a-zA-Z0-9-]+/g, '-').slice(0, 40) || 'reel';
  const d = new Date();
  const carimbo = `${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}${String(d.getDate()).padStart(2, '0')}-${String(d.getHours()).padStart(2, '0')}${String(d.getMinutes()).padStart(2, '0')}`;
  const destino = join(RAIZ, 'projetos', `${nome}-${carimbo}`);
  log(`📥 Pedido recebido: ${basename(zip)}`);
  try {
    if (!descompactar(zip, destino)) { log('✖ Não consegui abrir o pacote (zip incompleto?). Baixe de novo na plataforma.'); return; }
    const feitos = join(pastaDl, 'BW Reels - pedidos feitos');
    mkdirSync(feitos, { recursive: true });
    try { renameSync(zip, join(feitos, basename(zip))); } catch { /* arquivo em uso: fica onde está */ }
    let info = {}; try { info = JSON.parse(readFileSync(join(destino, 'bwreels.json'), 'utf8')); } catch { }
    log(`🎬 Renderizando "${info.nome || nome}" (projeto em projetos/${basename(destino)})`);
    const r = await renderizar(join(destino, 'roteiro.json'));
    const m = /✔ (.+\.mp4)/.exec(r.saida);
    if (r.cod !== 0 || !m) {
      log('✖ O render não terminou. Motivo:');
      console.log(r.saida.split('\n').filter((l) => /✖|ERRO|Erro|problemas|- /.test(l)).slice(0, 12).join('\n') || r.saida.slice(-800));
      return;
    }
    const mp4 = resolve(RAIZ, m[1].trim());
    const copia = join(feitos, basename(mp4));
    try { copyFileSync(mp4, copia); } catch { }
    log(`✅ Pronto! ${basename(mp4)} — cópia em Downloads/BW Reels - pedidos feitos`);
    abrir(existsSync(copia) ? copia : mp4);
  } finally { ocupado = false; }
}

function olhar(pastas) {
  if (ocupado) return;
  for (const p of pastas) {
    let itens = [];
    try { itens = readdirSync(p); } catch { continue; }
    for (const n of itens) {
      if (!/\.bwreels\.zip$/i.test(n)) continue;
      const arq = join(p, n);
      let tam = -1; try { tam = statSync(arq).size; } catch { continue; }
      if (tam > 0 && vistos.get(arq) === tam) { vistos.delete(arq); processar(arq, p); return; }
      vistos.set(arq, tam);
    }
  }
}

const pastas = pastasDownloads();
console.log('\n  BW REELS RENDER — motor ligado à plataforma Brightway › BW Reels Pro');
console.log('  Deixe esta janela aberta. Na plataforma, toque em RENDERIZAR NO PC.\n');
if (!pastas.length) { console.log('  ✖ Não achei a pasta Downloads. Use: node motor/vigia-downloads.mjs --pasta "C:\\caminho\\Downloads"'); process.exit(1); }
pastas.forEach((p) => log(`👀 de olho em: ${p}`));
if (flag('uma-vez')) { olhar(pastas); setTimeout(() => { olhar(pastas); const t = setInterval(() => { if (!ocupado) { clearInterval(t); process.exit(0); } }, 500); }, 1200); }
else setInterval(() => olhar(pastas), 2000);
