#!/usr/bin/env node
// BW Reels Assistente — abre a janela do passo a passo (assistente/index.html).
// A janela conversa com este programa direto pela ponte do navegador (sem servidor e sem endereço local).
// Uso: node motor/assistente.mjs        (teste automático: BWREELS_TESTE=1 abre sem janela e devolve { contexto, pagina })
import { join } from 'node:path';
import { pathToFileURL } from 'node:url';
import { mkdirSync } from 'node:fs';
import * as N from './assistente-nucleo.mjs';
import { PLANO, instalarRecomendadas } from './instalar-ias.mjs';

const ACOES = {
  iniciar: () => ({ checagem: N.checar(), prefs: N.lerPrefs(), galeria: N.modelos() }),
  checar: () => N.checar(),
  modos: () => N.modos(),
  ias: async () => { await N.ia.detectarLocal(); return { ...N.ia.status(), plano: PLANO }; },
  salvarIA: (d) => N.ia.salvarChave(d.id, d.chave),
  modeloIA: (d) => N.ia.trocarModelo(d.id, d.modelo),
  removerIA: (d) => N.ia.removerChave(d.id),
  proIA: (d) => N.ia.escolherPro(d.id),
  siteIA: (d) => N.abrirSite(d.id),
  guardar: (d) => N.salvarPrefs(d || {}),
  doModelo: (d) => N.roteiroDoModelo(d.modeloId, d.briefing),
  ganchos: (d) => N.iaGanchos(d.briefing, d.modo),
  roteiro: (d) => N.iaRoteiro(d.briefing, d.gancho, d.modo),
  tudo: (d) => N.iaTudo(d.briefing, d.modo),
  previa: (d) => N.previa(d.roteiro),
  salvar: (d) => N.salvarProjeto(d.roteiro, d.nome),
  abrir: (d) => N.abrirPasta(d.pasta),
  ativar: () => N.conta.ativar(),
};

export async function abrirAssistente({ semJanela = false } = {}) {
  let chromium;
  try { ({ chromium } = await import('playwright')); } catch { ({ chromium } = await import('playwright-core')); }
  const perfil = join(N.conta.PASTA, 'janela'); mkdirSync(perfil, { recursive: true });
  const url = pathToFileURL(join(N.RAIZ, 'assistente', 'index.html')).href;
  const contexto = await chromium.launchPersistentContext(perfil, {
    headless: semJanela, viewport: semJanela ? { width: 1100, height: 780 } : null,
    args: semJanela ? [] : [`--app=${url}`, '--window-size=1100,800'],
  });
  let pagina = null;
  await contexto.exposeFunction('bwNode', async (acao, dados) => {
    try {
      if (acao === 'render') {
        const r = await N.renderizar(dados.arquivo, { rascunho: !!dados.rascunho }, (p) => { pagina?.evaluate((x) => window.bwProgresso && window.bwProgresso(x), p).catch(() => {}); });
        return { ok: true, valor: r };
      }
      if (acao === 'instalarIAs') return { ok: true, valor: await instalarRecomendadas((p) => { pagina?.evaluate((x) => window.bwInstalando && window.bwInstalando(x), p).catch(() => {}); }) };
      if (acao === 'fechar') { setTimeout(() => contexto.close().catch(() => {}), 200); return { ok: true }; }
      if (!ACOES[acao]) throw new Error('ação desconhecida: ' + acao);
      return { ok: true, valor: await ACOES[acao](dados) };
    } catch (e) { return { ok: false, erro: e.message || String(e) }; }
  });
  pagina = contexto.pages()[0] || await contexto.newPage();
  await pagina.goto(url);
  return { contexto, pagina };
}

if (!process.env.BWREELS_TESTE) {
  try {
    const { contexto } = await abrirAssistente();
    contexto.on('close', () => process.exit(0));
  } catch (e) {
    console.error('\n  Não consegui abrir a janela do assistente: ' + e.message);
    console.error('  Rode o INSTALAR.bat de novo (ele instala o navegador do motor) e tente outra vez.\n');
    process.exit(1);
  }
}
