@echo off
title BW
cd /d "%~dp0"
set "PATH=%PATH%;C:\Program Files\nodejs;%LOCALAPPDATA%\Microsoft\WinGet\Links;%APPDATA%\npm"
rem BW como PROGRAMA (Electron). Primeira vez: baixa o componente e monta o BW.exe.
if exist "programa\BW.exe" goto :abrir
if not exist "node_modules\electron\dist\electron.exe" (
  echo.
  echo  Preparando o BW novo pela primeira vez - precisa de internet, leva alguns minutos.
  echo.
  call npm install --no-audit --no-fund
)
node motor\preparar-bw.mjs
if not exist "programa\BW.exe" (echo. & echo  Nao consegui montar o BW novo. Mande um print desta janela para o Claude. & pause & exit /b 1)
:abrir
start "" "programa\BW.exe" %*
