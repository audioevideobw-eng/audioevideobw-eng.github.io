@echo off
title BW
cd /d "%~dp0"
set "PATH=%PATH%;C:\Program Files\nodejs;%LOCALAPPDATA%\Microsoft\WinGet\Links;%APPDATA%\npm"
rem BW como PROGRAMA (Electron). Primeira vez: baixa o componente e monta o BW.exe.
if exist "programa\BW.exe" goto :abrir
if not exist "node_modules\electron\dist\electron.exe" (
  echo.
  echo  Preparando o BW novo pela primeira vez - precisa de internet, leva alguns minutos.
  echo.
  if not exist "node_modules\electron\install.js" call npm install --no-audit --no-fund
  if exist "node_modules\electron\install.js" node node_modules\electron\install.js
)
if not exist "node_modules\electron\dist\electron.exe" (echo. & echo  Nao consegui baixar o componente do BW novo. Confira a internet e abra de novo. Se repetir, mande um print para o Claude. & pause & exit /b 1)
node motor\preparar-bw.mjs
if not exist "programa\BW.exe" (echo. & echo  Nao consegui montar o BW novo. Mande um print desta janela para o Claude. & pause & exit /b 1)
:abrir
start "" "programa\BW.exe" %*
