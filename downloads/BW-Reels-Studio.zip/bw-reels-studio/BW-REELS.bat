@echo off
title BW
cd /d "%~dp0"
rem Desde a 1.9.43 o BW no PC e SO o programa (BW.exe). Tira os atalhos da fase de teste.
if exist "6 - ABRIR BW NOVO (PROGRAMA).bat" del /q "6 - ABRIR BW NOVO (PROGRAMA).bat" >nul 2>nul
if exist "7 - ABRIR BW ANTIGO (EDGE).bat" del /q "7 - ABRIR BW ANTIGO (EDGE).bat" >nul 2>nul
if exist "programa\BW.exe" (start "" "programa\BW.exe" %* & exit /b 0)
set "PATH=%PATH%;C:\Program Files\nodejs;%LOCALAPPDATA%\Microsoft\WinGet\Links;%APPDATA%\npm;%USERPROFILE%\.local\bin"
rem Primeira vez (ou instalacao incompleta): instala sozinho o que falta antes de abrir.
set "FALTA="
where node >nul 2>nul || set "FALTA=1"
if not exist "node_modules\playwright-core\package.json" set "FALTA=1"
if defined FALTA (
  echo.
  echo  Preparando o BW pela primeira vez - precisa de internet, leva alguns minutos.
  echo  Nao feche esta janela.
  echo.
  call "%~dp0INSTALAR.bat" auto
  where node >nul 2>nul || (echo. & echo  O Node.js foi instalado. Feche esta janela e abra o BW de novo. & pause & exit /b 1)
  if not exist "node_modules\playwright-core\package.json" (echo. & echo  Nao consegui terminar a preparacao. Confira a internet e abra o BW de novo. & pause & exit /b 1)
)
rem Monta o programa BW (primeira vez: baixa o componente, ~110 MB, numa janela visivel).
if not exist "node_modules\electron\dist\electron.exe" if exist "node_modules\electron\install.js" start "BW - preparando o programa" /wait cmd /c "echo. & echo  Preparando o BW pela primeira vez - baixando o programa (cerca de 110 MB). & echo  Nao feche esta janela. & echo. & node node_modules\electron\install.js"
if exist "node_modules\electron\dist\electron.exe" if not exist "programa\.bw-pronto" node motor\preparar-bw.mjs --quieto
if exist "programa\BW.exe" (start "" "programa\BW.exe" %* & exit /b 0)
rem Reserva: sem o programa (sem internet na 1a vez), abre o modo de reserva para ninguem ficar sem o BW.
node motor\app.mjs %*
if errorlevel 1 pause
