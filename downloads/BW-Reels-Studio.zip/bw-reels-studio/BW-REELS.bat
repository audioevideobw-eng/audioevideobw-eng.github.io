@echo off
title BW
cd /d "%~dp0"
set "PATH=%PATH%;C:\Program Files\nodejs;%LOCALAPPDATA%\Microsoft\WinGet\Links;%APPDATA%\npm;%USERPROFILE%\.local\bin"
rem Primeira vez (ou instalacao incompleta): instala sozinho o que falta antes de abrir.
set "FALTA="
where node >nul 2>nul || set "FALTA=1"
if not exist "node_modules\playwright-core\package.json" set "FALTA=1"
if defined FALTA (
  echo.
  echo  Preparando o BW pela primeira vez - precisa de internet, leva alguns minutos.
  echo  Nao feche esta janela.
  echo.
  call "%~dp0INSTALAR.bat" auto
  where node >nul 2>nul || (echo. & echo  O Node.js foi instalado. Feche esta janela e abra o BW de novo. & pause & exit /b 1)
  if not exist "node_modules\playwright-core\package.json" (echo. & echo  Nao consegui terminar a preparacao. Confira a internet e abra o BW de novo. & pause & exit /b 1)
)
if exist "node_modules\electron\dist\electron.exe" node motor\preparar-bw.mjs --quieto
node motor\app.mjs %*
if errorlevel 1 pause
