@echo off
title BW Reels - instalar
call "%~dp0INSTALAR.bat" %*
