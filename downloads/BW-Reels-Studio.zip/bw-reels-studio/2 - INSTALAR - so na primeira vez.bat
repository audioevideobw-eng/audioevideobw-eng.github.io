@echo off
title BW - instalar
call "%~dp0INSTALAR.bat" %*
