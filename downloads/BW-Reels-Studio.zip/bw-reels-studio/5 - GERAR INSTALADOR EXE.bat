@echo off
title BW - gerar instalador
call "%~dp0GERAR-INSTALADOR.bat" %*
