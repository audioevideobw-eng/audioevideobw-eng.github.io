@echo off
title BW Reels - gerar instalador
call "%~dp0GERAR-INSTALADOR.bat" %*
