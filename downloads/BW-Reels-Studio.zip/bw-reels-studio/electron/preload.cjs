// BW (Electron) — ponte das páginas com o programa. Roda isolada (contextIsolation + sandbox): a página só enxerga a função bwNode,
// que manda o pedido ao processo principal; lá o MESMO filtro do app de sempre confere quem pediu (só as telas do BW e, da plataforma,
// a lista DO_SITE). O script naPagina (botão ⌂ BW e avisos) roda no mundo da página, igual ao addInitScript da janela antiga.
const { contextBridge, ipcRenderer, webFrame } = require('electron');
contextBridge.exposeInMainWorld('bwNode', (acao, dados) => ipcRenderer.invoke('bwNode', String(acao || ''), dados === undefined ? null : dados));
try {
  const c = ipcRenderer.sendSync('bw-pagina');
  if (c && c.src) {
    contextBridge.exposeInMainWorld('BW_APP', { versao: c.cfg.versao, janela: 'electron' });   // antes de qualquer script da página (o modos.js lê no <head>)
    webFrame.executeJavaScript('(' + c.src + ')(' + JSON.stringify(c.cfg) + ')');
  }
} catch (e) { /* página sem ponte: segue normal */ }
