// BW — o aplicativo do PC como PROGRAMA de verdade (Electron): processo e ícone "BW" na barra de tarefas e no Gerenciador de Tarefas,
// a placa de vídeo de ALTO DESEMPENHO pedida pelo próprio app, e a mesma lógica do app de sempre (motor/app.mjs → criarNucleo).
// Uso: BW.exe (ou npx electron .)   [--assistente]   ·  teste: motor/teste-electron.mjs
import { app, BrowserWindow, ipcMain, session, net, shell, nativeImage } from 'electron';
import { join, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { mkdirSync, copyFileSync, rmSync, existsSync } from 'node:fs';
import { tmpdir } from 'node:os';
import * as N from '../motor/assistente-nucleo.mjs';
import * as O from '../motor/offline.mjs';
import { criarNucleo, naPagina, SITE, VERSAO, ARGS_GPU, URL_INICIO, URL_ASSISTENTE, daPlataforma, doApp } from '../motor/app.mjs';

const RAIZ = N.RAIZ, ICONE = join(RAIZ, 'bw-reels.ico');
const TESTE = !!process.env.BWREELS_TESTE;

/* ---------- antes do app ficar pronto: nome, perfil próprio, placa de vídeo ---------- */
app.setName('BW');
if (process.platform === 'win32') app.setAppUserModelId('com.bwaudiovisual.bw');
app.setPath('userData', process.env.BWREELS_PERFIL_TESTE || join(N.conta.PASTA, 'app-electron'));
for (const a of ARGS_GPU) {
  const [k, v] = a.replace(/^--/, '').split('=');
  if (k === 'enable-features') app.commandLine.appendSwitch('enable-features', v); else app.commandLine.appendSwitch(k);
}
// O Google recusa login em "navegador embutido" quando vê "Electron" no user agent: o app se apresenta como o Chrome que ele é por dentro.
app.userAgentFallback = app.userAgentFallback.replace(/\s(Electron|BW|bw-reels-studio)\/\S+/g, '');
if (!TESTE && !app.requestSingleInstanceLock()) { app.quit(); process.exit(0); }

/* ---------- adaptadores: a janela do Electron com a "cara" da Page/Download do Playwright que o núcleo conhece ---------- */
const pgs = new WeakMap();
function pagina(wc) {
  if (pgs.has(wc)) return pgs.get(wc);
  const vivo = () => !wc.isDestroyed();
  const pg = {
    wc,
    url: () => (vivo() ? wc.getURL() : ''),
    evaluate: async (fn, arg) => { if (!vivo()) throw new Error('janela fechada'); return wc.executeJavaScript('(' + fn.toString() + ')(' + (arg === undefined ? '' : JSON.stringify(arg)) + ')', true); },
    goto: async (url) => { if (!vivo()) return; try { await wc.loadURL(url); } catch (e) { if (!/ERR_ABORTED/.test(String(e && e.message))) throw e; } },
    waitForTimeout: (ms) => new Promise((ok) => setTimeout(ok, ms)),
    waitForSelector: async (sel, o = {}) => {
      const fim = Date.now() + (o.timeout || 30000);
      while (Date.now() < fim) { if (vivo() && await wc.executeJavaScript('!!document.querySelector(' + JSON.stringify(sel) + ')').catch(() => false)) return true; await new Promise((ok) => setTimeout(ok, 200)); }
      throw new Error('tempo esgotado esperando ' + sel);
    },
  };
  pgs.set(wc, pg); return pg;
}
/* O Electron exige o lugar do arquivo NA HORA do download; o núcleo decide depois (render, Downloads…). Então o download vai para uma
   pasta temporária e o saveAs() do adaptador espera terminar e copia para onde o núcleo pediu. */
function download(item) {
  const tmp = join(tmpdir(), 'bw-dl-' + Date.now() + '-' + Math.random().toString(36).slice(2, 8));
  item.setSavePath(tmp);
  const fim = new Promise((ok) => item.once('done', (e, estado) => ok(estado)));
  return {
    suggestedFilename: () => item.getFilename(),
    cancel: async () => { try { item.cancel(); } catch (e) { /* já acabou */ } },
    saveAs: async (alvo) => {
      const estado = await fim; if (estado !== 'completed') throw new Error('download ' + estado);
      mkdirSync(dirname(alvo), { recursive: true }); copyFileSync(tmp, alvo); rmSync(tmp, { force: true });
    },
  };
}

/* ---------- janela ---------- */
let principal = null, nucleo = null;
function janela(url, extra = {}) {
  const w = new BrowserWindow({
    show: false, title: 'BW', icon: existsSync(ICONE) ? nativeImage.createFromPath(ICONE) : undefined, backgroundColor: '#05070c',
    autoHideMenuBar: true, width: 1400, height: 900, ...extra,
    webPreferences: { preload: join(dirname(fileURLToPath(import.meta.url)), 'preload.cjs'), contextIsolation: true, sandbox: true, nodeIntegration: false, spellcheck: false, backgroundThrottling: false },
  });
  w.setMenuBarVisibility(false);
  const wc = w.webContents;
  wc.on('did-finish-load', () => { if (nucleo) nucleo.aoCarregar(pagina(wc)).catch(() => {}); });
  // janelas novas: 2º monitor e popups da plataforma ficam no app; links de fora abrem no navegador padrão
  wc.setWindowOpenHandler(({ url: u }) => {
    if (u === 'about:blank' || u === '' || daPlataforma(u) || doApp(u)) return { action: 'allow', overrideBrowserWindowOptions: { autoHideMenuBar: true, icon: existsSync(ICONE) ? nativeImage.createFromPath(ICONE) : undefined, backgroundColor: '#000000' } };
    if (/^https?:/i.test(u)) shell.openExternal(u).catch(() => {});
    return { action: 'deny' };
  });
  wc.on('did-create-window', (filha) => { filha.setMenuBarVisibility(false); filha.webContents.on('did-finish-load', () => { if (nucleo) nucleo.aoCarregar(pagina(filha.webContents)).catch(() => {}); }); });
  if (!extra.semAbrir) w.loadURL(url).catch(() => {});
  w.once('ready-to-show', () => { if (!TESTE) w.maximize(); w.show(); });
  return w;
}

app.whenReady().then(async () => {
  const ses = session.defaultSession;
  const pastaCopia = process.env.BWREELS_COPIA_TESTE || O.abrirCopia(RAIZ);
  const rede = O.ligarElectron(ses, net, SITE, pastaCopia);
  // microfone (Tio Cláudio), tela cheia, 2º monitor, notificações, área de transferência: só para as telas do BW e a plataforma
  const confiavel = (u) => !!u && (daPlataforma(u) || doApp(u) || /^https:\/\/[a-z0-9-]+\.supabase\.co\//.test(u));
  const PERM = new Set(['media', 'fullscreen', 'window-management', 'notifications', 'clipboard-read', 'clipboard-sanitized-write', 'fileSystem', 'speaker-selection', 'display-capture']);
  ses.setPermissionRequestHandler((wc, perm, ok, det) => ok(PERM.has(perm) && confiavel(det.requestingUrl || wc.getURL())));
  ses.setPermissionCheckHandler((wc, perm, origem) => PERM.has(perm) && confiavel(origem || (wc && wc.getURL())));
  ses.on('will-download', (e, item, wc) => { if (nucleo && wc) nucleo.aoBaixar(pagina(wc), download(item)).catch(() => {}); });

  nucleo = criarNucleo({
    pastaCopia, rede, canal: 'electron',
    fechar: () => { for (const w of BrowserWindow.getAllWindows()) w.close(); },
    paginas: () => BrowserWindow.getAllWindows().map((w) => pagina(w.webContents)),
    relancar: () => { if (TESTE) { app.__relancou = true; return; } app.relaunch(); setTimeout(() => app.exit(0), 300); },
  });
  ipcMain.on('bw-pagina', (ev) => { ev.returnValue = { src: naPagina.toString(), cfg: { site: SITE, raiz: pathToFileURL(RAIZ).href + '/', versao: VERSAO } }; });
  ipcMain.handle('bwNode', (ev, acao, dados) => {
    const f = ev.senderFrame, wc = ev.sender;
    return nucleo.ponte(String(acao || ''), dados || {}, pagina(wc), f ? f.url : '', !!f && f === wc.mainFrame);
  });

  const inicio = process.argv.includes('--assistente') && N.conta.estado().liberado ? URL_ASSISTENTE : (process.env.BWREELS_INICIO_TESTE || URL_INICIO);
  principal = janela(inicio);
  app.on('second-instance', () => { if (principal && !principal.isDestroyed()) { if (principal.isMinimized()) principal.restore(); principal.focus(); } });
});
app.on('window-all-closed', () => { if (nucleo) nucleo.parar(); app.quit(); });
