@echo off
title BW - gerar o instalador (.exe)
cd /d "%~dp0"
echo.
echo  Gerando o instalador BW-Setup.exe ...
echo.
set "ISCC="
if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
if exist "%ProgramFiles%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles%\Inno Setup 6\ISCC.exe"
if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
if not defined ISCC (
  echo  Falta o Inno Setup ^(programa gratuito que monta instaladores^). Instalando pelo winget...
  winget install -e --id JRSoftware.InnoSetup --accept-source-agreements --accept-package-agreements
  if exist "%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe" set "ISCC=%ProgramFiles(x86)%\Inno Setup 6\ISCC.exe"
  if exist "%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe" set "ISCC=%LOCALAPPDATA%\Programs\Inno Setup 6\ISCC.exe"
)
if not defined ISCC (echo. & echo  Nao achei o Inno Setup. Baixe em jrsoftware.org/isdl.php, instale e rode este arquivo de novo. & pause & exit /b 1)

echo  [1/2] Montando a pasta limpa (sem node_modules e sem os seus projetos)...
if exist "instalador\_pacote" rmdir /s /q "instalador\_pacote"
robocopy "%~dp0." "instalador\_pacote" /E /NFL /NDL /NJH /NJS /XD node_modules instalador .git .claude atualizacao site-offline clipes-ia "IA ARQUIVOS EXE" downloads-externos /XF *.lnk *.exe *.msi .mcp.json "0 - *.bat" "5 - *.bat" "8 - *.bat" "9 - *.bat" GERAR-INSTALADOR.bat instalador.iss >nul
if errorlevel 8 (echo  ERRO ao copiar os arquivos. & pause & exit /b 1)
for /d %%D in ("instalador\_pacote\projetos\*") do (echo %%~nxD | findstr /b /i "exemplo-" >nul || rmdir /s /q "%%D")
for /d %%D in ("instalador\_pacote\projetos\*") do (if exist "%%D\render" rmdir /s /q "%%D\render")

echo  [2/2] Compilando...
attrib -h -s "instalador\_pacote\*" /s /d >nul 2>nul
"%ISCC%" /Q instalador.iss
if errorlevel 1 (echo. & echo  ERRO ao compilar. Mande um print desta janela para o Claude. & pause & exit /b 1)
rmdir /s /q "instalador\_pacote"
echo.
echo  PRONTO: instalador\BW-Setup.exe
echo  Sem assinatura digital, o Windows mostra "O Windows protegeu o computador":
echo  quem instalar clica em "Mais informacoes" e "Executar assim mesmo".
start "" "%~dp0instalador"
pause
