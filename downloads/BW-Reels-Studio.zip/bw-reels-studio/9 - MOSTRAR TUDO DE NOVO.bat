@echo off
title BW Reels - mostrar tudo
cd /d "%~dp0"
for %%F in (BW-REELS.bat BW-REELS-ASSISTENTE.bat BW-REELS-RENDER.bat INSTALAR.bat CRIAR-ATALHO.bat GERAR-INSTALADOR.bat INSTALAR-LEGENDAS.bat INSTALAR-CLAUDE-CODE.bat ATUALIZAR.bat abrir-studio.ps1 instalador.iss site-offline.zip bw-reels.ico CLAUDE.md README.md TUTORIAL.md package.json package-lock.json .gitignore .mcp.json) do if exist "%%F" attrib -h "%%F"
for %%D in (node_modules schema motor assistente app assets conhecimento modelos atualizacao site-offline .claude instalador) do if exist "%%D" attrib -h "%%D"
for %%F in ("BW Reels Assistente.lnk" "BW Reels Render.lnk" "BW Reels Studio.lnk") do if exist %%F attrib -h %%F
echo  Pronto: todos os arquivos estao a vista de novo.
pause
