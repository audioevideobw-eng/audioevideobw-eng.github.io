# Presets por nicho

Ponto de partida — ajuste com o briefing do cliente. Duração em segundos.

| Nicho | Estilo | Duração | Ritmo/cena | Gancho que mais funciona | Prova típica | Cuidado |
|---|---|---|---|---|---|---|
| Eventos corporativos (BW) | `cinema` / `corporativo` | 20–35 | 2,5–3,5 | perda/risco, bastidor | filmagem real, nº de eventos, depoimento | autorização de imagem de participantes |
| Aftermovie / highlights | `cinema` + letterbox | 30–60 | 1,5–3 (batida) | revelação de resultado | a própria filmagem | música licenciada sincronizada |
| Fotografia / ensaios | `luxo` / `editorial` | 15–30 | 3–5 | antes × depois, bastidor | fotos finais | consentimento dos fotografados |
| Educação / dicas | `editorial` | 25–45 | 3–4 | número específico, mito × verdade | dado com fonte | fontes primárias sempre |
| Produto / e-commerce | `neon` / `corporativo` | 15–30 | 2–3 | demonstração, problema → solução | uso real, avaliação real | nada de depoimento inventado |
| Imobiliário | `luxo` | 20–40 | 3–4 | tour pelo detalhe, preço/m² | filmagem, planta | dados de preço datados |
| Saúde / bem-estar | `editorial` | 30–45 | 3–4 | mito × verdade | fonte oficial/científica | sem promessa de cura; aviso "procure um profissional" |
| Gastronomia | `luxo` / `cinema` | 15–30 | 2–3 | close no preparo | o prato | — |
| Música / festas | `neon` | 15–30 | 1–2 (batida) | curiosidade visual | o momento | direitos da música |
