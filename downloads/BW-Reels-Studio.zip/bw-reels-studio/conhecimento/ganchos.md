# Banco de padrões de gancho

Use padrões **diferentes** para gerar as 10 opções. `[ ]` = preencher com algo específico e verdadeiro.

| # | Padrão | Estrutura | Exemplo (eventos corporativos) |
|---|---|---|---|
| 1 | Contradição | "[Crença comum]. Errado." | "Transmitir evento é caro. Não é mais." |
| 2 | Número específico | "[N] [coisas] que [resultado]" | "3 erros que matam a transmissão do seu evento" |
| 3 | Perda/risco | "Você está perdendo [X] por [Y]" | "Seu evento termina às 22h. O alcance dele, não." |
| 4 | Bastidor proibido | "O que ninguém mostra de [X]" | "O que acontece 2h antes do palco acender" |
| 5 | Antes × depois | "[Estado A] → [Estado B] em [tempo]" | "Do palco vazio ao ao vivo em 40 minutos" |
| 6 | Pergunta de diagnóstico | "Seu [X] tem [sintoma]?" | "Sua live trava quando mais gente entra?" |
| 7 | Prova/autoridade | "[N anos/eventos] me ensinaram [X]" | "30 eventos por ano me ensinaram isso" |
| 8 | Mito vs verdade | "Mito: [X]. Verdade: [Y]" | "Mito: celular resolve. Verdade: som resolve." |
| 9 | Lista de proibições | "Pare de [X] se você [Y]" | "Pare de gravar o evento só com uma câmera" |
| 10 | Revelação de resultado | começa pelo final impressionante | "Esse aftermovie saiu 24h depois do evento" |
| 11 | Pessoa/nicho chamado | "Se você é [público], [promessa]" | "Se você organiza eventos, salve isso" |
| 12 | Curiosidade visual | ação estranha no 1º quadro + texto curto | câmera atravessando o palco + "Olha isso" |

## Camada visual do 1º quadro (escolha uma)
Movimento de câmera rápido · close em detalhe · rosto olhando para a câmera · resultado final mostrado primeiro ·
texto gigante que preenche a tela · objeto entrando em quadro.

## Fechamentos (CTA) que puxam ação
"Comenta EVENTO que eu te mando o checklist" · "Salva pra usar no próximo evento" · "Manda pra quem organiza os eventos aí" ·
"Segue pra ver o próximo bastidor".
