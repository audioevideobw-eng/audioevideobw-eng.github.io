# Estilos visuais

Definidos em `motor/estilos.mjs`. Para criar a identidade de um cliente, copie um bloco, troque cores/fontes e dê um nome
(ex.: `golden`, `arte-eventos`). O roteiro só referencia o nome.

| Nome | Fundo | Texto | Acento | Título | Uso |
|---|---|---|---|---|---|
| `cinema` | #0b0b0c | #f3eee4 | #e8b04a dourado | Anton (caixa alta) | eventos, institucional premium |
| `corporativo` | #0a1626 | #ffffff | #3ec7f2 ciano | Inter 800 | B2B, palestras, dados |
| `neon` | #07060d | #ffffff | #ff3db8 rosa + brilho | Bebas Neue | festas, lançamentos |
| `editorial` | #f2eee6 | #141210 | #d6452b vermelho | Playfair Display | educação, dicas |
| `luxo` | #0e0d0b | #efe6d2 | #c9a96e champanhe | Cormorant Garamond | casamento, imóvel, joia |

Fontes vêm do Google Fonts (precisa de internet no render). Para render offline, instale as fontes no sistema.
