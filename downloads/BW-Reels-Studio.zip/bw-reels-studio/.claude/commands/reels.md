---
description: Cria um Reel completo — briefing, pesquisa validada, ganchos, roteiro, render e revisão
argument-hint: <tema ou ideia do vídeo> [nicho] [cliente]
---

Produza um vídeo curto sobre: $ARGUMENTS

Siga o pipeline do CLAUDE.md:
1. Crie `projetos/<slug>/` e um `briefing.md` curto (nicho, objetivo, público, CTA, material disponível). Pergunte só o que faltar
   e for decisivo — no máximo 3 perguntas, de uma vez.
2. Se o vídeo afirma fatos/dados → skill `pesquisa-validada`.
3. Skill `ganchos-virais` → mostre o top 3 e **espere a escolha**.
4. Skills `roteiro-em-cenas` + `direcao-cinematica` → `roteiro.json` (consulte `conhecimento/nichos.md`). Valide.
5. Render `--rascunho`, folha de contato com `motor/amostrar.mjs`, skill `revisao-de-qualidade`. Mostre a folha e **espere aprovação**.
6. Render final + `post.md`. Responda com o caminho do vídeo e 1 linha de resumo.
