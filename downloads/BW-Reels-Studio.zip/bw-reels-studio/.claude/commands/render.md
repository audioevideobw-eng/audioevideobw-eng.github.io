---
description: Valida e renderiza um projeto (rascunho por padrão); aceita escolher ou comparar motores
argument-hint: <slug> [final] [nativo|hyperframes|remotion|comparar]
---

Projeto e opções: $ARGUMENTS

1. `node motor/validar.mjs projetos/<slug>/roteiro.json` — corrija erros no roteiro antes de seguir.
2. Sem "final" → adicione `--rascunho`. Motor informado → `--motor <motor>`.
3. "comparar" → rascunho em `nativo` e `remotion` (e `hyperframes` se instalado), folha de contato de cada um, e diga em
   2 linhas qual ficou melhor e por quê.
4. Gere a folha de contato (`motor/amostrar.mjs`) e mostre-a.
