---
description: Transforma um vídeo longo (evento, palestra, entrevista) em 1 a 5 Reels com gancho e legenda
argument-hint: <caminho do vídeo> [quantidade] [nicho]
---

Vídeo de origem e pedido: $ARGUMENTS

1. Crie `projetos/<slug>/` e copie o vídeo para `midia/`.
2. Com o MCP Kinocut (ou ffmpeg + faster-whisper se não estiver disponível): duração, cenas, silêncios e transcrição com
   timestamps → salve em `transcricao.json`. Não leia o vídeo no contexto.
3. Escolha os trechos mais fortes (frase de impacto, emoção, revelação, dado) — 15–45 s cada — e explique a escolha em 1 linha.
4. Para cada trecho: gancho (skill `ganchos-virais`), `roteiro-<n>.json` com cenas `midia` usando `inicioNoArquivo`,
   legendas com as palavras reais (`legendas.palavras`), CTA. Render em rascunho e folha de contato.
5. Espere aprovação antes do render final.
