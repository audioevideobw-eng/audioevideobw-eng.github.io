---
description: Revisa o último render de um projeto por amostragem de quadros e aplica correções no roteiro
argument-hint: <slug>
---

Projeto: $ARGUMENTS
Use a skill `revisao-de-qualidade` no vídeo mais recente de `projetos/<slug>/render/`. Liste os problemas encontrados
(máx. 5, do mais grave ao menos grave), corrija o `roteiro.json` e pergunte se renderiza de novo.
