---
description: Gera 10 ganchos pontuados (top 3) para um tema ou para um projeto existente
argument-hint: <tema | slug do projeto>
---

Use a skill `ganchos-virais` para: $ARGUMENTS
Se for um slug existente em `projetos/`, leia `briefing.md` e `pesquisa.md` antes. Salve em `ganchos.md` e mostre só o top 3.
