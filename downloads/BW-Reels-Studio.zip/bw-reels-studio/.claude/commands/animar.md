---
description: Cria uma animação por código (personagem, mascote, logo animado, motion livre) e renderiza em vídeo
argument-hint: <o que animar> [slug]
---

Pedido: $ARGUMENTS

Carregue a skill `animacao-por-codigo` e siga a rotina dela:
1. Se dá para fazer com cena `personagem` do roteiro, faça assim (mais barato) e renderize com `motor/render.mjs`.
2. Senão: storyboard curto → copie `modelos/animacoes/personagem-bw.html` para `projetos/<slug>/` e adapte →
   `node motor/animar.mjs projetos/<slug>/<arquivo>.html --checar` → `--folha` (mostre a folha) → `--rascunho`.
3. Se for para pôr em cima de uma filmagem: `--chroma verde` (.mp4 para chroma key) ou `--alfa` (.mov transparente);
   para cartões de interface/gráficos use `modelos/animacoes/cartao-ui.html` como base.
4. Pare e mostre o rascunho antes do render final. Diga onde está o MP4 e como usá-lo no Reel (cena `midia`).
