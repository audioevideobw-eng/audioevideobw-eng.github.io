---
description: Legenda automática da fala do reel (ou de um vídeo), no próprio computador, sem internet
argument-hint: <projeto ou caminho do vídeo>
---

Alvo: $ARGUMENTS

1. Se for um projeto: `node motor/legendar.mjs projetos/<slug>/roteiro.json`. Se for um arquivo de vídeo/áudio: `node motor/legendar.mjs "<caminho>"`.
2. Se o comando disser que a legenda não está instalada, peça para a pessoa dar dois cliques em `INSTALAR-LEGENDAS.bat` (uma vez, ~500 MB) e pare.
3. Mostre em 3 linhas: quantas palavras, em quais cenas ligou o som e o começo do texto ouvido. Não cole a transcrição inteira.
4. Pergunte se há nome de pessoa ou empresa para corrigir. Para corrigir, edite só as entradas de `legendas.palavras` no roteiro (não mude os tempos).
5. Ofereça o render em rascunho (`/render <slug>`).
