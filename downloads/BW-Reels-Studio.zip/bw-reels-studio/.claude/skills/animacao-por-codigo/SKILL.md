---
name: animacao-por-codigo
description: Personagens e motions feitos por código (SVG/Canvas/HTML) e renderizados quadro a quadro — histórias com personagens, mascote, logo animado, motion livre, desenho animado curto. Use quando o pedido for personagem, mascote, desenho animado, "motion" que não cabe nos tipos de cena prontos, ou ao comparar com IA de vídeo.
---

# Animação por código (personagens e motions)

O vídeo NÃO é gerado por IA de vídeo: você escreve um programa que desenha cada quadro a partir do tempo `t`,
e o motor captura (Chromium + FFmpeg). É o mesmo método dos vídeos virais "feitos com Claude" (2026).

## 1. Escolha o caminho mais barato (tokens) que resolve
| Pedido | Caminho | Custo |
|---|---|---|
| Personagens falando em balões, acenando, comemorando (2D estilo desenho) | cena `personagem` do roteiro | mínimo: só JSON |
| Mascote/logo/motion sob medida (ex.: logo montando, vinheta, abertura) | HTML próprio + `node motor/animar.mjs` | médio |
| Desenho animado com cenário 3D, câmera se movendo, contorno de tinta | Three.js ou Remotion por código (projeto à parte) | alto — combine o escopo antes |
| Pessoa realista falando/andando | IA de vídeo (Flux personagem → Higgsfield/Kling/Veo) e montar no roteiro como `midia` | créditos da IA |

Personagem realista ainda fica melhor em IA de vídeo; por código vence em 2D estilizado, pixel art, geométrico,
infográfico, tipografia e física.

## 2. Cena `personagem` (já pronta no motor)
```json
{ "tipo": "personagem", "duracao": 5, "cenario": "palco", "entrada": "desliza",
  "elenco": [ { "personagem": "ana", "acao": "pensa" }, { "personagem": "be" } ],
  "falas": [ { "quem": 0, "texto": "E quem não puder ir?" }, { "quem": 1, "texto": "Assiste ao vivo!" } ] }
```
- Personagens prontos (19): `be` (câmera BW), `ana`, `leo`, `bia`, `rui`, `robo`, `cinegrafista`, `tecnico`, `dj`, `palestrante`,
  `executivo`, `executiva`, `noiva`, `noivo`, `fotografa`, `cliente`, `garcom`, `cachorro`, `gato` — cores trocáveis em `cores`.
- Personagem MONTADO: `{ "personagem": "meu", "nome": "Marquinhos", "look": { "bicho": "nenhum|cachorro|gato", "cabelo": "curto|longo|coque|cacheado|rabo|franja|moicano|careca",
  "barba": "nenhuma|cheia|bigode|cavanhaque", "oculos": "nenhum|redondo|quadrado|escuro", "roupa": "camiseta|social|terno|jaqueta|vestido|avental",
  "acessorio": "nenhum|headset|camera|microfone|cracha|veu", "bone": false, "cores": { "pele", "cabelo", "roupa", "calca", "sapato", "detalhe" } } }`.
- Ações: parado, acena, fala, aponta, comemora, pensa, surpresa. Sem ação + com fala = boca mexendo sozinha.
- Cenário: raios, palco, bolinhas, nenhum (usa `midia` de fundo). Entrada: pula, desliza, surge, nenhuma.
- **Personagem do próprio usuário (foto/PNG):** `{ "personagem": "foto", "imagem": "midia/avatar.png", "acao": "acena" }` —
  recorte animado (entra, quica ao falar, acena balançando, comemora pulando, pensa inclinando); `"contorno": false` tira o contorno
  branco de adesivo, `"espelhar": true` vira para o outro lado. Recorte o fundo antes (PNG transparente).
- Cena só com imagem (ex.: o personagem desenhado pela IA naquela cena): `"elenco": [], "midia": "midia/cena-1.jpg"` + `falas`.
- Atalho para 1 personagem: `"personagem": "be", "acao": "acena", "balao": "Oi!"`.
- Balão ≤ 14 palavras e ≤ 2,8 palavras/s (o validador avisa). Máximo 2 personagens por cena.
- Mini-história que prende: **problema → virada → solução → chamada**. Uma ideia por balão.
- Personagem novo: copie um bloco de `PERSONAGENS` em `motor/personagens.mjs` (cores/cabelo) e rode
  `python3 motor/gerar-motor-web.py <site>/assets/reels-motor.js` para a plataforma ter o mesmo.

## 3. Animação livre (HTML) — contrato e regras
Comece de `modelos/animacoes/personagem-bw.html` (copie para `projetos/<slug>/`).
- Defina `window.__DUR`, `window.__seek(t)` e, se carregar fontes/imagens, `window.__pronto`.
- **Cada quadro depende só de `t`.** Nada de `Math.random()` sem semente, nada de estado acumulado entre quadros,
  nada de `requestAnimationFrame`/CSS transition. Use funções de easing e `fx(t, a, b)` (progresso 0..1).
- Personagem = partes separadas (corpo, cabeça, braços com ponto de giro, olhos, pálpebra, boca) mexidas por tempo:
  respiração (seno lento), piscar em tempos fixos, boca abrindo no ritmo de sílabas enquanto fala, squash & stretch na queda.
- Elementos que mudam de opacidade: `will-change: opacity` (senão o Chromium muda o serrilhado do texto e a checagem acusa).

## 4. Rotina (sempre nesta ordem)
1. **Storyboard primeiro**: liste os planos (tempo, o que aparece, o que se mexe) em `projetos/<slug>/storyboard.md`.
   Peça referência ao usuário (link ou print) e **nomeie cada estado** do movimento — prompt vago dá animação genérica.
2. Escreva a animação. Teste: `node motor/animar.mjs arquivo.html --checar` (determinística + sem erro de JS + TEXTOS: cortado, letra pequena, contraste, área dos botões do Reels).
   Todo render termina com a CONFERÊNCIA DO VÍDEO (imagem parada, tela preta, som mudo/baixo/estourado): corrija o que vier com ✗ antes de entregar; ⚠ é para olhar.
3. **Revise vendo os próprios quadros**: `--folha` gera 12 quadros numa imagem — leia só ela (barato). Procure: braço
   descolado, texto cortado, personagem atrás de outro elemento, cor sem contraste, área segura 9:16.
4. Meça em vez de achar: se algo "parece estranho", compare números (posição, tempo, tamanho) e corrija.
5. Rascunho `--rascunho`, depois final. Para pôr EM CIMA de uma filmagem (recorte):
   - `--alfa` → .mov ProRes 4444 transparente (Premiere, DaVinci, CapCut no PC: borda perfeita, arquivo grande).
   - `--chroma verde` (ou `azul`, `magenta`, `#hex`) → .mp4 leve com fundo de chroma key (CapCut no celular, InShot,
     qualquer editor com "Chroma key"/"Remover cor"). O motor avisa se a animação usa uma cor parecida com a do fundo.
   - Nos dois modos o fundo do HTML some: marque o fundo com `data-fundo` e, se quiser, ajuste o visual com
     `html.bw-recorte` (ex.: trocar sombra larga por contorno fino — sombra larga vira mancha no chroma key).
   - Deixe a área do rosto livre (ex.: animação nos 55% de cima, como em `modelos/animacoes/cartao-ui.html`).
6. Modelos prontos: `personagem-bw.html` (mascote que fala) e `cartao-ui.html` (cartões de interface + gráfico + legenda em
   etiquetas, estilo reels de tecnologia, feito para recorte).
7. ESTÚDIO DE MOTION da plataforma (motion.html): a pessoa monta a animação escolhendo itens e efeitos, com keyframes. ⬇ HTML DA ANIMAÇÃO
   gera um arquivo que este mesmo motor renderiza (`--checar`, `--folha`, `--chroma`, `--alfa`) — use-o como ponto de partida e edite só o
   bloco de dados (`var P = {...}`): itens, tempos, efeitos e keyframes. Dentro do app BW, o botão GERAR NO APP BW já faz o vídeo sozinho.
8. Clipe pronto entra no Reel como cena `midia` (`"midia": "render/arquivo.mp4"`).
Projeto grande (vários planos): divida por ARQUIVO entre subagentes (um por plano), não só por tarefa, para um não
sobrescrever o outro; junte no fim.

## 5. Honestidade e direitos
- Só personagens originais ou do cliente. Nada de personagem famoso, mascote de outra marca ou rosto de pessoa real sem autorização.
- Vídeo com personagem de IA realista: marque "Feito com IA" ao postar.
