---
name: montagem-e-render
description: Prepara mídia (filmagens, motions de IA, música, narração, legendas por Whisper), valida e renderiza o roteiro.json em qualquer motor (nativo, HyperFrames, Remotion), incluindo edição de material bruto via FFmpeg/Kinocut. Use para montar, renderizar, comparar motores ou cortar filmagens longas em Reels.
---

# Montagem e render

## Comandos
```bash
node motor/validar.mjs projetos/<slug>/roteiro.json                    # sempre antes
node motor/render.mjs projetos/<slug>/roteiro.json --rascunho          # meia resolução, rápido
node motor/render.mjs projetos/<slug>/roteiro.json                     # final
node motor/render.mjs projetos/<slug>/roteiro.json --motor remotion    # troca de motor sem mudar o roteiro
node motor/render.mjs projetos/<slug>/roteiro.json --motor hyperframes -- <flags do CLI hyperframes>
node motor/amostrar.mjs projetos/<slug>/render/<video>.mp4             # folha de contato para revisão
```
Saída em `projetos/<slug>/render/`. O motor nativo cria proxies (todo quadro é keyframe) em `render/proxies/` — cache reaproveitado.

## Mídia
- Coloque tudo em `projetos/<slug>/midia/` e referencie com caminho relativo (`"midia/abertura.mp4"`).
- Filmagem longa: use `"inicioNoArquivo"` (segundos) em vez de cortar o arquivo — o motor corta sozinho.
- Para achar os melhores trechos de um vídeo longo (evento, palestra), use o MCP **Kinocut** (`.mcp.json`):
  inspecionar → detectar cenas/silêncios → transcrever → escolher trechos. Não abra o vídeo no contexto.
- Narração com legendas exatas: transcreva com Whisper (`faster-whisper` ou ferramenta do Kinocut) e coloque as palavras em
  `"legendas": { "palavras": [{ "palavra", "inicio", "fim" }] }`.
- Voz IA (ElevenLabs) só com voz própria/consentida; música só licenciada (`assets/musicas/`).

## Escolha do motor
| Precisa de… | Motor |
|---|---|
| Motion/texto/dados, rápido, sem instalar nada além do projeto | `nativo` |
| Recursos do ecossistema HeyGen (blocos prontos, `/media-use`, `/reverse-any-video`) | `hyperframes` |
| Componentes React/Remotion (legendas `@remotion/captions`, 3D, templates da comunidade) | `remotion` |
Comparar: rascunho do mesmo roteiro em 2 motores + `amostrar.mjs` em cada um.

## Problemas comuns
- Fonte errada no nativo: o PC precisa de internet (Google Fonts) ou instale as fontes em `assets/fontes/`.
- Vídeo travado/preto: confira o caminho e se `inicioNoArquivo + duracao` cabe no arquivo.
- HyperFrames não renderiza: `cd projetos/<slug>/hyperframes && npx hyperframes render --help` e use a skill `/hyperframes-cli`.
- Remotion na 1ª vez: o script roda `npm install` em `motor/remotion/` sozinho.
