---
name: roteiro-em-cenas
description: Transforma briefing, pesquisa e gancho escolhido no roteiro.json de cenas que os motores de vídeo renderizam (nativo, HyperFrames ou Remotion). Use para escrever ou ajustar o roteiro de qualquer vídeo deste estúdio.
---

# Roteiro em cenas (`roteiro.json`)

O roteiro é o ÚNICO arquivo que você escreve por vídeo. Contrato completo em `schema/roteiro.schema.json`;
exemplos em `projetos/exemplo-*/roteiro.json`.

## Estrutura narrativa (15–45 s)
1. **Gancho** (2,5–3 s) — cena `gancho`.
2. **Reabertura** (3–4 s) — contexto ou contradição que faz querer ver o resto.
3. **Miolo** (3–5 cenas) — prova, passos, bastidores, dado (`dado`, `lista`, `midia`, `citacao`, `texto`). Uma ideia por cena.
4. **Virada/payoff** — a entrega prometida no gancho.
5. **CTA** (3 s) — cena `cta`, uma ação só.
Ritmo: alterne cenas de texto e de imagem; varie durações (2,5 / 3,5 / 2 s…) — duração sempre igual cansa.

## Tipos de cena
| tipo | campos | uso |
|---|---|---|
| `gancho` | `texto`, `enfase[]`, `chamada?`, `midia?` | abertura |
| `texto` | `titulo`, `subtitulo?`, `enfase[]` | afirmação/virada |
| `midia` | `midia`, `inicioNoArquivo?`, `movimento?`, `texto?` | filmagem/foto com Ken Burns |
| `dado` | `valor`, `prefixo?`, `sufixo?`, `casas?`, `rotulo`, `fonte` | número animado com fonte na tela |
| `lista` | `titulo?`, `itens[]` (≤ 4) | passos/benefícios |
| `citacao` | `texto`, `autor?` | depoimento/frase |
| `cta` | `texto`, `acao` | fechamento |
Todos aceitam: `duracao` (s, obrigatório), `transicao` (`corte`, `fade`, `zoom`, `deslize`, `flash`),
`fala` (gera legenda karaokê; no gancho só aparece com `"legenda": true`), `midia` (fundo).
`movimento` de mídia: `zoom-in`, `zoom-in-suave`, `zoom-out`, `pan-esq`, `pan-dir`, `fixo`.

## Globais
`formato` (`9:16`, `4:5`, `1:1`, `16:9`), `estilo` (ver `conhecimento/estilos.md`), `motor`,
`efeitos` {`grao`, `vinheta`, `letterbox`, `barraProgresso`, `sfx`, `luz`}, `marca.handle`,
`audio` {`musica`, `narracao`, `volumeMusica`}, `legendas` {`palavrasPorPagina`, `enfase[]`, `palavras[]` (timestamps do Whisper)},
`fontes[]` {`afirmacao`, `url`, `data`}.

## Checklist antes de salvar
- Gancho ≤ 3 s e é a 1ª cena · ≤ 3 palavras/s de texto · todo número com `fonte` · caminhos de mídia relativos ao projeto
- Rode `node motor/validar.mjs projetos/<slug>/roteiro.json` e corrija erros/avisos.
