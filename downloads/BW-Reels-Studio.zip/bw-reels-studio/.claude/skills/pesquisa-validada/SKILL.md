---
name: pesquisa-validada
description: Pesquisa e checagem de fatos para roteiros de vídeo — toda afirmação ou número sai com fonte primária, data e nível de confiança. Use antes de roteirizar qualquer vídeo que afirme fatos, dados, estatísticas, notícias ou dicas técnicas.
---

# Pesquisa validada

Objetivo: o vídeo nunca afirma algo que não consiga provar. Saída: `projetos/<slug>/pesquisa.md`.

## Passos
1. **Liste as afirmações** que o vídeo precisa fazer (máx. 5–7; vídeo curto = poucas afirmações fortes).
2. **Busque cada uma separadamente** (WebSearch, consultas curtas; WebFetch na página original).
3. **Suba até a fonte primária**: órgão oficial, estudo/paper, relatório da própria empresa, IBGE, OMS, documentação oficial.
   Blog, agregador e "segundo especialistas" são pistas, não fontes.
4. **Classifique**:
   - ✅ Confirmada — fonte primária, data conhecida, número idêntico
   - ⚠️ Parcial — fonte secundária confiável ou dado antigo (> 3 anos) → diga o ano na tela ("em 2023…")
   - ❌ Descartada — sem origem, contradita, ou "estatística zumbi" que circula sem estudo
5. **Nunca invente** estudo, número, URL ou citação. Se a busca não encontrar, a afirmação sai do roteiro ou vira
   opinião/experiência do criador ("na minha experiência com 30 eventos por ano…").
6. Para saúde, finanças, direito e segurança: só fontes oficiais/científicas, sem promessas de resultado.

## Formato do `pesquisa.md`
```
## Afirmações
| # | Afirmação (como vai aparecer) | Status | Fonte (título + URL) | Data | Nota |
## Ângulos e curiosidades encontrados (matéria-prima para ganchos)
## Descartado (e por quê)
```

## Passagem para o roteiro
Cada ✅/⚠️ usado vira um item em `"fontes"` do `roteiro.json`: `{ "afirmacao", "url", "data" }`.
Número na tela = cena `dado` com `"fonte"` curta (ex.: "IBGE, 2024").
Dados internos do cliente valem como fonte: `"url": "interno: informado por <cliente>"`.

## Economia
Reaproveite `pesquisa.md` de projetos anteriores do mesmo tema antes de buscar de novo. Pare de buscar quando cada
afirmação tiver 1 fonte primária — não colecione 5 fontes para o mesmo número.
