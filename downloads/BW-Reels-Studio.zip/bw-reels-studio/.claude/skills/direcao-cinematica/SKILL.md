---
name: direcao-cinematica
description: Direção de arte e edição moderna/cinematográfica para vídeos curtos — ritmo, tipografia, cor, movimento de câmera, transições, sound design e uso de motions de IA. Use ao definir o estilo de um vídeo, escolher transições e efeitos, ou quando o resultado parece "template" e precisa ficar premium.
---

# Direção cinematográfica

## Escolha do estilo (`estilo`)
| Estilo | Quando | Sensação |
|---|---|---|
| `cinema` | eventos, bastidores, institucional premium | filme, dourado, grão |
| `corporativo` | B2B, tecnologia, dados, palestras | limpo, confiável, azul |
| `neon` | festas, música, lançamentos, público jovem | energia, brilho |
| `editorial` | educação, dicas, revista, saúde | claro, sofisticado, leitura fácil |
| `luxo` | casamentos, imóveis alto padrão, joias, gastronomia fina | serifa, calma, espaço |
Combine com a identidade do cliente (cores/fontes em `conhecimento/estilos.md` → crie preset novo em `motor/estilos.mjs` uma vez).

## Ritmo e corte
- Corte no **ritmo da fala ou da batida**; troca de cena a cada 2–4 s em vídeos de retenção, 4–6 s em `luxo`/`editorial`.
- **Transições com motivo**: `zoom` para impacto/virada, `deslize` para continuidade de raciocínio, `flash` para revelação,
  `fade` para emoção/tempo passando, `corte` seco para energia. Não use a mesma transição o vídeo inteiro.
- Imagem parada nunca fica parada: sempre `movimento` (Ken Burns). Filmagem real: `zoom-in-suave`.

## Tipografia
- 1 fonte de título + 1 de texto. Caixa alta só em títulos curtos. Destaque com cor de acento em 1–2 palavras.
- Texto em blocos de até 3 linhas; legendas de 2–3 palavras por página.

## Cor e textura
- `grao` + `vinheta` = cinema; `letterbox` em cenas de filmagem dão "cara de filme" (não use com muito texto).
- Gradação de filmagens: faça no Premiere/DaVinci **por camada de ajuste** (padrão BW) antes de trazer para cá.

## Som (metade da percepção de qualidade)
- `sfx: true` gera whoosh nas transições e impacto no gancho (sintetizados, sem direitos autorais).
- Música licenciada em `assets/musicas/`; com narração, o motor abaixa a música automaticamente (ducking).
- Comece a música já no quadro 1 e termine com fade (o motor faz).

## Motions de IA (Higgsfield, Veo/Gemini, Kling, Runway)
Use para o que a câmera não pega: logo 3D, cenografia, transição impossível, abertura. Gere o clipe → salve em
`projetos/<slug>/midia/` → use em cena `midia`. Escreva o prompt com: sujeito + ação + câmera (dolly in, orbit, crane) +
luz + lente + estilo + duração. Nunca gere pessoas reais identificáveis ou marcas de terceiros sem autorização.

## Anti-"cara de template"
Varie durações · 1 elemento de assinatura por vídeo (ex.: número gigante, frase em serifa) · menos efeitos, melhor usados ·
espaço vazio é elegância · o 1º e o último quadro são os mais caprichados.
