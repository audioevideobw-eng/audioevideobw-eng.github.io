---
name: revisao-de-qualidade
description: Revisão de qualidade de um vídeo renderizado por amostragem de quadros (barata em tokens) — gancho, legibilidade, áreas seguras, ritmo, fontes e specs de publicação, mais a legenda do post. Use depois de cada rascunho e antes de entregar ou publicar.
---

# Revisão de qualidade

1. Gere a folha de contato: `node motor/amostrar.mjs <video> --tempos 0.3,1.5,2.8,<meio>,<fim-1>` e leia a imagem.
   Para checar um momento exato, passe só esse tempo. Nunca leia o vídeo inteiro.
2. Confira com a lista abaixo e corrija **no roteiro.json** (não no motor). Re-renderize só em `--rascunho`.

## Lista
- [ ] Quadro 0,3 s já mostra movimento + texto do gancho legível
- [ ] Gancho termina até 3 s e a 2ª cena reabre a curiosidade
- [ ] Nenhum texto importante nos 11% superiores / 25% inferiores; legenda não cobre título
- [ ] Contraste: texto legível sobre filmagem (se não, use `"movimento"` mais fechado ou outra mídia)
- [ ] Toda cifra tem fonte na tela e em `"fontes"`; nada que a pesquisa marcou ❌
- [ ] Ritmo variado (durações e transições não repetitivas)
- [ ] CTA com uma ação só e @ correto
- [ ] Duração final adequada (Reels 15–45 s ideal; até 90 s)
- [ ] Áudio: música licenciada, sem estourar (o motor limita a 0,95)

## Entrega (`post.md`)
Legenda do post com: 1ª linha = gancho reescrito, 2–4 linhas de valor, CTA, 3–5 hashtags específicas do nicho,
palavras-chave pesquisáveis no texto, e a lista de fontes quando houver dados.
