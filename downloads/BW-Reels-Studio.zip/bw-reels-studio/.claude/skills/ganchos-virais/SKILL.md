---
name: ganchos-virais
description: Cria e pontua ganchos para os 3 primeiros segundos de Reels, Shorts e TikToks (texto na tela + fala + visual), sempre verdadeiros ao conteúdo. Use ao escolher a abertura de qualquer vídeo curto ou quando um vídeo tem boa ideia mas baixa retenção.
---

# Ganchos virais (honestos)

O gancho decide se o vídeo é assistido. Ele tem 3 camadas que precisam bater: **visual** (o 1º quadro),
**texto na tela** (lido sem som) e **fala** (se houver). Saída: `projetos/<slug>/ganchos.md`.

## Processo
1. Releia `briefing.md` e `pesquisa.md` — o melhor gancho sai do fato mais surpreendente ou da dor mais concreta do público.
2. Gere **10 ganchos** usando padrões diferentes de `conhecimento/ganchos.md` (não 10 variações do mesmo).
3. Pontue cada um de 1 a 5 em:
   - **Especificidade** (número, nome, situação concreta > genérico)
   - **Tensão** (lacuna de curiosidade, contradição, risco, perda)
   - **Relevância** (o público do nicho se reconhece em 1 segundo)
   - **Verdade** (o vídeo entrega exatamente o que promete) — nota < 4 aqui = descarte
   - **Brevidade** (≤ 9 palavras na tela; legível em 2,5 s)
4. Apresente o **top 3** com: texto na tela · fala · sugestão de 1º quadro · por que funciona. O usuário escolhe.

## Regras
- O 1º quadro já tem movimento ou rosto/ação — nunca tela preta, logo ou "Olá, pessoal".
- Destaque (`"enfase"`) em 1–2 palavras-chave, não mais.
- Proibido: promessa falsa, número inventado, "você não vai acreditar" sem entregar, medo/urgência fabricados.
- Depois do gancho, a 2ª cena precisa **reabrir a curiosidade** (um "mas…", uma pergunta, um número) para segurar até o fim.
- Fechamento puxa a próxima ação (seguir, salvar, comentar uma palavra, chamar no direct) — uma só.

## Formato do `ganchos.md`
```
| # | Padrão | Texto na tela | Fala | 1º quadro | Esp | Ten | Rel | Ver | Bre | Total |
## Top 3 recomendados
```
