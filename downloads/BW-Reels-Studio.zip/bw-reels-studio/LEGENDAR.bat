@echo off
title BW - Legendar
cd /d "%~dp0"
set "PATH=%PATH%;C:\Program Files\nodejs;%LOCALAPPDATA%\Microsoft\WinGet\Links;%APPDATA%\npm"
if "%~1"=="" (
  echo.
  echo   Arraste um video, um audio ou o roteiro.json de um projeto para cima deste arquivo.
  echo.
  pause
  exit /b 0
)
node motor\legendar.mjs "%~1"
echo.
pause
