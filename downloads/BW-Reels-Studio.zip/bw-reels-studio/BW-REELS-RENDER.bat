@echo off
title BW Reels Render
cd /d "%~dp0"
set "PATH=%PATH%;C:\Program Files\nodejs"
node motor\vigia-downloads.mjs %*
pause
